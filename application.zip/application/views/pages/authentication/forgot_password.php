                            <p>Masukkan alamat email yang terdaftar di sistem untuk mendapatkan tautan reset password.</p>
                            
                            <?php echo form_open('', 'class="form-auth-small"'); ?>

                                <div class="form-group">                                    
                                    <input type="email" class="form-control" id="signin-email" placeholder="Alamat email" name="email_address" required="required" autofocus="autofocus" />
                                </div>
                                <button type="submit" class="btn btn-primary btn-lg btn-block">RESET PASSWORD</button>
                                <div class="bottom">
                                    <span class="helper-text"><a href="masuk">Kembali ke halaman login</a></span>
                                </div>
                            </form>