                                                        <?php
                                                            $select_name[1] = 'division';
                                                            
                                                            $label[1] = 'Posisi yang dilamar dan pilihan waktu tes';

                                                            if(date('N') == 1)
                                                            {
                                                                $date = date_create(date('Y-m-d'));

                                                                date_add($date, date_interval_create_from_date_string('1 days'));

                                                                $tuesday_schedule = ' (Selasa, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';

                                                                date_add($date, date_interval_create_from_date_string('1 days'));

                                                                $wednesday_schedule = ' (Rabu, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';

                                                                date_add($date, date_interval_create_from_date_string('1 days'));
                                                                
                                                                $thursday_schedule = ' (Kamis, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                
                                                                date_add($date, date_interval_create_from_date_string('1 days'));
                                                                
                                                                $marketing_a = 'MARKETING (Jumat, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                $marketing_b = 'MARKETING (Jumat, '.date_format($date, 'd-m-Y').' pukul 14:00 WIB)';

                                                                if((strtotime(date("Y-m-d 10:00:00")) - strtotime(date("Y-m-d H:i:s"))) >= 3600)
                                                                    $monday_schedule = ' (Senin, '.date('d-m-Y').' pukul 10:00 WIB)';
                                                                else
                                                                {
                                                                    date_add($date, date_interval_create_from_date_string('3 days'));

                                                                    $monday_schedule = ' (Senin, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                }
                                                            }
                                                            else if(date('N') == 2)
                                                            {
                                                                $date = date_create(date('Y-m-d'));

                                                                date_add($date, date_interval_create_from_date_string('1 days'));

                                                                $wednesday_schedule = ' (Rabu, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';

                                                                date_add($date, date_interval_create_from_date_string('1 days'));
                                                                
                                                                $thursday_schedule = ' (Kamis, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                
                                                                date_add($date, date_interval_create_from_date_string('1 days'));
                                                                
                                                                $marketing_a = 'MARKETING (Jumat, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                $marketing_b = 'MARKETING (Jumat, '.date_format($date, 'd-m-Y').' pukul 14:00 WIB)';
                                                                
                                                                date_add($date, date_interval_create_from_date_string('3 days'));

                                                                $monday_schedule = ' (Senin, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';

                                                                if((strtotime(date("Y-m-d 10:00:00")) - strtotime(date("Y-m-d H:i:s"))) >= 3600)
                                                                    $tuesday_schedule = ' (Selasa, '.date('d-m-Y').' pukul 10:00 WIB)';
                                                                else
                                                                {
                                                                    date_add($date, date_interval_create_from_date_string('1 days'));

                                                                    $tuesday_schedule = ' (Selasa, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                }
                                                            }
                                                            else if(date('N') == 3)
                                                            {
                                                                $date = date_create(date('Y-m-d'));

                                                                date_add($date, date_interval_create_from_date_string('1 days'));
                                                                
                                                                $thursday_schedule = ' (Kamis, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                
                                                                date_add($date, date_interval_create_from_date_string('1 days'));
                                                                
                                                                $marketing_a = 'MARKETING (Jumat, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                $marketing_b = 'MARKETING (Jumat, '.date_format($date, 'd-m-Y').' pukul 14:00 WIB)';

                                                                date_add($date, date_interval_create_from_date_string('3 days'));

                                                                $monday_schedule = ' (Senin, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                
                                                                date_add($date, date_interval_create_from_date_string('1 days'));

                                                                $tuesday_schedule = ' (Selasa, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';

                                                                if((strtotime(date("Y-m-d 10:00:00")) - strtotime(date("Y-m-d H:i:s"))) >= 3600)
                                                                    $wednesday_schedule = ' (Rabu, '.date('d-m-Y').' pukul 10:00 WIB)';
                                                                else
                                                                {
                                                                    date_add($date, date_interval_create_from_date_string('1 days'));

                                                                    $wednesday_schedule = ' (Rabu, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                }
                                                            }
                                                            else if(date('N') == 4)
                                                            {
                                                                $date = date_create(date('Y-m-d'));

                                                                date_add($date, date_interval_create_from_date_string('1 days'));
                                                                
                                                                $marketing_a = 'MARKETING (Jumat, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                $marketing_b = 'MARKETING (Jumat, '.date_format($date, 'd-m-Y').' pukul 14:00 WIB)';

                                                                date_add($date, date_interval_create_from_date_string('3 days'));

                                                                $monday_schedule = ' (Senin, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                
                                                                date_add($date, date_interval_create_from_date_string('1 days'));

                                                                $tuesday_schedule = ' (Selasa, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                
                                                                date_add($date, date_interval_create_from_date_string('1 days'));

                                                                $wednesday_schedule = ' (Rabu, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';

                                                                if((strtotime(date("Y-m-d 21:20:00")) - strtotime(date("Y-m-d H:i:s"))) >= 3600)
                                                                    $thursday_schedule = ' (Kamis, '.date('d-m-Y').' pukul 10:00 WIB)';
                                                                else
                                                                {
                                                                    date_add($date, date_interval_create_from_date_string('1 days'));
                                                                
                                                                    $thursday_schedule = ' (Kamis, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                }
                                                            }
                                                            else if(date('N') == 5)
                                                            {
                                                                $date = date_create(date('Y-m-d'));
                                                                
                                                                date_add($date, date_interval_create_from_date_string('3 days'));

                                                                $monday_schedule = ' (Senin, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                
                                                                date_add($date, date_interval_create_from_date_string('1 days'));

                                                                $tuesday_schedule = ' (Selasa, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';

                                                                date_add($date, date_interval_create_from_date_string('1 days'));

                                                                $wednesday_schedule = ' (Rabu, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';

                                                                date_add($date, date_interval_create_from_date_string('1 days'));
                                                                
                                                                $thursday_schedule = ' (Kamis, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';

                                                                date_add($date, date_interval_create_from_date_string('1 days'));
                                                                
                                                                if((strtotime(date("Y-m-d 10:00:00")) - strtotime(date("Y-m-d H:i:s"))) >= 3600)
                                                                    $marketing_a = 'MARKETING (Jumat, '.date('d-m-Y').' pukul 10:00 WIB)';
                                                                else
                                                                    $marketing_a = 'MARKETING (Jumat, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';

                                                                if((strtotime(date("Y-m-d 14:00:00")) - strtotime(date("Y-m-d H:i:s"))) >= 3600)
                                                                    $marketing_b = 'MARKETING (Jumat '.date('d-m-Y').' pukul 14:00 WIB)';
                                                                else
                                                                    $marketing_b = 'MARKETING (Jumat, '.date_format($date, 'd-m-Y').' pukul 14:00 WIB)';
                                                            }
                                                            else
                                                            {
                                                                $date = date_create(date('Y-m-d'));
                                                                
                                                                if(date('N') == 6)
                                                                    date_add($date, date_interval_create_from_date_string('2 days'));
                                                                else
                                                                    date_add($date, date_interval_create_from_date_string('1 days'));

                                                                $monday_schedule = ' (Senin, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                
                                                                date_add($date, date_interval_create_from_date_string('1 days'));

                                                                $tuesday_schedule = ' (Selasa, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';

                                                                date_add($date, date_interval_create_from_date_string('1 days'));

                                                                $wednesday_schedule = ' (Rabu, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                
                                                                date_add($date, date_interval_create_from_date_string('1 days'));
                                                                
                                                                $thursday_schedule = ' (Kamis, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                
                                                                date_add($date, date_interval_create_from_date_string('1 days'));
                                                                
                                                                $marketing_a = 'MARKETING (Jumat, '.date_format($date, 'd-m-Y').' pukul 10:00 WIB)';
                                                                $marketing_b = 'MARKETING (Jumat, '.date_format($date, 'd-m-Y').' pukul 14:00 WIB)';
                                                            }

                                                            $options[1] = array(
                                                                'DRIVER'.$monday_schedule => 'DRIVER'.$monday_schedule,
                                                                'OFFICE BOY'.$monday_schedule => 'OFFICE BOY'.$monday_schedule,
                                                                'VIDEOGRAFER'.$monday_schedule => 'VIDEOGRAFER'.$monday_schedule,
                                                                'CUSTOMER SERVICE'.$tuesday_schedule => 'CUSTOMER SERVICE'.$tuesday_schedule,
                                                                'HRD'.$tuesday_schedule => 'HRD'.$tuesday_schedule,
                                                                'RND'.$tuesday_schedule => 'RND'.$tuesday_schedule,
                                                                'IT'.$wednesday_schedule => 'IT'.$wednesday_schedule,
                                                                'CONTENT WRITER'.$wednesday_schedule => 'CONTENT WRITER'.$wednesday_schedule,
                                                                'FINANCE'.$thursday_schedule => 'FINANCE'.$thursday_schedule,
                                                                'LOGISTIK'.$thursday_schedule => 'LOGISTIK'.$thursday_schedule,
                                                                $marketing_a => $marketing_a,
                                                                $marketing_b => $marketing_b,
                                                                'INSTRUKTUR' => 'INSTRUKTUR'
                                                            );

                                                            $value[1] = $division_schedule;

                                                            for($select_counter = 1; $select_counter < 2; $select_counter++)
                                                            {
                                                                echo form_label($label[$select_counter], $select_name[$select_counter], 'class="control-label"');
                                                                echo form_dropdown($select_name[$select_counter], $options[$select_counter], $value[$select_counter], 'class="form-control" id="division-select"');
                                                            }
                                                        ?>