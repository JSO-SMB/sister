            <div id="main-content" class="profilepage_1">
                <div class="container">
                    <div class="block-header">
                        <div class="row">
                            <div class="col-lg-5 col-md-8 col-sm-12">                        
                                <h2><?php echo $header; ?></h2>
                                <!--<ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>
                                    <li class="breadcrumb-item">Pages</li>
                                    <li class="breadcrumb-item active">User Profile</li>
                                </ul>-->
                            </div>            
                            <!--<div class="col-lg-7 col-md-4 col-sm-12 text-right">
                                <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                    <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#00c5dc"
                                        data-fill-Color="transparent">3,5,1,6,5,4,8,3</div>
                                    <span>Visitors</span>
                                </div>
                                <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                    <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#f4516c"
                                        data-fill-Color="transparent">4,6,3,2,5,6,5,4</div>
                                    <span>Visits</span>
                                </div>
                            </div>-->
                        </div>
                    </div>

                    <div class="row clearfix">
                        <div class="col-lg-12">
                            <div class="card">
                                
                                <?php
                                    //$hidden = array('user_id' => $user_id);

                                    echo form_open('', 'id="it-form" onsubmit="return validateSubmission()"');//, $hidden);

                                        for($subheader_counter = 1; $subheader_counter < 29; $subheader_counter++)
                                        {
                                            $attributes[$subheader_counter] = ' class="body"';
                                            
                                            if($subheader_counter < 2)
                                                $subheader[$subheader_counter] = 'Kepemilikan';
                                            else if($subheader_counter > 1 && $subheader_counter < 7)
                                            {
                                                if($subheader_counter == 2)
                                                    $subheader[$subheader_counter] = 'General';
                                                else if($subheader_counter == 4)
                                                    $subheader[$subheader_counter] = 'Space';
                                                else if($subheader_counter == 5)
                                                    $subheader[$subheader_counter] = 'cPanel';
                                                else if($subheader_counter == 6)
                                                    $subheader[$subheader_counter] = 'FTP';
                                                else
                                                    $subheader[$subheader_counter] = '';
                                                
                                                $attributes[$subheader_counter] = ' class="body hosting"';

                                                if($type == 'Hosting')
                                                    $attributes[$subheader_counter] = $attributes[$subheader_counter].' style="display: block;"';
                                                else
                                                    $attributes[$subheader_counter] = $attributes[$subheader_counter].' style="display: none;"';
                                            }
                                            else if($subheader_counter > 6 && $subheader_counter < 23)
                                            {
                                                if($subheader_counter == 7)
                                                    $subheader[$subheader_counter] = 'General';
                                                else if($subheader_counter == 9)
                                                    $subheader[$subheader_counter] = 'Akun Live Chat';
                                                else if($subheader_counter == 10)
                                                    $subheader[$subheader_counter] = 'Harga';
                                                else if($subheader_counter == 11)
                                                    $subheader[$subheader_counter] = 'Pos';
                                                else if($subheader_counter == 13)
                                                    $subheader[$subheader_counter] = 'Wordpress';
                                                else if($subheader_counter == 14)
                                                    $subheader[$subheader_counter] = 'Registrant';
                                                else if($subheader_counter == 15)
                                                    $subheader[$subheader_counter] = 'Contact Person 1';
                                                else if($subheader_counter == 16)
                                                    $subheader[$subheader_counter] = 'Contact Person 2';
                                                else if($subheader_counter == 17)
                                                    $subheader[$subheader_counter] = 'Contact Person 3';
                                                else if($subheader_counter == 18)
                                                    $subheader[$subheader_counter] = 'Contact Person 4';
                                                else if($subheader_counter == 19)
                                                    $subheader[$subheader_counter] = 'Contact Person 5';
                                                else if($subheader_counter == 20)
                                                    $subheader[$subheader_counter] = 'Contact Person 6';
                                                else if($subheader_counter == 21)
                                                    $subheader[$subheader_counter] = 'Additional Information';
                                                else
                                                    $subheader[$subheader_counter] = '';
                                                
                                                $attributes[$subheader_counter] = ' class="body domain"';

                                                if($type == 'Domain')
                                                    $attributes[$subheader_counter] = $attributes[$subheader_counter].' style="display: block;"';
                                                else
                                                    $attributes[$subheader_counter] = $attributes[$subheader_counter].' style="display: none;"';
                                            }
                                            else if($subheader_counter > 22 && $subheader_counter < 25)
                                            {
                                                if($subheader_counter == 23)
                                                {
                                                    $subheader[$subheader_counter] = 'Data email';
                                                    $attributes[$subheader_counter] = $attributes[$subheader_counter].' id="email-div"';
                                                }
                                                else
                                                    $subheader[$subheader_counter] = '';

                                                if($type == 'email')
                                                    $attributes[$subheader_counter] = $attributes[$subheader_counter].' style="display: block;"';
                                                else
                                                    $attributes[$subheader_counter] = $attributes[$subheader_counter].' style="display: none;"';
                                            }
                                            else if($subheader_counter > 24 && $subheader_counter < 27)
                                            {
                                                if($subheader_counter == 25)
                                                {
                                                    $subheader[$subheader_counter] = 'Data Nomor HP/Telepon';
                                                    $attributes[$subheader_counter] = $attributes[$subheader_counter].' id="mobile-number-div"';
                                                }
                                                else
                                                    $subheader[$subheader_counter] = '';

                                                if($type == 'Nomor HP/Telepon')
                                                    $attributes[$subheader_counter] = $attributes[$subheader_counter].' style="display: block;"';
                                                else
                                                    $attributes[$subheader_counter] = $attributes[$subheader_counter].' style="display: none;"';
                                            }
                                            else
                                            {
                                                if($subheader_counter == 27)
                                                {
                                                    $subheader[$subheader_counter] = 'Data Akun Media Sosial';
                                                    $attributes[$subheader_counter] = $attributes[$subheader_counter].' id="social-media-div"';
                                                }
                                                else
                                                    $subheader[$subheader_counter] = '';

                                                if($type == 'Akun Medsos dll.')
                                                    $attributes[$subheader_counter] = $attributes[$subheader_counter].' style="display: block;"';
                                                else
                                                    $attributes[$subheader_counter] = $attributes[$subheader_counter].' style="display: none;"';
                                            }
                                        }
                                        
                                        $label[1][1] = 'Pemilik Unit';
                                        $label[1][2] = 'Jenis Data';
                                        $label[2][1] = 'Nama Hosting';
                                        $label[2][2] = 'Penyedia Jasa Hosting';
                                        $label[2][3] = 'Tanggal Beli';
                                        $label[2][4] = 'Jatuh Tempo';
                                        $label[3][1] = 'Harga Perpanjangan Per Tahun';
                                        $label[3][2] = 'Sub Domain';
                                        $label[3][3] = 'Tanggal Terakhir di Update';
                                        $label[3][4] = '';
                                        $label[4][1] = 'Total';
                                        $label[4][2] = 'Terpakai';
                                        $label[4][3] = 'Sisa';
                                        $label[5][1] = 'Username';
                                        $label[5][2] = 'URL';
                                        $label[5][3] = 'Password';
                                        $label[6][1] = 'Username';
                                        $label[6][2] = 'Password';
                                        $label[7][1] = 'Nama Domain';
                                        $label[7][2] = 'Hosting';
                                        $label[7][3] = 'Penyedia Jasa Domain';
                                        $label[7][4] = 'EPP Code';
                                        $label[8][1] = 'Tanggal Beli';
                                        $label[8][2] = 'Jatuh Tempo';
                                        $label[8][3] = 'Nama Backlink di Widget';
                                        $label[8][4] = 'Webmaster Tools';
                                        $label[9][1] = 'Username';
                                        $label[9][2] = 'Email';
                                        $label[9][3] = 'Password';
                                        $label[10][1] = 'Perpanjangan Per Tahun';
                                        $label[10][2] = 'Privacy Who is';
                                        $label[10][3] = 'SSL';
                                        $label[10][4] = 'Total';
                                        $label[11][1] = 'Draft';
                                        $label[11][2] = 'Published';
                                        $label[11][3] = 'Scheduled';
                                        $label[12][1] = 'Total Post';
                                        $label[12][2] = 'Tanggal published terakhir';
                                        $label[12][3] = '';
                                        $label[13][1] = 'Username wp-admin';
                                        $label[13][2] = 'URL wp-admin';
                                        $label[13][3] = 'Pass wp-admin';
                                        $label[13][4] = 'Nama Template';
                                        $label[14][1] = 'Nama Registran';
                                        $label[14][2] = 'Email yang didaftarkan';
                                        $label[14][3] = 'No Telp yang didaftarkan';
                                        $label[15][1] = 'Nama';
                                        $label[15][2] = 'No HP';
                                        $label[15][3] = 'Email';
                                        $label[16][1] = 'Nama';
                                        $label[16][2] = 'No HP';
                                        $label[16][3] = 'Email';
                                        $label[17][1] = 'Nama';
                                        $label[17][2] = 'No HP';
                                        $label[17][3] = 'Email';
                                        $label[18][1] = 'Nama';
                                        $label[18][2] = 'No HP';
                                        $label[18][3] = 'Email';
                                        $label[19][1] = 'Nama';
                                        $label[19][2] = 'No HP';
                                        $label[19][3] = 'Email';
                                        $label[20][1] = 'Nama';
                                        $label[20][2] = 'No HP';
                                        $label[20][3] = 'Email';
                                        $label[21][1] = 'Unit';
                                        $label[21][2] = 'Alamat';
                                        $label[21][3] = 'No. Telp';
                                        $label[21][4] = 'email';
                                        $label[22][1] = 'Manager';
                                        $label[22][2] = 'Market';
                                        $label[22][3] = 'Direktur';
                                        $label[22][4] = '';
                                        $label[23][1] = 'Nama Akun';
                                        $label[23][2] = 'Nama User';
                                        $label[23][3] = 'Password Email';
                                        $label[23][4] = 'No HP yang didaftarkan';
                                        $label[24][1] = 'Keterangan';
                                        $label[24][2] = 'Divisi';
                                        $label[24][3] = 'Tanggal Pembuatan';
                                        $label[24][4] = 'Karyawan yang menjadi PIC';
                                        $label[25][1] = 'Nomor';
                                        $label[25][2] = 'Inventaris yang digunakan';
                                        $label[25][3] = 'Pendaftaran SIM CARD';
                                        $label[26][1] = 'Status';
                                        $label[26][2] = 'Karyawan yang menjadi PIC';
                                        $label[26][3] = '';
                                        $label[27][1] = 'Nama Sosmed / Portal';
                                        $label[27][2] = 'Nama Akun';
                                        $label[27][3] = 'Link';
                                        $label[27][4] = 'Email yang didaftarkan';
                                        $label[28][1] = 'Nama User';
                                        $label[28][2] = 'Password';
                                        $label[28][3] = 'Tanggal Pembuatan';
                                        $label[28][4] = 'Karyawan yang menjadi PIC';

                                        $select_name[1][1] = 'unit_id';
                                        $select_name[1][2] = 'type';
                                        $input_name[2][1] = 'data_name';
                                        $select_name[2][2] = 'vendor_id';
                                        $input_name[2][3] = 'purchase_date';
                                        $input_name[3][1] = 'annual_renewal_price';
                                        $select_name[3][2] = 'domain_it_data_id[]';
                                        $input_name[3][3] = 'last_update_date';
                                        $input_name[4][1] = 'space_total';
                                        $input_name[4][2] = 'space_used';
                                        $input_name[5][1] = 'cpanel_username';
                                        $input_name[5][2] = 'cpanel_url';
                                        $input_name[5][3] = 'cpanel_password';
                                        $input_name[6][1] = 'ftp_username';
                                        $input_name[6][2] = 'ftp_password';
                                        $input_name[7][1] = 'data_name';
                                        $select_name[7][2] = 'hosting_it_data_id';
                                        $select_name[7][3] = 'vendor_id';
                                        $input_name[7][4] = 'epp_code';
                                        $input_name[8][1] = 'purchase_date';
                                        $input_name[8][3] = 'widget_backlink_text';
                                        $select_name[8][4] = 'webmaster_tools_email_address_it_data_id';
                                        $input_name[9][1] = 'live_chat_username';
                                        $input_name[9][2] = 'live_chat_email_address';
                                        $input_name[9][3] = 'live_chat_password';
                                        $input_name[10][1] = 'annual_renewal_price';
                                        $input_name[10][2] = 'whois_privacy_price';
                                        $input_name[10][3] = 'ssl_certificate_price';
                                        $input_name[11][1] = 'post_draft';
                                        $input_name[11][2] = 'post_published';
                                        $input_name[11][3] = 'post_scheduled';
                                        $input_name[12][2] = 'post_last_publish_date';
                                        $input_name[13][1] = 'wp_username';
                                        $input_name[13][2] = 'wp_admin_url';
                                        $input_name[13][3] = 'wp_password';
                                        $input_name[13][4] = 'wp_theme';
                                        $input_name[14][1] = 'registrant_name';
                                        $input_name[14][2] = 'registrant_email_address';
                                        $input_name[14][3] = 'registrant_phone_number';
                                        $select_name[15][1] = 'cp_a_user_id';
                                        $select_name[15][2] = 'cp_a_mobile_number_it_data_id';
                                        $select_name[15][3] = 'cp_a_email_address_it_data_id';
                                        $select_name[16][1] = 'cp_b_user_id';
                                        $select_name[16][2] = 'cp_b_mobile_number_it_data_id';
                                        $select_name[16][3] = 'cp_b_email_address_it_data_id';
                                        $select_name[17][1] = 'cp_c_user_id';
                                        $select_name[17][2] = 'cp_c_mobile_number_it_data_id';
                                        $select_name[17][3] = 'cp_c_email_address_it_data_id';
                                        $select_name[18][1] = 'cp_d_user_id';
                                        $select_name[18][2] = 'cp_d_mobile_number_it_data_id';
                                        $select_name[18][3] = 'cp_d_email_address_it_data_id';
                                        $select_name[19][1] = 'cp_e_user_id';
                                        $select_name[19][2] = 'cp_e_mobile_number_it_data_id';
                                        $select_name[19][3] = 'cp_e_email_address_it_data_id';
                                        $select_name[20][1] = 'cp_f_user_id';
                                        $select_name[20][2] = 'cp_f_mobile_number_it_data_id';
                                        $select_name[20][3] = 'cp_f_email_address_it_data_id';
                                        $select_name[22][1] = 'manager_user_id';
                                        $input_name[23][1] = 'data_name';
                                        $input_name[23][2] = 'email_username';
                                        $input_name[23][3] = 'email_password';
                                        $select_name[23][4] = 'email_mobile_number_it_data_id';
                                        $textarea_name[24][1] = 'email_notes';
                                        $select_name[24][2] = 'division';
                                        $input_name[24][3] = 'creation_date';
                                        $select_name[24][4] = 'pic_user_id';
                                        $input_name[25][1] = 'mobile_number';
                                        $select_name[25][2] = 'inventory_id';
                                        $input_name[25][3] = 'registration';
                                        $input_name[26][1] = 'status';
                                        $select_name[26][2] = 'pic_user_id';
                                        $select_name[27][1] = 'social_media_name';
                                        $input_name[27][2] = 'data_name';
                                        $input_name[27][3] = 'social_media_link';
                                        $select_name[27][4] = 'social_media_email_address_it_data_id';
                                        $input_name[28][1] = 'account_username';
                                        $input_name[28][2] = 'account_password';
                                        $input_name[28][3] = 'creation_date';
                                        $select_name[28][4] = 'pic_user_id';

                                        $options[1][1] = $units;
                                        $options[1][2] = $types;
                                        $options[2][2] = $it_vendors;
                                        $options[3][2] = $domains;
                                        $options[7][2] = $hostings;
                                        $options[7][3] = $it_vendors;
                                        $options[8][4] = $email_addresses;
                                        $options[15][1] = $marketings;
                                        $options[15][2] = $mobile_numbers;
                                        $options[15][3] = $email_addresses;
                                        $options[16][1] = $marketings;
                                        $options[16][2] = $mobile_numbers;
                                        $options[16][3] = $email_addresses;
                                        $options[17][1] = $marketings;
                                        $options[17][2] = $mobile_numbers;
                                        $options[17][3] = $email_addresses;
                                        $options[18][1] = $marketings;
                                        $options[18][2] = $mobile_numbers;
                                        $options[18][3] = $email_addresses;
                                        $options[19][1] = $marketings;
                                        $options[19][2] = $mobile_numbers;
                                        $options[19][3] = $email_addresses;
                                        $options[20][1] = $marketings;
                                        $options[20][2] = $mobile_numbers;
                                        $options[20][3] = $email_addresses;
                                        $options[22][1] = $managers;
                                        $options[23][4] = $mobile_numbers;
                                        $options[24][2] = $divisions;
                                        $options[24][4] = $active_employees;
                                        $options[25][2] = $handphones;
                                        $options[26][2] = $active_employees;
                                        $options[27][1] = $social_medias;
                                        $options[27][4] = $email_addresses;
                                        $options[28][4] = $active_employees;
                                        
                                        $value[1][1][1] = $unit_id;
                                        $value[1][2][1] = $type;
                                        $value[2][1][1] = $data_name;
                                        $value[2][2][1] = $vendor_id;
                                        $value[2][3][1] = $purchase_date;
                                        $value[3][1][1] = $annual_renewal_price;
                                        $value[3][2][1] = $domain_it_data_id;
                                        $value[3][3][1] = $last_update_date;
                                        $value[4][1][1] = $space_total;
                                        $value[4][2][1] = $space_used;
                                        $value[5][1][1] = $cpanel_username;
                                        $value[5][2][1] = $cpanel_url;
                                        $value[5][3][1] = $cpanel_password;
                                        $value[6][1][1] = $ftp_username;
                                        $value[6][2][1] = $ftp_password;
                                        $value[7][1][1] = $data_name;
                                        $value[7][2][1] = $hosting_it_data_id;
                                        $value[7][3][1] = $vendor_id;
                                        $value[7][4][1] = $epp_code;
                                        $value[8][1][1] = $purchase_date;
                                        $value[8][3][1] = $widget_backlink_text;
                                        $value[8][4][1] = $webmaster_tools_email_address_it_data_id;
                                        $value[9][1][1] = $live_chat_username;
                                        $value[9][2][1] = $live_chat_email_address;
                                        $value[9][3][1] = $live_chat_password;
                                        $value[10][1][1] = $annual_renewal_price;
                                        $value[10][2][1] = $whois_privacy_price;
                                        $value[10][3][1] = $ssl_certificate_price;
                                        $value[11][1][1] = $post_draft;
                                        $value[11][2][1] = $post_published;
                                        $value[11][3][1] = $post_scheduled;
                                        $value[12][2][1] = $post_last_publish_date;
                                        $value[13][1][1] = $wp_username;
                                        $value[13][2][1] = $wp_admin_url;
                                        $value[13][3][1] = $wp_password;
                                        $value[13][4][1] = $wp_theme;
                                        $value[14][1][1] = $registrant_name;
                                        $value[14][2][1] = $registrant_email_address;
                                        $value[14][3][1] = $registrant_phone_number;
                                        $value[15][1][1] = $cp_a_user_id;
                                        $value[15][2][1] = $cp_a_mobile_number_it_data_id;
                                        $value[15][3][1] = $cp_a_email_address_it_data_id;
                                        $value[16][1][1] = $cp_b_user_id;
                                        $value[16][2][1] = $cp_b_mobile_number_it_data_id;
                                        $value[16][3][1] = $cp_b_email_address_it_data_id;
                                        $value[17][1][1] = $cp_c_user_id;
                                        $value[17][2][1] = $cp_c_mobile_number_it_data_id;
                                        $value[17][3][1] = $cp_c_email_address_it_data_id;
                                        $value[18][1][1] = $cp_d_user_id;
                                        $value[18][2][1] = $cp_d_mobile_number_it_data_id;
                                        $value[18][3][1] = $cp_d_email_address_it_data_id;
                                        $value[19][1][1] = $cp_e_user_id;
                                        $value[19][2][1] = $cp_e_mobile_number_it_data_id;
                                        $value[19][3][1] = $cp_e_email_address_it_data_id;
                                        $value[20][1][1] = $cp_f_user_id;
                                        $value[20][2][1] = $cp_f_mobile_number_it_data_id;
                                        $value[20][3][1] = $cp_f_email_address_it_data_id;
                                        $value[22][1][1] = $manager_user_id;
                                        $value[23][1][1] = $data_name;
                                        $value[23][2][1] = $email_username;
                                        $value[23][3][1] = $email_password;
                                        $value[23][4][1] = $email_mobile_number_it_data_id;
                                        $value[24][1][1] = $email_notes;
                                        $value[24][2][1] = $division;
                                        $value[24][3][1] = $creation_date;
                                        $value[24][4][1] = $pic_user_id;
                                        $value[25][1][1] = $mobile_number;
                                        $value[25][2][1] = $inventory_id;
                                        $value[25][3][1] = $registration;
                                        $value[26][1][1] = 'Aktif';
                                        $value[26][1][2] = 'Tidak Aktif';
                                        $value[26][2][1] = $pic_user_id;
                                        $value[27][1][1] = $social_media_name;
                                        $value[27][2][1] = $data_name;
                                        $value[27][3][1] = $social_media_link;
                                        $value[27][4][1] = $social_media_email_address_it_data_id;
                                        $value[28][1][1] = $account_username;
                                        $value[28][2][1] = $account_password;
                                        $value[28][3][1] = $creation_date;
                                        $value[28][4][1] = $pic_user_id;

                                        $id[2][1] = 'hosting-data-name-input';
                                        $id[2][3] = 'hosting-purchase-date-input';
                                        $id[2][4] = 'hosting-due-date-input';
                                        $id[3][1] = 'hosting-annual-renewal-price-input';
                                        $id[3][2] = 'domain-it-data-id-select';
                                        $id[4][1] = 'space-total-input';
                                        $id[4][2] = 'space-used-input';
                                        $id[4][3] = 'space-remaining-input';
                                        $id[7][1] = 'domain-name-data-name-input';
                                        $id[7][2] = 'hosting-it-data-id-select';
                                        $id[8][1] = 'domain-name-purchase-date-input';
                                        $id[8][2] = 'domain-name-due-date-input';
                                        $id[8][4] = 'webmaster-tools-email-address-it-data-id-select';
                                        $id[10][1] = 'domain-name-annual-renewal-price-input';
                                        $id[10][2] = 'whois-privacy-price-input';
                                        $id[10][3] = 'ssl-certificate-price-input';
                                        $id[10][4] = 'total-price-input';
                                        $id[11][1] = 'post-draft-input';
                                        $id[11][2] = 'post-published-input';
                                        $id[11][3] = 'post-scheduled-input';
                                        $id[12][1] = 'post-total-input';
                                        $id[15][1] = 'cp-a-user-id-select';
                                        $id[15][2] = 'cp-a-mobile-number-it-data-id-select';
                                        $id[15][3] = 'cp-a-email-address-it-data-id-select';
                                        $id[16][1] = 'cp-b-user-id-select';
                                        $id[16][2] = 'cp-b-mobile-number-it-data-id-select';
                                        $id[16][3] = 'cp-b-email-address-it-data-id-select';
                                        $id[17][1] = 'cp-c-user-id-select';
                                        $id[17][2] = 'cp-c-mobile-number-it-data-id-select';
                                        $id[17][3] = 'cp-c-email-address-it-data-id-select';
                                        $id[18][1] = 'cp-d-user-id-select';
                                        $id[18][2] = 'cp-d-mobile-number-it-data-id-select';
                                        $id[18][3] = 'cp-d-email-address-it-data-id-select';
                                        $id[19][1] = 'cp-e-user-id-select';
                                        $id[19][2] = 'cp-e-mobile-number-it-data-id-select';
                                        $id[19][3] = 'cp-e-email-address-it-data-id-select';
                                        $id[20][1] = 'cp-f-user-id-select';
                                        $id[20][2] = 'cp-f-mobile-number-it-data-id-select';
                                        $id[20][3] = 'cp-f-email-address-it-data-id-select';
                                        $id[21][1] = 'unit-input';
                                        $id[21][2] = 'address-textarea';
                                        $id[21][3] = 'additional-information-phone-number-input';
                                        $id[21][4] = 'additional-information-email-address-input';
                                        $id[22][1] = 'manager-user-id-select';
                                        $id[22][2] = 'additional-information-market-input';
                                        $id[22][3] = 'additional-information-director-input';
                                        $id[23][1] = 'email-data-name-input';
                                        $id[23][2] = 'email-username-input';
                                        $id[23][4] = 'email-mobile-number-it-data-id-select';
                                        $id[24][3] = 'email-creation-date-input';
                                        $id[24][4] = 'email-pic-user-id-select';
                                        $id[25][1] = 'mobile-number-input';
                                        $id[25][2] = 'inventory-id-select';
                                        $id[26][2] = 'mobile-number-pic-user-id-select';
                                        $id[27][2] = 'social-media-data-name-input';
                                        $id[27][3] = 'social-media-link-input';
                                        $id[27][4] = 'social-media-email-address-it-data-id-select';
                                        $id[28][3] = 'social-media-creation-date-input';
                                        $id[28][4] = 'social-media-pic-user-id-select';

                                        $span_id[2][1] = 'hosting-span';
                                        $span_id[7][1] = 'domain-span';
                                        $span_id[23][2] = 'email-span';
                                        $span_id[25][1] = 'mobile-number-span';
                                        $span_id[27][3] = 'social-media-span';

                                        for($subheader_counter = 1; $subheader_counter < 29; $subheader_counter++)
                                        {
                                            if($subheader[$subheader_counter] != '')
                                            {
                                    ?>

                                                <div<?php echo $attributes[$subheader_counter]; ?>>
                                                    <h6><?php echo $subheader[$subheader_counter]; ?></h6>
                                        
                                    <?php
                                            }
                                    ?>

                                            <div class="row clearfix">
                                                
                                                <?php
                                                    if($subheader_counter < 2 || $subheader_counter == 6)
                                                        $label_count = 2;
                                                    else if(($subheader_counter > 1 && $subheader_counter < 4) || ($subheader_counter > 6 && $subheader_counter < 9) || $subheader_counter == 10 || $subheader_counter == 13 || ($subheader_counter > 20 && $subheader_counter < 25) || $subheader_counter > 26)
                                                        $label_count = 4;
                                                    else
                                                        $label_count = 3;
                                                    
                                                    for($label_counter = 1; $label_counter <= $label_count; $label_counter++)
                                                    {
                                                        if($label[$subheader_counter][$label_counter] != '')
                                                        {
                                                ?>
                                                            
                                                            <div class="col-lg-<?php if($label_count == 2) echo '6'; else if($label_count == 3) echo '4'; else echo '3'; ?> col-md-12">
                                                                <div class="form-group">
                                                
                                                                    <?php
                                                                        echo form_label($label[$subheader_counter][$label_counter], '', 'class="control-label"');

                                                                        if($subheader_counter < 2 || ($subheader_counter == 2 && $label_counter == 2) || ($subheader_counter == 7 && ($label_counter == 2 || $label_counter == 3)) || ($subheader_counter == 8 && $label_counter > 3) || ($subheader_counter > 14 && $subheader_counter < 21) || ($subheader_counter == 22 && $label_counter < 2) || ($subheader_counter == 23 && $label_counter > 3) || ($subheader_counter == 24 && ($label_counter == 2 || $label_counter > 3)) || (($subheader_counter == 25 || $subheader_counter == 26) && $label_counter == 2) || ($subheader_counter == 27 && ($label_counter < 2 || $label_counter > 3)) || ($subheader_counter > 27 && $label_counter > 3))
                                                                        {
                                                                            $extra = 'class="form-control"';

                                                                            if($subheader_counter < 2)
                                                                            {
                                                                                if($label_counter < 2)
                                                                                    $extra = $extra.' id="unit-id-select" onchange="setUnitRelatedOptions('."'".$unit_related_option_retrieve_link."', this.value)".'"';
                                                                                else
                                                                                    $extra = $extra.' id="type-select" onchange="hideShowTypicalDiv(this.value)"';
                                                                            }
                                                                            else if(($subheader_counter == 2 && $label_counter == 2) || ($subheader_counter == 7 && $label_counter == 3))
                                                                            {
                                                                                if($subheader_counter < 7)
                                                                                    $extra = $extra.' id="hosting-vendor-id-select"';
                                                                                else
                                                                                    $extra = $extra.' id="domain-name-vendor-id-select"';
                                                                                
                                                                                $extra = $extra.' onchange="setVendor(this.value)"';
                                                                            }
                                                                            else if($subheader_counter == 7 && $label_counter == 2)
                                                                                $extra = 'class="form-control hosting-select"';
                                                                            else if(($subheader_counter == 8 && $label_counter > 3) || ($subheader_counter > 14 && $subheader_counter < 21 && $label_counter > 2) || ($subheader_counter == 27 && $label_counter > 3))
                                                                                $extra = 'class="form-control email-address-select"';
                                                                            else if($subheader_counter > 14 && $subheader_counter < 21 && $label_counter < 2)
                                                                                $extra = 'class="form-control marketing-select"';
                                                                            else if(($subheader_counter > 14 && $subheader_counter < 21 && $label_counter == 2) || ($subheader_counter == 23 && $label_counter > 3))
                                                                                $extra = 'class="form-control mobile-number-select"';
                                                                            else if($subheader_counter == 22 && $label_counter < 2)
                                                                                $extra = 'class="form-control manager-select"';
                                                                            else if(($subheader_counter == 24 && $label_counter > 3) || ($subheader_counter == 26 && $label_counter == 2) || ($subheader_counter > 27 && $label_counter > 3))
                                                                            {
                                                                                if($subheader_counter == 24)
                                                                                    $extra = 'id="email-pic-user-id-select"';
                                                                                else if($subheader_counter == 26)
                                                                                    $extra = 'id="mobile-number-pic-user-id-select"';
                                                                                else
                                                                                    $extra = 'id="social-media-pic-user-id-select"';
                                                                                
                                                                                $extra = $extra.' class="form-control pic-select" onchange="setPIC()"';
                                                                            }

                                                                            echo form_dropdown($select_name[$subheader_counter][$label_counter], $options[$subheader_counter][$label_counter], $value[$subheader_counter][$label_counter][1], $extra);
                                                                        }
                                                                        else if($subheader_counter == 3 && $label_counter == 2)
                                                                            echo '<br />'.form_multiselect($select_name[$subheader_counter][$label_counter], $options[$subheader_counter][$label_counter], $value[$subheader_counter][$label_counter][1], 'id="multiselect2" class="multiselect multiselect-custom"');
                                                                        else
                                                                        {
                                                                            if($subheader_counter == 26 && $label_counter < 2)
                                                                            {
                                                                                $value_count = 2;
                                                                    ?>
                                                                                
                                                                                <div class="fancy-radio">
                                                                    
                                                                        <?php
                                                                            }
                                                                            else
                                                                            {
                                                                                $value_count = 1;

                                                                                if(($subheader_counter == 2 && $label_counter > 2) || ($subheader_counter == 3 && $label_counter != 2) || $subheader_counter == 4 || ($subheader_counter == 8 && $label_counter < 3) || $subheader_counter == 10 || ($subheader_counter == 12 && $label_counter > 1) || (($subheader_counter == 24 || $subheader_counter == 28) && $label_counter == 3))
                                                                                {
                                                                    ?>
                                                                                    
                                                                                    <div class="input-group mb-3">

                                                                                        <?php
                                                                                            if(!($subheader_counter == 4))
                                                                                            {
                                                                                        ?>
                                                                                                
                                                                                                <div class="input-group-prepend">
                                                                                                    <span class="input-group-text">

                                                                                                        <?php
                                                                                                            if(($subheader_counter == 2 && $label_counter > 2) || ($subheader_counter == 3 && $label_counter > 2) || ($subheader_counter == 8 && $label_counter < 3) || ($subheader_counter == 12 && $label_counter > 1) || (($subheader_counter == 24 || $subheader_counter == 28) && $label_counter == 3))
                                                                                                            {
                                                                                                        ?>
                                                                                                                
                                                                                                                <i class="icon-calendar"></i>
                                                                                                        
                                                                                                        <?php
                                                                                                            }
                                                                                                            else
                                                                                                                echo 'Rp.';
                                                                                                        ?>
                                                                                                    
                                                                                                    </span>
                                                                                                </div>
                                                                                        
                                                                        <?php
                                                                                            }
                                                                                }
                                                                            }
                                                                            
                                                                            for($value_counter = 1; $value_counter <= $value_count; $value_counter++)
                                                                            {
                                                                                $data = array(
                                                                                        'class'	    => 'form-control'
                                                                                );
                                                                                
                                                                                if((($subheader_counter == 2 || $subheader_counter == 7 || $subheader_counter == 23) && $label_counter < 2) || ($subheader_counter == 27 && $label_counter == 2))
                                                                                {
                                                                                    $data['class'] = $data['class'].' data-name';
                                                                                    $data['onchange'] = 'setDataName()';
                                                                                }
                                                                                else if(($subheader_counter == 3 && $label_counter < 2) || $subheader_counter == 10)
                                                                                    $data['class'] = $data['class'].' currency';

                                                                                if(($type == 'Hosting' && $subheader_counter == 2 && $label_counter < 2) || ($subheader_counter == 5 && $label_counter == 2) || ($type == 'Domain' && $subheader_counter == 7 && $label_counter < 2) || ($subheader_counter == 13 && $label_counter == 2) || ($subheader_counter == 27 && $label_counter == 3))
                                                                                    $data['type'] = 'url';
                                                                                else if(($subheader_counter == 2 && $label_counter > 2) || ($subheader_counter == 3 && $label_counter > 2) || ($subheader_counter == 8 && $label_counter < 3) || ($subheader_counter == 12 && $label_counter > 1) || (($subheader_counter == 24 || $subheader_counter == 28) && $label_counter == 3))
                                                                                {
                                                                                    $data['type'] = 'date';

                                                                                    if(($subheader_counter == 2 && $label_counter == 3) || ($subheader_counter == 8 && $label_counter < 2))
                                                                                        $data['onchange'] = 'setPurchaseDueDate(this.value)';
                                                                                    else if(($subheader_counter == 24 || $subheader_counter == 28) && $label_counter == 3)
                                                                                        $data['onchange'] = 'setCreationDate(this.value)';
                                                                                }
                                                                                else if((($subheader_counter == 9 || $subheader_counter == 14) && $label_counter == 2) || ($subheader_counter == 21 && $label_counter > 3) || ($subheader_counter == 23 && $label_counter == 2))
                                                                                    $data['type'] = 'email';
                                                                                else if($subheader_counter == 4 || $subheader_counter == 11 || ($subheader_counter == 12 && $label_counter < 2))
                                                                                {
                                                                                    $data['type'] = 'number';

                                                                                    if($subheader_counter < 11 && $label_counter < 3)
                                                                                        $data['onchange'] = 'calculateSpaceRemaining()';
                                                                                    else if($subheader_counter == 11)
                                                                                        $data['onchange'] = 'calculatePostTotal()';
                                                                                }
                                                                                else if((($subheader_counter == 14 || $subheader_counter == 21) && $label_counter == 3) || ($subheader_counter == 25 && $label_counter < 2))
                                                                                {
                                                                                    $data['type'] = 'tel';
                                                                                    $data['pattern'] = '\d+';
                                                                                }

                                                                                if(($subheader_counter == 2 && $label_counter > 3) || ($subheader_counter == 4 && $label_counter == 3) || ($subheader_counter == 8 && $label_counter == 2) || ($subheader_counter == 10 && $label_counter > 3) || ($subheader_counter == 12 && $label_counter < 2) || $subheader_counter == 21 || ($subheader_counter == 22 && $label_counter > 1))
                                                                                    $data['disabled'] = 'disabled';
                                                                                else
                                                                                {
                                                                                    if($subheader_counter == 24 && $label_counter < 2)
                                                                                        $data['name'] = $textarea_name[$subheader_counter][$label_counter];
                                                                                    else
                                                                                        $data['name'] = $input_name[$subheader_counter][$label_counter];
                                                                                    
                                                                                    $data['value'] = $value[$subheader_counter][$label_counter][$value_counter];
                                                                                }
                                                                                
                                                                                if($subheader_counter < 2 || ($subheader_counter == 2 && $label_counter != 2) || ($subheader_counter == 3 && $label_counter < 2) || $subheader_counter == 4 || ($subheader_counter == 7 && $label_counter < 3) || ($subheader_counter == 8 && $label_counter < 3) || $subheader_counter == 10 || $subheader_counter == 11 || ($subheader_counter == 12 && $label_counter < 2) || ($subheader_counter > 14 && $subheader_counter < 23) || ($subheader_counter == 23 && $label_counter != 3) || ($subheader_counter == 24 && $label_counter > 2) || ($subheader_counter == 25 && $label_counter < 3) || ($subheader_counter == 26 && $label_counter == 2) || ($subheader_counter == 27 && $label_counter > 1) || ($subheader_counter > 27 && $label_counter > 2))
                                                                                    $data['id'] = $id[$subheader_counter][$label_counter];
                                                                                
                                                                                if($subheader_counter == 3 && $label_counter == 3)
                                                                                    $data['readonly'] = 'readonly';

                                                                                //if(($subheader_counter == 1 && ($label_counter == 1 || ($header == 'Form Pendaftaran Vendor' && $label_counter > 1))) || $subheader_counter == 2 || $subheader_counter == 3 || ($type == 'Hotel' && (($subheader_counter == 4 && $label_counter < 4) || ($subheader_counter == 5 && ($label_counter == 2 || $label_counter == 3)))) || $subheader_counter == 6 || ($header == 'Form Pendaftaran Vendor' && $subheader_counter == 7 && ($label_counter == 1 || ($type == 'Hotel' && $label_counter == 2))))
                                                                                //    $data['required'] = 'required';
                                                                                
                                                                                if((($subheader_counter == 2 || $subheader_counter == 7) && $label_counter < 2) || ($subheader_counter == 23 && $label_counter == 2) || ($subheader_counter == 25 && $label_counter < 2) || ($subheader_counter == 27 && $label_counter == 3))
                                                                                {
                                                                                    if($subheader_counter == 2 || $subheader_counter == 7)
                                                                                        $account = $data_name;
                                                                                    else if($subheader_counter == 23)
                                                                                        $account = $email_username;
                                                                                    else if($subheader_counter == 25)
                                                                                        $account = $mobile_number;
                                                                                    else
                                                                                        $account = $social_media_link;
                                                                                    
                                                                                    $data['onfocusout'] = "checkAccount('".$account_check_link."', '".$account."', this.value);";
                                                                                    $data['oninput'] = $data['onfocusout'];
                                                                                    $data['onmouseout'] = $data['onfocusout'];
                                                                                }
                                                                                else if(($subheader_counter == 3 && $label_counter < 2) || ($subheader_counter == 10 && $label_counter < 4))
                                                                                {
                                                                                    $data['onchange'] = '';

                                                                                    if(($subheader_counter == 3 || $subheader_counter == 10) && $label_counter < 2)
                                                                                        $data['onchange'] = 'setAnnualRenewalPrice(this.value);';
                                                                                    
                                                                                    if($subheader_counter == 10 && $label_counter < 4)
                                                                                        $data['onchange'] = $data['onchange'].'calculateTotalPrice();';
                                                                                }

                                                                                if(($subheader_counter == 21 && $label_counter == 2) || ($subheader_counter == 24 && $label_counter < 2))
                                                                                {
                                                                                    $data['rows'] = 2;

                                                                                    echo form_textarea($data);
                                                                                }
                                                                                else if($subheader_counter == 26 && $label_counter < 2)
                                                                                {
                                                                                    if($status == $value[$subheader_counter][$label_counter][$value_counter])
                                                                                        $data['checked'] = TRUE;
                                                                                    else
                                                                                        $data['checked'] = FALSE;
                                                                        ?>
                                                                                    
                                                                                    <label class="fancy-radio custom-color-green"><?php echo form_radio($data); ?><span><i></i><?php echo $value[$subheader_counter][$label_counter][$value_counter]; ?></span></label>
                                                                            
                                                                            <?php
                                                                                }
                                                                                else
                                                                                    echo form_input($data);
                                                                                
                                                                                if(($subheader_counter == 14 && $label_counter == 3) || ($subheader_counter == 25 && $label_counter < 2))
                                                                                {
                                                                            ?>

                                                                                    <span class="help-block">Isikan dengan awalan kode negara, misal 62xxx</span>
                                                                            
                                                                            <?php
                                                                                }

                                                                                if((($subheader_counter == 2 || $subheader_counter == 7) && $label_counter < 2) || ($subheader_counter == 23 && $label_counter == 2) || ($subheader_counter == 25 && $label_counter < 2) || ($subheader_counter == 27 && $label_counter == 3))
                                                                                {
                                                                                    if($subheader_counter == 25)
                                                                                    {
                                                                            ?>

                                                                                        <br />
                                                                                
                                                                                <?php
                                                                                    }
                                                                                ?>

                                                                                    <span class="help-block" id="<?php echo $span_id[$subheader_counter][$label_counter]; ?>" style="color: red;display: none;">* Akun tersebut sudah terdaftar di database SISTER.</span>
                                                                        
                                                                        <?php
                                                                                }
                                                                            }

                                                                            if(($subheader_counter == 2 && $label_counter > 2) || ($subheader_counter == 3 && $label_counter != 2) || $subheader_counter == 4 || ($subheader_counter == 8 && $label_counter < 3) || $subheader_counter == 10 || ($subheader_counter == 12 && $label_counter > 1) || ($subheader_counter == 24 && $label_counter == 3) || ($subheader_counter == 26 && $label_counter < 2) || ($subheader_counter == 28 && $label_counter == 3))
                                                                            {
                                                                                if(($subheader_counter == 3 && $label_counter < 2) || $subheader_counter == 4 || $subheader_counter == 10)
                                                                                {
                                                                                    if($subheader_counter == 4)
                                                                                        $text = 'GB';
                                                                                    else
                                                                                        $text = ',00';
                                                                        ?>

                                                                                    <div class="input-group-append">
                                                                                        <span class="input-group-text"><?php echo $text; ?></span>
                                                                                    </div>
                                                                            
                                                                            <?php
                                                                                }
                                                                            ?>
                                                                                
                                                                                </div>
                                                                        
                                                                    <?php
                                                                            }
                                                                        }
                                                                    ?>

                                                                </div>
                                                            </div>
                                            
                                                <?php
                                                        }
                                                    }
                                                ?>
                                            
                                            </div>
                                        
                                        <?php
                                            if($subheader_counter < 2 || ($subheader_counter > 2 && $subheader_counter < 7) || ($subheader_counter > 7 && $subheader_counter < 11) || ($subheader_counter > 11 && $subheader_counter < 21) || $subheader_counter == 22 || $subheader_counter == 24 || $subheader_counter == 26 || $subheader_counter > 27)
                                            {
                                                if($subheader_counter < 2 || ($subheader_counter > 2 && $subheader_counter < 6) || ($subheader_counter > 7 && $subheader_counter < 11) || ($subheader_counter > 11 && $subheader_counter < 21))
                                                {
                                        ?>

                                                    <hr style="height: 2px;border-width: 0;background-color: gray;" />
                                        
                                            <?php
                                                }
                                            ?>

                                                </div>
                                    
                                    <?php       
                                            }
                                        }
                                    ?>

                                    <div class="body">
                                        
                                        <?php
                                            $data = array(
                                                    'name'          => 'submit',
                                                    'value'         => 'dikirim',
                                                    'type'          => 'submit',
                                                    'class'         => 'btn btn-primary',
                                                    'content'       => 'Kirim'
                                            );

                                            echo form_button($data);
                                        ?>
                                    
                                    </div>
                                
                                <?php echo form_close(); ?>
                            
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>