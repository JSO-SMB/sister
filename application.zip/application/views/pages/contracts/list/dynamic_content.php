                                            <?php
                                                $counter = 0;

                                                foreach($users_contracts as &$user_contract)
                                                {
                                                    $counter++;
                                            ?>
                                                    
                                                    <tr>
                                                        <th scope="row"><?php echo ((5 * ($page_number - 1)) + $counter); ?></th>
                                                        <td><?php echo $user_contract['employee_name']; ?></td>
                                                        <td><?php echo $user_contract['user_status']; ?></td>
                                                        <td><?php echo $user_contract['division']; ?></td>
                                                        <td><?php echo $user_contract['position']; ?></td>
                                                        <td><?php echo substr($user_contract['expiry_date'], -2).'-'.substr($user_contract['expiry_date'], 5, 2).'-'.substr($user_contract['expiry_date'], 0, 4); ?></td>
                                                        <td><?php echo $user_contract['unit_name']; ?></td>
                                                        <td><a href="<?php echo base_url('kontrak/tambah_ubah/'.$user_contract['contract_id']); ?>" class="btn btn-success btn-sm">Lihat Detail</a></td>
                                                    </tr>
                                            
                                            <?php
                                                }
                                            ?>