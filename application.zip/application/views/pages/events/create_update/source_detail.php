                                                                        <?php
                                                                            echo form_label($label_text, 'source-detail-input', 'class="control-label"');
                                                                            
                                                                            if($source == 'Website')
                                                                                echo form_dropdown('source_detail', $websites , $selected, 'class="form-control"');
                                                                            else
                                                                            {   
                                                                                $data = array(
                                                                                        'name'			=> 'source_detail',
                                                                                        'class'			=> 'form-control',
                                                                                        'id'            => 'source-detail-input'
                                                                                );

                                                                                if($source == 'Referensi')
                                                                                    $data['required'] = 'required';
                                                                                
                                                                                echo form_input($data);
                                                                            }
                                                                        ?>