                                <div class="body">
                                    <div class="row clearfix">
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Nama unit', 'unit-id-select', 'class="control-label"');

                                                    $attributes = array(
                                                            'class'     => 'form-control',
                                                            'id'        => 'unit-id-select',
                                                            'onchange'  => 'setStaffField(this.value)'
                                                    );
                                                    
                                                    echo form_dropdown('unit_id', $units, $unit_id, $attributes);
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Nama Staff Marketing', 'marketing-user-id-select', 'class="control-label"');

                                                    $attributes = array(
                                                            'class' => 'form-control',
                                                            'id'    => 'marketing-user-id-select'
                                                    );
                                                    
                                                    echo form_dropdown('marketing_user_id', $staffs, $marketing_user_id, $attributes);
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Nama Manajer Marketing', 'manager-user-id-select', 'class="control-label"');

                                                    $attributes = array(
                                                            'class' => 'form-control',
                                                            'id'    => 'manager-user-id-select'
                                                    );
                                                    
                                                    echo form_dropdown('manager_user_id', $managers, $manager_user_id, $attributes);
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Bulan & tahun', 'start-date-input', 'class="control-label"');

                                                    $attributes = array(
                                                            'class' => 'form-control',
                                                            'id'    => 'start-date-input',
                                                            'name'  => 'start_date',
                                                            'type'  => 'month',
                                                            'value' => $start_date
                                                    );
                                                    
                                                    echo form_input($attributes);
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <!--<div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Status', 'project-status-select', 'class="control-label"');

                                                    $event_statuses = array(
                                                        ''              => 'Semua Status',
                                                        'Lunas'         => 'Lunas',
                                                        'Piutang'       => 'Piutang',
                                                        'Belum Running' => 'Belum Running',
                                                        'Sudah Running' => 'Sudah Running'
                                                    );

                                                    $attributes = array(
                                                            'class' => 'form-control',
                                                            'id'    => 'project-status-select'
                                                    );
                                                    
                                                    echo form_dropdown('project_status', $event_statuses, $event_status, $attributes);
                                                ?>
                                            
                                            </div>
                                        </div>-->
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Urutkan berdasarkan', 'ordering-select', 'class="control-label"');

                                                    $ordering_options = array(
                                                        'DESC' => 'Tanggal mulai kegiatan terkini',
                                                        'ASC' => 'Tanggal mulai kegiatan terlama',
                                                    );

                                                    echo form_dropdown('ordering', $ordering_options , $ordering, 'class="form-control" id="ordering-select"');
                                                ?>
                                            
                                            </div>
                                        </div>
                                    </div>

                                    <?php echo form_button('', 'Cari', 'class="btn btn-primary" id="search-button" onclick="getDynamicContent(1)"'); ?>
                                
                                </div>

                                <div class="body table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>KODE EVENT</th>
                                                <th>PENDAPATAN</th>
                                                <th>PROSENTASE PROFIT</th>
                                                <th>BUKTI TRANSFER</th>
                                                <th>OPERASI</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php
                                                $counter = 0;

                                                foreach($events as &$event)
                                                {
                                                    $counter++;
                                            ?>
                                                    
                                                    <tr>
                                                        <th scope="row" style="vertical-align: middle;"><?php echo ((5 * ($page_number - 1)) + $counter); ?></th>
                                                        <td><?php echo $event['event_name'].' ('.substr($event['start_date'], -2).'/'.substr($event['start_date'], 5, 2).'/'.substr($event['start_date'], 0, 4).' - '.substr($event['end_date'], -2).'/'.substr($event['end_date'], 5, 2).'/'.substr($event['end_date'], 0, 4).') '.$event['unit_name'].' by '.$event['marketing_name']; ?></td>
                                                        <td><?php echo 'Rp'.number_format($event['revenue'], 0, ",", ".").',00'; ?></td>
                                                        <td>
                                                            
                                                            <?php
                                                                $profit_percentage = 0;
                                                                
                                                                if($event['revenue'] > 0)
                                                                    $profit_percentage = ($event['profit_loss'] / $event['revenue']) * 100;
                                                                
                                                                echo $profit_percentage.'%';
                                                            ?>
                                                        
                                                        </td>
                                                        <td>
                                                            
                                                            <?php
                                                                $event_payment_counter = 1;
                                                                
                                                                foreach($event['event_payments'] as $event_payment)
                                                                {
                                                                    if($event_payment_counter > 1)
                                                                        echo '<br />';
                                                                    
                                                                    echo '<a href="'.base_url('uploads/events/payments/'.$event['event_id'].'/'.$event_payment['proof_of_payment']).'" target="_blank">Bukti Transfer '.$event_payment_counter.'</a>';

                                                                    $event_payment_counter++;
                                                                }
                                                            ?>
                                                        
                                                        </td>
                                                        <td style="text-align: center;">
                                                            <a class="btn btn-primary btn-sm" href="<?php echo base_url('kegiatan/remunerasi/'.$event['event_id'].'?revenue='.$event['revenue'].'&profit_percentage='.urlencode($profit_percentage)); ?>" target="_blank">Remunerasi</a>
                                                        </td>
                                                    </tr>
                                            
                                            <?php
                                                }
                                            ?>
                                        
                                        </tbody>
                                    </table>
                                </div>
                                
                                <?php
                                    if($page_count > 1)
                                    {
                                ?>
                                        
                                        <ul class="body pagination pagination-primary">
                                        
                                            <?php
                                                if($page_number > 1)
                                                {
                                            ?>
                                                    
                                                    <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo ($page_number - 1); ?>)">Sebelumnya</a></li>
                                            
                                            <?php
                                                    for($page_counter = $previous_page_count; $page_counter > 0; $page_counter--)
                                                    {
                                                        $previous_page_number = $page_number - $page_counter;
                                            ?>

                                                            <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo $previous_page_number; ?>)"><?php echo $previous_page_number; ?></a></li>
                                            
                                            <?php
                                                    }
                                                }

                                                if($page_count > 1)
                                                {
                                            ?>
                                                    
                                                    <li class="page-item active"><a class="page-link" href="javascript:void(0);"><?php echo $page_number; ?></a></li>
                                            
                                            <?php
                                                    if($page_count > $page_number)
                                                    {
                                                        for($page_counter = 1; $page_counter <= $next_page_count; $page_counter++)
                                                        {
                                                            $next_page_number = $page_number + $page_counter;
                                            ?>

                                                            <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo $next_page_number; ?>)"><?php echo $next_page_number; ?></a></li>
                                            
                                            <?php
                                                        }
                                            ?>

                                                        <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo ($page_number + 1); ?>)">Selanjutnya</a></li>
                                            
                                            <?php
                                                    }
                                                }
                                            ?>
                                        
                                        </ul>
                                
                                <?php
                                    }
                                ?>