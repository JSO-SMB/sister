            <div id="main-content">
                <div class="container">
                    <div class="block-header">
                        <div class="row">
                            <div class="col-lg-12 col-md-8 col-sm-12">
                                <h2>Remunerasi Event <?php echo $remuneration['event_name'].' ('.substr($remuneration['start_date'], -2).'/'.substr($remuneration['start_date'], 5, 2).'/'.substr($remuneration['start_date'], 0, 4).' - '.substr($remuneration['end_date'], -2).'/'.substr($remuneration['end_date'], 5, 2).'/'.substr($remuneration['end_date'], 0, 4).') '.$remuneration['unit_name'].' by '.$remuneration['marketing_name']; ?></h2>
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>"><i class="icon-home"></i></a></li>
                                    <li class="breadcrumb-item">Karyawan</li>
                                    <li class="breadcrumb-item active">
                                        <a href="javascript:void(0);">Data Event</a>
                                    </li>
                                </ul>
                            </div>            
                            <!--<div class="col-lg-7 col-md-4 col-sm-12 text-right">
                                <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                    <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#00c5dc"
                                        data-fill-Color="transparent">3,5,1,6,5,4,8,3</div>
                                    <span>Visitors</span>
                                </div>
                                <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                    <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#f4516c"
                                        data-fill-Color="transparent">4,6,3,2,5,6,5,4</div>
                                    <span>Visits</span>
                                </div>
                            </div>-->
                        </div>
                    </div>
                    
                    <div class="row clearfix">
                        <div class="col-lg-12">
                            <div class="card" id="card">
                                <div class="body table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr><td>#</td><td>Jenis Fee</td><td>Nominal</td><td>Pembayaran</td></tr>
                                        </thead>
                                        <tbody>
                                            <tr><td>1</td><td>Fee Marketing 1</td><td><?php echo 'Rp'.number_format(($remuneration['staff_monthly_fee'] * $revenue), 0, ",", ".").',00'; ?></td><td><?php if($remuneration['staff_monthly_fee_payment'] == 'Sudah dibayarkan') echo 'V'; else echo '-'; ?></td></tr>
                                            <tr><td>2</td><td>Fee Marketing 2</td><td><?php echo 'Rp'.number_format(($remuneration['staff_quarterly_fee'] * $revenue), 0, ",", ".").',00'; ?></td><td><?php if($remuneration['staff_quarterly_fee_payment'] == 'Sudah dibayarkan') echo 'V'; else echo '-'; ?></td></tr>
                                            <tr><td>3</td><td>Fee Marketing 3</td><td><?php echo 'Rp'.number_format(($remuneration['staff_annual_fee'] * $revenue), 0, ",", ".").',00'; ?></td><td><?php if($remuneration['staff_annual_fee_payment'] == 'Sudah dibayarkan') echo 'V'; else echo '-'; ?></td></tr>
                                            <tr><td>4</td><td>Fee Manajer 1</td><td><?php echo 'Rp'.number_format(($remuneration['manager_monthly_fee'] * $revenue), 0, ",", ".").',00'; ?></td><td><?php if($remuneration['manager_monthly_fee_payment'] == 'Sudah dibayarkan') echo 'V'; else echo '-'; ?></td></tr>
                                            <tr><td>5</td><td>Fee Manajer 2</td><td><?php echo 'Rp'.number_format(($remuneration['manager_quarterly_fee'] * $revenue), 0, ",", ".").',00'; ?></td><td><?php if($remuneration['manager_quarterly_fee_payment'] == 'Sudah dibayarkan') echo 'V'; else echo '-'; ?></td></tr>
                                            <tr><td>6</td><td>Fee Manajer 3</td><td><?php echo 'Rp'.number_format(($remuneration['manager_annual_fee'] * $revenue), 0, ",", ".").',00'; ?></td><td><?php if($remuneration['manager_annual_fee_payment'] == 'Sudah dibayarkan') echo 'V'; else echo '-'; ?></td></tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>