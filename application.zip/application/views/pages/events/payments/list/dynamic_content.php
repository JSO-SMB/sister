                                <div class="body">
                                    <div class="row clearfix">
                                        <div class="col-lg-6 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Filter berdasarkan', 'filter-column-select', 'class="control-label"');
                                                    echo form_dropdown('filter_column', $filter_columns , $filter_column, 'class="form-control" id="filter-column-select" onchange="setFilterValue(this.value)"');
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label($label, '', 'class="control-label" id="filter-value-label"');

                                                    $attributes = array(
                                                            'class' => 'form-control',
                                                            'id'    => 'filter-value-select'
                                                    );

                                                    if($filter_column == 'events.unit_id,where' || $filter_column == 'payment_status,where')
                                                        $attributes['style'] = 'display: inline';
                                                    else
                                                    {
                                                        $attributes['disabled'] = 'disabled';
                                                        $attributes['style'] = 'display: none';
                                                    }
                                                    
                                                    echo form_dropdown('filter_value', $filter_values, $filter_value, $attributes);
                                                    
                                                    $attributes = array(
                                                            'class' => 'form-control',
                                                            'id'    => 'filter-value-input',
                                                            'name'  => 'filter_value',
                                                            'value' => $filter_value
                                                    );

                                                    if($filter_column == 'payment_date,like')
                                                    {
                                                        $attributes['style'] = 'display: inline';
                                                        $attributes['type'] = 'month';
                                                    }
                                                    else
                                                    {
                                                        $attributes['disabled'] = 'disabled';
                                                        $attributes['style'] = 'display: none';
                                                    }
                                                    
                                                    echo form_input($attributes);
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <!--<div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Urutkan berdasarkan', 'ordering-column-select', 'class="control-label"');

                                                    $ordering_columns = array(
                                                        'transaction_date' => 'Tanggal transaksi',
                                                        'submission_date' => 'Tanggal submit',
                                                    );

                                                    echo form_dropdown('ordering_column', $ordering_columns , $ordering_column, 'class="form-control" id="ordering-column-select"');
                                                ?>
                                            
                                            </div>
                                        </div>-->
                                    </div>

                                    <?php echo form_button('', 'Cari', 'class="btn btn-primary" id="search-button" onclick="getDynamicContent(1)"'); ?>
                                
                                </div>

                                <div class="body table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>TANGGAL BAYAR</th>
                                                <th>KODE EVENT</th>
                                                <th>NOMINAL</th>
                                                <th>STATUS</th>
                                                <th>OPERASI</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php
                                                $counter = 0;

                                                foreach($event_payments as &$event_payment)
                                                {
                                                    $counter++;
                                            ?>
                                                    
                                                    <tr>
                                                        <th scope="row"><?php echo ((5 * ($page_number - 1)) + $counter); ?></th>
                                                        <td><?php echo substr($event_payment['payment_date'], -2).'/'.substr($event_payment['payment_date'], 5, 2).'/'.substr($event_payment['payment_date'], 0, 4); ?></td>
                                                        <td><?php echo $event_payment['event_name'].' ('.substr($event_payment['start_date'], -2).'/'.substr($event_payment['start_date'], 5, 2).'/'.substr($event_payment['start_date'], 0, 4).' - '.substr($event_payment['end_date'], -2).'/'.substr($event_payment['end_date'], 5, 2).'/'.substr($event_payment['end_date'], 0, 4).') '.$event_payment['unit_name'].' by '.$event_payment['marketing_name']; ?></td>
                                                        <td><?php echo 'Rp'.number_format($event_payment['nominal'], 0, ",", ".").',00'; ?></td>
                                                        <td>
                                                            
                                                            <?php
                                                                if($event_payment['payment_status'] == 1)
                                                                    echo 'Baru DP';
                                                                else if($event_payment['payment_status'] == 2)
                                                                    echo 'Cicilan';
                                                                else
                                                                    echo 'Sudah Lunas';
                                                            ?>
                                                        
                                                        </td>
                                                        <td>
                                                            <a href="<?php echo base_url('kegiatan/daftar_pembayaran/'.$event_payment['event_id']); ?>" class="btn btn-primary btn-sm">Lihat Detail</a>
                                                        </td>
                                                    </tr>
                                            
                                            <?php
                                                }
                                            ?>
                                        
                                        </tbody>
                                    </table>
                                </div>
                                
                                <?php
                                    if($page_count > 1)
                                    {
                                ?>
                                        
                                        <ul class="body pagination pagination-primary">
                                        
                                            <?php
                                                if($page_number > 1)
                                                {
                                            ?>
                                                    
                                                    <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo ($page_number - 1); ?>)">Sebelumnya</a></li>
                                            
                                            <?php
                                                    for($page_counter = $previous_page_count; $page_counter > 0; $page_counter--)
                                                    {
                                                        $previous_page_number = $page_number - $page_counter;
                                            ?>

                                                            <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo $previous_page_number; ?>)"><?php echo $previous_page_number; ?></a></li>
                                            
                                            <?php
                                                    }
                                                }

                                                if($page_count > 1)
                                                {
                                            ?>
                                                    
                                                    <li class="page-item active"><a class="page-link" href="javascript:void(0);"><?php echo $page_number; ?></a></li>
                                            
                                            <?php
                                                    if($page_count > $page_number)
                                                    {
                                                        for($page_counter = 1; $page_counter <= $next_page_count; $page_counter++)
                                                        {
                                                            $next_page_number = $page_number + $page_counter;
                                            ?>

                                                            <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo $next_page_number; ?>)"><?php echo $next_page_number; ?></a></li>
                                            
                                            <?php
                                                        }
                                            ?>

                                                        <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo ($page_number + 1); ?>)">Selanjutnya</a></li>
                                            
                                            <?php
                                                    }
                                                }
                                            ?>
                                        
                                        </ul>
                                
                                <?php
                                    }
                                ?>