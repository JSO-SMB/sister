            <div id="main-content">
                <div class="container">
                    <div class="block-header">
                        <div class="row">
                            <div class="col-lg-5 col-md-8 col-sm-12">
                                <h2>Detail Pembayaran Kegiatan</h2>
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>"><i class="icon-home"></i></a></li>
                                    <li class="breadcrumb-item">Progress Harian</li>
                                    <li class="breadcrumb-item">Data Pembayaran</li>
                                    <li class="breadcrumb-item active">
                                        <a href="javascript:void(0);">Detail Pembayaran</a>
                                    </li>
                                </ul>
                            </div>            
                            <!--<div class="col-lg-7 col-md-4 col-sm-12 text-right">
                                <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                    <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#00c5dc"
                                        data-fill-Color="transparent">3,5,1,6,5,4,8,3</div>
                                    <span>Visitors</span>
                                </div>
                                <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                    <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#f4516c"
                                        data-fill-Color="transparent">4,6,3,2,5,6,5,4</div>
                                    <span>Visits</span>
                                </div>
                            </div>-->
                        </div>
                    </div>
                    
                    <div class="row clearfix">
                        <div class="col-lg-12">
                            <div class="card" id="card">
                                <div class="body table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>TANGGAL INPUT</th>
                                                <th>TANGGAL BAYAR</th>
                                                <th>JENIS PEMBAYARAN</th>
                                                <th>BUKTI TRANSFER</th>
                                                <th>NOMINAL</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php
                                                $counter = 0;
                                                $total_nominal = 0;

                                                foreach($event_payments as &$event_payment)
                                                {
                                                    $counter++;
                                                    $total_nominal = $total_nominal + $event_payment['nominal'];
                                            ?>
                                                    
                                                    <tr>
                                                        <th scope="row"><?php echo $counter; ?></th>
                                                        <td><?php echo substr($event_payment['submission_date'], -2).'/'.substr($event_payment['submission_date'], 5, 2).'/'.substr($event_payment['submission_date'], 0, 4); ?></td>
                                                        <td><?php echo substr($event_payment['payment_date'], -2).'/'.substr($event_payment['payment_date'], 5, 2).'/'.substr($event_payment['payment_date'], 0, 4); ?></td>
                                                        <td>
                                                            
                                                            <?php
                                                                if($event_payment['payment_status'] == 1)
                                                                    echo 'DP';
                                                                else if($event_payment['payment_status'] == 2)
                                                                    echo 'Cicilan';
                                                                else
                                                                    echo 'Pelunasan';
                                                            ?>
                                                        
                                                        </td>
                                                        <td>
                                                            <a href="<?php echo base_url('uploads/events/payments/'.$event_payment['event_id'].'/'.$event_payment['proof_of_payment']); ?>" target="_blank"><?php echo $event_payment['proof_of_payment']; ?></a>
                                                        </td>
                                                        <td style="text-align:right;"><?php echo 'Rp'.number_format($event_payment['nominal'], 0, ",", ".").',00'; ?></td>
                                                    </tr>
                                            
                                            <?php
                                                }
                                            ?>

                                            <tr>
                                                <td colspan="5" style="text-align:right;">TOTAL</td>
                                                <td style="text-align:right;"><?php echo 'Rp'.number_format($total_nominal, 0, ",", ".").',00'; ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>