                                <div class="body">
                                    <div class="row clearfix">
                                        <div class="col-lg-6 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    if($category == 'general')
                                                    {
                                                        echo form_label('Nama Klien', 'name-input', 'class="control-label"');
                                                        
                                                        $data = array(
                                                                'name'			=> 'name',
                                                                'value'			=> $query,
                                                                'class'			=> 'form-control',
                                                                'id'            => 'name-input',
                                                                'placeholder'	=> 'Kosongkan untuk menampilkan semua data'
                                                        );
                                                        
                                                        echo form_input($data);
                                                    }
                                                    else
                                                    {
                                                        echo form_label('Unit Kerja', 'unit-id-select', 'class="control-label"');
                                                        echo form_dropdown('unit_id', $units , $query, 'class="form-control" id="unit-id-select"');
                                                    }
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-12"></div>
                                    </div>

                                    <?php echo form_button('', 'Cari', 'class="btn btn-primary" id="search-button" onclick="getDynamicContent(1)"'); ?>
                                
                                </div>

                                <div class="body table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>NAMA</th>
                                                <th>PERUSAHAAN</th>

                                                <?php
                                                    if($category == 'general')
                                                    {
                                                ?>
                                                        
                                                        <th>TRAINING TERAKHIR</th>
                                                
                                                <?php
                                                    }
                                                    else
                                                    {
                                                ?>
                                                        
                                                        <th>NOMOR TELEPON</th>
                                                        <th>EMAIL</th>
                                                
                                                <?php
                                                    }
                                                ?>
                                                
                                                <th>OPERASI</th>
                                            
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php
                                                $counter = 0;

                                                foreach($clients as &$client)
                                                {
                                                    $counter++;
                                            ?>
                                                    
                                                    <tr>
                                                        <th scope="row"><?php echo ((5 * ($page_number - 1)) + $counter); ?></th>
                                                        <td><?php echo $client['greeting'].' '.$client['name']; ?></td>
                                                        <td><?php echo $client['company']; ?></td>

                                                        <?php
                                                            if($category == 'general')
                                                            {
                                                        ?>
                                                                
                                                                <td>

                                                                    <?php
                                                                        if($client['event_id'] > 0)
                                                                        {
                                                                    ?>
                                                                            
                                                                            <a href="<?php echo base_url('kegiatan/tambah_ubah/'.$client['event_id']); ?>" target="_blank">
                                                                                
                                                                                <?php echo $client['event_name']; ?>
                                                                                
                                                                                <br />

                                                                                <?php echo $client['event_date']; ?>
                                                                            
                                                                            </a>
                                                                    
                                                                    <?php
                                                                        }
                                                                        else
                                                                            echo '-';
                                                                    ?>
                                                                
                                                                </td>
                                                        
                                                        <?php
                                                            }
                                                            else
                                                            {
                                                        ?>
                                                                
                                                                <td><?php echo $client['mobile_number']; ?></td>
                                                                <td><?php echo $client['email_address']; ?></td>
                                                        
                                                        <?php
                                                            }
                                                        ?>

                                                        <td><a href="<?php echo base_url('klien/tambah_ubah/'.$client['client_id']); ?>" class="btn btn-success btn-sm">Lihat Detail</a></td>
                                                    </tr>
                                            
                                            <?php
                                                }
                                            ?>
                                        
                                        </tbody>
                                    </table>
                                </div>
                                
                                <?php
                                    if($page_count > 1)
                                    {
                                ?>
                                        
                                        <ul class="body pagination pagination-primary">
                                        
                                            <?php
                                                if($page_number > 1)
                                                {
                                            ?>
                                                    
                                                    <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo ($page_number - 1); ?>)">Sebelumnya</a></li>
                                            
                                            <?php
                                                    for($page_counter = $previous_page_count; $page_counter > 0; $page_counter--)
                                                    {
                                                        $previous_page_number = $page_number - $page_counter;
                                            ?>

                                                            <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo $previous_page_number; ?>)"><?php echo $previous_page_number; ?></a></li>
                                            
                                            <?php
                                                    }
                                                }

                                                if($page_count > 1)
                                                {
                                            ?>
                                                    
                                                    <li class="page-item active"><a class="page-link" href="javascript:void(0);"><?php echo $page_number; ?></a></li>
                                            
                                            <?php
                                                    if($page_count > $page_number)
                                                    {
                                                        for($page_counter = 1; $page_counter <= $next_page_count; $page_counter++)
                                                        {
                                                            $next_page_number = $page_number + $page_counter;
                                            ?>

                                                            <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo $next_page_number; ?>)"><?php echo $next_page_number; ?></a></li>
                                            
                                            <?php
                                                        }
                                            ?>

                                                        <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo ($page_number + 1); ?>)">Selanjutnya</a></li>
                                            
                                            <?php
                                                    }
                                                }
                                            ?>
                                        
                                        </ul>
                                
                                <?php
                                    }
                                ?>