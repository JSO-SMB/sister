            <div id="main-content" class="profilepage_1">
                <div class="container">
                    <div class="block-header">
                        <div class="row">
                            <div class="col-lg-5 col-md-8 col-sm-12">                        
                                <h2><?php echo $header; ?></h2>
                                <!--<ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>
                                    <li class="breadcrumb-item">Pages</li>
                                    <li class="breadcrumb-item active">User Profile</li>
                                </ul>-->
                            </div>            
                            <!--<div class="col-lg-7 col-md-4 col-sm-12 text-right">
                                <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                    <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#00c5dc"
                                        data-fill-Color="transparent">3,5,1,6,5,4,8,3</div>
                                    <span>Visitors</span>
                                </div>
                                <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                    <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#f4516c"
                                        data-fill-Color="transparent">4,6,3,2,5,6,5,4</div>
                                    <span>Visits</span>
                                </div>
                            </div>-->
                        </div>
                    </div>

                    <div class="row clearfix">
                        <div class="col-lg-12">
                            <div class="card">
                                
                                <?php
                                    echo form_open_multipart('', 'id="client-form" onsubmit="return validateSubmission()"');

                                        $subheader[1] = 'Data Perwakilan Perusahaan';
                                        $subheader[2] = '';
                                        $subheader[3] = 'Data Perusahaan';
                                        $subheader[4] = '';
                                        
                                        $label[1][1] = 'Sapaan';
                                        $label[1][2] = 'Nama Lengkap';
                                        $label[1][3] = 'Jabatan/Posisi';
                                        $label[1][4] = 'Nama Atasan';
                                        $label[2][1] = 'Alamat email';
                                        $label[2][2] = 'Nomor HP';
                                        $label[2][3] = 'Apakah nomor HP sekaligus nomor WA?';
                                        $label[2][4] = 'Channel Pemasaran';
                                        $label[3][1] = 'Nama';
                                        $label[3][2] = 'Bidang';
                                        $label[3][3] = 'Nama HRD';
                                        $label[4][1] = 'Nomor Telepon';
                                        $label[4][2] = 'Alamat';
                                        $label[4][3] = '';

                                        $input_name[1][1] = 'greeting';
                                        $input_name[1][2] = 'name';
                                        $input_name[1][3] = 'position';
                                        $input_name[1][4] = 'boss';
                                        $input_name[2][1] = 'email_address';
                                        $input_name[2][2] = 'mobile_number';
                                        $input_name[2][3] = 'whatsapp';
                                        $input_name[2][4] = 'marketing[]';
                                        $input_name[3][1] = 'company';
                                        $select_name[3][2] = 'sector[]';
                                        $input_name[3][3] = 'hrd';
                                        $input_name[4][1] = 'phone_number';
                                        $input_name[4][2] = 'address';
                                        $input_name[4][3] = '';
                                        
                                        $options[3][2] = $sectors;

                                        $value[1][1][1] = 'Bapak';
                                        $value[1][1][2] = 'Ibu';
                                        $value[1][2][1] = $name;
                                        $value[1][3][1] = $position;
                                        $value[1][4][1] = $boss;
                                        $value[2][1][1] = $email_address;
                                        $value[2][2][1] = $mobile_number;
                                        $value[2][3][1] = 'Ya';
                                        $value[2][3][2] = 'Tidak';
                                        $value[2][4][1] = 'WA';
                                        $value[2][4][2] = 'Email';
                                        $value[3][1][1] = $company;
                                        $value[3][2][1] = $sector;
                                        $value[3][3][1] = $hrd;
                                        $value[4][1][1] = $phone_number;
                                        $value[4][2][1] = $address;
                                        $value[4][3][1] = '';

                                        $id[2][1][1] = 'email-address-input';
                                        $id[2][2][1] = 'mobile-number-input';
                                        $id[2][4][1] = 'email-marketing-input';
                                        $id[2][4][2] = 'whatsapp-marketing-input';

                                        for($subheader_counter = 1; $subheader_counter < 5; $subheader_counter++)
                                        {
                                            if($subheader[$subheader_counter] != '')
                                            {
                                    ?>

                                                <div class="body">
                                                    <h6><?php echo $subheader[$subheader_counter]; ?></h6>
                                        
                                    <?php
                                            }
                                    ?>

                                            <div class="row clearfix">
                                                
                                                <?php
                                                    if($subheader_counter < 3)
                                                        $label_count = 4;
                                                    else
                                                        $label_count = 3;
                                                    
                                                    for($label_counter = 1; $label_counter <= $label_count; $label_counter++)
                                                    {
                                                        if($label[$subheader_counter][$label_counter] != '')
                                                        {
                                                ?>
                                                            
                                                            <div class="col-lg-<?php if($label_count == 3) echo '4'; else echo '3'; ?> col-md-12">
                                                                <div class="form-group">
                                                
                                                                    <?php
                                                                        echo form_label($label[$subheader_counter][$label_counter], '', 'class="control-label"');

                                                                        if($subheader_counter == 3 && $label_counter == 2)
                                                                            echo '<br />'.form_multiselect($select_name[$subheader_counter][$label_counter], $options[$subheader_counter][$label_counter], $value[$subheader_counter][$label_counter][1], 'id="multiselect2" class="multiselect multiselect-custom" required="required"');
                                                                        else
                                                                        {
                                                                            if(($subheader_counter == 1 && $label_counter == 1) || ($subheader_counter == 2 && $label_counter == 3) || ($subheader_counter == 2 && $label_counter == 4))
                                                                            {
                                                                                $value_count = 2;
                                                                    ?>
                                                                                
                                                                                <div class="fancy-<?php if($subheader_counter == 2 && $label_counter == 4) echo 'checkbox'; else echo 'radio'; ?>">
                                                                    
                                                                    <?php
                                                                            }
                                                                            else
                                                                                $value_count = 1;
                                                                                    
                                                                            for($value_counter = 1; $value_counter <= $value_count; $value_counter++)
                                                                            {
                                                                                $data = array(
                                                                                        'name'	    => $input_name[$subheader_counter][$label_counter],
                                                                                        'value'	    => $value[$subheader_counter][$label_counter][$value_counter],
                                                                                        'class'	    => 'form-control'
                                                                                );
                                                                                
                                                                                if($subheader_counter == 2 && $label_counter == 1)
                                                                                {
                                                                                    $data['type'] = 'email';
                                                                                    $data['multiple'] = 'multiple';
                                                                                }
                                                                                else if(($subheader_counter == 2 && $label_counter == 2) || ($subheader_counter == 4 && $label_counter == 1))
                                                                                {
                                                                                    $data['type'] = 'tel';
                                                                                    $data['pattern'] = '\d+';
                                                                                }
                                                                                
                                                                                if($subheader_counter == 2 && $label_counter != 3)
                                                                                    $data['id'] = $id[$subheader_counter][$label_counter][$value_counter];
                                                                                
                                                                                if($subheader_counter == 1 && $label_counter == 2)
                                                                                    $data['required'] = 'required';
                                                                                
                                                                                if(($subheader_counter == 1 && $label_counter == 1) || ($subheader_counter == 2 && $label_counter == 3))
                                                                                {
                                                                                    if($subheader_counter == 1 && $label_counter == 1)
                                                                                        $checked = $greeting;
                                                                                    else
                                                                                        $checked = $whatsapp;
                                                                                    
                                                                                    if($checked == $value[$subheader_counter][$label_counter][$value_counter])
                                                                                        $data['checked'] = TRUE;
                                                                                    else
                                                                                        $data['checked'] = FALSE;
                                                                            ?>
                                                                                    
                                                                                    <label class="fancy-radio custom-color-green"><?php echo form_radio($data); ?><span><i></i><?php echo $value[$subheader_counter][$label_counter][$value_counter]; ?></span></label>
                                                                            
                                                                            <?php
                                                                                }
                                                                                else if($subheader_counter == 2 && $label_counter == 4)
                                                                                {
                                                                                    if(strpos($marketing, $value[$subheader_counter][$label_counter][$value_counter]) !== false)
                                                                                        $data['checked'] = TRUE;
                                                                                    else
                                                                                        $data['checked'] = FALSE;
                                                                            ?>

                                                                                    <label class="fancy-checkbox"><?php echo form_checkbox($data); ?><span><?php echo $value[$subheader_counter][$label_counter][$value_counter]; ?></span></label>
                                                                            
                                                                            <?php
                                                                                }
                                                                                else if($subheader_counter == 4 && $label_counter == 2)
                                                                                {
                                                                                    $data['rows'] = 2;

                                                                                    echo form_textarea($data);
                                                                                }
                                                                                else
                                                                                    echo form_input($data);

                                                                                if(($subheader_counter == 2 && $label_counter == 1) || ($subheader_counter == 2 && $label_counter == 2) || ($subheader_counter == 4 && $label_counter == 1))
                                                                                {
                                                                                    if($subheader_counter == 2 && $label_counter == 1)
                                                                                        $help_text = '* Jika tersedia lebih dari 1 alamat email, pisahkan dengan tanda koma, misal: user1@email.com,user2@email.com,dst.';
                                                                                    else
                                                                                        $help_text = '* Isikan dengan awalan kode negara, misal 62xxxxxxxxxxx';
                                                                            ?>

                                                                                    <span class="help-block"><?php echo $help_text; ?></span>
                                                                            
                                                                    <?php
                                                                                }
                                                                            }

                                                                            if(($subheader_counter == 1 && $label_counter == 1) || ($subheader_counter == 2 && $label_counter == 3) || ($subheader_counter == 2 && $label_counter == 4))
                                                                            {
                                                                    ?>
                                                                                
                                                                                </div>
                                                                    
                                                                    <?php
                                                                            }
                                                                        }
                                                                    ?>

                                                                </div>
                                                            </div>
                                            
                                                <?php
                                                        }
                                                    }
                                                ?>
                                            
                                            </div>
                                        
                                        <?php
                                            if($subheader_counter == 2 || $subheader_counter == 4)
                                            {
                                                if($subheader_counter == 4)
                                                {
                                                    $data = array(
                                                            'name'          => 'submit',
                                                            'value'         => 'dikirim',
                                                            'type'          => 'submit',
                                                            'class'         => 'btn btn-primary',
                                                            'content'       => 'Kirim'
                                                    );
    
                                                    echo form_button($data);
                                                }
                                        ?>
                                                
                                                </div>
                                    
                                <?php
                                                
                                            }
                                        }
                                    
                                    echo form_close();
                                ?>
                            
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>