                                                <?php
                                                    for($field_counter = 1; $field_counter < 4; $field_counter++)
                                                    {
                                                        if($field['label_text'][$field_counter] != '')
                                                        {
                                                            $attributes = ' class="form-group"';
                                                            
                                                            /*if($subheader_counter > 3 && $field_counter < 2)
                                                            {
                                                                $attributes = $attributes.' id="utilization-detail-a-div"';
                                                                
                                                                if(($financing_code == 'Logistik (Bensin Kendaraan Kantor; ATK)') || ($financing_code == 'Outing (Gathering; Sayembara) & CSR (Sumbangan)') || ($financing_code == 'Bebkantor (Telp; Speedy; Listrik; Uang Sampah)'))
                                                                    $attributes = $attributes.' style="display: none"';
                                                                else
                                                                    $attributes = $attributes.' style="display: block"';
                                                            }
                                                            
                                                            if($subheader_counter > 3 && $field_counter == 2)
                                                            {
                                                                $attributes = $attributes.' id="utilization-detail-b-div"';
                                                                
                                                                if(($financing_code == 'lain') || ($financing_code == 'Inventaris'))
                                                                    $attributes = $attributes.' style="display: block"';
                                                                else
                                                                    $attributes = $attributes.' style="display: none"';
                                                            }
                                                            
                                                            if($subheader_counter > 3 && $field_counter > 2)
                                                            {
                                                                $attributes = $attributes.' id="utilization-detail-c-div"';
                                                                
                                                                if($financing_code == 'Inventaris')
                                                                    $attributes = $attributes.' style="display: block"';
                                                                else
                                                                    $attributes = $attributes.' style="display: none"';
                                                            }*/
                                                ?>
                                                            
                                                            <div class="col-lg-4 col-md-12">
                                                                <div<?php echo $attributes; ?>>
                                                
                                                                    <?php
                                                                        echo form_label($field['label_text'][$field_counter], $field['id'][$field_counter], 'class="control-label"');

                                                                        $attributes = array(
                                                                                'class' => 'form-control',
                                                                                'id'    => $field['id'][$field_counter]
                                                                        );
                                                                                                        
                                                                        if(isset($field['onfocus'][$field_counter]))
                                                                            $attributes['onfocus'] = $field['onfocus'][$field_counter];
                                                                        
                                                                        if(isset($field['onchange'][$field_counter]))
                                                                            $attributes['onchange'] = $field['onchange'][$field_counter];

                                                                        if($field['type'][$field_counter] == 'select')
                                                                            echo form_dropdown($field['name'][$field_counter], $field['options'][$field_counter], $field['selected'][$field_counter], $attributes);
                                                                        /*else
                                                                        {
                                                                            /*if($subheader_counter < 2 && $field_counter > 1)
                                                                            {
                                                                    ?>

                                                                                <div class="input-group mb-3">
                                                                                    <div class="input-group-prepend">
                                                                                        <span class="input-group-text">

                                                                                            <?php
                                                                                                if($field_counter == 2)
                                                                                                {
                                                                                            ?>
                                                                                                    
                                                                                                    <i class="icon-calendar"></i>
                                                                                            
                                                                                            <?php
                                                                                                }
                                                                                                else
                                                                                                    echo 'Rp.';
                                                                                            ?>
                                                                                        
                                                                                        </span>
                                                                                    </div>
                                                                            
                                                                        <?php
                                                                            }

                                                                            if($subheader_counter == 2 && $field_counter == 2)
                                                                            {
                                                                                /*if($field_counter < 2)
                                                                                    $data = array(
                                                                                            'class'	    => 'dropify'
                                                                                    );
                                                                                else
                                                                                    $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'id'    => $field_id[$field_counter]
                                                                                    );
                                                                            }
                                                                            else
                                                                            {
                                                                                $data = array(
                                                                                        'value'	    => $value[$field_counter],
                                                                                        'class'	    => 'form-control',
                                                                                        'id'    => $field_id[$field_counter]
                                                                                );

                                                                                if($subheader_counter < 2 && $field_counter == 2)
                                                                                    $data['class'] = $data['class'].' currency';
                                                                            }
                                                                            //else if(($subheader_counter == 6 && $field_counter != 2) || ($subheader_counter > 10 && $subheader_counter < 52 && ($field_counter == 2 || $field_counter == 4)) || ($subheader_counter == 52 && $field_counter != 2) || $subheader_counter == 53)
                                                                            //    $data['class'] = 'form-control currency';

                                                                            /*if(($subheader_counter == 1 && ($field_counter == 1 || ($header == 'Form Pendaftaran Vendor' && $field_counter > 1))) || $subheader_counter == 2 || $subheader_counter == 3 || ($type == 'Hotel' && (($subheader_counter == 4 && $field_counter < 4) || ($subheader_counter == 5 && ($field_counter == 2 || $field_counter == 3)))) || $subheader_counter == 6 || ($header == 'Form Pendaftaran Vendor' && $subheader_counter == 7 && ($field_counter == 1 || ($type == 'Hotel' && $field_counter == 2))))
                                                                                $data['required'] = 'required';
                                                                            
                                                                            if($subheader_counter > 2 && ($field_counter > 1 && $field_counter < 4))
                                                                                $data['disabled'] = 'disabled';
                                                                            
                                                                            /*if($subheader_counter == 1 && $field_counter > 1)
                                                                            {
                                                                                $data['name'] = $password_name[$field_counter];
                                                                                $data['onfocusout'] = 'validatePassword()';
                                                                                $data['oninput'] = $data['onfocusout'];
                                                                                $data['onmouseout'] = $data['onfocusout'];

                                                                                echo form_password($data);
                                                                            }
                                                                            else if($subheader_counter == 2 && $field_counter < 2)
                                                                            {
                                                                                $data['name'] = $textarea_name[$field_counter];
                                                                                $data['rows'] = 2;

                                                                                echo form_textarea($data);
                                                                            }
                                                                            else
                                                                            {
                                                                                $data['name'] = $field_name[$field_counter];

                                                                                /*if($subheader_counter == 4 && $field_counter < 2)
                                                                                {
                                                                                    if($stars == $value[$field_counter][$value_counter])
                                                                                        $data['checked'] = TRUE;
                                                                                    else
                                                                                        $data['checked'] = FALSE;
                                                                    ?>
                                                                                    
                                                                                    <label class="fancy-radio custom-color-green"><?php echo form_radio($data); ?><span><i></i><?php echo $value[$field_counter][$value_counter]; ?></span></label>
                                                                            
                                                                            <?php
                                                                                }
                                                                                else if($subheader_counter == 2 && $field_counter == 2)
                                                                                {
                                                                                    if($header == 'Ubah Data Pengajuan Finance')
                                                                                    {
                                                                            ?>
                                                                                        
                                                                                        <div class="media-left m-r-15">

                                                                                            <?php
                                                                                                foreach($value[$field_counter][$value_counter] as &$uri_part)
                                                                                                {
                                                                                            ?>
                                                                                                    
                                                                                                    <img src="<?php echo base_url('uploads/'.$uri_part); ?>" class="user-photo media-object" alt="User">
                                                                                            
                                                                                            <?php
                                                                                                }
                                                                                            ?>
                                                                                        
                                                                                        </div>
                                                                                
                                                                                <?php
                                                                                    }
                                                                                ?>
                                                                                    
                                                                                    <div class="media-body">
                                                                                        <p><em>Untuk memilih lebih dari 1 file, tekan tombol CTRL atau SHIFT ketika memilih file</em></p>
                                                                                                
                                                                                        <?php
                                                                                            $data['multiple'] = 'multiple';
                                                                                            
                                                                                            echo form_upload($data);
                                                                                        ?>
                                                                                        
                                                                                    </div>
                                                                        
                                                                        <?php
                                                                                }*/
                                                                                else if($field['type'][$field_counter] == 'text' || $field['type'][$field_counter] == 'number')
                                                                                {
                                                                                    /*if(($subheader_counter == 1 && $field_counter == 1) || ($subheader_counter == 4 && $field_counter > 3))
                                                                                    {
                                                                                        $data['type'] = 'email';

                                                                                        if($subheader_counter == 1 && $field_counter == 1)
                                                                                        {
                                                                                            $data['autofocus'] = 'autofocus';
                                                                                            $data['onfocusout'] = "checkEmailAddress('".$email_address_check_link."', '".$email_address."', this.value)";
                                                                                            $data['oninput'] = $data['onfocusout'];
                                                                                            $data['onmouseout'] = $data['onfocusout'];
                                                                                        }
                                                                                    }
                                                                                    else if(($subheader_counter == 2 && ($field_counter == 2 || $field_counter == 3)) || ($subheader_counter == 4 && $field_counter > 2))
                                                                                    {
                                                                                        $data['type'] = 'tel';
                                                                                        $data['pattern'] = '\d+';
                                                                                    }
                                                                                    else if($subheader_counter == 2 && $field_counter > 3)
                                                                                        $data['type'] = 'url';
                                                                                    
                                                                                    if($subheader_counter < 2 && $field_counter > 2)
                                                                                        $data['type'] = 'date';*/
                                                                                    
                                                                                    if($field['type'][$field_counter] == 'number')
                                                                                        $attributes['type'] = 'number';
                                                                                    
                                                                                    echo form_input($attributes);
                                                                                }
                                                                            /*}

                                                                            /*if($subheader_counter == 1 && $field_counter > 2)
                                                                            {
                                                                        ?>

                                                                                <span class="help-block" id="password-confirmation-help" style="color: red;display: none;">Password yang Anda input-kan tidak cocok!</span>
                                                                        
                                                                        <?php
                                                                            }
                                                                            else if(($subheader_counter == 2 && ($field_counter == 2 || $field_counter == 3)) || ($subheader_counter == 4 && $field_counter == 3))
                                                                            {
                                                                        ?>

                                                                                <span class="help-block">Isikan dengan awalan kode negara, misal 62xxx</span>
                                                                        
                                                                        <?php
                                                                            }
                                                                            else if($subheader_counter == 1 && $field_counter < 2)
                                                                            {
                                                                        ?>

                                                                                <span class="help-block" id="email-address-help" style="color: red;display: none;">* Alamat email tersebut sudah terdaftar di database SISTER.</span>
                                                                    
                                                                    <?php
                                                                            }
                                                                            
                                                                            if($subheader_counter < 2 && $field_counter > 1)
                                                                            {
                                                                                if($field_counter == 2)
                                                                                {
                                                                        ?>

                                                                                    <div class="input-group-append">
                                                                                        <span class="input-group-text">,00</span>
                                                                                    </div>
                                                                        
                                                                            <?php
                                                                                }
                                                                            ?>

                                                                                </div>
                                                                        
                                                                    <?php
                                                                            }
                                                                        }*/
                                                                    ?>

                                                                </div>
                                                            </div>
                                            
                                                <?php
                                                        }
                                                    }
                                                ?>