            <div id="main-content" class="profilepage_1">
                <div class="container">
                    <div class="block-header">
                        <div class="row">
                            <div class="col-lg-5 col-md-8 col-sm-12">                        
                                <h2><?php echo $header; ?></h2>
                                <!--<ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>
                                    <li class="breadcrumb-item">Pages</li>
                                    <li class="breadcrumb-item active">User Profile</li>
                                </ul>-->
                            </div>            
                            <!--<div class="col-lg-7 col-md-4 col-sm-12 text-right">
                                <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                    <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#00c5dc"
                                        data-fill-Color="transparent">3,5,1,6,5,4,8,3</div>
                                    <span>Visitors</span>
                                </div>
                                <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                    <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#f4516c"
                                        data-fill-Color="transparent">4,6,3,2,5,6,5,4</div>
                                    <span>Visits</span>
                                </div>
                            </div>-->
                        </div>
                    </div>

                    <div class="row clearfix">
                        <div class="col-lg-12">
                            <div class="card">
                                
                                <?php
                                    echo form_open_multipart('', 'id="finance-form" onsubmit="return validateSubmission()"');

                                        $id[1] = 'controller-link';
                                        $id[2] = 'applicant-user-id';
                        
                                        $value[1] = $controller_link;
                                        $value[2] = $applicant_user_id;
                        
                                        for($input_counter = 1; $input_counter < 3; $input_counter++)
                                        {
                                            $data = array(
                                                    'type'  => 'hidden',
                                                    'id'    => $id[$input_counter],
                                                    'value' => $value[$input_counter]
                                            );
                                            
                                            echo form_input($data);
                                        }

                                        unset($value);

                                        for($subheader_counter = 1; $subheader_counter < 6; $subheader_counter++)
                                        {
                                            if($subheader_counter == 1)
                                                $subheader[$subheader_counter] = 'Data Pengajuan';
                                            else if($subheader_counter == 3)
                                                $subheader[$subheader_counter] = 'Data Transfer';
                                            else if($subheader_counter == 4)
                                                $subheader[$subheader_counter] = 'Data Penggunaan';
                                            else if($subheader_counter == 5)
                                                $subheader[$subheader_counter] = 'Status Pengajuan';
                                            else
                                                $subheader[$subheader_counter] = '';
                                        }
                                        
                                        $label[1][1] = 'Kode Pembiayaan';
                                        $label[1][2] = 'Nominal';
                                        $label[1][3] = 'Deadline Pembayaran';
                                        $label[2][1] = 'Keterangan Lain (Detail Lain)';
                                        $label[2][2] = 'Bukti Tagihan / Bukti Pembayaran';
                                        $label[2][3] = 'Penggunaan untuk unit apa?';
                                        $label[3][1] = 'Atas Nama Rekening';
                                        $label[3][2] = 'Nama Bank Tujuan ';
                                        $label[3][3] = 'Nomer Rekening Tujuan';
                                        $label[3][4] = 'Berita Transfer';
                                        $label[4][1] = '';
                                        $label[4][2] = '';
                                        $label[4][3] = '';
                                        $label[5][1] = 'Status';
                                        $label[5][2] = '';
                                        $label[5][3] = '';

                                        $select_name[1][1] = 'financing_code';
                                        $input_name[1][2] = 'nominal';
                                        $input_name[1][3] = 'payment_deadline';
                                        $textarea_name[2][1] = 'other_details';
                                        $input_name[2][2] = 'proof_of_payments[]';
                                        $select_name[2][3] = 'utilizing_unit_id';
                                        $input_name[3][1] = 'accountee';
                                        $input_name[3][2] = 'bank';
                                        $input_name[3][3] = 'account_number';
                                        $input_name[3][4] = 'transfer_information';
                                        $select_name[5][1] = 'status';

                                        $options[1][1] = $financing_codes;
                                        $options[2][3] = $units;
                                        $options[5][1] = $statuses;
                                        
                                        $value[1][1] = $financing_code;
                                        $value[1][2] = $nominal;
                                        $value[1][3] = $payment_deadline;
                                        $value[2][1] = $other_details;
                                        $value[2][2] = $proof_of_payments;
                                        $value[2][3] = $utilizing_unit_id;
                                        $value[3][1] = $accountee;
                                        $value[3][2] = $bank;
                                        $value[3][3] = $account_number;
                                        $value[3][4] = $transfer_information;
                                        $value[5][1] = $status;
                                        
                                        $input_id[1][1] = 'financing-code-select';
                                        $input_id[1][2] = 'nominal-input';
                                        $input_id[1][3] = 'payment-deadline-input';
                                        $input_id[2][1] = 'other-details-textarea';
                                        $input_id[2][2] = 'proof-of-payments-input';
                                        $input_id[2][3] = 'utilizing-unit-id-select';
                                        $input_id[3][1] = 'accountee-input';
                                        $input_id[3][2] = 'bank-input';
                                        $input_id[3][3] = 'account-number-input';
                                        $input_id[3][4] = 'transfer-information-input';
                                        $input_id[5][1] = 'status-select';

                                        $button_id[2][2] = 'proof-of-payments-upload-btn';

                                        if($financing_code == 'Honor Instruktur 1' || $financing_code == 'Honor Instruktur 2' || $financing_code == 'Sertifikasi / Kunjungan' || $financing_code == 'Meeting Room' || $financing_code == 'Akomodasi Peserta' || $financing_code == 'Akomodasi Instruktur' || $financing_code == 'Akomodasi Tim' || $financing_code == 'Transportasi Peserta' || $financing_code == 'Transportasi Instruktur' || $financing_code == 'City Tour' || $financing_code == 'Transportasi Tim' || $financing_code == 'Modul' || $financing_code == 'Dokumentasi' || $financing_code == 'Spanduk' || $financing_code == 'Sewa' || $financing_code == 'Pengiriman' || $financing_code == 'Fee Agent' || $financing_code == 'Fee Driver' || $financing_code == 'Fee CS' || $financing_code == 'Lunch / Dinner' || $financing_code == 'Operasional')
                                        {
                                            $label[4][1] = 'Kegiatan';
                                            
                                            $select_name[4][1] = 'event_id';
                                            
                                            $options[4][1] = $events;
                                            
                                            $value[4][1] = $event_id;
                                            
                                            $input_id[4][1] = 'event-id-select';

                                            if($financing_code == 'Honor Instruktur 2' || $financing_code == 'Sertifikasi / Kunjungan')
                                            {
                                                $label[4][2] = 'Instruktur';
                                            
                                                $select_name[4][2] = 'receiver_user_id';
                                                
                                                $options[4][2] = $instructors;
                                                
                                                $value[4][2] = $receiver_user_id;
                                                
                                                $input_id[4][2] = 'receiver-user-id-select';
                                            }
                                            else if($financing_code == 'Akomodasi Peserta' || $financing_code == 'Akomodasi Instruktur' || $financing_code == 'Akomodasi Tim' || $financing_code == 'Transportasi Instruktur' || $financing_code == 'City Tour' || $financing_code == 'Transportasi Tim' || $financing_code == 'Modul' || $financing_code == 'Dokumentasi' || $financing_code == 'Spanduk' || $financing_code == 'Sewa' || $financing_code == 'Pengiriman')
                                            {
                                                $label[4][2] = 'Vendor';
                                            
                                                $select_name[4][2] = 'vendor_id';
                                                
                                                $options[4][2] = $vendors;
                                                
                                                $value[4][2] = $vendor_id;
                                                
                                                $input_id[4][2] = 'vendor-id-select';
                                            }
                                        }
                                        else if($financing_code == 'Kit (DP; Pelunasan; Training kit)')
                                        {
                                            $label[4][1] = 'GRN';
                                            
                                            $select_name[4][1] = 'order_id';
                                            
                                            $options[4][1] = $grn_list;
                                            
                                            $value[4][1] = $order_id;
                                            
                                            $input_id[4][1] = 'order-id-select';
                                        }
                                        else if(($financing_code == 'Pulsa (Go-Jek; Pulsa HP Kantor)') || ($financing_code == 'IT (Hostdomain; Software)'))
                                        {
                                            if($financing_code == 'Pulsa (Go-Jek; Pulsa HP Kantor)')
                                                $label[4][1] = 'Nomor Telepon';
                                            else
                                                $label[4][1] = 'Nama Domain/ Hosting';
                                            
                                            $select_name[4][1] = 'it_data_id';
                                            
                                            $options[4][1] = $it_data;
                                            
                                            $value[4][1] = $it_data_id;
                                            
                                            $input_id[4][1] = 'it-data-id-select';
                                        }
                                        else if($financing_code == 'Inventaris (Pengadaan Barang Inventaris Perusahaan)')
                                        {
                                            $label[4][1] = 'Nama Item';
                                            $label[4][2] = 'Jumlah';
                                            $label[4][3] = 'Satuan';
                                            
                                            $input_name[4][1] = 'inventory_item';
                                            $input_name[4][2] = 'inventory_item_quantity';
                                            $input_name[4][3] = 'inventory_item_unit';
                                            
                                            $value[4][1] = $inventory_item;
                                            $value[4][2] = $inventory_item_quantity;
                                            $value[4][3] = $inventory_item_unit;
                                            
                                            $input_id[4][1] = 'inventory-item-input';
                                            $input_id[4][2] = 'inventory-item-quantity-input';
                                            $input_id[4][3] = 'inventory-item-unit-input';
                                        }
                                        /*else
                                            $label[4][1] = 'Kegiatan';
                                        
                                        if($financing_code == 'lain')
                                            $label[4][2] = 'Vendor';
                                        else
                                            $label[4][2] = 'Jumlah';
                                        
                                        $label[4][3] = 'Satuan';*/

                                        for($subheader_counter = 1; $subheader_counter < 6; $subheader_counter++)
                                        {
                                            if($subheader[$subheader_counter] != '')
                                            {
                                                $attributes = ' class="body"';

                                                if($subheader_counter == 4)
                                                {
                                                    $attributes = $attributes.' id="utilization-data-div"';

                                                    if(($financing_code == 'Logistik (Bensin Kendaraan Kantor; ATK)') || ($financing_code == 'Outing (Gathering; Sayembara) & CSR (Sumbangan)') || ($financing_code == 'Bebkantor (Telp; Speedy; Listrik; Uang Sampah)'))
                                                        $attributes = $attributes.' style="display: none;"';
                                                    else
                                                        $attributes = $attributes.' style="display: block;"';
                                                }
                                                else if($subheader_counter > 4)
                                                {
                                                    $attributes = $attributes.' id="submission-status-div"';

                                                    if($logged_in_user['division'] == 'FINANCE' && $header == 'Ubah Data Pengajuan Finance')
                                                        $attributes = $attributes.' style="display: block;"';
                                                    else
                                                        $attributes = $attributes.' style="display: none;"';
                                                }
                                    ?>

                                                <div<?php echo $attributes; ?>>
                                                    <h6><?php echo $subheader[$subheader_counter]; ?></h6>
                                        
                                    <?php
                                            }
                                    ?>

                                            <div class="row clearfix"<?php if($subheader_counter == 4) echo ' id="utilization-details-div"'; ?>>
                                                
                                                <?php
                                                    if(($subheader_counter < 3) || ($subheader_counter > 3))
                                                        $label_count = 3;
                                                    else if($subheader_counter == 3)
                                                        $label_count = 4;
                                                    
                                                    for($label_counter = 1; $label_counter <= $label_count; $label_counter++)
                                                    {
                                                        if($label[$subheader_counter][$label_counter] != '')
                                                        {
                                                            $attributes = ' class="form-group"';
                                                ?>
                                                            
                                                            <div class="col-lg-<?php if($label_count == 2) echo '6'; else if($label_count == 3) echo '4'; else echo '3'; ?> col-md-12">
                                                                <div<?php echo $attributes; ?>>
                                                
                                                                    <?php
                                                                        echo form_label($label[$subheader_counter][$label_counter], '', 'class="control-label"');

                                                                        if(($subheader_counter < 2 && $label_counter < 2) || ($subheader_counter == 2 && $label_counter > 2) || ($subheader_counter == 4 && $label_counter < 2 && $financing_code != 'Inventaris (Pengadaan Barang Inventaris Perusahaan)') || ($subheader_counter > 4))
                                                                        {
                                                                            $extra = 'class="form-control"';

                                                                            $extra = $extra.' id="'.$input_id[$subheader_counter][$label_counter].'"';

                                                                            if($subheader_counter < 2 && $label_counter < 2)
                                                                                $extra = $extra.' onchange="setUtilizationData(this.value)"';
                                                                            else if($subheader_counter == 4 && $label_counter < 2)
                                                                                $extra = $extra.' onchange="setUnitOptions()"';
                                                                            
                                                                            if($subheader_counter < 5 && (($applicant_user_id != $this->session->userdata('user_id')) || ($status != 'Sudah Diajukan' && $status != 'Butuh Perbaikan')))
                                                                                $extra = $extra.' disabled="disabled"';
                                                                            
                                                                            echo form_dropdown($select_name[$subheader_counter][$label_counter], $options[$subheader_counter][$label_counter], $value[$subheader_counter][$label_counter], $extra);
                                                                        }
                                                                        else
                                                                        {
                                                                            if($subheader_counter < 2 && $label_counter > 1)
                                                                            {
                                                                    ?>

                                                                                <div class="input-group mb-3">
                                                                                    <div class="input-group-prepend">
                                                                                        <span class="input-group-text">

                                                                                            <?php
                                                                                                if($label_counter > 2)
                                                                                                {
                                                                                            ?>
                                                                                                    
                                                                                                    <i class="icon-calendar"></i>
                                                                                            
                                                                                            <?php
                                                                                                }
                                                                                                else
                                                                                                    echo 'Rp.';
                                                                                            ?>
                                                                                        
                                                                                        </span>
                                                                                    </div>
                                                                            
                                                                        <?php
                                                                            }

                                                                            if($subheader_counter == 2 && $label_counter == 2)
                                                                            {
                                                                                /*if($label_counter < 2)
                                                                                    $data = array(
                                                                                            'class'	    => 'dropify'
                                                                                    );
                                                                                else*/
                                                                                    $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'id'    => $input_id[$subheader_counter][$label_counter]
                                                                                    );
                                                                            }
                                                                            else
                                                                            {
                                                                                $data = array(
                                                                                        'value' => $value[$subheader_counter][$label_counter],
                                                                                        'class' => 'form-control',
                                                                                        'id'    => $input_id[$subheader_counter][$label_counter]
                                                                                );

                                                                                if($subheader_counter < 2 && $label_counter == 2)
                                                                                {
                                                                                    $data['class'] = $data['class'].' currency';
                                                                                    //$data['data-max-value'] = -1;
                                                                                    //$data['onmouseout'] = "checkNominalLimit()";
                                                                                }
                                                                            }
                                                                            //else if(($subheader_counter == 6 && $label_counter != 2) || ($subheader_counter > 10 && $subheader_counter < 52 && ($label_counter == 2 || $label_counter == 4)) || ($subheader_counter == 52 && $label_counter != 2) || $subheader_counter == 53)
                                                                            //    $data['class'] = 'form-control currency';

                                                                            if(($subheader_counter < 2 && $label_counter > 1) || ($subheader_counter == 2 && (($label_counter < 2 && $financing_code == 'Bebkantor (Telp; Speedy; Listrik; Uang Sampah)') || ($label_counter == 2 && $header == 'Form Pengajuan Finance'))))
                                                                                $data['required'] = 'required';
                                                                            
                                                                            //if($subheader_counter > 2 && ($label_counter > 1 && $label_counter < 4))
                                                                            if(($applicant_user_id != $this->session->userdata('user_id')) || ($status != 'Sudah Diajukan' && $status != 'Butuh Perbaikan'))
                                                                                $data['disabled'] = 'disabled';
                                                                            
                                                                            /*if($subheader_counter == 1 && $label_counter > 1)
                                                                            {
                                                                                $data['name'] = $password_name[$subheader_counter][$label_counter];
                                                                                $data['onfocusout'] = 'validatePassword()';
                                                                                $data['oninput'] = $data['onfocusout'];
                                                                                $data['onmouseout'] = $data['onfocusout'];

                                                                                echo form_password($data);
                                                                            }
                                                                            else */if($subheader_counter == 2 && $label_counter < 2)
                                                                            {
                                                                                $data['name'] = $textarea_name[$subheader_counter][$label_counter];
                                                                                $data['rows'] = 2;

                                                                                echo form_textarea($data);
                                                                            }
                                                                            else
                                                                            {
                                                                                $data['name'] = $input_name[$subheader_counter][$label_counter];

                                                                                /*if($subheader_counter == 4 && $label_counter < 2)
                                                                                {
                                                                                    if($stars == $value[$subheader_counter][$label_counter][$value_counter])
                                                                                        $data['checked'] = TRUE;
                                                                                    else
                                                                                        $data['checked'] = FALSE;
                                                                    ?>
                                                                                    
                                                                                    <label class="fancy-radio custom-color-green"><?php echo form_radio($data); ?><span><i></i><?php echo $value[$subheader_counter][$label_counter][$value_counter]; ?></span></label>
                                                                            
                                                                            <?php
                                                                                }
                                                                                else */if($subheader_counter == 2 && $label_counter == 2)
                                                                                {
                                                                                    if($header == 'Ubah Data Pengajuan Finance')
                                                                                    {
                                                                            ?>
                                                                                        
                                                                                        <div class="media-left m-r-15">

                                                                                            <?php
                                                                                                foreach($value[$subheader_counter][$label_counter] as &$uri_part)
                                                                                                {
                                                                                            ?>
                                                                                                    
                                                                                                    <a href="<?php echo base_url('uploads/finance/submissions/'.$uri_part); ?>"><?php echo $uri_part; ?></a>
                                                                                            
                                                                                            <?php
                                                                                                }
                                                                                            ?>
                                                                                        
                                                                                        </div>
                                                                                
                                                                                <?php
                                                                                    }
                                                                                ?>
                                                                                    
                                                                                    <div class="media-body">
                                                                                        <p><em>Untuk memilih lebih dari 1 file, tekan tombol CTRL atau SHIFT ketika memilih file</em></p>
                                                                                                
                                                                                        <?php
                                                                                            $data['multiple'] = 'multiple';
                                                                                            
                                                                                            echo form_upload($data);
                                                                                        ?>
                                                                                        
                                                                                    </div>
                                                                        
                                                                        <?php
                                                                                }
                                                                                else
                                                                                {
                                                                                    /*if(($subheader_counter == 1 && $label_counter == 1) || ($subheader_counter == 4 && $label_counter > 3))
                                                                                    {
                                                                                        $data['type'] = 'email';

                                                                                        if($subheader_counter == 1 && $label_counter == 1)
                                                                                        {
                                                                                            $data['autofocus'] = 'autofocus';
                                                                                            $data['onfocusout'] = "checkEmailAddress('".$email_address_check_link."', '".$email_address."', this.value)";
                                                                                            $data['oninput'] = $data['onfocusout'];
                                                                                            $data['onmouseout'] = $data['onfocusout'];
                                                                                        }
                                                                                    }
                                                                                    else if(($subheader_counter == 2 && ($label_counter == 2 || $label_counter == 3)) || ($subheader_counter == 4 && $label_counter > 2))
                                                                                    {
                                                                                        $data['type'] = 'tel';
                                                                                        $data['pattern'] = '\d+';
                                                                                    }
                                                                                    else if($subheader_counter == 2 && $label_counter > 3)
                                                                                        $data['type'] = 'url';*/
                                                                                    
                                                                                    if($subheader_counter < 2 && $label_counter > 2)
                                                                                        $data['type'] = 'date';
                                                                                    
                                                                                    echo form_input($data);
                                                                                }
                                                                            }

                                                                            /*if($subheader_counter == 1 && $label_counter > 2)
                                                                            {
                                                                        ?>

                                                                                <span class="help-block" id="password-confirmation-help" style="color: red;display: none;">Password yang Anda input-kan tidak cocok!</span>
                                                                        
                                                                        <?php
                                                                            }
                                                                            else if(($subheader_counter == 2 && ($label_counter == 2 || $label_counter == 3)) || ($subheader_counter == 4 && $label_counter == 3))
                                                                            {
                                                                        ?>

                                                                                <span class="help-block">Isikan dengan awalan kode negara, misal 62xxx</span>
                                                                        
                                                                        <?php
                                                                            }
                                                                            else if($subheader_counter == 1 && $label_counter < 2)
                                                                            {
                                                                        ?>

                                                                                <span class="help-block" id="email-address-help" style="color: red;display: none;">* Alamat email tersebut sudah terdaftar di database SISTER.</span>
                                                                    
                                                                    <?php
                                                                            }*/
                                                                            
                                                                            if($subheader_counter < 2 && $label_counter > 1)
                                                                            {
                                                                                if($label_counter == 2)
                                                                                {
                                                                        ?>

                                                                                    <div class="input-group-append">
                                                                                        <span class="input-group-text">,00</span>
                                                                                    </div>
                                                                        
                                                                            <?php
                                                                                }
                                                                            ?>

                                                                                </div>
                                                                        
                                                                    <?php
                                                                            }
                                                                        }
                                                                    ?>

                                                                </div>
                                                            </div>
                                            
                                                <?php
                                                        }
                                                    }
                                                ?>
                                            
                                            </div>
                                        
                                        <?php
                                            if($subheader_counter > 1)
                                            {
                                                $attributes = ' style="height: 2px;border-width: 0;background-color: gray;';

                                                if($subheader_counter == 3)
                                                {
                                                    $attributes = ' id="bank-account-line"'.$attributes;
                                                    
                                                    if(($financing_code == 'Logistik (Bensin Kendaraan Kantor; ATK)') || ($financing_code == 'Outing (Gathering; Sayembara) & CSR (Sumbangan)') || ($financing_code == 'Bebkantor (Telp; Speedy; Listrik; Uang Sampah)'))
                                                        $attributes = $attributes.'display: none;';
                                                    else
                                                        $attributes = $attributes.'display: block;';
                                                }
                                                else if($subheader_counter == 4)
                                                {
                                                    if($logged_in_user['division'] == 'FINANCE')
                                                        $attributes = $attributes.'display: block;';
                                                    else
                                                        $attributes = $attributes.'display: none;';
                                                }
                                                
                                                $attributes = $attributes.'"';
                                                
                                                if($subheader_counter < 5)
                                                {
                                        ?>
                                                    
                                                    <hr<?php echo $attributes; ?> />
                                        
                                        <?php
                                                }
                                        ?>
                                                
                                                </div>
                                            
                                <?php       
                                            }
                                        }
                                ?>

                                        <div class="body">

                                            <?php
                                                $data = array(
                                                    'name'      => 'submit',
                                                    'value'     => 'dikirim',
                                                    'type'      => 'submit',
                                                    'class'     => 'btn btn-primary',
                                                    'content'   => 'Kirim'
                                                );

                                                echo form_button($data);
                                            ?>
                                        
                                        </div>
                                
                                <?php
                                    
                                    echo form_close();
                                ?>
                            
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>