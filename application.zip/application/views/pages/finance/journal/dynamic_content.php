                            
                                <div class="body">
                                    <div class="row clearfix">
                                        <div class="col-lg-3 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Urutkan berdasarkan', 'ordering-column-select', 'class="control-label"');

                                                    $ordering_columns = array(
                                                        'transaction_date' => 'Tanggal transaksi',
                                                        'submission_date' => 'Tanggal submit',
                                                    );

                                                    echo form_dropdown('ordering_column', $ordering_columns , $ordering_column, 'class="form-control js-basic-single" id="ordering-column-select"');
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Nama unit', 'unit-id-select', 'class="control-label"');

                                                    $attributes = array(
                                                            'class' => 'form-control js-basic-single',
                                                            'id'    => 'unit-id-select'
                                                    );
                                                    
                                                    echo form_dropdown('unit_id', $units_for_filter, $unit_id, $attributes);
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Kode referensi debit', 'debt-reference-code-select', 'class="control-label"');

                                                    $attributes = array(
                                                            'class' => 'form-control js-basic-single',
                                                            'id'    => 'debt-reference-code-select'
                                                    );
                                                    
                                                    echo form_dropdown('debt_reference_code', $reference_codes_for_filter, $debt_reference_code, $attributes);
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Kode referensi kredit', 'credit-reference-code-select', 'class="control-label"');

                                                    $attributes = array(
                                                            'class' => 'form-control js-basic-single',
                                                            'id'    => 'credit-reference-code-select'
                                                    );
                                                    
                                                    echo form_dropdown('credit_reference_code', $reference_codes_for_filter, $credit_reference_code, $attributes);
                                                ?>
                                            
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row clearfix">
                                        <div class="col-lg-3 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Periode submit', 'submission-period-parameter-select', 'class="control-label"');
                                                    echo form_dropdown('submission_period_parameter', $submission_period_parameters , $submission_period_parameter, 'class="form-control" id="submission-period-parameter-select" onchange="setSubmissionPeriodField(this.value)"');
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label($submission_period_label, '', 'class="control-label" id="submission-period-label"');

                                                    $attributes = array(
                                                            'class' => 'form-control',
                                                            'id'    => 'submission-period-select'
                                                    );

                                                    if($submission_period_parameter == 'YEAR(submission_date),where')
                                                        $attributes['style'] = 'display: inline';
                                                    else
                                                    {
                                                        $attributes['disabled'] = 'disabled';
                                                        $attributes['style'] = 'display: none';
                                                    }
                                                    
                                                    echo form_dropdown('submission_period', $submission_periods, $submission_period, $attributes);
                                                    
                                                    $attributes = array(
                                                            'class' => 'form-control',
                                                            'id'    => 'submission-period-input',
                                                            'name'  => 'submission_period',
                                                            'value' => $submission_period
                                                    );

                                                    if($submission_period_parameter == 'submission_date,where' || $submission_period_parameter == 'submission_date,like')
                                                    {
                                                        $attributes['style'] = 'display: inline';
                                                        
                                                        if($submission_period_parameter == 'submission_date,where')
                                                            $attributes['type'] = 'date';
                                                        else
                                                            $attributes['type'] = 'month';
                                                    }
                                                    else
                                                    {
                                                        $attributes['disabled'] = 'disabled';
                                                        $attributes['style'] = 'display: none';
                                                    }
                                                    
                                                    echo form_input($attributes);
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Periode transaksi', 'transaction-period-parameter-select', 'class="control-label"');
                                                    echo form_dropdown('transaction_period_parameter', $transaction_period_parameters , $transaction_period_parameter, 'class="form-control" id="transaction-period-parameter-select" onchange="setTransactionPeriodField(this.value)"');
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label($transaction_period_label, '', 'class="control-label" id="transaction-period-label"');

                                                    $attributes = array(
                                                            'class' => 'form-control',
                                                            'id'    => 'transaction-period-select'
                                                    );

                                                    if($transaction_period_parameter == 'YEAR(transaction_date),where')
                                                        $attributes['style'] = 'display: inline';
                                                    else
                                                    {
                                                        $attributes['disabled'] = 'disabled';
                                                        $attributes['style'] = 'display: none';
                                                    }
                                                    
                                                    echo form_dropdown('transaction_period', $transaction_periods, $transaction_period, $attributes);
                                                    
                                                    $attributes = array(
                                                            'class' => 'form-control',
                                                            'id'    => 'transaction-period-input',
                                                            'name'  => 'transaction_period',
                                                            'value' => $transaction_period
                                                    );

                                                    if($transaction_period_parameter == 'transaction_date,where' || $transaction_period_parameter == 'transaction_date,like')
                                                    {
                                                        $attributes['style'] = 'display: inline';
                                                        
                                                        if($transaction_period_parameter == 'transaction_date,where')
                                                            $attributes['type'] = 'date';
                                                        else
                                                            $attributes['type'] = 'month';
                                                    }
                                                    else
                                                    {
                                                        $attributes['disabled'] = 'disabled';
                                                        $attributes['style'] = 'display: none';
                                                    }
                                                    
                                                    echo form_input($attributes);
                                                ?>
                                            
                                            </div>
                                        </div>
                                    </div>

                                    <?php echo form_button('', 'Cari', 'class="btn btn-primary" id="search-button" onclick="getDynamicContent(1)"'); ?>
                                
                                </div>

                                <div class="body table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th rowspan="2">#</th>
                                                <th>TANGGAL SUBMIT</th>
                                                <th rowspan="2"><?php echo wordwrap('JENIS TRANSAKSI', 5, "<br />"); ?></th>
                                                <th rowspan="2"><?php echo wordwrap('KODE TRANSAKSI', 4, "<br />"); ?></th>
                                                <th style="text-align: center;">TUJUAN TRANSFER</th>
                                                <th rowspan="2">KETERANGAN</th>
                                                <th colspan="3" style="text-align: center;">TRANSAKSI</th>
                                                <th rowspan="2">PERSETUJUAN</th>
                                                <th rowspan="2">OPERASI</th>
                                            </tr>
                                            <tr>                                                
                                                <th>TANGGAL TRANSAKSI</th>
                                                <th>NO. REK. / BANK / A.N.</th>
                                                <th>REFF</th>
                                                <th>DEBIT</th>
                                                <th>KREDIT</th>
                                            </tr>
                                        </thead>

                                        <?php
                                            $transaction_types = array(
                                                'IN: Manual' => 'IN: Manual',
                                                'IN: Event' => 'IN: Event',
                                                'OUT: Manual' => 'OUT: Manual',
                                                'OUT: Pengajuan' => 'OUT: Pengajuan',
                                            );

                                            $field['onchange'][3] = 'setTransactionCodeField(this)';
                                            $field['onchange'][8] = 'setCreditNominal(this)';

                                            $field['options'][3] = $transaction_types;
                                            $field['options'][7] = $reference_codes;
                                            
                                            $field['type'][3] = 'select2';
                                            $field['type'][6] = 'text';
                                            $field['type'][7] = 'select2';
                                            $field['type'][8] = 'currency';
                                            $field['type'][10] = 'select2';
                                        ?>
                                        
                                        <tbody>
                                            
                                            <?php
                                                if($logged_in_user['division'] == 'FINANCE' && $logged_in_user['position'] == 'Staff')
                                                {
                                            ?>
                                                    
                                                    <tr>

                                                        <?php
                                                            $field['id'][3] = 'transaction_type[0]';
                                                            $field['id'][6] = 'notes[0]';
                                                            $field['id'][7] = 'debt_reference_code[0]';
                                                            $field['id'][8] = 'nominal[0]';
                                                            
                                                            for($column_counter = 1;$column_counter < 12;$column_counter++)
                                                            {
                                                        ?>
                                                                <td style="padding: 0;text-align: center;"<?php if(!($column_counter == 2 || $column_counter == 4 || ($column_counter > 6 && $column_counter < 10))) echo ' rowspan="2"'; ?>>
                                                                    
                                                                    <?php
                                                                        if($column_counter < 3)
                                                                            echo '-';
                                                                        else if($column_counter > 2 && $column_counter < 9 && $column_counter != 4 && $column_counter != 5)
                                                                        {
                                                                            $attributes = array(
                                                                                    'class'                 => 'form-control',
                                                                                    'data-transaction-id'   => 0,
                                                                                    'id'                    => $field['id'][$column_counter]
                                                                            );

                                                                            if(isset($field['onchange'][$column_counter]))
                                                                                $attributes['onchange'] = $field['onchange'][$column_counter];

                                                                            if($field['type'][$column_counter] == 'date' || $field['type'][$column_counter] == 'text' || $field['type'][$column_counter] == 'currency')
                                                                            {
                                                                                if($field['type'][$column_counter] == 'currency')
                                                                                {
                                                                                    $attributes['class'] = $attributes['class'].' currency';
                                                                                    $attributes['placeholder'] = 'Nominal';
                                                                                }
                                                                                
                                                                                if($field['type'][$column_counter] == 'date')
                                                                                    $attributes['type'] = 'date';
                                                                                                        
                                                                                echo form_input($attributes);
                                                                            }
                                                                            else
                                                                            {
                                                                                if($field['type'][$column_counter] == 'select2')
                                                                                {
                                                                                    $attributes['class'] = $attributes['class'].' js-basic-single';
                                                                                    $attributes['style'] = 'width: 115px;';
                                                                                }
                                                                                
                                                                                if(isset($field['onchange'][$column_counter]))
                                                                                    $attributes['onchange'] = $field['onchange'][$column_counter];
                                                                                
                                                                                //if($subheader_counter < 5 && (($applicant_user_id != $this->session->userdata('user_id')) || ($status != 'Sudah Diajukan' && $status != 'Butuh Perbaikan')))
                                                                                //    $extra = $extra.' disabled="disabled"';
                                                                                
                                                                                echo form_dropdown('', $field['options'][$column_counter], '', $attributes);
                                                                            }
                                                                        }
                                                                        else if($column_counter == 4)
                                                                        {
                                                                            $attributes = array(
                                                                                    'class'                 => 'form-control',
                                                                                    'data-transaction-id'   => 0
                                                                            );
                                                                            
                                                                            $attributes['id'] = 'transaction_code[0]';
                                                                            $attributes['style'] = 'display: inline;';
                                                                                                        
                                                                            echo form_input($attributes);
                                                                            
                                                                            $attributes['id'] = 'event_id[0]';
                                                                            $attributes['disabled'] = 'disabled';
                                                                            $attributes['onchange'] = "setEventFundingSubmissionDetail(this, 'kegiatan/tambah_ubah/')";
                                                                            $attributes['style'] = 'display: none;';
                                                                                
                                                                            echo form_dropdown('', $events_users, '', $attributes);
                                                                            
                                                                            $attributes['id'] = 'funding_submission_id[0]';
                                                                            $attributes['onchange'] = "setEventFundingSubmissionDetail(this, 'keuangan/pengajuan/')";
                                                                                
                                                                            echo form_dropdown('', $funding_submissions_users_units, '', $attributes);
                                                                        }
                                                                        else if($column_counter == 5)
                                                                        {
                                                                            $attributes = array(
                                                                                    'class'                 => 'form-control',
                                                                                    'data-transaction-id'   => 0
                                                                            );
                                                                            
                                                                            $attributes['id'] = 'account_number[0]';
                                                                            $attributes['placeholder'] = 'No. Rekening';
                                                                                                        
                                                                            echo form_input($attributes);
                                                                            
                                                                            $attributes['id'] = 'bank[0]';
                                                                            $attributes['placeholder'] = 'Bank';
                                                                                                        
                                                                            echo form_input($attributes);
                                                                            
                                                                            $attributes['id'] = 'accountee[0]';
                                                                            $attributes['placeholder'] = 'Atas Nama';
                                                                                                        
                                                                            echo form_input($attributes);
                                                                        }
                                                                        else if($column_counter == 10)
                                                                            echo 'Unchecked';
                                                                        else if($column_counter == 11)
                                                                        {
                                                                            $attributes = array(
                                                                                'class'     => 'btn btn-primary',
                                                                                'content'   => 'Simpan',
                                                                                'onclick'   => 'saveTransaction(this.value)',
                                                                                'value'     => 0
                                                                            );

                                                                            echo form_button($attributes);
                                                                        }
                                                                    ?>
                                                                
                                                                </td>
                                                        
                                                        <?php
                                                            }
                                                        ?>
                                            
                                                    </tr>
                                                    <tr>
                                                        <td style="padding: 0;text-align: center;">
                                                            
                                                            <?php
                                                                $attributes = array(
                                                                        'class'                 => 'form-control',
                                                                        'data-transaction-id'   => 0,
                                                                        'id'                    => 'transaction_date[0]',
                                                                        'type'                  => 'date'
                                                                );
                                                                
                                                                echo form_input($attributes);
                                                            ?>
                                                        
                                                        </td>
                                                        
                                                        <td id="event-funding-submission-detail[0]" style="padding: 0;text-align: center;">
                                                            
                                                            <?php
                                                                $attributes = array(
                                                                        'class' => 'form-control',
                                                                        'id'    => 'unit_id[0]'
                                                                );
                                                                
                                                                echo form_dropdown('', $units, '', $attributes);
                                                            ?>
                                                        
                                                        </td>
                                                        
                                                        <?php
                                                            $field['id'][7] = 'credit_reference_code[0]';

                                                            $field['options'][7] = $reference_codes;
                                                            
                                                            for($column_counter = 7;$column_counter < 10;$column_counter++)
                                                            {
                                                        ?>
                                                                <td style="padding: 0;text-align: center;"<?php if($column_counter == 9) echo ' id="credit-nominal-data[0]"'; ?>>
                                                                    
                                                                    <?php
                                                                        if($column_counter == 7)
                                                                        {
                                                                            $attributes = array(
                                                                                    //'value' => $value[$subheader_counter][$label_counter],
                                                                                    'class' => 'js-basic-single',
                                                                                    'id'    => $field['id'][$column_counter],
                                                                                    'style' => 'width: 115px;'
                                                                            );

                                                                            //if($subheader_counter < 5 && (($applicant_user_id != $this->session->userdata('user_id')) || ($status != 'Sudah Diajukan' && $status != 'Butuh Perbaikan')))
                                                                            //    $extra = $extra.' disabled="disabled"';
                                                                            
                                                                            echo form_dropdown('', $field['options'][$column_counter], '', $attributes);
                                                                        }
                                                                    ?>
                                                                
                                                                </td>
                                                        
                                                        <?php
                                                            }
                                                        ?>
                                                    
                                                    </tr>
                                            
                                            <?php
                                                }

                                                $counter = 0;

                                                foreach($transactions as &$transaction)
                                                {
                                                    $counter++;
                                            ?>
                                                    
                                                    <tr style="border-top: 3px solid black;">

                                                        <?php
                                                            $field['id'][3] = 'transaction_type['.$transaction['transaction_id'].']';
                                                            $field['id'][6] = 'notes['.$transaction['transaction_id'].']';
                                                            $field['id'][7] = 'debt_reference_code['.$transaction['transaction_id'].']';
                                                            $field['id'][8] = 'nominal['.$transaction['transaction_id'].']';
                                                            $field['id'][10] = 'approval_status['.$transaction['transaction_id'].']';

                                                            $field['onchange'][10] = 'setApprovalRequirement(this)';

                                                            $field['options'][10] = array(
                                                                'Unchecked' => 'Unchecked',
                                                                'Pending' => 'Pending',
                                                                'Approved' => 'Approved',
                                                                'Rejected' => 'Rejected'
                                                            );

                                                            $field['value'][3] = $transaction['transaction_type'];
                                                            $field['value'][6] = $transaction['notes'];
                                                            $field['value'][7] = $transaction['debt_reference_code'];
                                                            $field['value'][8] = $transaction['nominal'];
                                                            $field['value'][10] = $transaction['approval_status'];
                                                            
                                                            for($column_counter = 1;$column_counter < 12;$column_counter++)
                                                            {
                                                        ?>
                                                                <td style="padding: 0;text-align: center;"<?php if(!($column_counter == 2 || $column_counter == 4 || ($column_counter > 6 && $column_counter < 11))) echo ' rowspan="2"'; ?>>
                                                                    
                                                                    <?php
                                                                        if($column_counter == 1)
                                                                            echo $counter;
                                                                        else if($column_counter == 2)
                                                                            echo substr($transaction['submission_date'], -2).'/'.substr($transaction['submission_date'], 5, 2).'/'.substr($transaction['submission_date'], 0, 4);
                                                                        else if($column_counter > 2 && $column_counter < 11 && $column_counter != 4 && $column_counter != 5 && $column_counter != 9)
                                                                        {
                                                                            $attributes = array(
                                                                                    'class'                 => 'form-control',
                                                                                    'data-transaction-id'   => $transaction['transaction_id'],
                                                                                    'id'                    => $field['id'][$column_counter]
                                                                            );

                                                                            if(isset($field['onchange'][$column_counter]))
                                                                                $attributes['onchange'] = $field['onchange'][$column_counter];

                                                                            if($field['type'][$column_counter] == 'date' || $field['type'][$column_counter] == 'text' || $field['type'][$column_counter] == 'currency')
                                                                            {
                                                                                if($field['type'][$column_counter] == 'currency')
                                                                                    $attributes['class'] = $attributes['class'].' currency';
                                                                                
                                                                                if($field['type'][$column_counter] == 'date')
                                                                                    $attributes['type'] = 'date';
                                                                                
                                                                                $attributes['value'] = $field['value'][$column_counter];
                                                                                                        
                                                                                echo form_input($attributes);
                                                                            }
                                                                            else
                                                                            {
                                                                                if($field['type'][$column_counter] == 'select2')
                                                                                {
                                                                                    $attributes['class'] = $attributes['class'].' js-basic-single';
                                                                                    $attributes['style'] = 'width: 115px;';
                                                                                }
                                                                                
                                                                                if($logged_in_user['position'] == 'Staff' && $column_counter == 10)
                                                                                    $attributes['disabled'] = 'disabled';
                                                                                
                                                                                echo form_dropdown('', $field['options'][$column_counter], $field['value'][$column_counter], $attributes);
                                                                            }
                                                                        }
                                                                        else if($column_counter == 4)
                                                                        {
                                                                            $attributes = array(
                                                                                    'class'                 => 'form-control',
                                                                                    'data-transaction-id'   => $transaction['transaction_id']
                                                                            );
                                                                            
                                                                            $attributes['id'] = 'transaction_code['.$transaction['transaction_id'].']';

                                                                            if($transaction['transaction_type'] == 'IN: Manual' || $transaction['transaction_type'] == 'OUT: Manual')
                                                                                $attributes['style'] = 'display: inline;';
                                                                            else
                                                                            {
                                                                                $attributes['disabled'] = 'disabled';
                                                                                $attributes['style'] = 'display: none;';
                                                                            }
                                                                                
                                                                            $attributes['value'] = $transaction['transaction_code'];
                                                                                                        
                                                                            echo form_input($attributes);

                                                                            if(isset($attributes['disabled']))
                                                                                unset($attributes['disabled']);
                                                                            
                                                                            $attributes['id'] = 'event_id['.$transaction['transaction_id'].']';

                                                                            if($transaction['transaction_type'] == 'IN: Event')
                                                                                $attributes['style'] = 'display: inline;';
                                                                            else
                                                                            {
                                                                                $attributes['disabled'] = 'disabled';
                                                                                $attributes['style'] = 'display: none;';
                                                                            }

                                                                            $attributes['onchange'] = "setEventFundingSubmissionDetail(this, 'kegiatan/tambah_ubah/')";
                                                                                
                                                                            echo form_dropdown('', $events_users, $transaction['event_id'], $attributes);

                                                                            if(isset($attributes['disabled']))
                                                                                unset($attributes['disabled']);
                                                                            
                                                                            $attributes['id'] = 'funding_submission_id['.$transaction['transaction_id'].']';

                                                                            if($transaction['transaction_type'] == 'OUT: Pengajuan')
                                                                                $attributes['style'] = 'display: inline;';
                                                                            else
                                                                            {
                                                                                $attributes['disabled'] = 'disabled';
                                                                                $attributes['style'] = 'display: none;';
                                                                            }

                                                                            $attributes['onchange'] = "setEventFundingSubmissionDetail(this, 'keuangan/pengajuan/')";
                                                                                
                                                                            echo form_dropdown('', $funding_submissions_users_units, $transaction['funding_submission_id'], $attributes);
                                                                        }
                                                                        else if($column_counter == 5)
                                                                        {
                                                                            $attributes = array(
                                                                                    'class'                 => 'form-control',
                                                                                    'data-transaction-id'   => $transaction['transaction_id']
                                                                            );
                                                                                
                                                                            $attributes['id'] = 'account_number['.$transaction['transaction_id'].']';
                                                                            $attributes['value'] = $transaction['account_number'];
                                                                            $attributes['placeholder'] = 'No. Rekening';
                                                                                                        
                                                                            echo form_input($attributes);
                                                                                
                                                                            $attributes['id'] = 'bank['.$transaction['transaction_id'].']';
                                                                            $attributes['value'] = $transaction['bank'];
                                                                            $attributes['placeholder'] = 'Bank';
                                                                                                        
                                                                            echo form_input($attributes);
                                                                                
                                                                            $attributes['id'] = 'accountee['.$transaction['transaction_id'].']';
                                                                            $attributes['value'] = $transaction['accountee'];
                                                                            $attributes['placeholder'] = 'Atas Nama';
                                                                                                        
                                                                            echo form_input($attributes);
                                                                        }
                                                                        else if($column_counter == 11)
                                                                        {
                                                                            $attributes = array(
                                                                                'class'     => 'btn btn-primary',
                                                                                'content'   => 'Simpan',
                                                                                'onclick'   => 'saveTransaction(this.value)',
                                                                                'value'     => $transaction['transaction_id']
                                                                            );

                                                                            echo form_button($attributes);
                                                                        }
                                                                    ?>
                                                                
                                                                </td>
                                                        
                                                        <?php
                                                            }
                                                        ?>
                                                    
                                                    </tr>
                                                    <tr>
                                                        <td style="padding: 0;text-align: center;">
                                                            
                                                            <?php
                                                                $attributes = array(
                                                                        'class'                 => 'form-control',
                                                                        'data-transaction-id'   => $transaction['transaction_id'],
                                                                        'id'                    => 'transaction_date['.$transaction['transaction_id'].']',
                                                                        'type'                  => 'date',
                                                                        'value'                 => $transaction['transaction_date']
                                                                );
                                                                
                                                                echo form_input($attributes);
                                                            ?>
                                                        
                                                        </td>
                                                        
                                                        <td id="event-funding-submission-detail[<?php echo $transaction['transaction_id']; ?>]" style="padding: 0;text-align: center;">
                                                            
                                                            <?php
                                                                if($transaction['transaction_type'] == 'IN: Manual' || $transaction['transaction_type'] == 'OUT: Manual')
                                                                {
                                                                    $attributes = array(
                                                                            'class' => 'form-control',
                                                                            'id'    => 'unit_id['.$transaction['transaction_id'].']'
                                                                    );

                                                                    //if($subheader_counter < 5 && (($applicant_user_id != $this->session->userdata('user_id')) || ($status != 'Sudah Diajukan' && $status != 'Butuh Perbaikan')))
                                                                    //    $extra = $extra.' disabled="disabled"';
                                                                    
                                                                    echo form_dropdown('', $units, $transaction['unit_id'], $attributes);
                                                                }
                                                                else if($transaction['transaction_type'] == 'IN: Event')
                                                                {
                                                            ?>

                                                                    <a href="<?php echo base_url('kegiatan/tambah_ubah/'.$transaction['event_id']); ?>" target="_blank">Detail</a>
                                                            
                                                            <?php
                                                                }
                                                                else// if($transaction['transaction_type'] == 'OUT: Pengajuan')
                                                                {
                                                            ?>

                                                                    <a href="<?php echo base_url('keuangan/pengajuan/'.$transaction['funding_submission_id']); ?>" target="_blank">Detail</a>
                                                            
                                                            <?php
                                                                }
                                                            ?>
                                                        
                                                        </td>
                                                
                                                        <?php
                                                            $field['id'][7] = 'credit_reference_code['.$transaction['transaction_id'].']';
                                                            
                                                            for($column_counter = 7;$column_counter < 10;$column_counter++)
                                                            {
                                                        ?>
                                                                <td style="padding: 0;text-align: center;"<?php if($column_counter == 9) echo ' id="credit-nominal-data['.$transaction['transaction_id'].']"'; ?>>
                                                                    
                                                                    <?php
                                                                        if($column_counter == 7)
                                                                        {
                                                                            $attributes = array(
                                                                                    'class' => 'js-basic-single',
                                                                                    'id'    => $field['id'][$column_counter],
                                                                                    'style' => 'width: 115px;'
                                                                            );

                                                                            //if($subheader_counter < 5 && (($applicant_user_id != $this->session->userdata('user_id')) || ($status != 'Sudah Diajukan' && $status != 'Butuh Perbaikan')))
                                                                            //    $extra = $extra.' disabled="disabled"';
                                                                            
                                                                            echo form_dropdown('', $field['options'][$column_counter], $transaction['credit_reference_code'], $attributes);
                                                                        }
                                                                        else if($column_counter == 9)
                                                                            echo $transaction['nominal'];
                                                                    ?>
                                                                
                                                                </td>
                                                        
                                                        <?php
                                                            }
                                                        ?>

                                                        <td style="padding: 0;text-align: center;">
                                                            
                                                            <?php
                                                                $attributes = array(
                                                                        'data-transaction-id'   => $transaction['transaction_id']
                                                                );
                                                                
                                                                $attributes['class'] = 'form-control';
                                                                $attributes['id'] = 'planned_transfer_date['.$transaction['transaction_id'].']';
                                                                $attributes['type'] = 'date';
                                                                
                                                                if($logged_in_user['position'] == 'Staff')
                                                                    $attributes['disabled'] = 'disabled';

                                                                if($transaction['approval_status'] == 'Pending')
                                                                    $attributes['style'] = 'display: inline;';
                                                                else
                                                                {
                                                                    $attributes['disabled'] = 'disabled';
                                                                    $attributes['style'] = 'display: none;';
                                                                }
                                                                    
                                                                $attributes['value'] = $transaction['planned_transfer_date'];
                                                                                            
                                                                echo form_input($attributes);

                                                                if(isset($attributes['disabled']))
                                                                    unset($attributes['disabled']);
                                                                
                                                                unset($attributes['class']);

                                                                if($logged_in_user['position'] == 'Staff' && $column_counter == 13)
                                                                    $attributes['disabled'] = 'disabled';
                                                                
                                                                $attributes['id'] = 'transfer_proof['.$transaction['transaction_id'].']';
                                                                $attributes['multiple'] = 'multiple';

                                                                if($transaction['approval_status'] == 'Approved')
                                                                {
                                                                    $transfer_proofs = explode(',', $transaction['transfer_proof']);

                                                                    $transfer_proof_counter = 0;

                                                                    foreach($transfer_proofs as &$transfer_proof)
                                                                    {
                                                                        $transfer_proof_counter++;
                                                            ?>
                                                                        
                                                                        <a class="<?php echo 'transfer_proof_link['.$transaction['transaction_id'].']'; ?>" href="<?php echo base_url('uploads/finance/journal/transfer_proofs/'.$transfer_proof); ?>" target="_blank" style="display: block;">Bukti transfer <?php echo $transfer_proof_counter; ?></a>
                                                            
                                                            <?php
                                                                    }
                                                                    
                                                                    $attributes['style'] = 'display: inline;width: 187px;';
                                                                }
                                                                else
                                                                {
                                                                    $attributes['disabled'] = 'disabled';
                                                                    $attributes['style'] = 'display: none;width: 187px;';
                                                                }
                                                                    
                                                                echo form_upload($attributes);

                                                                if(isset($attributes['disabled']))
                                                                    unset($attributes['disabled']);
                                                                
                                                                $attributes['class'] = 'form-control';
                                                                $attributes['id'] = 'rejection_reason['.$transaction['transaction_id'].']';
                                                                $attributes['placeholder'] = 'Alasan reject';
                                                                $attributes['type'] = 'text';
                                                                
                                                                if($logged_in_user['position'] == 'Staff' && $column_counter == 13)
                                                                    $attributes['disabled'] = 'disabled';

                                                                if($transaction['approval_status'] == 'Rejected')
                                                                    $attributes['style'] = 'display: inline;';
                                                                else
                                                                {
                                                                    $attributes['disabled'] = 'disabled';
                                                                    $attributes['style'] = 'display: none;';
                                                                }
                                                                    
                                                                $attributes['value'] = $transaction['rejection_reason'];
                                                                                            
                                                                echo form_input($attributes);
                                                            ?>
                                                        
                                                        </td>
                                                    
                                                    </tr>
                                            
                                            <?php
                                                }
                                            ?>
                                        
                                        </tbody>
                                    </table>
                                </div>
                                
                                <?php
                                    if($page_count > 1)
                                    {
                                ?>
                                        
                                        <ul class="body pagination pagination-primary">
                                        
                                            <?php
                                                if($page_number > 1)
                                                {
                                            ?>
                                                    
                                                    <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo ($page_number - 1); ?>)">Sebelumnya</a></li>
                                            
                                            <?php
                                                    for($page_counter = $previous_page_count; $page_counter > 0; $page_counter--)
                                                    {
                                                        $previous_page_number = $page_number - $page_counter;
                                            ?>

                                                            <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo $previous_page_number; ?>)"><?php echo $previous_page_number; ?></a></li>
                                            
                                            <?php
                                                    }
                                                }

                                                if($page_count > 1)
                                                {
                                            ?>
                                                    
                                                    <li class="page-item active"><a class="page-link" href="javascript:void(0);"><?php echo $page_number; ?></a></li>
                                            
                                            <?php
                                                    if($page_count > $page_number)
                                                    {
                                                        for($page_counter = 1; $page_counter <= $next_page_count; $page_counter++)
                                                        {
                                                            $next_page_number = $page_number + $page_counter;
                                            ?>

                                                            <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo $next_page_number; ?>)"><?php echo $next_page_number; ?></a></li>
                                            
                                            <?php
                                                        }
                                            ?>

                                                        <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo ($page_number + 1); ?>)">Selanjutnya</a></li>
                                            
                                            <?php
                                                    }
                                                }
                                            ?>
                                        
                                        </ul>
                                
                                <?php
                                    }
                                ?>