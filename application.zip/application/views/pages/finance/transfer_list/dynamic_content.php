                                <div class="body">
                                    <div class="row clearfix">
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Filter berdasarkan', 'filter-column-select', 'class="control-label"');
                                                    echo form_dropdown('filter_column', $filter_columns , $filter_column, 'class="form-control" id="filter-column-select" onchange="setFilterValue(this.value)"');
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label($label, 'filter-value-select', 'class="control-label" id="filter-value-label"');
                                                    echo form_dropdown('filter_value', $filter_values , $filter_value, 'class="form-control" id="filter-value-select"');
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Urutkan berdasarkan', 'ordering-column-select', 'class="control-label"');

                                                    $ordering_columns = array(
                                                        'payment_deadline' => 'Deadline Pembayaran',
                                                        'submission_date' => 'Timestamp Pengajuan',
                                                    );

                                                    echo form_dropdown('ordering_column', $ordering_columns , $ordering_column, 'class="form-control" id="ordering-column-select"');
                                                ?>
                                            
                                            </div>
                                        </div>
                                    </div>

                                    <?php echo form_button('', 'Cari', 'class="btn btn-primary" id="search-button" onclick="getDynamicContent(1)"'); ?>
                                
                                </div>

                                <div class="body table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>TIMESTAMP</th>
                                                <th><?php echo wordwrap('NAMA PEMOHON', 4, "<br />"); ?></th>
                                                <th><?php echo wordwrap('KODE PEMBIAYAAN', 4, "<br />"); ?></th>
                                                <th>NOMINAL</th>
                                                <th><?php echo wordwrap('NOMOR REKENING TUJUAN', 5, "<br />"); ?></th>
                                                <th><?php echo wordwrap('BANK TUJUAN', 4, "<br />"); ?></th>
                                                <th><?php echo wordwrap('ATAS NAMA REKENING', 4, "<br />"); ?></th>
                                                <th><?php echo wordwrap('BERITA TRANSFER', 6, "<br />"); ?></th>
                                                <th><?php echo wordwrap('DEADLINE PEMBAYARAN', 8, "<br />"); ?></th>
                                                <th><?php echo wordwrap('PENGGUNAAN UNTUK UNIT', 4, "<br />"); ?></th>
                                                <th>OPERASI</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php
                                                $counter = 0;

                                                foreach($funding_submissions_users_units as &$funding_submission_user_unit)
                                                {
                                                    $counter++;
                                            ?>
                                                    
                                                    <tr>
                                                        <th scope="row"><?php echo ((5 * ($page_number - 1)) + $counter); ?></th>
                                                        <td><?php echo wordwrap(substr($funding_submission_user_unit['submission_date'], -2).'/'.substr($funding_submission_user_unit['submission_date'], 5, 2).'/'.substr($funding_submission_user_unit['submission_date'], 0, 4), 10, "<br />"); ?></td>
                                                        <td><?php echo wordwrap($funding_submission_user_unit['applicant_name'], 4, "<br />"); ?></td>
                                                        <td><?php echo wordwrap($funding_submission_user_unit['financing_code'], 4, "<br />"); ?></td>
                                                        <td><?php echo wordwrap('Rp'.number_format($funding_submission_user_unit['nominal'], 0, ",", ".").',00', 12, "<br />"); ?></td>
                                                        <td><?php echo wordwrap($funding_submission_user_unit['account_number'], 5, "<br />"); ?></td>
                                                        <td><?php echo wordwrap($funding_submission_user_unit['bank'], 4, "<br />"); ?><?php echo $funding_submission_user_unit['bank']; ?></td>
                                                        <td><?php echo wordwrap($funding_submission_user_unit['accountee'], 4, "<br />"); ?></td>
                                                        <td><?php echo wordwrap($funding_submission_user_unit['transfer_information'], 6, "<br />"); ?></td>
                                                        <td><?php echo wordwrap(substr($funding_submission_user_unit['payment_deadline'], -2).'/'.substr($funding_submission_user_unit['payment_deadline'], 5, 2).'/'.substr($funding_submission_user_unit['payment_deadline'], 0, 4), 10, "<br />"); ?></td>
                                                        <td><?php echo wordwrap($funding_submission_user_unit['unit_name'], 4, "<br />"); ?></td>
                                                        <td><a href="<?php echo base_url('keuangan/pengajuan/'.$funding_submission_user_unit['funding_submission_id']); ?>" class="btn btn-success btn-sm" style="margin-bottom: 3px;">Lihat Detail</a></td>
                                                    </tr>
                                            
                                            <?php
                                                }
                                            ?>
                                        
                                        </tbody>
                                    </table>
                                </div>
                                
                                <?php
                                    if($page_count > 1)
                                    {
                                ?>
                                        
                                        <ul class="body pagination pagination-primary">
                                        
                                            <?php
                                                if($page_number > 1)
                                                {
                                            ?>
                                                    
                                                    <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo ($page_number - 1); ?>)">Sebelumnya</a></li>
                                            
                                            <?php
                                                    for($page_counter = $previous_page_count; $page_counter > 0; $page_counter--)
                                                    {
                                                        $previous_page_number = $page_number - $page_counter;
                                            ?>

                                                            <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo $previous_page_number; ?>)"><?php echo $previous_page_number; ?></a></li>
                                            
                                            <?php
                                                    }
                                                }

                                                if($page_count > 1)
                                                {
                                            ?>
                                                    
                                                    <li class="page-item active"><a class="page-link" href="javascript:void(0);"><?php echo $page_number; ?></a></li>
                                            
                                            <?php
                                                    if($page_count > $page_number)
                                                    {
                                                        for($page_counter = 1; $page_counter <= $next_page_count; $page_counter++)
                                                        {
                                                            $next_page_number = $page_number + $page_counter;
                                            ?>

                                                            <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo $next_page_number; ?>)"><?php echo $next_page_number; ?></a></li>
                                            
                                            <?php
                                                        }
                                            ?>

                                                        <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo ($page_number + 1); ?>)">Selanjutnya</a></li>
                                            
                                            <?php
                                                    }
                                                }
                                            ?>
                                        
                                        </ul>
                                
                                <?php
                                    }
                                ?>