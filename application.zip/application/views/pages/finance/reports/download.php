            <div id="main-content">
                <div class="container">
                    <div class="block-header">
                        <div class="row">
                            <div class="col-lg-5 col-md-8 col-sm-12">
                                <h2>Laporan Laba Rugi & Neraca</h2>
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>"><i class="icon-home"></i></a></li>                            
                                    <li class="breadcrumb-item">Keuangan</li>
                                    <li class="breadcrumb-item active">
                                        <a href="javascript:void(0);">Laporan Laba Rugi & Neraca</a>
                                    </li>
                                </ul>
                            </div>            
                            <!--<div class="col-lg-7 col-md-4 col-sm-12 text-right">
                                <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                    <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#00c5dc"
                                        data-fill-Color="transparent">3,5,1,6,5,4,8,3</div>
                                    <span>Visitors</span>
                                </div>
                                <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                    <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#f4516c"
                                        data-fill-Color="transparent">4,6,3,2,5,6,5,4</div>
                                    <span>Visits</span>
                                </div>
                            </div>-->
                        </div>
                    </div>
                    
                    <div class="row clearfix">
                        <div class="col-lg-12">
                            <div class="card" id="card">
                                <div class="body">
                                    
                                    <?php echo form_open('', 'id="report-form"'); ?>

                                        <div class="row clearfix">
                                            <div class="col-lg-6 col-md-12">
                                                <div class="form-group">
                                                                
                                                    <?php
                                                        echo form_label('Unit Kerja', 'unit-id-select', 'class="control-label"');
                                                        echo form_dropdown('unit_id', $units , '', 'class="form-control" id="unit-id-select"');
                                                    ?>
                                                
                                                </div>
                                            </div>
                                            <div class="col-lg-6 col-md-12">
                                                <div class="form-group">
                                                                
                                                    <?php
                                                        echo form_label('Tahun Pembukuan', 'transaction-year-select', 'class="control-label"');

                                                        for($option_counter = date('Y'); $option_counter >= 2020; $option_counter--)
                                                        {
                                                            $accounting_years[$option_counter] = $option_counter;
                                                        }

                                                        echo form_dropdown('transaction_year', $accounting_years , '', 'class="form-control" id="transaction-year-select"');
                                                    ?>
                                                
                                                </div>
                                            </div>
                                        </div>

                                    <?php
                                            $data = array(
                                                    'name'          => 'submit',
                                                    'value'         => 'dikirim',
                                                    'type'          => 'submit',
                                                    'class'         => 'btn btn-primary',
                                                    'content'       => 'Unduh'
                                            );

                                            echo form_button($data);
                                        echo form_close();
                                    ?>
                                
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>