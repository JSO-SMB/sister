                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>KODE</th>
                                                <th>PERUSAHAAN KLIEN</th>
                                                <th>OMZET RAB</th>
                                                <th>JUMLAH BAYAR</th>
                                                <th>KEKURANGAN</th>
                                                <th>RENCANA BAYAR</th>
                                                <th>DETAIL</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php
                                                $counter = 0;
                                                $start_month = '';
                                                $total_turnover = 0;
                                                $total_revenue = 0;
                                                $total_credit = 0;

                                                foreach($projects as &$project)
                                                {
                                                    $revenue = $project['revenue'];
                                                    $turnover = $project['clients_number'] * $project['price'];
                                                    
                                                    if((($revenue / $turnover) * 100) < 90)
                                                    {
                                                        $counter++;

                                                        if(substr($project['start_date'], 0, 7) == $start_month)
                                                            $project_number++;
                                                        else
                                                            $project_number = 1;
                                                        
                                                        $total_turnover = $total_turnover + $turnover;
                                                        $total_revenue = $total_revenue + $revenue;
                                            ?>
                                                        
                                                        <tr>
                                                            <th scope="row" style="vertical-align: middle;"><?php echo $counter; ?></th>
                                                            <td><?php echo $project['event_name'].' ('.substr($project['start_date'], -2).'/'.substr($project['start_date'], 5, 2).'/'.substr($project['start_date'], 0, 4).' - '.substr($project['end_date'], -2).'/'.substr($project['end_date'], 5, 2).'/'.substr($project['end_date'], 0, 4).') '.$project['unit_name'].' by '.$project['marketing_name']; ?></td>
                                                            <td><?php echo $project['company']; ?></td>
                                                            <td style="text-align: right;"><?php echo 'Rp'.number_format($turnover, 0, ",", ".").',00'; ?></td>
                                                            <td style="text-align: right;"><?php echo 'Rp'.number_format($revenue, 0, ",", ".").',00'; ?></td>
                                                            <td style="text-align: right;"><?php echo 'Rp'.number_format(($turnover - $revenue), 0, ",", ".").',00'; ?></td>
                                                            <td><?php echo substr($project['payment_plan'], -2).'/'.substr($project['payment_plan'], 5, 2).'/'.substr($project['payment_plan'], 0, 4); ?></td>
                                                            <td style="text-align: center;">
                                                                <a class="btn btn-primary btn-sm" href="<?php echo base_url('projects_management/detail/'.$project['event_id'].'/invoice/'.$project_number); ?>" target="_blank">Invoice</a>
                                                                
                                                                <?php
                                                                    if($project['approval_status'] == 'Disetujui')
                                                                    {
                                                                ?>
                                                                        
                                                                        <a class="btn btn-dark btn-sm" href="<?php echo base_url('projects_management/detail/'.$project['event_id'].'/cashflow'); ?>" style="margin-top: 3px;" target="_blank">Cashflow</a>
                                                                
                                                                <?php
                                                                    }
                                                                ?>
                                                            
                                                            </td>
                                                        </tr>
                                            
                                            <?php
                                                    }
                                                }
                                            ?>
                                        
                                        </tbody>
                                        <tfoot>
                                                <tr>
                                                    <td colspan="3" style="text-align: right;">Total</td>
                                                    <td style="text-align: right;"><?php echo 'Rp'.number_format($total_turnover, 0, ",", ".").',00'; ?></td>
                                                    <td style="text-align: right;"><?php echo 'Rp'.number_format($total_revenue, 0, ",", ".").',00'; ?></td>
                                                    <td style="text-align: right;"><?php echo 'Rp'.number_format(($total_turnover - $total_revenue), 0, ",", ".").',00'; ?></td>
                                                    <td colspan="2"></td>
                                                </tr>
                                        </tfoot>