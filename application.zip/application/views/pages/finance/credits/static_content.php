            <div id="main-content">
                <div class="container">
                    <div class="block-header">
                        <div class="row">
                            <div class="col-lg-5 col-md-8 col-sm-12">
                                <h2>Piutang</h2>
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>"><i class="icon-home"></i></a></li>
                                    <li class="breadcrumb-item"><a href="javascript:void(0);">Keuangan</a></li>
                                    <li class="breadcrumb-item active">
                                        <a href="javascript:void(0);">Piutang</a>
                                    </li>
                                </ul>
                            </div>            
                            <!--<div class="col-lg-7 col-md-4 col-sm-12 text-right">
                                <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                    <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#00c5dc"
                                        data-fill-Color="transparent">3,5,1,6,5,4,8,3</div>
                                    <span>Visitors</span>
                                </div>
                                <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                    <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#f4516c"
                                        data-fill-Color="transparent">4,6,3,2,5,6,5,4</div>
                                    <span>Visits</span>
                                </div>
                            </div>-->
                        </div>
                    </div>
                    
                    <div class="row clearfix">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="body">
                                    <div class="row clearfix">
                                        <div class="col-lg-3 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Nama unit', 'unit-id-select', 'class="control-label"');

                                                    $attributes = array(
                                                            'class' => 'form-control',
                                                            'id'    => 'unit-id-select'
                                                    );
                                                    
                                                    echo form_dropdown('unit_id', $units, $unit_id, $attributes);
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Status', 'project-status-select', 'class="control-label"');

                                                    $project_statuses = array(
                                                        ''              => 'Semua Status',
                                                        'Belum Running' => 'Belum Running',
                                                        'Sudah Running' => 'Sudah Running'
                                                    );

                                                    $attributes = array(
                                                            'class' => 'form-control',
                                                            'id'    => 'project-status-select'
                                                    );
                                                    
                                                    echo form_dropdown('project_status', $project_statuses, '', $attributes);
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Bulan & Tahun Awal', 'beginning-start-date-input', 'class="control-label"');

                                                    $attributes = array(
                                                            'class' => 'form-control',
                                                            'id'    => 'beginning-start-date-input',
                                                            'name'  => 'beginning_start_date',
                                                            'type'  => 'month',
                                                            'value' => date('Y-m')
                                                    );
                                                    
                                                    echo form_input($attributes);
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Bulan & Tahun Akhir', 'ending-start-date-input', 'class="control-label"');

                                                    $attributes = array(
                                                            'class' => 'form-control',
                                                            'id'    => 'ending-start-date-input',
                                                            'name'  => 'ending_start_date',
                                                            'type'  => 'month',
                                                            'value' => date('Y-m')
                                                    );
                                                    
                                                    echo form_input($attributes);
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <!--<div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Urutkan berdasarkan', 'ordering-column-select', 'class="control-label"');

                                                    $ordering_columns = array(
                                                        'transaction_date' => 'Tanggal transaksi',
                                                        'submission_date' => 'Tanggal submit',
                                                    );

                                                    echo form_dropdown('ordering_column', $ordering_columns , $ordering_column, 'class="form-control" id="ordering-column-select"');
                                                ?>
                                            
                                            </div>
                                        </div>-->
                                    </div>

                                    <?php echo form_button('', 'Cari', 'class="btn btn-primary" id="search-button" onclick="getResponse()"'); ?>
                                
                                </div>

                                <div class="body table-responsive">
                                    <table class="table table-bordered" id="credits-table"></table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <?php
                $id[1] = 'controller-link';
                //$id[2] = 'user-status';

                $value[1] = base_url('keuangan/');
                //$value[2] = $user_status;

                for($input_counter = 1; $input_counter < 2; $input_counter++)
                {
                    $data = array(
                            'type'  => 'hidden',
                            'id'    => $id[$input_counter],
                            'value' => $value[$input_counter]
                    );
                    
                    echo form_input($data);
                }
            ?>