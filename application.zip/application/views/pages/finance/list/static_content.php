            <div id="main-content">
                <div class="container">
                    <div class="block-header">
                        <div class="row">
                            <div class="col-lg-5 col-md-8 col-sm-12">
                                <h2>Data Vendor</h2>
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>"><i class="icon-home"></i></a></li>                            
                                    <li class="breadcrumb-item">Vendor</li>
                                    <li class="breadcrumb-item active">
                                        <a href="javascript:void(0);">Data Vendor</a>
                                    </li>
                                </ul>
                            </div>            
                            <!--<div class="col-lg-7 col-md-4 col-sm-12 text-right">
                                <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                    <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#00c5dc"
                                        data-fill-Color="transparent">3,5,1,6,5,4,8,3</div>
                                    <span>Visitors</span>
                                </div>
                                <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                    <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#f4516c"
                                        data-fill-Color="transparent">4,6,3,2,5,6,5,4</div>
                                    <span>Visits</span>
                                </div>
                            </div>-->
                        </div>
                    </div>
                    
                    <div class="row clearfix">
                        <div class="col-lg-12">
                            <div class="card" id="card"></div>
                        </div>
                    </div>

                </div>
            </div>

            <?php
                $id[1] = 'controller-link';
                //$id[2] = 'status';

                $value[1] = base_url('vendor/');
                //$value[2] = $status;

                for($input_counter = 1; $input_counter < 2; $input_counter++)
                {
                    $data = array(
                            'type'  => 'hidden',
                            'id'    => $id[$input_counter],
                            'value' => $value[$input_counter]
                    );
                    
                    echo form_input($data);
                }
            ?>