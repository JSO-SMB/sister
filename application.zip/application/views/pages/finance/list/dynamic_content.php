                                <div class="body">
                                    <div class="row clearfix">
                                        <div class="col-lg-6 col-md-12">
                                            <div class="form-group">
                                                            
                                                <?php
                                                    echo form_label('Nama Vendor', 'name-input', 'class="control-label"');
                                                    
                                                    $data = array(
                                                            'name'			=> 'name',
                                                            'value'			=> $query,
                                                            'class'			=> 'form-control',
                                                            'id'            => 'name-input',
                                                            'placeholder'	=> 'Kosongkan untuk menampilkan semua data'
                                                    );
                                                    
                                                    echo form_input($data);
                                                ?>
                                            
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-12"></div>
                                    </div>

                                    <?php echo form_button('', 'Cari', 'class="btn btn-primary" id="search-button" onclick="getDynamicContent(1)"'); ?>
                                
                                </div>

                                <div class="body table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>NAMA</th>
                                                <th>NOMOR TELEPON</th>
                                                <th>KOTA</th>
                                                <th>ALAMAT</th>
                                                <th>JENIS</th>
                                                <th>OPERASI</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php
                                                $counter = 0;

                                                foreach($users_vendors as &$user_vendor)
                                                {
                                                    $counter++;
                                            ?>
                                                    
                                                    <tr>
                                                        <th scope="row"><?php echo ((5 * ($page_number - 1)) + $counter); ?></th>
                                                        <td><?php echo $user_vendor['name']; ?></td>
                                                        <td><?php echo $user_vendor['phone_number']; ?></td>
                                                        <td><?php echo $user_vendor['city']; ?></td>
                                                        <td><?php echo $user_vendor['address']; ?></td>
                                                        <td><?php echo $user_vendor['type']; ?></td>
                                                        <td><a href="<?php echo base_url('vendor/tambah_ubah/'.$user_vendor['vendor_id']); ?>" class="btn btn-success btn-sm" style="margin-bottom: 3px;">Lihat Detail</a></td>
                                                    </tr>
                                            
                                            <?php
                                                }
                                            ?>
                                        
                                        </tbody>
                                    </table>
                                </div>
                                
                                <?php
                                    if($page_count > 1)
                                    {
                                ?>
                                        
                                        <ul class="body pagination pagination-primary">
                                        
                                            <?php
                                                if($page_number > 1)
                                                {
                                            ?>
                                                    
                                                    <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo ($page_number - 1); ?>)">Sebelumnya</a></li>
                                            
                                            <?php
                                                    for($page_counter = $previous_page_count; $page_counter > 0; $page_counter--)
                                                    {
                                                        $previous_page_number = $page_number - $page_counter;
                                            ?>

                                                            <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo $previous_page_number; ?>)"><?php echo $previous_page_number; ?></a></li>
                                            
                                            <?php
                                                    }
                                                }

                                                if($page_count > 1)
                                                {
                                            ?>
                                                    
                                                    <li class="page-item active"><a class="page-link" href="javascript:void(0);"><?php echo $page_number; ?></a></li>
                                            
                                            <?php
                                                    if($page_count > $page_number)
                                                    {
                                                        for($page_counter = 1; $page_counter <= $next_page_count; $page_counter++)
                                                        {
                                                            $next_page_number = $page_number + $page_counter;
                                            ?>

                                                            <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo $next_page_number; ?>)"><?php echo $next_page_number; ?></a></li>
                                            
                                            <?php
                                                        }
                                            ?>

                                                        <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="getDynamicContent(<?php echo ($page_number + 1); ?>)">Selanjutnya</a></li>
                                            
                                            <?php
                                                    }
                                                }
                                            ?>
                                        
                                        </ul>
                                
                                <?php
                                    }
                                ?>