<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	//use PhpOffice\PhpSpreadsheet\Spreadsheet;
	//use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
	
	class Klien extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}
        }
        
        public function tambah_ubah($client_id = 0)
	    {
	    	if($this->input->post('submit') != NULL)
			{
				$this->load->model('client_model');
				
				$this->client_model->create_update_client($client_id);

                $this->session->set_flashdata('operation_result', 'client data saved');
                
				if($client_id == 0)
                    redirect('klien/tambah_ubah');
                else
                    redirect('klien/tambah_ubah/'.$client_id);
			}
			else
			{
				$this->load->model('employee_model');
				$this->load->helper('form');

                $data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

				require 'Options.php';

				if($client_id == '')
				{
					if($data['logged_in_user']['division'] != 'MARKETING')
						redirect();
					
					$header = 'Klien Baru';
					
                    $data['greeting'] = 'Bapak';
                    $data['name'] = '';
                    $data['email_address'] = '';
                    $data['mobile_number'] = '62';
                    $data['whatsapp'] = 'Ya';
                    $data['company'] = '';
                    $data['sector'] = 'Instansi Pemerintah';
                    $data['address'] = '';
                    $data['phone_number'] = '62';
                    $data['position'] = '';
                    $data['boss'] = '';
                    $data['hrd'] = '';
                    $data['marketing'] = 'WA, Email';
				}
				else
				{
					if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'MARKETING' && $data['logged_in_user']['division'] != 'IT')
						redirect();
					
					$this->load->model('client_model');
                    
                    $header = 'Ubah Data Klien';
					
                    $client = $this->client_model->read_clients($client_id);

					$data['greeting'] = $client['greeting'];
                    $data['name'] = $client['name'];
                    $data['email_address'] = $client['email_address'];
                    $data['mobile_number'] = $client['mobile_number'];
                    $data['whatsapp'] = $client['whatsapp'];
                    $data['company'] = $client['company'];
                    $data['sector'] = explode(',', $client['sector']);
                    $data['address'] = $client['address'];
                    $data['phone_number'] = $client['phone_number'];
                    $data['position'] = $client['position'];
                    $data['boss'] = $client['boss'];
                    $data['hrd'] = $client['hrd'];
                    $data['marketing'] = $client['marketing'];
				}
                    
				$data['title'] = ':: Sister JSO :: '.$header;
				
				$data['vendor_css_links'] = array(
					'bootstrap/css/bootstrap.min.css',
					'font-awesome/css/font-awesome.min.css',
					'animate-css/animate.min.css',
					'bootstrap-multiselect/bootstrap-multiselect.css',
					'multi-select/css/multi-select.css',
					'bootstrap-datepicker/css/bootstrap-datepicker3.min.css',
					'toastr/toastr.min.css'
                );
				
                $data['header'] = $header;
				$data['sectors'] = $sectors;
                
				$data['js_links'] = array(
					'assets/bundles/libscripts.bundle.js',
					'assets/bundles/vendorscripts.bundle.js',
					'vendor/bootstrap-colorpicker/js/bootstrap-colorpicker.js',
					'vendor/jquery-inputmask/jquery.inputmask.bundle.js',
					'vendor/jquery.maskedinput/jquery.maskedinput.min.js',
					'vendor/multi-select/js/jquery.multi-select.js',
					'vendor/bootstrap-multiselect/bootstrap-multiselect.js',
					'vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js',
					'vendor/toastr/toastr.js',
					'assets/bundles/mainscripts.bundle.js',
					'assets/js/pages/forms/advanced-form-elements.js',
					'assets/js/pages/client/create_update.js'
				);

				// Render view on main layout
				$this->load->view('templates/dashboard/top', $data);
				$this->load->view('pages/clients/create_update', $data);
				$this->load->view('templates/dashboard/bottom', $data);
			}
	    }

		public function daftar($category = 'general')
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->helper('form');

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');
			
			if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'MARKETING' && $data['logged_in_user']['division'] != 'IT')
				redirect();

			if($category == 'general')
				$data['title'] = ':: Sister JSO :: Data Klien';
			else
				$data['title'] = ':: Sister JSO :: Data Klien Per CV';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);
			
			$data['category'] = $category;
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'assets/js/pages/client/list.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/clients/list/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		public function data($page_number, $category, $query = '')
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('client_model');
			$this->load->helper('form');

			$data['query'] = urldecode($query);

            if($category == 'general')
                $join_tables_list = '';
            else
            {
				$this->load->model('unit_model');
				
				$join_tables_list = 'contracts';
				
				$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
				
				foreach($unit_list as &$unit)
				{
					$units[$unit['unit_id']] = $unit['name'];
				}
	
				$data['units'] = $units;
			}
            
            $data['clients'] = $this->client_model->read_clients(0, 'result_array', urldecode($query), $category, $page_number, $join_tables_list);
			
			$data['page_number'] = $page_number;
            $data['category'] = $category;
            
            $page_count = ceil($this->client_model->read_clients(0, 'num_rows', urldecode($query), $category, 0, $join_tables_list) / 5);

			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				if($page_count > 10)
				{
					if($page_number > 6)
					{
						if(($page_count - $page_number) >= 4)
							$next_page_count = 4;
						else
							$next_page_count = $page_count - $page_number;
						
						$previous_page_count = 9 - $next_page_count;
					}
					else
					{
						$previous_page_count = $page_number - 1;
						$next_page_count = 9 - $previous_page_count;
					}
				}
				else
				{
					$previous_page_count = $page_number - 1;
					$next_page_count = $page_count - $page_number;
				}

				$data['previous_page_count'] = $previous_page_count;
				$data['next_page_count'] = $next_page_count;
			}

			echo $this->load->view('pages/clients/list/dynamic_content', $data, TRUE);
	    }

		/*public function ekspor()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('client_model');

			$spreadsheet = new Spreadsheet();
			
			$sheet = $spreadsheet->getActiveSheet();

			$sheet->setCellValue('A1', 'Nomor');
			$sheet->setCellValue('B1', 'Unit');
            $sheet->setCellValue('C1', 'Marketing');
            $sheet->setCellValue('D1', 'Nama');
            $sheet->setCellValue('E1', 'Alamat email');
            $sheet->setCellValue('F1', 'No. HP');
            $sheet->setCellValue('G1', 'Apakah nomor HP sekaligus nomor WA?');
            $sheet->setCellValue('H1', 'Perusahaan');
            $sheet->setCellValue('I1', 'Bidang Perusahaan');
            $sheet->setCellValue('J1', 'Alamat');
            $sheet->setCellValue('K1', 'No. Kantor');
            $sheet->setCellValue('L1', 'Jabatan/Posisi');
            $sheet->setCellValue('M1', 'Nama Atasan');
            $sheet->setCellValue('N1', 'Nama HRD');
            $sheet->setCellValue('O1', 'Foll Up Training Terakhir');
            $sheet->setCellValue('P1', 'Tanggal Komunikasi Terakhir');
            $sheet->setCellValue('Q1', 'Keterangan Terakhir');
            $sheet->setCellValue('R1', 'Pemasaran');

            $users_contracts_companies_clients_progress = $this->client_model->read_clients(0, 'result_array', '', 'general', 0, 'users', ', clients.name as client_name, users.name as marketing_name, clients.phone_number as company_phone_number, clients.email_address as client_email_address, clients.address as company_address');
            
			$number = 1;

			foreach($users_contracts_companies_clients_progress as &$user_contract_company_client_progress)
			{
				$sheet->setCellValue('A'.($number + 1), $number);
				$sheet->setCellValue('B'.($number + 1), 'PT JSO SMB');
                $sheet->setCellValue('C'.($number + 1), $user_contract_company_client_progress['marketing_name']);
                $sheet->setCellValue('D'.($number + 1), $user_contract_company_client_progress['greeting'].' '.$user_contract_company_client_progress['client_name']);
                $sheet->setCellValue('E'.($number + 1), $user_contract_company_client_progress['client_email_address']);
                $sheet->setCellValueExplicit('F'.($number + 1), $user_contract_company_client_progress['mobile_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
                $sheet->setCellValue('G'.($number + 1), $user_contract_company_client_progress['whatsapp']);
                $sheet->setCellValue('H'.($number + 1), $user_contract_company_client_progress['company']);
                $sheet->setCellValue('I'.($number + 1), $user_contract_company_client_progress['sector']);
                $sheet->setCellValue('J'.($number + 1), $user_contract_company_client_progress['company_address']);
                $sheet->setCellValueExplicit('K'.($number + 1), $user_contract_company_client_progress['company_phone_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
                $sheet->setCellValue('L'.($number + 1), $user_contract_company_client_progress['position']);
                $sheet->setCellValue('M'.($number + 1), $user_contract_company_client_progress['boss']);
                $sheet->setCellValue('N'.($number + 1), $user_contract_company_client_progress['hrd']);
                $sheet->setCellValue('O'.($number + 1), '');
                $sheet->setCellValue('P'.($number + 1), '');
                $sheet->setCellValue('Q'.($number + 1), '');
                $sheet->setCellValue('R'.($number + 1), $user_contract_company_client_progress['marketing']);

				$number++;
			}

			$sheet->getColumnDimension('A')->setAutoSize(true);
			$sheet->getColumnDimension('B')->setAutoSize(true);
			$sheet->getColumnDimension('C')->setAutoSize(true);
			$sheet->getColumnDimension('D')->setAutoSize(true);
			$sheet->getColumnDimension('E')->setAutoSize(true);
			$sheet->getColumnDimension('F')->setAutoSize(true);
			$sheet->getColumnDimension('G')->setAutoSize(true);
			$sheet->getColumnDimension('H')->setAutoSize(true);
			$sheet->getColumnDimension('I')->setAutoSize(true);
			$sheet->getColumnDimension('J')->setAutoSize(true);
			$sheet->getColumnDimension('K')->setAutoSize(true);
			$sheet->getColumnDimension('L')->setAutoSize(true);
			$sheet->getColumnDimension('M')->setAutoSize(true);
			$sheet->getColumnDimension('N')->setAutoSize(true);
			$sheet->getColumnDimension('O')->setAutoSize(true);
			$sheet->getColumnDimension('P')->setAutoSize(true);
			$sheet->getColumnDimension('Q')->setAutoSize(true);
			$sheet->getColumnDimension('R')->setAutoSize(true);
			
			$writer = new Xlsx($spreadsheet);
	
			$filename = 'Data Klien '.date("d-m-Y H.i").' WIB';
	
			header('Content-Type: application/vnd.ms-excel');
			header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
			header('Cache-Control: max-age=0');
			
			$writer->save('php://output'); // download file
	    }*/
	}
?>