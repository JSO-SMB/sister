<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	use PhpOffice\PhpSpreadsheet\Spreadsheet;
	use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
	
	class Vendor extends CI_Controller
	{
		/*public function __construct()
		{
			parent::__construct();
			
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}
        }*/
        
        public function tambah_ubah($vendor_id = 0)
	    {
			if($this->input->post('submit') != NULL)
			{
				$this->load->model('vendor_model');
				
				if($_FILES['office_photo']['size'] > 0 || !empty(array_filter($_FILES['venues_photos']['name'])))
				{
					$config['upload_path']          = './uploads/';
					$config['allowed_types']        = 'jpg|jpeg|png|gif';
	
					$this->load->library('upload', $config);
				}

				$uri = 'vendor/tambah_ubah/';
	
				if($vendor_id > 0)
					$uri = $uri.$vendor_id;

				if($_FILES['office_photo']['size'] > 0)
				{
					if(!$this->upload->do_upload('office_photo'))
					{
						$this->session->set_flashdata('error_messages', $this->upload->display_errors());
						
						redirect($uri);
					}
					else
						$office_photo = $this->upload->data('file_name');
				}
				else
					$office_photo = '';

				$venues_photos = '';
				
				if(!empty(array_filter($_FILES['venues_photos']['name'])))
				{ 
					foreach($_FILES['venues_photos']['name'] as $key=>$value)
					{
						$_FILES['venue_photo']['name'] = $_FILES['venues_photos']['name'][$key];
						$_FILES['venue_photo']['type'] = $_FILES['venues_photos']['type'][$key];
						$_FILES['venue_photo']['tmp_name'] = $_FILES['venues_photos']['tmp_name'][$key];
						$_FILES['venue_photo']['error'] = $_FILES['venues_photos']['error'][$key];
						$_FILES['venue_photo']['size'] = $_FILES['venues_photos']['size'][$key];

						if(!$this->upload->do_upload('venue_photo'))
						{
							$this->session->set_flashdata('error_messages', $this->upload->display_errors());
							
							redirect($uri);
						}
						else
						{
							if($venues_photos == '')
								$venues_photos = $this->upload->data('file_name');
							else
								$venues_photos = $venues_photos.','.$this->upload->data('file_name');
						}
					}
				}

				if($this->input->post('password') == '')
					$hashed_password = '';
				else
				{
					$password_hash_options['cost'] = 9;
					
					$hashed_password = password_hash($this->input->post('password'), PASSWORD_DEFAULT, $password_hash_options);
				}

				$this->vendor_model->create_update_vendor($hashed_password, $office_photo, $venues_photos, $vendor_id);

				if($vendor_id > 0)
				{
					$value = 'update success';
					
					$this->session->set_userdata('email_address', $this->input->post('email_address'));
				}
				else
					$value = 'vendor registration success';
				
				$this->session->set_flashdata('operation_result', $value);
				
				redirect($uri);
					
				/*$user_role = $this->employee_model->read_users_roles('', 2);
				
				$message = 'Yth. HRD JSO SMB,<br /><br />';
				$message = $message.'Terdapat data registrasi seleksi calon karyawan baru yang masuk untuk posisi & pilihan jadwal wawancara berikut:<br /><br />';
				$message = $message.'<b>Nama: '.$this->input->post('name').'<br />';
				$message = $message.'Alamat email: '.$this->input->post('email_address').'<br />';
				$message = $message.'Posisi & pilihan jadwal wawancara: '.$this->input->post('division').'</b><br /><br />';
				$message = $message.'Anda dapat melihat detail dari data registrasi tersebut pada <a href="'.base_url('vendor/tambah_ubah/'.rawurlencode($this->input->post('email_address'))).'" target="_blank">tautan ini</a>.<br /><br />';
				$message = $message.'Salam,<br />SISTER JSO SMB';

				$this->load->library('email');
				
				// Sending to an account, for activation (username, password)
				$this->email->from('sister.jsosmboffice@gmail.com', 'SISTER JSO');	
				$this->email->to($user_role['email_address']);

				//$this->email->cc('another@another-example.com');
				//$this->email->bcc('them@their-example.com');
				$this->email->subject('Data Registrasi Seleksi Calon Karyawan');
				$this->email->message($message);

				$this->email->send();*/
			}
			else
			{
				$this->load->helper('form');

				require 'Options.php';

				if($vendor_id > 0)
				{
					if(!$this->session->has_userdata('user_id'))
					{	
						$this->session->set_userdata('previous_url', current_url());
						
						redirect('otentikasi/masuk');
					}
					
					$this->load->model('employee_model');
					$this->load->model('vendor_model');

					if($this->session->userdata('role_id') < 2)
						$role_specific_table = 'employees';
					else
						$role_specific_table = 'vendors';
					
					$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, $role_specific_table);

					if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['role_id'] != 2 && !($data['logged_in_user']['role_id'] == 1 && $data['logged_in_user']['position'] == 'Manajer' && ($data['logged_in_user']['division'] == 'LOGISTIK' || $data['logged_in_user']['division'] == 'MARKETING')))
						redirect();
					
					$header = 'Ubah Data Vendor';
					
					$user_vendor = $this->vendor_model->read_users_vendors('user', 0, 'row_array', '', $vendor_id);

					$data['name'] = $user_vendor['name'];
					$data['city'] = $user_vendor['city'];
					$data['address'] = $user_vendor['address'];
					$data['email_address'] = $user_vendor['email_address'];
					$data['phone_number'] = $user_vendor['phone_number'];
					$data['whatsapp_number'] = $user_vendor['whatsapp_number'];
					$data['website'] = $user_vendor['website'];
					$data['account_number'] = $user_vendor['account_number'];
					$data['bank'] = $user_vendor['bank'];
					$data['accountee'] = $user_vendor['accountee'];
					$data['office_photo'] = $user_vendor['office_photo'];
					$data['type'] = $user_vendor['type'];
					$data['stars'] = $user_vendor['stars'];
					$data['average_hotel_room_rates'] = $user_vendor['average_hotel_room_rates'];
					$data['hotel_meeting_room_minimal_pax'] = $user_vendor['hotel_meeting_room_minimal_pax'];
					$data['hotel_meeting_room_per_pax_rate'] = $user_vendor['hotel_meeting_room_per_pax_rate'];
					$data['marketing_name'] = $user_vendor['marketing_name'];
					$data['marketing_phone_number'] = $user_vendor['marketing_phone_number'];
					$data['marketing_email_address'] = $user_vendor['marketing_email_address'];
					$data['notes'] = $user_vendor['notes'];
					$data['venues_photos'] = explode(',', $user_vendor['venues_photos']);
					$data['user_id'] = $user_vendor['user_id'];
				}
				else
				{
					if($this->session->has_userdata('user_id'))
						redirect();
					
					$header = 'Form Pendaftaran Vendor';
					
					$data['name'] = '';
					$data['city'] = 'Yogyakarta';
					$data['address'] = '';
					$data['email_address'] = '';
					$data['phone_number'] = '62';
					$data['whatsapp_number'] = '62';
					$data['website'] = '';
					$data['account_number'] = '';
					$data['bank'] = '';
					$data['accountee'] = '';
					$data['office_photo'] = '';
					$data['type'] = 'Konveksi';
					$data['stars'] = 5;
					$data['average_hotel_room_rates'] = '';
					$data['hotel_meeting_room_minimal_pax'] = '';
					$data['hotel_meeting_room_per_pax_rate'] = '';
					$data['marketing_name'] = '';
					$data['marketing_phone_number'] = '62';
					$data['marketing_email_address'] = '';
					$data['notes'] = '';
					$data['venues_photos'] = '';
					$data['user_id'] = 0;
				}
                    
				$data['title'] = ':: Sister JSO :: '.$header;
				
				$data['vendor_css_links'] = array(
					'bootstrap/css/bootstrap.min.css',
					'font-awesome/css/font-awesome.min.css',
					'animate-css/animate.min.css',
					'bootstrap-multiselect/bootstrap-multiselect.css',
					'bootstrap-datepicker/css/bootstrap-datepicker3.min.css',
					'bootstrap-colorpicker/css/bootstrap-colorpicker.css',
					'multi-select/css/multi-select.css',
					'bootstrap-tagsinput/bootstrap-tagsinput.css',
					'nouislider/nouislider.min.css',
					'toastr/toastr.min.css',
                    'dropify/css/dropify.min.css'
                );
				
				$data['header'] = $header;
				$data['email_address_check_link'] = base_url('karyawan/cek_alamat_email/');
				$data['vendor_types'] = $vendor_types;
				$data['cities'] = $cities;
				
				$data['js_links'] = array(
					'assets/bundles/libscripts.bundle.js',
					'assets/bundles/vendorscripts.bundle.js',
					'vendor/toastr/toastr.js',
                    'vendor/dropify/js/dropify.min.js',
					'assets/bundles/mainscripts.bundle.js',
					'assets/js/pages/forms/advanced-form-elements.js',
                    'assets/js/pages/forms/dropify.js',
					'assets/js/pages/vendor/create_update.js'
				);

				// Render view on main layout
				$this->load->view('templates/dashboard/top', $data);
				$this->load->view('pages/vendors/create_update', $data);
				$this->load->view('templates/dashboard/bottom', $data);
			}
	    }

		public function daftar()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->helper('form');

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			if($this->session->userdata('user_id') != 1 && !($data['logged_in_user']['position'] == 'Manajer' && ($data['logged_in_user']['division'] == 'LOGISTIK' || $data['logged_in_user']['division'] == 'MARKETING')))
				redirect();

			$data['title'] = ':: Sister JSO :: Data Vendor';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'assets/js/pages/vendor/list.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/vendors/list/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		public function data($page_number, $query = '')
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('vendor_model');
			$this->load->helper('form');

			$data['query'] = urldecode($query);

            $data['users_vendors'] = $this->vendor_model->read_users_vendors('user', $page_number, 'result_array', urldecode($query));
			$data['page_number'] = $page_number;
            
			$page_count = ceil($this->vendor_model->read_users_vendors('', 0, 'num_rows') / 5);

			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				if($page_count > 10)
				{
					if($page_number > 6)
					{
						if(($page_count - $page_number) >= 4)
							$next_page_count = 4;
						else
							$next_page_count = $page_count - $page_number;
						
						$previous_page_count = 9 - $next_page_count;
					}
					else
					{
						$previous_page_count = $page_number - 1;
						$next_page_count = 9 - $previous_page_count;
					}
				}
				else
				{
					$previous_page_count = $page_number - 1;
					$next_page_count = $page_count - $page_number;
				}

				$data['previous_page_count'] = $previous_page_count;
				$data['next_page_count'] = $next_page_count;
			}

			echo $this->load->view('pages/vendors/list/dynamic_content', $data, TRUE);
		}

		public function ekspor()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->model('vendor_model');

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			if($this->session->userdata('user_id') != 1 && !($data['logged_in_user']['position'] == 'Manajer' && ($data['logged_in_user']['division'] == 'LOGISTIK' || $data['logged_in_user']['division'] == 'MARKETING')))
				redirect();

			$spreadsheet = new Spreadsheet();
			
			$sheet = $spreadsheet->getActiveSheet();

			$sheet->setCellValue('A1', 'Nomor');
			$sheet->setCellValue('B1', 'Nama');
			$sheet->setCellValue('C1', 'Kota');
			$sheet->setCellValue('D1', 'Alamat');
			$sheet->setCellValue('E1', 'Nomor Telepon');
			$sheet->setCellValue('F1', 'Jenis');

			$users_vendors = $this->vendor_model->read_users_vendors('user');
			
			$number = 1;

			foreach($users_vendors as &$user_vendor)
			{
				$sheet->setCellValue('A'.($number + 1), $number);
				$sheet->setCellValue('B'.($number + 1), $user_vendor['name']);
				$sheet->setCellValue('C'.($number + 1), $user_vendor['city']);
				$sheet->setCellValue('D'.($number + 1), $user_vendor['address']);
				$sheet->setCellValueExplicit('E'.($number + 1), $user_vendor['phone_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
				$sheet->setCellValue('F'.($number + 1), $user_vendor['type']);

				$number++;
			}

			$sheet->getColumnDimension('A')->setAutoSize(true);
			$sheet->getColumnDimension('B')->setAutoSize(true);
			$sheet->getColumnDimension('C')->setAutoSize(true);
			$sheet->getColumnDimension('D')->setAutoSize(true);
			$sheet->getColumnDimension('E')->setAutoSize(true);
			$sheet->getColumnDimension('F')->setAutoSize(true);
			
			$writer = new Xlsx($spreadsheet);
	
			$filename = 'Data Vendor '.date("d-m-Y H.i").' WIB';
	
			header('Content-Type: application/vnd.ms-excel');
			header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
			header('Cache-Control: max-age=0');
			
			$writer->save('php://output'); // download file
	    }
	}
?>