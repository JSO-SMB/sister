<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Dasbor extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			
			if(!$this->session->has_userdata('user_id'))
				redirect('otentikasi/masuk');
		}

		public function index()
		{
			$this->load->model('employee_model');
			
			// Set title page
			$data['title'] = ':: Sister JSO :: Dashboard';
			
			$data['vendor_css_links'] = array(
                'bootstrap/css/bootstrap.min.css',
                'font-awesome/css/font-awesome.min.css',
                'animate-css/animate.min.css',
                'bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css',
                'chartist/css/chartist.min.css',
                'chartist-plugin-tooltip/chartist-plugin-tooltip.css',
                'toastr/toastr.min.css'
			);
			
			if($this->session->userdata('role_id') < 2)
				$role_specific_table = 'employees';
			else
				$role_specific_table = 'vendors';
			
			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, $role_specific_table);

			$data['js_links'] = array(
                'assets/bundles/libscripts.bundle.js',
                'assets/bundles/vendorscripts.bundle.js',
                'assets/bundles/chartist.bundle.js',
                'assets/bundles/knob.bundle.js',
                'vendor/toastr/toastr.js',
                'assets/bundles/mainscripts.bundle.js',
                'assets/js/index.js'
            );

	        // Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/dashboard', $data);
			$this->load->view('templates/dashboard/bottom', $data);
		}
	}
