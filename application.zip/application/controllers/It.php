<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	//use PhpOffice\PhpSpreadsheet\Spreadsheet;
	//use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
	
	class It extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}
        }
        
        public function tambah_ubah($it_data_id = 0)
	    {
			$this->load->model('it_model');
			
			if($this->input->post('submit') != NULL)
			{
				$this->it_model->create_update_it_data($it_data_id);

                $this->session->set_flashdata('operation_result', 'it data saved');
                
				if($it_data_id == 0)
                    redirect('it/tambah_ubah');
                else
                    redirect('it/tambah_ubah/'.$it_data_id);
			}
			else
			{
				$this->load->model('employee_model');
				$this->load->model('unit_model');
				$this->load->model('vendor_model');
				$this->load->helper('form');

                $data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

				require 'Options.php';

				if($it_data_id < 1)
				{
					if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'IT')
						redirect();
					
					$header = 'Tambah Data IT';
					
                    $data['type'] = 'Hosting';
					$data['data_name'] = '';
					$data['purchase_date'] = date('Y-m-d');
					$data['annual_renewal_price'] = 100;
					$data['domain_it_data_id'] = array();
					$data['last_update_date'] = date('Y-m-d');
					$data['space_total'] = 0;
					$data['space_used'] = 0;
					$data['cpanel_username'] = '';
					$data['cpanel_url'] = '';
					$data['cpanel_password'] = '';
					$data['ftp_username'] = '';
					$data['ftp_password'] = '';
					$data['epp_code'] = '';
					$data['widget_backlink_text'] = '';
					$data['live_chat_username'] = '';
					$data['live_chat_email_address'] = '';
					$data['live_chat_password'] = '';
					$data['whois_privacy_price'] = 100;
					$data['ssl_certificate_price'] = 100;
					$data['post_draft'] = 0;
					$data['post_published'] = 0;
					$data['post_scheduled'] = 0;
					$data['post_last_publish_date'] = '0000-00-00';
					$data['wp_username'] = '';
					$data['wp_admin_url'] = '';
					$data['wp_password'] = '';
					$data['wp_theme'] = '';
					$data['registrant_name'] = '';
					$data['registrant_email_address'] = '';
					$data['registrant_phone_number'] = '62';
					$data['email_username'] = '';
					$data['email_password'] = '';
					$data['email_notes'] = '';
					$data['division'] = 'DRIVER';
					$data['creation_date'] = date('Y-m-d');
					$data['mobile_number'] = '62';
					$data['registration'] = '';
					$data['status'] = 'Aktif';
					$data['social_media_name'] = 'blogspot';
					$data['social_media_link'] = '';
					$data['account_username'] = '';
					$data['account_password'] = '';
				}
				else
				{
					if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'IT' && $data['logged_in_user']['division'] != 'FINANCE' && $data['logged_in_user']['division'] != 'HRD')
						redirect();
					
					$header = 'Ubah Data IT';
					
					$it_datum = $this->it_model->read_it_data('*', 0, '', '', 'row_array', '', 0, $it_data_id);

					$data['unit_id'] = $it_datum['unit_id'];
					$data['type'] = $it_datum['type'];
					$data['data_name'] = $it_datum['data_name'];
					$data['vendor_id'] = $it_datum['vendor_id'];
					$data['purchase_date'] = $it_datum['purchase_date'];
					$data['annual_renewal_price'] = number_format($it_datum['annual_renewal_price'], 0, ',', '.');
					$data['domain_it_data_id'] = explode(',', $it_datum['domain_it_data_id']);
					$data['last_update_date'] = $it_datum['last_update_date'];
					$data['space_total'] = $it_datum['space_total'];
					$data['space_used'] = $it_datum['space_used'];
					$data['cpanel_username'] = $it_datum['cpanel_username'];
					$data['cpanel_url'] = $it_datum['cpanel_url'];
					$data['cpanel_password'] = $it_datum['cpanel_password'];
					$data['ftp_username'] = $it_datum['ftp_username'];
					$data['ftp_password'] = $it_datum['ftp_password'];
					$data['hosting_it_data_id'] = $it_datum['hosting_it_data_id'];
					$data['epp_code'] = $it_datum['epp_code'];
					$data['purchase_date'] = $it_datum['purchase_date'];
					$data['widget_backlink_text'] = $it_datum['widget_backlink_text'];
					$data['webmaster_tools_email_address_it_data_id'] = $it_datum['webmaster_tools_email_address_it_data_id'];
					$data['live_chat_username'] = $it_datum['live_chat_username'];
					$data['live_chat_email_address'] = $it_datum['live_chat_email_address'];
					$data['live_chat_password'] = $it_datum['live_chat_password'];
					$data['whois_privacy_price'] = number_format($it_datum['whois_privacy_price'], 0, ',', '.');
					$data['ssl_certificate_price'] = number_format($it_datum['ssl_certificate_price'], 0, ',', '.');
					$data['post_draft'] = $it_datum['post_draft'];
					$data['post_published'] = $it_datum['post_published'];
					$data['post_scheduled'] = $it_datum['post_scheduled'];
					$data['post_last_publish_date'] = $it_datum['post_last_publish_date'];
					$data['wp_username'] = $it_datum['wp_username'];
					$data['wp_admin_url'] = $it_datum['wp_admin_url'];
					$data['wp_password'] = $it_datum['wp_password'];
					$data['wp_theme'] = $it_datum['wp_theme'];
					$data['registrant_name'] = $it_datum['registrant_name'];
					$data['registrant_email_address'] = $it_datum['registrant_email_address'];
					$data['registrant_phone_number'] = $it_datum['registrant_phone_number'];
					$data['cp_a_user_id'] = $it_datum['cp_a_user_id'];
					$data['cp_a_mobile_number_it_data_id'] = $it_datum['cp_a_mobile_number_it_data_id'];
					$data['cp_a_email_address_it_data_id'] = $it_datum['cp_a_email_address_it_data_id'];
					$data['cp_b_user_id'] = $it_datum['cp_b_user_id'];
					$data['cp_b_mobile_number_it_data_id'] = $it_datum['cp_b_mobile_number_it_data_id'];
					$data['cp_b_email_address_it_data_id'] = $it_datum['cp_b_email_address_it_data_id'];
					$data['cp_c_user_id'] = $it_datum['cp_c_user_id'];
					$data['cp_c_mobile_number_it_data_id'] = $it_datum['cp_c_mobile_number_it_data_id'];
					$data['cp_c_email_address_it_data_id'] = $it_datum['cp_c_email_address_it_data_id'];
					$data['cp_d_user_id'] = $it_datum['cp_d_user_id'];
					$data['cp_d_mobile_number_it_data_id'] = $it_datum['cp_d_mobile_number_it_data_id'];
					$data['cp_d_email_address_it_data_id'] = $it_datum['cp_d_email_address_it_data_id'];
					$data['cp_e_user_id'] = $it_datum['cp_e_user_id'];
					$data['cp_e_mobile_number_it_data_id'] = $it_datum['cp_e_mobile_number_it_data_id'];
					$data['cp_e_email_address_it_data_id'] = $it_datum['cp_e_email_address_it_data_id'];
					$data['cp_f_user_id'] = $it_datum['cp_f_user_id'];
					$data['cp_f_mobile_number_it_data_id'] = $it_datum['cp_f_mobile_number_it_data_id'];
					$data['cp_f_email_address_it_data_id'] = $it_datum['cp_f_email_address_it_data_id'];
					$data['manager_user_id'] = $it_datum['manager_user_id'];
					$data['email_username'] = $it_datum['email_username'];
					$data['email_password'] = $it_datum['email_password'];
					$data['email_mobile_number_it_data_id'] = $it_datum['email_mobile_number_it_data_id'];
					$data['email_notes'] = $it_datum['email_notes'];
					$data['division'] = $it_datum['division'];
					$data['creation_date'] = $it_datum['creation_date'];
					$data['pic_user_id'] = $it_datum['pic_user_id'];
					$data['mobile_number'] = $it_datum['mobile_number'];
					$data['inventory_id'] = $it_datum['inventory_id'];
					$data['registration'] = $it_datum['registration'];
					$data['status'] = $it_datum['status'];
					$data['social_media_name'] = $it_datum['social_media_name'];
					$data['social_media_link'] = $it_datum['social_media_link'];
					$data['social_media_email_address_it_data_id'] = $it_datum['social_media_email_address_it_data_id'];
					$data['account_username'] = $it_datum['account_username'];
					$data['account_password'] = $it_datum['account_password'];
				}
                    
				$data['title'] = ':: Sister JSO :: '.$header;
				
				$data['vendor_css_links'] = array(
					'bootstrap/css/bootstrap.min.css',
					'font-awesome/css/font-awesome.min.css',
					'animate-css/animate.min.css',
					'bootstrap-multiselect/bootstrap-multiselect.css',
					'bootstrap-datepicker/css/bootstrap-datepicker3.min.css',
					'bootstrap-colorpicker/css/bootstrap-colorpicker.css',
					'multi-select/css/multi-select.css',
					'bootstrap-tagsinput/bootstrap-tagsinput.css',
					'nouislider/nouislider.min.css',
					'toastr/toastr.min.css'
                );
				
				$data['header'] = $header;

				$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
			
				foreach($unit_list as &$unit)
				{
					$units[$unit['unit_id']] = $unit['name'];
				}

				$data['units'] = $units;
				
				if($it_data_id < 1)
					//$data['unit_id'] = $unit['unit_id'];
					$data['unit_id'] = 1;

				$data['unit_related_option_retrieve_link'] = base_url('it/opsi_unit/');
				$data['account_check_link'] = base_url('it/cek_akun/');
				
				$data['types'] = array(
					'Hosting' => 'Hosting',
					'Domain' => 'Domain',
					'email' => 'email',
					'Nomor HP/Telepon' => 'Nomor HP/Telepon',
					'Akun Medsos dll.' => 'Akun Medsos dll.'
				);
				
				$users_vendors = $this->vendor_model->read_users_vendors('user', 0, 'result_array', '', 0, 'IT');

				foreach($users_vendors as &$user_vendor)
				{
					$it_vendors[$user_vendor['vendor_id']] = $user_vendor['name'];
				}
				
				$data['it_vendors'] = $it_vendors;

				if($it_data_id < 1)
					$data['vendor_id'] = $user_vendor['vendor_id'];
				
				$it_data = $this->it_model->read_it_data('it_data_id, data_name', $data['unit_id'], 'Domain');

				$data['domains'] = array();
				
				if(!empty($it_data))
				{
					foreach($it_data as &$it_datum)
					{
						$domains[$it_datum['it_data_id']] = $it_datum['data_name'];
					}
					
					$data['domains'] = $domains;
				}
				
				$it_data = $this->it_model->read_it_data('it_data_id, data_name', $data['unit_id'], 'Hosting');

				$data['hostings'] = array();
				
				if(!empty($it_data))
				{
					foreach($it_data as &$it_datum)
					{
						$hostings[$it_datum['it_data_id']] = $it_datum['data_name'];
					}
					
					$data['hostings'] = $hostings;

					if($it_data_id < 1)
						$data['hosting_it_data_id'] = $it_datum['it_data_id'];
				}
				else if($it_data_id < 1)
					$data['hosting_it_data_id'] = 0;
				
				$it_data = $this->it_model->read_it_data('it_data_id, email_username', $data['unit_id'], 'email');

				$data['email_addresses'] = array();
				
				if(!empty($it_data))
				{
					foreach($it_data as &$it_datum)
					{
						$email_addresses[$it_datum['it_data_id']] = $it_datum['email_username'];
					}
					
					$data['email_addresses'] = $email_addresses;

					if($it_data_id < 1)
					{
						$data['webmaster_tools_email_address_it_data_id'] = $it_datum['it_data_id'];
						$data['cp_a_email_address_it_data_id'] = $it_datum['it_data_id'];
						$data['cp_b_email_address_it_data_id'] = $it_datum['it_data_id'];
						$data['cp_c_email_address_it_data_id'] = $it_datum['it_data_id'];
						$data['cp_d_email_address_it_data_id'] = $it_datum['it_data_id'];
						$data['cp_e_email_address_it_data_id'] = $it_datum['it_data_id'];
						$data['cp_f_email_address_it_data_id'] = $it_datum['it_data_id'];
						$data['social_media_email_address_it_data_id'] = $it_datum['it_data_id'];
					}
				}
				else if($it_data_id < 1)
				{
					$data['webmaster_tools_email_address_it_data_id'] = 0;
					$data['cp_a_email_address_it_data_id'] = 0;
					$data['cp_b_email_address_it_data_id'] = 0;
					$data['cp_c_email_address_it_data_id'] = 0;
					$data['cp_d_email_address_it_data_id'] = 0;
					$data['cp_e_email_address_it_data_id'] = 0;
					$data['cp_f_email_address_it_data_id'] = 0;
					$data['social_media_email_address_it_data_id'] = 0;
				}

				$users = $this->it_model->read_users_roles_contracts('MARKETING', 'Staff', $data['unit_id']);

				$data['marketings'] = array();
				
				if(!empty($users))
				{
					foreach($users as &$user)
					{
						$marketings[$user['user_id']] = $user['name'];
					}
					
					$data['marketings'] = $marketings;

					if($it_data_id < 1)
					{
						$data['cp_a_user_id'] = $user['user_id'];
						$data['cp_b_user_id'] = $user['user_id'];
						$data['cp_c_user_id'] = $user['user_id'];
						$data['cp_d_user_id'] = $user['user_id'];
						$data['cp_e_user_id'] = $user['user_id'];
						$data['cp_f_user_id'] = $user['user_id'];
					}
				}
				else if($it_data_id < 1)
				{
					$data['cp_a_user_id'] = 0;
					$data['cp_b_user_id'] = 0;
					$data['cp_c_user_id'] = 0;
					$data['cp_d_user_id'] = 0;
					$data['cp_e_user_id'] = 0;
					$data['cp_f_user_id'] = 0;
				}
				
				$it_data = $this->it_model->read_it_data('it_data_id, mobile_number', $data['unit_id'], 'Nomor HP/Telepon');

				$data['mobile_numbers'] = array();
				
				if(!empty($it_data))
				{
					foreach($it_data as &$it_datum)
					{
						$mobile_numbers[$it_datum['it_data_id']] = $it_datum['mobile_number'];
					}
					
					$data['mobile_numbers'] = $mobile_numbers;

					if($it_data_id < 1)
					{
						$data['cp_a_mobile_number_it_data_id'] = $it_datum['it_data_id'];
						$data['cp_b_mobile_number_it_data_id'] = $it_datum['it_data_id'];
						$data['cp_c_mobile_number_it_data_id'] = $it_datum['it_data_id'];
						$data['cp_d_mobile_number_it_data_id'] = $it_datum['it_data_id'];
						$data['cp_e_mobile_number_it_data_id'] = $it_datum['it_data_id'];
						$data['cp_f_mobile_number_it_data_id'] = $it_datum['it_data_id'];
						$data['email_mobile_number_it_data_id'] = $it_datum['it_data_id'];
					}
				}
				else if($it_data_id < 1)
				{
					$data['cp_a_mobile_number_it_data_id'] = 0;
					$data['cp_b_mobile_number_it_data_id'] = 0;
					$data['cp_c_mobile_number_it_data_id'] = 0;
					$data['cp_d_mobile_number_it_data_id'] = 0;
					$data['cp_e_mobile_number_it_data_id'] = 0;
					$data['cp_f_mobile_number_it_data_id'] = 0;
					$data['email_mobile_number_it_data_id'] = 0;
				}

				$users = $this->it_model->read_users_roles_contracts('MARKETING', 'Manajer', $data['unit_id']);

				$data['managers'] = array();
				
				if(!empty($users))
				{
					foreach($users as &$user)
					{
						$managers[$user['user_id']] = $user['name'];
					}
					
					$data['managers'] = $managers;

					if($it_data_id < 1)
						$data['manager_user_id'] = $user['user_id'];
				}
				else if($it_data_id < 1)
					$data['manager_user_id'] = 0;

				$users = $this->it_model->read_users_roles_contracts('', '', $data['unit_id']);

				$data['active_employees'] = array();
				
				if(!empty($users))
				{
					foreach($users as &$user)
					{
						$active_employees[$user['user_id']] = $user['name'];
					}
					
					$data['active_employees'] = $active_employees;

					if($it_data_id < 1)
						$data['pic_user_id'] = $user['user_id'];
				}
				else if($it_data_id < 1)
					$data['pic_user_id'] = 0;
				
				$data['divisions'] = array(
					'DRIVER' => 'DRIVER',
					'OFFICE BOY' => 'OFFICE BOY',
					'VIDEOGRAFER' => 'VIDEOGRAFER',
					'CUSTOMER SERVICE' => 'CUSTOMER SERVICE',
					'HRD' => 'HRD',
					'RND' => 'RND',
					'IT' => 'IT',
					'CONTENT WRITER' => 'CONTENT WRITER',
					'FINANCE' => 'FINANCE',
					'LOGISTIK' => 'LOGISTIK',
					'MARKETING' => 'MARKETING',
					'INSTRUKTUR' => 'INSTRUKTUR',
					'MANAJEMEN' => 'MANAJEMEN'
				);

				$data['handphones'] = array(
					1 => 'Redmi 5A',
					2 => 'HP Pribadi',
					3 => 'Redmi 6A',
					4 => 'Samsung Duos Flip',
					5 => 'Evercoss Xtream 1+',
					6 => 'Advance s4z',
					7 => 'redmi 4A',
					8 => 'Lenovo',
					9 => 'Redmi X4',
					10 => 'asus zenfone4',
					11 => 'Realme c2 black',
					12 => 'Realme c2 blue ',
					13 => 'Redmi 6',
					14 => 'Kantor',
					15 => 'Mi4'
				);

				if($it_data_id < 1)
					$data['inventory_id'] = 15;
				
				$data['social_medias'] = $social_medias;
				
				$data['js_links'] = array(
					'assets/bundles/libscripts.bundle.js',
					'assets/bundles/vendorscripts.bundle.js',
					'vendor/bootstrap-colorpicker/js/bootstrap-colorpicker.js',
					'vendor/jquery-inputmask/jquery.inputmask.bundle.js',
					'vendor/jquery-mask/jquery.mask.min.js',
					'vendor/multi-select/js/jquery.multi-select.js',
					'vendor/bootstrap-multiselect/bootstrap-multiselect.js',
					'vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js',
					'vendor/bootstrap-tagsinput/bootstrap-tagsinput.js',
					'vendor/nouislider/nouislider.js',
					'vendor/toastr/toastr.js',
					'assets/bundles/mainscripts.bundle.js',
					'assets/js/pages/forms/advanced-form-elements.js',
					'assets/js/pages/it_data/create_update.js'
				);

				// Render view on main layout
				$this->load->view('templates/dashboard/top', $data);
				$this->load->view('pages/it_data/create_update/static_content', $data);
				$this->load->view('templates/dashboard/bottom', $data);
			}
	    }
	    
		public function opsi_unit($unit_id)
		{
			$this->load->model('it_model');

			$query = urldecode($this->input->get('kueri'));
			$options = '';

			if($query == '' || $query == 'Staff' || $query == 'Manajer')
			{
				if($query == '')
					$division = '';
				else
					$division = 'MARKETING';
				
				$users = $this->it_model->read_users_roles_contracts($division, $query, $unit_id);
				
				foreach($users as &$user)
				{
					$options = $options.'<option value="'.$user['user_id'].'">'.$user['name'].'</option>';
				}
			}
			else
			{
				if($query == 'email')
					$text = 'email_username';
				else if($query == 'Nomor HP/Telepon')
					$text = 'mobile_number';
				else
					$text = 'data_name';
				
				$it_data = $this->it_model->read_it_data('it_data_id, '.$text, $unit_id, $query);

				foreach($it_data as &$it_datum)
				{
					$options = $options.'<option value="'.$it_datum['it_data_id'].'">'.$it_datum[$text].'</option>';
				}
			}

			echo $options;
		}
	    
		public function cek_akun()
		{
			$this->load->model('it_model');
			
			echo $this->it_model->read_it_data('*', 0, urldecode($this->input->get('jenis')), urldecode($this->input->get('akun')), 'num_rows');
		}
		
	    public function detail_sumber($source)
	    {
			$this->load->helper('form');

			$data['source'] = $source;

			if($source == 'Website')
			{
				$data['label_text'] = 'Alamat Website';
				
				$data['websites'] = array(
					1 => 'https://jso-smb.co.id'
				);
				
				$data['selected'] = 1;
			}
			else
				$data['label_text'] = 'Nama Referal';
			
			echo $this->load->view('pages/events/create_update/source_detail', $data, TRUE);
		}

		public function daftar()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->helper('form');

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'IT' && $data['logged_in_user']['division'] != 'FINANCE' && $data['logged_in_user']['division'] != 'HRD')
				redirect();

			$data['title'] = ':: Sister JSO :: Data IT';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'assets/js/pages/it_data/list.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/it_data/list/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		public function data($page_number)
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('it_model');
			$this->load->helper('form');
			
			$query = urldecode($this->input->get('query'));

			$data['query'] = $query;
            
			$data['it_data'] = $this->it_model->read_it_data('*', 0, '', '', 'result_array', $query, $page_number);
			$data['page_number'] = $page_number;
            
			$page_count = ceil($this->it_model->read_it_data('*', 0, '', '', 'num_rows', $query) / 5);

			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				if($page_count > 10)
				{
					if($page_number > 6)
					{
						if(($page_count - $page_number) >= 4)
							$next_page_count = 4;
						else
							$next_page_count = $page_count - $page_number;
						
						$previous_page_count = 9 - $next_page_count;
					}
					else
					{
						$previous_page_count = $page_number - 1;
						$next_page_count = 9 - $previous_page_count;
					}
				}
				else
				{
					$previous_page_count = $page_number - 1;
					$next_page_count = $page_count - $page_number;
				}

				$data['previous_page_count'] = $previous_page_count;
				$data['next_page_count'] = $next_page_count;
			}

			echo $this->load->view('pages/it_data/list/dynamic_content', $data, TRUE);
		}

		/*public function ekspor()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('it_model');

			$spreadsheet = new Spreadsheet();
			
			$sheet = $spreadsheet->getActiveSheet();

			$sheet->setCellValue('A1', 'Nomor');
			$sheet->setCellValue('B1', 'Tanggal');
			$sheet->setCellValue('C1', 'Event');
			$sheet->setCellValue('D1', 'Kategori');
			$sheet->setCellValue('E1', 'Jenis');
			$sheet->setCellValue('F1', 'Status');
			$sheet->setCellValue('G1', 'Tayang');
			$sheet->setCellValue('H1', 'Tanggal Mulai Pelatihan');
			$sheet->setCellValue('I1', 'Tanggal Berakhir Pelatihan');
			$sheet->setCellValue('J1', 'Jam Mulai');
			$sheet->setCellValue('K1', 'Jam Selesai');
			$sheet->setCellValue('L1', 'Instruktur');
			$sheet->setCellValue('M1', 'Kota');
			$sheet->setCellValue('N1', 'Hotel');
			$sheet->setCellValue('O1', 'Penyelenggara');
			$sheet->setCellValue('P1', 'Marketing');
			$sheet->setCellValue('Q1', 'CS');
			$sheet->setCellValue('R1', 'Driver');
			$sheet->setCellValue('S1', 'Logistik');
			$sheet->setCellValue('T1', 'Sumber');
			$sheet->setCellValue('U1', 'Harga');
			$sheet->setCellValue('V1', 'Jumlah');
			$sheet->setCellValue('W1', 'Total');
			$sheet->setCellValue('X1', 'Peserta');
			$sheet->setCellValue('Y1', 'Email');
			$sheet->setCellValue('Z1', 'Perusahaan');
			$sheet->setCellValue('AA1', 'Posisi');
			$sheet->setCellValue('AB1', 'HP');
			$sheet->setCellValue('AC1', 'Telp Kantor');
			$sheet->setCellValue('AD1', 'Keterangan');			

			$events_users_vendors_clients = $this->it_model->read_events_vendors_clients('*, events.name as event_name, clients.name as client_name', 'client');
			
			$number = 1;

			foreach($events_users_vendors_clients as &$event_user_vendor_client)
			{
				$sheet->setCellValue('A'.($number + 1), $number);
				$sheet->setCellValue('B'.($number + 1), substr($event_user_vendor_client['proposal_date'], -2).'-'.substr($event_user_vendor_client['proposal_date'], 5, 2).'-'.substr($event_user_vendor_client['proposal_date'], 0, 4));
				$sheet->setCellValue('C'.($number + 1), $event_user_vendor_client['event_name']);
				$sheet->setCellValue('D'.($number + 1), $event_user_vendor_client['category']);
				$sheet->setCellValue('E'.($number + 1), $event_user_vendor_client['type']);
				$sheet->setCellValue('F'.($number + 1), $event_user_vendor_client['status']);

				if($event_user_vendor_client['status'] == 'Fixed')
					$aired = 'V';
				else
					$aired = '';
				
				$sheet->setCellValue('G'.($number + 1), $aired);
				$sheet->setCellValue('H'.($number + 1), substr($event_user_vendor_client['start_date'], -2).'-'.substr($event_user_vendor_client['start_date'], 5, 2).'-'.substr($event_user_vendor_client['start_date'], 0, 4));
				$sheet->setCellValue('I'.($number + 1), substr($event_user_vendor_client['end_date'], -2).'-'.substr($event_user_vendor_client['end_date'], 5, 2).'-'.substr($event_user_vendor_client['end_date'], 0, 4));
				$sheet->setCellValue('J'.($number + 1), $event_user_vendor_client['starting_hour']);
				$sheet->setCellValue('K'.($number + 1), $event_user_vendor_client['completion_hour']);
				$sheet->setCellValue('L'.($number + 1), $event_user_vendor_client['instructor_name']);
				$sheet->setCellValue('M'.($number + 1), $event_user_vendor_client['city']);
				$sheet->setCellValue('N'.($number + 1), $event_user_vendor_client['hotel_vendor_id']);
				$sheet->setCellValue('O'.($number + 1), 'PT JSO SMB');
				$sheet->setCellValue('P'.($number + 1), $event_user_vendor_client['marketing_name']);
				$sheet->setCellValue('Q'.($number + 1), $event_user_vendor_client['cs_name']);
				$sheet->setCellValue('R'.($number + 1), $event_user_vendor_client['driver_name']);
				$sheet->setCellValue('S'.($number + 1), $event_user_vendor_client['logistic_name']);
				$sheet->setCellValue('T'.($number + 1), $event_user_vendor_client['source']);
				$sheet->setCellValue('U'.($number + 1), $event_user_vendor_client['price']);
				$sheet->setCellValue('V'.($number + 1), $event_user_vendor_client['clients_number']);
				$sheet->setCellValue('W'.($number + 1), ($event_user_vendor_client['price'] * $event_user_vendor_client['clients_number']));
				$sheet->setCellValue('X'.($number + 1), $event_user_vendor_client['client_name']);
				$sheet->setCellValue('Y'.($number + 1), $event_user_vendor_client['email_address']);
				$sheet->setCellValue('Z'.($number + 1), $event_user_vendor_client['company']);
				$sheet->setCellValue('AA'.($number + 1), $event_user_vendor_client['position']);
				$sheet->setCellValueExplicit('AB'.($number + 1), $event_user_vendor_client['mobile_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
				$sheet->setCellValueExplicit('AC'.($number + 1), $event_user_vendor_client['phone_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
				$sheet->setCellValue('AD'.($number + 1), $event_user_vendor_client['notes']);				

				$number++;
			}

			$sheet->getColumnDimension('A')->setAutoSize(true);
			$sheet->getColumnDimension('B')->setAutoSize(true);
			$sheet->getColumnDimension('C')->setAutoSize(true);
			$sheet->getColumnDimension('D')->setAutoSize(true);
			$sheet->getColumnDimension('E')->setAutoSize(true);
			$sheet->getColumnDimension('F')->setAutoSize(true);
			$sheet->getColumnDimension('G')->setAutoSize(true);
			$sheet->getColumnDimension('H')->setAutoSize(true);
			$sheet->getColumnDimension('I')->setAutoSize(true);
			$sheet->getColumnDimension('J')->setAutoSize(true);
			$sheet->getColumnDimension('K')->setAutoSize(true);
			$sheet->getColumnDimension('L')->setAutoSize(true);
			$sheet->getColumnDimension('M')->setAutoSize(true);
			$sheet->getColumnDimension('N')->setAutoSize(true);
			$sheet->getColumnDimension('O')->setAutoSize(true);
			$sheet->getColumnDimension('P')->setAutoSize(true);
			$sheet->getColumnDimension('Q')->setAutoSize(true);
			$sheet->getColumnDimension('R')->setAutoSize(true);
			$sheet->getColumnDimension('S')->setAutoSize(true);
			$sheet->getColumnDimension('T')->setAutoSize(true);
			$sheet->getColumnDimension('U')->setAutoSize(true);
			$sheet->getColumnDimension('V')->setAutoSize(true);
			$sheet->getColumnDimension('W')->setAutoSize(true);
			$sheet->getColumnDimension('X')->setAutoSize(true);
			$sheet->getColumnDimension('Y')->setAutoSize(true);
			$sheet->getColumnDimension('Z')->setAutoSize(true);
			$sheet->getColumnDimension('AA')->setAutoSize(true);
			$sheet->getColumnDimension('AB')->setAutoSize(true);
			$sheet->getColumnDimension('AC')->setAutoSize(true);
			$sheet->getColumnDimension('AD')->setAutoSize(true);
			
			$writer = new Xlsx($spreadsheet);
	
			$filename = 'Data Progress Harian '.date("d-m-Y H.i").' WIB';
	
			header('Content-Type: application/vnd.ms-excel');
			header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
			header('Cache-Control: max-age=0');
			
			$writer->save('php://output'); // download file
	    }*/
	}
?>