<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	//use PhpOffice\PhpSpreadsheet\Spreadsheet;
	//use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
	
	class Projects_management extends CI_Controller
	{
		public function index()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->helper('form');

			$data['title'] = ':: Sister JSO :: Projects Management';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'assets/js/pages/project_management/list.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/projects_management/list/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		public function projects($page_number)
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('unit_model');
			$this->load->model('project_management_model');
			$this->load->helper('form');

			$data['units'] = array(
				'' => 'Semua Unit'
			);

			$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
			
			foreach($unit_list as &$unit)
			{
				$data['units'][$unit['unit_id']] = $unit['name'];
			}

			$data['unit_id'] = $this->input->get('unit_id');
			$data['project_status'] = urldecode($this->input->get('project_status'));
			$data['start_date'] = urldecode($this->input->get('start_date'));

			$data['projects'] = $this->project_management_model->read_events('event_id, events.name as event_name, start_date, end_date, clients_number, price, approval_status, units.name as unit_name, users.name as marketing_name, company', 0, $page_number);
			
			$data['page_number'] = $page_number;
            
			$page_count = ceil($this->project_management_model->read_events('*', 0, 0, 'num_rows') / 5);

			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				if($page_count > 10)
				{
					if($page_number > 6)
					{
						if(($page_count - $page_number) >= 4)
							$next_page_count = 4;
						else
							$next_page_count = $page_count - $page_number;
						
						$previous_page_count = 9 - $next_page_count;
					}
					else
					{
						$previous_page_count = $page_number - 1;
						$next_page_count = 9 - $previous_page_count;
					}
				}
				else
				{
					$previous_page_count = $page_number - 1;
					$next_page_count = $page_count - $page_number;
				}

				$data['previous_page_count'] = $previous_page_count;
				$data['next_page_count'] = $next_page_count;
			}

			echo $this->load->view('pages/projects_management/list/dynamic_content', $data, TRUE);
		}
	    
		public function opsi_nilai_filter_pembayaran()
		{
			$filter_column = urldecode($this->input->get('filter_column'));
			
			$options = '';
			
			if($filter_column == 'events.unit_id,where')
			{
				$this->load->model('unit_model');

				$options = $options.'<option value="">Semua Unit</option>';

				$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
				
				foreach($unit_list as &$unit)
				{
					$options = $options.'<option value="'.$unit['unit_id'].'">'.$unit['name'].'</option>';
				}
			}
			else
			{
				$options = $options.'<option value="">Semua Status</option>';
				
				$filter_values = array(
					1 => 'Baru DP',
					2 => 'Cicilan',
					3 => 'Sudah Lunas'
				);
				
				foreach($filter_values as $key => $value)
				{
					$options = $options.'<option value="'.$key.'">'.$value.'</option>';
				}
			}

			echo $options;
        }

		public function detail($event_id, $view = 'event', $project_number = 0)
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->model('project_management_model');
			$this->load->helper('form');

			$data['title'] = ':: Sister JSO :: ';
			
			if($view == 'invoice' || $view == 'event' || $view == 'cashflow')
				$data['title'] = $data['title'].ucwords($view);
			else if($view == 'budget')
				$data['title'] = $data['title'].'RAB';
			else if($view == 'journal')
				$data['title'] = $data['title'].'Jurnal';
			else if($view == 'tax')
				$data['title'] = $data['title'].'Pajak';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');
			
			if($view == 'invoice' || $view == 'budget' || $view == 'logistic' || $view == 'journal' || $view == 'tax' || $view == 'cashflow')
			{
				$data['project'] = $this->project_management_model->read_events('*, events.name as event_name, units.name as unit_name, users.name as marketing_name', $event_id, 0, 'row_array', $view);

				if($view == 'journal')
					$data['project']['expenses_transactions'] = $this->project_management_model->read_journal('debt_reference_code, credit_reference_code, nominal', $event_id, '"beban instruktur", "beban hotel", "beban transportasi", "beban training", "beban ppn", "beban pph 23", "beban sewa", "beban konsumsi", "beban operasional", "beban kirim", "beban customer service", "beban driver", "beban training lain", "beban retur"');
				else if($view == 'tax')
					$data['project']['taxes_transactions'] = $this->project_management_model->read_journal('debt_reference_code, credit_reference_code, nominal', $event_id, '"pendapatan usaha", "beban ppn", "beban pph 23", "beban pph 21", "beban pph final"');
				else if($view == 'cashflow')
					$data['project']['expenses_taxes_transactions'] = $this->project_management_model->read_journal('transaction_date, debt_reference_code, credit_reference_code, nominal', $event_id, '"beban instruktur", "beban hotel", "beban transportasi", "beban training", "beban ppn", "beban pph 23", "beban sewa", "beban konsumsi", "beban operasional", "beban kirim", "beban customer service", "beban driver", "beban training lain", "beban retur", "pendapatan usaha", "beban ppn", "beban pph 23", "beban pph 21", "beban pph final"');
			}
			else if($view == 'event')
				$data['project'] = $this->project_management_model->read_events('*, events.name as event_name, units.name as unit_name', $event_id, 0, 'row_array', $view);
				
			
			if($view == 'invoice' || $view == 'tax')
				$data['project_number'] = $project_number;
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				//'assets/js/pages/event/payment/list.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/projects_management/'.$view, $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }
        
        public function sertifikat($event_id)
	    {
			$this->load->model('event_model');
			
			if($this->input->post('submit') != NULL)
			{
				$this->event_model->update_certificates($event_id);

                $this->session->set_flashdata('operation_result', 'certificates data saved');
                
				redirect('kegiatan/sertifikat/'.$event_id);
			}
			else
			{
				/*if($event_user_vendor_client['user_status'] != 'Calon karyawan' && !$this->session->has_userdata('user_id'))
                {	
                    $this->session->set_userdata('previous_url', current_url());

                    redirect('otentikasi/masuk');
                }

                $logged_in_user_role = $this->employee_model->read_users_roles_contracts($this->session->userdata('user_id'));

				if(($user_id == 0) && ($this->session->userdata('role_id') != 1))
					redirect('karyawan/tambah_ubah/'.$this->session->userdata('user_id'));

				if ( ($logged_in_user_role['user_id'] != $user_id) && ($this->session->userdata('role_id') != 1) )
					redirect('karyawan/tambah_ubah/'.$this->session->userdata('user_id'));
                */
				$this->load->model('employee_model');
				$this->load->helper('form');

				$header = 'Data Sertifikat';

				$event = $this->event_model->read_events_vendors_clients('*', '', 0, 'row_array', '', '', $event_id);
				
				$data['number_of_instructors'] = $event['number_of_instructors'];
				$data['clients_number'] = $event['clients_number'];

				$data['certificates'] = $this->event_model->read_certificates($event_id);
                    
				$data['title'] = ':: Sister JSO :: '.$header;
				
				$data['vendor_css_links'] = array(
					'bootstrap/css/bootstrap.min.css',
					'font-awesome/css/font-awesome.min.css',
					'animate-css/animate.min.css',
					'bootstrap-multiselect/bootstrap-multiselect.css',
					'bootstrap-datepicker/css/bootstrap-datepicker3.min.css',
					'bootstrap-colorpicker/css/bootstrap-colorpicker.css',
					'multi-select/css/multi-select.css',
					'bootstrap-tagsinput/bootstrap-tagsinput.css',
					'nouislider/nouislider.min.css',
					'toastr/toastr.min.css'
                );
                
				$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');
				
				$data['header'] = $header;
				
				$data['js_links'] = array(
					'assets/bundles/libscripts.bundle.js',
					'assets/bundles/vendorscripts.bundle.js',
					'vendor/jquery/jquery-3.3.1.min.js',
					'vendor/bootstrap-colorpicker/js/bootstrap-colorpicker.js',
					'vendor/jquery-inputmask/jquery.inputmask.bundle.js',
					'vendor/jquery-mask/jquery.mask.min.js',
					'vendor/multi-select/js/jquery.multi-select.js',
					'vendor/bootstrap-multiselect/bootstrap-multiselect.js',
					'vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js',
					'vendor/bootstrap-tagsinput/bootstrap-tagsinput.js',
					'vendor/nouislider/nouislider.js',
					'vendor/toastr/toastr.js',
					'assets/bundles/mainscripts.bundle.js',
					'assets/js/pages/forms/advanced-form-elements.js',
					'assets/js/pages/event/create_update.js'
				);

				// Render view on main layout
				$this->load->view('templates/dashboard/top', $data);
				$this->load->view('pages/certificates/update', $data);
				$this->load->view('templates/dashboard/bottom', $data);
			}
	    }

		/*public function ekspor()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('event_model');

			$spreadsheet = new Spreadsheet();
			
			$sheet = $spreadsheet->getActiveSheet();

			$sheet->setCellValue('A1', 'Nomor');
			$sheet->setCellValue('B1', 'Tanggal');
			$sheet->setCellValue('C1', 'Event');
			$sheet->setCellValue('D1', 'Kategori');
			$sheet->setCellValue('E1', 'Jenis');
			$sheet->setCellValue('F1', 'Status');
			$sheet->setCellValue('G1', 'Tayang');
			$sheet->setCellValue('H1', 'Tanggal Mulai Pelatihan');
			$sheet->setCellValue('I1', 'Tanggal Berakhir Pelatihan');
			$sheet->setCellValue('J1', 'Jam Mulai');
			$sheet->setCellValue('K1', 'Jam Selesai');
			$sheet->setCellValue('L1', 'Instruktur');
			$sheet->setCellValue('M1', 'Kota');
			$sheet->setCellValue('N1', 'Hotel');
			$sheet->setCellValue('O1', 'Penyelenggara');
			$sheet->setCellValue('P1', 'Marketing');
			$sheet->setCellValue('Q1', 'CS');
			$sheet->setCellValue('R1', 'Driver');
			$sheet->setCellValue('S1', 'Logistik');
			$sheet->setCellValue('T1', 'Sumber');
			$sheet->setCellValue('U1', 'Harga');
			$sheet->setCellValue('V1', 'Jumlah');
			$sheet->setCellValue('W1', 'Total');
			$sheet->setCellValue('X1', 'Peserta');
			$sheet->setCellValue('Y1', 'Email');
			$sheet->setCellValue('Z1', 'Perusahaan');
			$sheet->setCellValue('AA1', 'Posisi');
			$sheet->setCellValue('AB1', 'HP');
			$sheet->setCellValue('AC1', 'Telp Kantor');
			$sheet->setCellValue('AD1', 'Keterangan');			

			$events_users_vendors_clients = $this->event_model->read_events_vendors_clients('*, events.name as event_name, clients.name as client_name', 'client');
			
			$number = 1;

			foreach($events_users_vendors_clients as &$event_user_vendor_client)
			{
				$sheet->setCellValue('A'.($number + 1), $number);
				$sheet->setCellValue('B'.($number + 1), substr($event_user_vendor_client['proposal_date'], -2).'-'.substr($event_user_vendor_client['proposal_date'], 5, 2).'-'.substr($event_user_vendor_client['proposal_date'], 0, 4));
				$sheet->setCellValue('C'.($number + 1), $event_user_vendor_client['event_name']);
				$sheet->setCellValue('D'.($number + 1), $event_user_vendor_client['category']);
				$sheet->setCellValue('E'.($number + 1), $event_user_vendor_client['type']);
				$sheet->setCellValue('F'.($number + 1), $event_user_vendor_client['status']);

				if($event_user_vendor_client['status'] == 'Fixed')
					$aired = 'V';
				else
					$aired = '';
				
				$sheet->setCellValue('G'.($number + 1), $aired);
				$sheet->setCellValue('H'.($number + 1), substr($event_user_vendor_client['start_date'], -2).'-'.substr($event_user_vendor_client['start_date'], 5, 2).'-'.substr($event_user_vendor_client['start_date'], 0, 4));
				$sheet->setCellValue('I'.($number + 1), substr($event_user_vendor_client['end_date'], -2).'-'.substr($event_user_vendor_client['end_date'], 5, 2).'-'.substr($event_user_vendor_client['end_date'], 0, 4));
				$sheet->setCellValue('J'.($number + 1), $event_user_vendor_client['starting_hour']);
				$sheet->setCellValue('K'.($number + 1), $event_user_vendor_client['completion_hour']);
				$sheet->setCellValue('L'.($number + 1), $event_user_vendor_client['instructor_name']);
				$sheet->setCellValue('M'.($number + 1), $event_user_vendor_client['city']);
				$sheet->setCellValue('N'.($number + 1), $event_user_vendor_client['hotel_vendor_id']);
				$sheet->setCellValue('O'.($number + 1), 'PT JSO SMB');
				$sheet->setCellValue('P'.($number + 1), $event_user_vendor_client['marketing_name']);
				$sheet->setCellValue('Q'.($number + 1), $event_user_vendor_client['cs_name']);
				$sheet->setCellValue('R'.($number + 1), $event_user_vendor_client['driver_name']);
				$sheet->setCellValue('S'.($number + 1), $event_user_vendor_client['logistic_name']);
				$sheet->setCellValue('T'.($number + 1), $event_user_vendor_client['source']);
				$sheet->setCellValue('U'.($number + 1), $event_user_vendor_client['price']);
				$sheet->setCellValue('V'.($number + 1), $event_user_vendor_client['clients_number']);
				$sheet->setCellValue('W'.($number + 1), ($event_user_vendor_client['price'] * $event_user_vendor_client['clients_number']));
				$sheet->setCellValue('X'.($number + 1), $event_user_vendor_client['client_name']);
				$sheet->setCellValue('Y'.($number + 1), $event_user_vendor_client['email_address']);
				$sheet->setCellValue('Z'.($number + 1), $event_user_vendor_client['company']);
				$sheet->setCellValue('AA'.($number + 1), $event_user_vendor_client['position']);
				$sheet->setCellValueExplicit('AB'.($number + 1), $event_user_vendor_client['mobile_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
				$sheet->setCellValueExplicit('AC'.($number + 1), $event_user_vendor_client['phone_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
				$sheet->setCellValue('AD'.($number + 1), $event_user_vendor_client['notes']);				

				$number++;
			}

			$sheet->getColumnDimension('A')->setAutoSize(true);
			$sheet->getColumnDimension('B')->setAutoSize(true);
			$sheet->getColumnDimension('C')->setAutoSize(true);
			$sheet->getColumnDimension('D')->setAutoSize(true);
			$sheet->getColumnDimension('E')->setAutoSize(true);
			$sheet->getColumnDimension('F')->setAutoSize(true);
			$sheet->getColumnDimension('G')->setAutoSize(true);
			$sheet->getColumnDimension('H')->setAutoSize(true);
			$sheet->getColumnDimension('I')->setAutoSize(true);
			$sheet->getColumnDimension('J')->setAutoSize(true);
			$sheet->getColumnDimension('K')->setAutoSize(true);
			$sheet->getColumnDimension('L')->setAutoSize(true);
			$sheet->getColumnDimension('M')->setAutoSize(true);
			$sheet->getColumnDimension('N')->setAutoSize(true);
			$sheet->getColumnDimension('O')->setAutoSize(true);
			$sheet->getColumnDimension('P')->setAutoSize(true);
			$sheet->getColumnDimension('Q')->setAutoSize(true);
			$sheet->getColumnDimension('R')->setAutoSize(true);
			$sheet->getColumnDimension('S')->setAutoSize(true);
			$sheet->getColumnDimension('T')->setAutoSize(true);
			$sheet->getColumnDimension('U')->setAutoSize(true);
			$sheet->getColumnDimension('V')->setAutoSize(true);
			$sheet->getColumnDimension('W')->setAutoSize(true);
			$sheet->getColumnDimension('X')->setAutoSize(true);
			$sheet->getColumnDimension('Y')->setAutoSize(true);
			$sheet->getColumnDimension('Z')->setAutoSize(true);
			$sheet->getColumnDimension('AA')->setAutoSize(true);
			$sheet->getColumnDimension('AB')->setAutoSize(true);
			$sheet->getColumnDimension('AC')->setAutoSize(true);
			$sheet->getColumnDimension('AD')->setAutoSize(true);
			
			$writer = new Xlsx($spreadsheet);
	
			$filename = 'Data Progress Harian '.date("d-m-Y H.i").' WIB';
	
			header('Content-Type: application/vnd.ms-excel');
			header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
			header('Cache-Control: max-age=0');
			
			$writer->save('php://output'); // download file
	    }*/
	}
?>