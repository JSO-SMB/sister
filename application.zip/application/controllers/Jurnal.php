<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	use PhpOffice\PhpSpreadsheet\Spreadsheet;
	use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
	
	class Jurnal extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}
        }
		
		public function index()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->helper('form');

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'FINANCE')
				redirect();

			$data['title'] = ':: Sister JSO :: Jurnal';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);
			
			$data['js_links'] = array(
				//'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
                'assets/js/pages/journal.js',
                /*'vendor/bootstrap-colorpicker/js/bootstrap-colorpicker.js',
                'vendor/jquery-inputmask/jquery.inputmask.bundle.js',*/
                'vendor/jquery-mask/jquery.mask.min.js',
                /*'vendor/multi-select/js/jquery.multi-select.js',
                'vendor/bootstrap-multiselect/bootstrap-multiselect.js',
                'vendor/nouislider/nouislider.js',
                'assets/js/pages/forms/advanced-form-elements.js'*/
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/finance/journal/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		public function data_transaksi($page_number)
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			require 'Options.php';

			$this->load->model('employee_model');
			$this->load->model('journal_model');
			$this->load->model('unit_model');
			$this->load->helper('form');

			$data['units_for_filter'] = array(
				'' => 'Semua Unit'
			);

			$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
			
			foreach($unit_list as &$unit)
			{
				$data['units_for_filter'][$unit['unit_id']] = $unit['name'];
			}

			$data['unit_id'] = $this->input->get('unit_id');

			$data['reference_codes_for_filter'] = array_merge(array('' => 'Semua Kode'), $reference_codes);

			$data['debt_reference_code'] = urldecode($this->input->get('debt_reference_code'));
			$data['credit_reference_code'] = urldecode($this->input->get('credit_reference_code'));

			$data['submission_period_parameters'] = array(
				'submission_date,where' => 'Tanggal submit',
				'submission_date,like' => 'Bulan & tahun submit',
				'YEAR(submission_date),where' => 'Tahun submit'
			);

			$data['submission_period_parameter'] = urldecode($this->input->get('submission_period_parameter'));

			if($data['submission_period_parameter'] == 'submission_date,where' || $data['submission_period_parameter'] == 'submission_date,like')
			{
				if($data['submission_period_parameter'] == 'submission_date,where')
					$data['submission_period_label'] = 'Tanggal';
				else
					$data['submission_period_label'] = 'Bulan & Tahun';
				
				$data['submission_periods'] = array();
			}
			else
			{
				$data['submission_period_label'] = 'Tahun';

				$data['submission_periods'] = array(
					'' => 'Semua Tahun'
				);
				
				for($option_counter = date('Y'); $option_counter >= 2020; $option_counter--)
                {
                    $data['submission_periods'][$option_counter] = $option_counter;
				}
			}

			$data['submission_period'] = urldecode($this->input->get('submission_period'));

			$data['transaction_period_parameters'] = array(
				'transaction_date,where' => 'Tanggal transaksi',
				'transaction_date,like' => 'Bulan & tahun transaksi',
				'YEAR(transaction_date),where' => 'Tahun transaksi',
			);

			$data['transaction_period_parameter'] = urldecode($this->input->get('transaction_period_parameter'));

			if($data['transaction_period_parameter'] == 'transaction_date,where' || $data['transaction_period_parameter'] == 'transaction_date,like')
			{
				if($data['transaction_period_parameter'] == 'transaction_date,where')
					$data['transaction_period_label'] = 'Tanggal';
				else
					$data['transaction_period_label'] = 'Bulan & Tahun';
				
				$data['transaction_periods'] = array();
			}
			else
			{
				$data['transaction_period_label'] = 'Tahun';

				$data['transaction_periods'] = array(
					'' => 'Semua Tahun'
				);
				
				for($option_counter = date('Y'); $option_counter >= 2020; $option_counter--)
                {
                    $data['transaction_periods'][$option_counter] = $option_counter;
				}
			}

			$data['transaction_period'] = urldecode($this->input->get('transaction_period'));
			$data['ordering_column'] = urldecode($this->input->get('ordering_column'));
			
			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
					
			foreach($unit_list as &$unit)
			{
				$units[$unit['unit_id']] = $unit['name'];
			}

			$data['units'] = $units;
            
            $event_user_list = $this->journal_model->read_events_users();

            foreach($event_user_list as $event_user)
            {
                $data['events_users'][$event_user['event_id']] = $event_user['event_name'].' ('.substr($event_user['start_date'], -2).'/'.substr($event_user['start_date'], 5, 2).'/'.substr($event_user['start_date'], 0, 4).' - '.substr($event_user['end_date'], -2).'/'.substr($event_user['end_date'], 5, 2).'/'.substr($event_user['end_date'], 0, 4).') '.$event_user['unit_name'].' by '.$event_user['marketing_name'];
            }
            
            $funding_submission_user_unit_list = $this->journal_model->read_funding_submissions_users_units('funding_submission_id, users.name as applicant_name, code, financing_code, nominal, payment_deadline');

            foreach($funding_submission_user_unit_list as $funding_submission_user_unit)
            {
                $data['funding_submissions_users_units'][$funding_submission_user_unit['funding_submission_id']] = $funding_submission_user_unit['applicant_name'].' : '.$funding_submission_user_unit['code'].'; '.$funding_submission_user_unit['financing_code'].'; '.$funding_submission_user_unit['nominal'].' - '.substr($funding_submission_user_unit['payment_deadline'], -2).'/'.substr($funding_submission_user_unit['payment_deadline'], 5, 2).'/'.substr($funding_submission_user_unit['payment_deadline'], 0, 4);
			}
			
			$data['reference_codes'] = $reference_codes;
            
			$data['transactions'] = $this->journal_model->read_journal('*', $page_number);
			$data['page_number'] = $page_number;
            
			$page_count = ceil($this->journal_model->read_journal('*', 0, 'num_rows') / 5);

			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				if($page_count > 10)
				{
					if($page_number > 6)
					{
						if(($page_count - $page_number) >= 4)
							$next_page_count = 4;
						else
							$next_page_count = $page_count - $page_number;
						
						$previous_page_count = 9 - $next_page_count;
					}
					else
					{
						$previous_page_count = $page_number - 1;
						$next_page_count = 9 - $previous_page_count;
					}
				}
				else
				{
					$previous_page_count = $page_number - 1;
					$next_page_count = $page_count - $page_number;
				}

				$data['previous_page_count'] = $previous_page_count;
				$data['next_page_count'] = $next_page_count;
			}

			echo $this->load->view('pages/finance/journal/dynamic_content', $data, TRUE);
        }
        
		public function simpan_data_transaksi()
		{
			$this->load->model('journal_model');

			if(array_key_exists('transfer_proof', $_FILES))
			{
				/*$inputs = 1;
				
				$input_name = array(
					'transfer_proof'
				);

				$docs = 0;
				$skip = 0;
				$uri = 'jurnal';
				
				for($input_counter = 0; $input_counter < $inputs; $input_counter++)
				{
					if($_FILES[$input_name[$input_counter]]['size'] > 0)
					{
						$this->load->library('upload');

						$docs++;

						break;
					}
					else
						$skip++;
				}
				
				if($docs > 0)
				{
					for($input_counter = 0; $input_counter < $inputs; $input_counter++)
					{
						if($skip > 0)
						{
							$skip--;

							$file_names[$input_name[$input_counter]] = '';
						}
						else
						{
							if($_FILES[$input_name[$input_counter]]['size'] > 0)
							{
								$config['upload_path']		= './uploads/finance/journal/transfer_proofs';
								$config['allowed_types'] 	= 'jpg|jpeg|png';

								$this->upload->initialize($config);
								
								if(!$this->upload->do_upload($input_name[$input_counter]))
								{
									$this->session->set_flashdata('operation_result', $this->upload->display_errors());
									
									redirect($uri);
								}
								else
									$file_names[$input_name[$input_counter]] = $this->upload->data('file_name');
							}
							else
								$file_names[$input_name[$input_counter]] = '';
						}
					}
				}
				else
				{
					for($input_counter = 0; $input_counter < $inputs; $input_counter++)
					{
						$file_names[$input_counter] = '';
					}
				}*/

				$config['upload_path']		= './uploads/finance/journal/transfer_proofs';
				$config['allowed_types'] 	= '*';

				$this->load->library('upload', $config);
				
				$file_names['transfer_proof'] = '';

				echo 'exist';
				
				//if(!empty(array_filter($_FILES['transfer_proof']['name'])))
				//{ 
					foreach($_FILES['transfer_proof']['name'] as $key=>$value)
					{
						$_FILES['proof']['name'] = $_FILES['transfer_proof']['name'][$key];
						$_FILES['proof']['type'] = $_FILES['transfer_proof']['type'][$key];
						$_FILES['proof']['tmp_name'] = $_FILES['transfer_proof']['tmp_name'][$key];
						$_FILES['proof']['error'] = $_FILES['transfer_proof']['error'][$key];
						$_FILES['proof']['size'] = $_FILES['transfer_proof']['size'][$key];

						if(!$this->upload->do_upload('proof'))
						{
							$this->session->set_flashdata('error_messages', $this->upload->display_errors());
							
							redirect('jurnal');
						}
						else
						{
							if($file_names['transfer_proof'] == '')
								$file_names['transfer_proof'] = $this->upload->data('file_name');
							else
								$file_names['transfer_proof'] = $file_names['transfer_proof'].','.$this->upload->data('file_name');
						}
					}
				//}
			}
			else
				$file_names = array();

			$this->journal_model->update($file_names);
		}
	}
?>