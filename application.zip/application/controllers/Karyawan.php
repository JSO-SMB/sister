<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	use PhpOffice\PhpSpreadsheet\Spreadsheet;
	use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
	
	class Karyawan extends CI_Controller
	{
		public function tambah_ubah($email_address = '')
	    {
	    	if($this->input->post('submit') != NULL)
			{
				$this->load->model('employee_model');
				
				if($email_address == '')
				{
					$config['upload_path']          = './uploads/';
					$config['allowed_types']        = 'jpg|jpeg';
	
					$this->load->library('upload', $config);
					
					if(!$this->upload->do_upload('id_card'))
					{
						$this->session->set_flashdata('error_messages', $this->upload->display_errors());
						
						redirect('karyawan/tambah_ubah');
					}
					else
						$id_card = $this->upload->data('file_name');
				
					if(!$this->upload->do_upload('photo'))
					{
						$this->session->set_flashdata('error_messages', $this->upload->display_errors());
						
						redirect('karyawan/tambah_ubah');
					}
					else
						$photo = $this->upload->data('file_name');

					$this->employee_model->create_update_user($id_card, $photo);
				}
				else
				{
					if($_FILES['id_card']['size'] > 0 || $_FILES['photo']['size'] > 0)
					{
						$config['upload_path']          = './uploads/';
						$config['allowed_types']        = 'jpg|jpeg';
		
						$this->load->library('upload', $config);
					}

					if($_FILES['id_card']['size'] > 0)
					{
						if(!$this->upload->do_upload('id_card'))
						{
							$this->session->set_flashdata('error_messages', $this->upload->display_errors());
							
							redirect('karyawan/tambah_ubah/'.$email_address);
						}
						else
							$id_card = $this->upload->data('file_name');
					}
					else
						$id_card = '';

					if($_FILES['photo']['size'] > 0)
					{	
						if(!$this->upload->do_upload('photo'))
						{
							$this->session->set_flashdata('error_messages', $this->upload->display_errors());
							
							redirect('karyawan/tambah_ubah/'.$email_address);
						}
						else
							$photo = $this->upload->data('file_name');
					}
					else
						$photo = '';

					$this->employee_model->create_update_user($id_card, $photo, urldecode($email_address));
				}

				if($this->session->has_userdata('user_id'))
				{
					if($this->session->userdata('email_address') == $email_address)
						$this->session->set_userdata('email_address', $this->input->post('email_address'));
					
					$this->session->set_flashdata('operation_result', 'update success');

					redirect('karyawan/tambah_ubah/'.urlencode($this->input->post('email_address')));
				}
				else
				{
					$user_role = $this->employee_model->read_users_roles('', 2);
					
					$message = 'Yth. HRD JSO SMB,<br /><br />';
					$message = $message.'Terdapat data registrasi seleksi calon karyawan baru yang masuk untuk posisi & pilihan jadwal wawancara berikut:<br /><br />';
					$message = $message.'<b>Nama: '.$this->input->post('name').'<br />';
					$message = $message.'Alamat email: '.$this->input->post('email_address').'<br />';
					$message = $message.'Posisi & pilihan jadwal wawancara: '.$this->input->post('division').'</b><br /><br />';
					$message = $message.'Anda dapat melihat detail dari data registrasi tersebut pada <a href="'.base_url('karyawan/tambah_ubah/'.rawurlencode($this->input->post('email_address'))).'" target="_blank">tautan ini</a>.<br /><br />';
					$message = $message.'Salam,<br />SISTER JSO SMB';

					$this->load->library('email');
					
					// Sending to an account, for activation (username, password)
					$this->email->from('sister.jsosmboffice@gmail.com', 'SISTER JSO');	
					$this->email->to($user_role['email_address']);

					//$this->email->cc('another@another-example.com');
					//$this->email->bcc('them@their-example.com');
					$this->email->subject('Data Registrasi Seleksi Calon Karyawan');
					$this->email->message($message);

					$this->email->send();
					
					$this->session->set_flashdata('operation_result', 'employee candidate registration success');

					redirect('karyawan/tambah_ubah');
				}
			}
			else
			{
				/*$logged_in_user_role = $this->employee_model->read_users_roles($this->session->userdata('user_id'));

				if(($user_id == 0) && ($this->session->userdata('role_id') != 1))
					redirect('karyawan/tambah_ubah/'.$this->session->userdata('user_id'));

				if ( ($logged_in_user_role['user_id'] != $user_id) && ($this->session->userdata('role_id') != 1) )
					redirect('karyawan/tambah_ubah/'.$this->session->userdata('user_id'));
				*/
				$this->load->helper('form');

				require 'Options.php';
				
				// Set title page
				if($this->session->has_userdata('user_id'))
					$data['title'] = ':: Sister JSO :: Ubah Data Karyawan';
				else
					$data['title'] = ':: Sister JSO :: Registrasi Seleksi Calon Karyawan';
				
				$data['vendor_css_links'] = array(
					'bootstrap/css/bootstrap.min.css',
					'font-awesome/css/font-awesome.min.css',
					'animate-css/animate.min.css',
					'bootstrap-datepicker/css/bootstrap-datepicker3.min.css',
					'toastr/toastr.min.css',
                    'dropify/css/dropify.min.css'
				);
					
				if($email_address == '')
				{
					if($this->session->has_userdata('user_id'))
						redirect('karyawan/tambah_ubah/'.urlencode($this->session->userdata('email_address')));

					$data['email_address'] = '';
					$data['name'] = '';
					$data['nickname'] = '';
					$data['birthplace'] = '';
					$data['birthday'] = '0000-00-00';
					$data['age'] = '0';
					$data['religion'] = 'Islam';
					$data['marital_status'] = 'Belum menikah';
					$data['last_education'] = 'SMP / SEDERAJAT';
					$data['major'] = '';
					$data['gender'] = 'Laki - Laki';
					$data['phone_number'] = '62';
					$data['id_card_city'] = '';
					$data['id_card_address'] = '';
					$data['single_address'] = FALSE;
					$data['city'] = '';
					$data['address'] = '';
					$data['father_phone_number'] = '62';
					$data['expertise'] = '';
					$data['company_profile_knowledge'] = '';
					$data['interest_to_company'] = '';
					$data['interest_to_division'] = '';
					$data['other_divisions'] = '';
					$data['overtime'] = '';
					$data['probation'] = '';
					$data['ambitions'] = '';
					$data['positive_attitudes'] = '';
					$data['negative_attitudes'] = '';
					$data['recruit_reasons'] = '';
					$data['to_dos'] = '';
					$data['referral'] = '';
					$data['user_status'] = '';
				}
				else
				{
					$this->load->model('employee_model');
					
					$user_role = $this->employee_model->read_users_roles_2(urldecode($email_address), 0, 'employees');

					if($user_role['user_status'] != 'Calon karyawan' && !$this->session->has_userdata('user_id'))
					{	
						$this->session->set_userdata('previous_url', current_url());

						redirect('otentikasi/masuk');
					}

					$data['email_address'] = $user_role['email_address'];
					$data['name'] = $user_role['name'];
					$data['nickname'] = $user_role['nickname'];
					$data['birthplace'] = $user_role['birthplace'];
					$data['birthday'] = $user_role['birthday'];
					$data['age'] = date_diff(date_create($user_role['birthday']), date_create(date('Y-m-d')))->format('%y');
					$data['religion'] = $user_role['religion'];
					$data['marital_status'] = $user_role['marital_status'];
					$data['last_education'] = $user_role['last_education'];
					$data['major'] = $user_role['major'];
					$data['gender'] = $user_role['gender'];
					$data['phone_number'] = $user_role['phone_number'];
					$data['id_card_city'] = $user_role['id_card_city'];
					$data['id_card_address'] = $user_role['id_card_address'];
					
					if($user_role['id_card_city'] == $user_role['city'] && $user_role['id_card_address'] == $user_role['address'])
						$data['single_address'] = TRUE;
					else
						$data['single_address'] = FALSE;
					
					$data['city'] = $user_role['city'];
					$data['address'] = $user_role['address'];
					$data['id_card'] = $user_role['id_card'];
					$data['photo'] = $user_role['photo'];
					$data['father_phone_number'] = $user_role['father_phone_number'];
					$data['expertise'] = $user_role['expertise'];
					$data['company_profile_knowledge'] = $user_role['company_profile_knowledge'];
					$data['interest_to_company'] = $user_role['interest_to_company'];
					$data['interest_to_division'] = $user_role['interest_to_division'];
					$data['other_divisions'] = $user_role['other_divisions'];
					$data['overtime'] = $user_role['overtime'];
					$data['probation'] = $user_role['probation'];
					$data['ambitions'] = $user_role['ambitions'];
					$data['positive_attitudes'] = $user_role['positive_attitudes'];
					$data['negative_attitudes'] = $user_role['negative_attitudes'];
					$data['recruit_reasons'] = $user_role['recruit_reasons'];
					$data['to_dos'] = $user_role['to_dos'];
					$data['referral'] = $user_role['referral'];
					$data['user_status'] = $user_role['user_status'];

					if($this->session->has_userdata('user_id'))
					{
						$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');
						
						$data['account_number'] = $user_role['account_number'];
						$data['accountee'] = $user_role['accountee'];
						$data['mate_name'] = $user_role['mate_name'];
						$data['mate_phone_number'] = $user_role['mate_phone_number'];
						$data['mate_occupation'] = $user_role['mate_occupation'];
						$data['id_card_number'] = $user_role['id_card_number'];
						$data['mother_name'] = $user_role['mother_name'];
						$data['mother_phone_number'] = $user_role['mother_phone_number'];
						$data['mother_occupation'] = $user_role['mother_occupation'];
						$data['father_name'] = $user_role['father_name'];
						$data['father_occupation'] = $user_role['father_occupation'];
						$data['division'] = $user_role['division'];
						$data['interview_invitation'] = $user_role['interview_invitation'];
						$data['user_id'] = $user_role['user_id'];
					}
				}
				
				$data['email_address_check_link'] = base_url('karyawan/cek_alamat_email/');
				$data['religions'] = $religions;
				$data['marital_status_options'] = $marital_status_options;
				$data['educational_level'] = $educational_level;
				
				$data['js_links'] = array(
					'assets/bundles/libscripts.bundle.js',
					'assets/bundles/vendorscripts.bundle.js',
					'vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js',
					'vendor/toastr/toastr.js',
                    'vendor/dropify/js/dropify.min.js',
					'assets/bundles/mainscripts.bundle.js',
                    'assets/js/pages/forms/dropify.js',
					'assets/js/pages/employee/create_update.js'
				);

				// Render view on main layout
				$this->load->view('templates/dashboard/top', $data);
				$this->load->view('pages/employees/create_update/static_content', $data);
				$this->load->view('templates/dashboard/bottom', $data);
			}
	    }
	    
		public function cek_alamat_email($email_address)
		{
			$this->load->model('employee_model');
			
			$user = $this->employee_model->read_email_address(urldecode($email_address));
			
			if(isset($user['user_status']))
				echo $user['user_status'];
			else
				echo '';
		}

		public function hapus()
		{
			$this->load->library('authorization');
			
			$this->authorization->is_logged_in();
			
			if($this->input->post('submission') != NULL)
			{
				$this->load->model('employee_model');
				
				$this->employee_model->delete($this->input->get('user_id'));
                
				$this->session->set_flashdata('operation_result', 'data deleted');
				
                redirect('karyawan');
			}
		}
		
	    public function wawancara()
	    {
			$this->load->helper('form');

			if($this->input->get('division_schedule') != NULL)
				$data['division_schedule'] = $this->input->get('division_schedule');
			else
				$data['division_schedule'] = '';
			
			echo $this->load->view('pages/employees/create_update/interview_schedules', $data, TRUE);
		}
		
		public function undang($email_address, $subject = 'wawancara')
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());

				redirect('otentikasi/masuk');
			}
			
			$this->load->model('employee_model');
			$this->load->library('email');
			
			$user_role = $this->employee_model->read_users_roles(urldecode($email_address), '', 'employees');
		
			// Sending to an account, for activation (username, password)
			$this->email->from('sister.jsosmboffice@gmail.com', 'SISTER JSO');	
			$this->email->to($user_role['$email_address']);

			//$this->email->cc('another@another-example.com');
			//$this->email->bcc('them@their-example.com');
			
			$message = 'Yth. ';
			
			if($user_role['gender'] == 'Laki - Laki')
				$message = 'Saudara ';
			else
				$message = 'Saudari ';
			
			$message = $message.$user_role['name'].',<br /><br />';

			if($subject == 'wawancara')
			{
				$this->email->subject('Undangan Seleksi Wawancara Calon Karyawan JSO SMB');
				
				$message = $message.'Berikut kami sampaikan undangan seleksi wawancara sesuai posisi & jadwal wawancara yang telah Anda pilih:<br /><br />';
				$message = $message.'<b>'.$user_role['division'].'</b><br /><br />';
				$message = $message.'Silakan datang ke kantor JSO SMB sesuai jadwal yang telah Anda pilih untuk melakukan wawancara dengan bagian HRD JSO SMB.<br /><br />';
			}
			else
			{
				$this->email->subject('Undangan Kontrak Kerja Calon Karyawan JSO SMB');

				$message = $message.'Melalui email ini kami ucapkan selamat karena Anda telah lolos proses seleksi calon karyawan PT. JSO SMB. Selanjutnya silakan datang ke kantor PT. JSO SMB untuk pembuatan kontrak kerja sesuai posisi yang Anda lamar.<br /><br />';
			}
			
			$message = $message.'Salam,<br />SISTER JSO SMB';
			
			$this->email->message($message);

			$this->email->send();

			if($subject == 'wawancara')
			{
				$this->employee_model->update_interview_invitation($user_role['user_id']);
				
				$this->session->set_flashdata('operation_result', 'interview invitation sent');
			}
			else
				$this->session->set_flashdata('operation_result', 'contract invitation sent');

			redirect('karyawan/tambah_ubah/'.$email_address);
		}

		public function daftar($category = 'rekening')
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->helper('form');

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'HRD' && $data['logged_in_user']['division'] != 'FINANCE')
				redirect();

			if($category == 'general')
				$data['title'] = ':: Sister JSO :: Data Karyawan';
			else
				$data['title'] = ':: Sister JSO :: Data Rekening';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'/*,
				'toastr/toastr.min.css'*/
			);
			
			$data['category'] = $category;
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				//'vendor/toastr/toastr.js',
				'assets/js/pages/employee/list.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/employees/list/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		public function data($page_number, $category, $name = '')
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->helper('form');

			$data['name'] = urldecode($name);

			$data['users_roles'] = $this->employee_model->read_users_roles('', 0, '', 'result_array', $page_number, urldecode($name));
			
			$data['page_number'] = $page_number;
			$data['category'] = $category;

			$page_count = ceil($this->employee_model->read_users_roles('', 0, '', 'num_rows', 0, urldecode($name)) / 5);
			
			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				if($page_count > 10)
				{
					if($page_number > 6)
					{
						if(($page_count - $page_number) >= 4)
							$next_page_count = 4;
						else
							$next_page_count = $page_count - $page_number;
						
						$previous_page_count = 9 - $next_page_count;
					}
					else
					{
						$previous_page_count = $page_number - 1;
						$next_page_count = 9 - $previous_page_count;
					}
				}
				else
				{
					$previous_page_count = $page_number - 1;
					$next_page_count = $page_count - $page_number;
				}

				$data['previous_page_count'] = $previous_page_count;
				$data['next_page_count'] = $next_page_count;
			}

			echo $this->load->view('pages/employees/list/dynamic_content', $data, TRUE);
	    }

		public function index()
	    {
			$this->load->library('authorization');
			
			$this->authorization->is_logged_in();

			$this->load->model('general_model');
			$this->load->model('employee_model');

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'HRD')
				redirect();
			
			if($this->input->get('category') == NULL)
				$data['header'] = 'Data Karyawan';
			else
			{
				if($this->input->get('category') == 'Rekening')
					$data['header'] = 'Data Rekening';
				else
					redirect('karyawan');
			}
			
			$this->load->helper('form');

			require 'Options.php';
			
			$data['title'] = ':: Sister JSO :: '.$data['header'];

			$data['breadcrumbs'] = 2;

			$data['breadcrumb']['item'][1] = 'Karyawan';

			$data['table']['order']['input']['options'] = array(
				''						=> '',
				'users.name,ASC'		=> 'Nama(A-Z)',
				'users.name,DESC'		=> 'Nama(Z-A)',
				'email_address,ASC'		=> 'Alamat email(A-Z)',
				'email_address,DESC'	=> 'Alamat email(Z-A)',
				'birthday,ASC'			=> 'Umur(ASC)',
				'birthday,DESC'			=> 'Umur(DESC)',
				// 'position,ASC'			=> 'Jabatan(A-Z)',
				// 'position,DESC'			=> 'Jabatan(Z-A)',
				'division,ASC'			=> 'Divisi(A-Z)',
				'division,DESC'			=> 'Divisi(Z-A)',
				'address,ASC'			=> 'Alamat(A-Z)',
				'address,DESC'			=> 'Alamat(Z-A)',
				'last_education,ASC'	=> 'Pendidikan(A-Z)',
				'last_education,DESC'	=> 'Pendidikan(Z-A)',
				'major,ASC'				=> 'Jurusan(A-Z)',
				'major,DESC'			=> 'Jurusan(Z-A)',
				'expertise,ASC'			=> 'Keahlian(A-Z)',
				'expertise,DESC'		=> 'Keahlian(Z-A)',
				'user_status,ASC'		=> 'Status(A-Z)',
				'user_status,DESC'		=> 'Status(Z-A)'
			);

			$data['columns'] = 11;

			$data['table']['header'][1] = '#';
			$data['table']['header'][2] = 'NAMA';
			$data['table']['header'][3] = 'EMAIL';
			$data['table']['header'][4] = 'UMUR';
			$data['table']['header'][5] = 'DIVISI';
			$data['table']['header'][6] = 'ALAMAT';
			$data['table']['header'][7] = 'PENDIDIKAN';
			$data['table']['header'][8] = 'JURUSAN';
			$data['table']['header'][9] = 'KEAHLIAN';
			$data['table']['header'][10] = 'STATUS';
			$data['table']['header'][11] = 'OPERASI';

			$data['table']['filter']['input']['id'][2] = 'name-input';
			$data['table']['filter']['input']['id'][3] = 'email-address-input';
			$data['table']['filter']['input']['id'][4] = 'age-input';
			$data['table']['filter']['input']['id'][5] = 'division-select';
			$data['table']['filter']['input']['id'][6] = 'address-input';
			$data['table']['filter']['input']['id'][7] = 'last-education-select';
			$data['table']['filter']['input']['id'][8] = 'major-input';
			$data['table']['filter']['input']['id'][9] = 'expertise-input';
			$data['table']['filter']['input']['id'][10] = 'user-status-select';

			$data['table']['filter']['input']['type'][2] = 'text';
			$data['table']['filter']['input']['type'][3] = 'text';
			$data['table']['filter']['input']['type'][4] = 'number';
			$data['table']['filter']['input']['type'][5] = 'multiselect';
			$data['table']['filter']['input']['type'][6] = 'text';
			$data['table']['filter']['input']['type'][7] = 'multiselect';
			$data['table']['filter']['input']['type'][8] = 'text';
			$data['table']['filter']['input']['type'][9] = 'text';
			$data['table']['filter']['input']['type'][10] = 'multiselect';
				
			$data['table']['filter']['input']['options'][5] = array(
				'DRIVER' => 'DRIVER',
				'OFFICE BOY' => 'OFFICE BOY',
				'VIDEOGRAFER' => 'VIDEOGRAFER',
				// 'CUSTOMER SERVICE' => 'CUSTOMER SERVICE',
				'HRD' => 'HRD',
				'RND' => 'RND',
				'IT' => 'IT',
				'CONTENT WRITER' => 'CONTENT WRITER',
				'FINANCE' => 'FINANCE',
				'LOGISTIK' => 'LOGISTIK',
				'MARKETING' => 'MARKETING',
				// 'INSTRUKTUR' => 'INSTRUKTUR',
				'MANAJEMEN' => 'MANAJEMEN'
			);
			$data['table']['filter']['input']['options'][7] = $educational_level;
			$data['table']['filter']['input']['options'][10] = array(
				'Calon karyawan'	=> 'Calon karyawan',
				'Aktif'				=> 'Aktif',
				'SP 3'				=> 'SP 3',
				'Resign'			=> 'Resign'
			);

			$data['table']['filter']['input']['value'][5] = array();
			$data['table']['filter']['input']['value'][7] = array();
			$data['table']['filter']['input']['value'][10] = array();

			$data['table']['filter']['input']['onchange'][5] = 'getTableData(1)';
			$data['table']['filter']['input']['onchange'][7] = 'getTableData(1)';
			$data['table']['filter']['input']['onchange'][10] = 'getTableData(1)';

			$data['table']['filter']['input']['oninput'][2] = 'getTableData(1)';
			$data['table']['filter']['input']['oninput'][3] = 'getTableData(1)';
			$data['table']['filter']['input']['oninput'][4] = 'getTableData(1)';
			$data['table']['filter']['input']['oninput'][6] = 'getTableData(1)';
			$data['table']['filter']['input']['oninput'][8] = 'getTableData(1)';
			$data['table']['filter']['input']['oninput'][9] = 'getTableData(1)';

			// $data['table']['bulk_action']['input']['options'] = array(
			// 	'Dijual'		=> 'Ubah status menjadi "Dijual"',
			// 	'Tidak dijual'	=> 'Ubah status menjadi "Tidak dijual"',
			// 	'Dihapus'		=> 'Hapus'
			// );

			// $data['table']['bulk_action']['input']['value'] = 'Dijual';

			// $data['table']['bulk_action']['input']['id'] = 'bulk-action-select';

			// $data['button']['link'] = base_url('kontrak/tambah_ubah');

			$data['hidden_input']['value'][1] = base_url('karyawan');
			$data['hidden_input']['value'][2] = base_url('member/produk/tambah_ubah?status=');

			$data['hidden_input']['id'][1] = 'controller-link';
			$data['hidden_input']['id'][2] = 'formaction';
			
			$data['hidden_inputs'] = 2;
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css',
				'toastr/toastr.min.css'
			);
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'vendor/toastr/toastr.js',
				'assets/js/pages/employee/list.js',
				'assets/js/templates/table.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('templates/dashboard/list/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
		}

		public function table_data($page_number, $limit)
	    {
			$this->load->model('general_model');
			$this->load->helper('html');
			$this->load->helper('form');

			$joins[1]['table'] = 'users';
			// $joins[2]['table'] = 'units';

			$joins[1]['on'] = 'employees.user_id = users.user_id';
			// $joins[2]['on'] = 'contracts.unit_id = units.unit_id';

			if($this->input->get('division') != NULL && $this->input->get('division') != '')
			{
				$filters[1]['operator'] = 'where_in';
				
				$filters[1]['field'] = 'division';

				$filters[1]['value'] = explode(',', urldecode($this->input->get('division')));
			}
			else
			{
				$filters[1]['operator'] = 'where_not_in';
				
				$filters[1]['field'] = 'division';

				$filters[1]['value'] = array('SUPER USER', 'CUSTOMER SERVICE', 'INSTRUKTUR');
			}

			if($this->input->get('user_status') != NULL && $this->input->get('user_status') != '')
			{
				$filters[2]['operator'] = 'where_in';
				
				$filters[2]['field'] = 'user_status';

				$filters[2]['value'] = explode(',', urldecode($this->input->get('user_status')));
			}
			else
			{
				$filters[2]['operator'] = 'where';
				
				$filters[2]['field'] = 'user_status <>';

				$filters[2]['value'] = 'Dihapus';
			}

			$filter_counter = 2;

			if($this->input->get('name') != NULL && $this->input->get('name') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'users.name';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('name'));
			}

			if($this->input->get('email_address') != NULL && $this->input->get('email_address') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'email_address';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('email_address'));
			}

			if($this->input->get('age') != NULL && $this->input->get('age') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where';
				
				$filters[$filter_counter]['field'] = '';

				$filters[$filter_counter]['value'] = 'TIMESTAMPDIFF(YEAR,birthday,CURDATE()) = '.$this->input->get('age');
			}

			if($this->input->get('address') != NULL && $this->input->get('address') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'address';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('address'));
			}

			if($this->input->get('last_education') != NULL && $this->input->get('last_education') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where_in';
				
				$filters[$filter_counter]['field'] = 'last_education';

				$filters[$filter_counter]['value'] = explode(',', urldecode($this->input->get('last_education')));
			}

			if($this->input->get('major') != NULL && $this->input->get('major') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'major';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('major'));
			}

			if($this->input->get('expertise') != NULL && $this->input->get('expertise') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'expertise';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('expertise'));
			}

			if($this->input->get('order_by') != NULL && $this->input->get('order_by') != '')
			{	
				$order = explode(',', urldecode($this->input->get('order_by')));

				$orders[1]['field'] = $order[0];

				$orders[1]['direction'] = $order[1];
			}
			else
				$orders = array();
			
			$data['records'] = $this->general_model->read('select', '*, TIMESTAMPDIFF(YEAR,birthday,CURDATE()) as age', 'employees', $joins, $filters, $orders, $page_number, $limit, 'result_array');

			$data['columns'] = 11;

			if(!empty($data['records']))
            {
				$data['table']['data'][2] = 'name';
				$data['table']['data'][3] = 'email_address';
				$data['table']['data'][4] = 'age';
				$data['table']['data'][5] = 'division';
				$data['table']['data'][6] = 'address';
				$data['table']['data'][7] = 'last_education';
				$data['table']['data'][8] = 'major';
				$data['table']['data'][9] = 'expertise';
				$data['table']['data'][10] = 'user_status';

				$data['buttons'] = 2;

                $button['link'] = base_url('karyawan/');
                $button['class'] = 'btn btn-sm ';

				$num_rows = $this->general_model->read('select', 'employee_id', 'employees', $joins, $filters, array(), $page_number, $limit, 'num_rows');
                
                for($record_counter = 0; $record_counter < $num_rows; $record_counter++)
                {
                    $data['records'][$record_counter]['button']['type'][1] = 'button';
                    
                    $data['records'][$record_counter]['button']['title'][1] = 'Ubah';
                    
                    $data['records'][$record_counter]['button']['link'][1] = $button['link'].'tambah_ubah/'.rawurlencode($data['records'][$record_counter]['email_address']);

                    $data['records'][$record_counter]['button']['formaction'][1] = '';

                    $data['records'][$record_counter]['button']['class'][1] = $button['class'].'btn-primary';

                    $data['records'][$record_counter]['button']['onclick'][1] = '';

                    // $data['records'][$record_counter]['button']['icon'][1] = 'mdi mdi-square-edit-outline';
					$data['records'][$record_counter]['button']['icon'][1] = 'Ubah';

                    $data['records'][$record_counter]['button']['type'][2] = 'submit';

                    $data['records'][$record_counter]['button']['title'][2] = 'Hapus';

                    $data['records'][$record_counter]['button']['link'][2] = 'javascript:void(0)';
                    
                    $data['records'][$record_counter]['button']['formaction'][2] = $button['link'].'hapus?user_id='.$data['records'][$record_counter]['user_id'].'&user_status=Dihapus';

                    $data['records'][$record_counter]['button']['class'][2] = $button['class'].'btn-danger';

                    $data['records'][$record_counter]['button']['onclick'][2] = 'return confirmDeletion()';

                    // $data['records'][$record_counter]['button']['icon'][2] = 'mdi mdi-delete';
					$data['records'][$record_counter]['button']['icon'][2] = 'Hapus';
                }
            }

			echo $this->load->view('templates/dashboard/list/data', $data, TRUE);
		}

		public function pagination($page_number, $limit)
	    {
			$this->load->model('general_model');
			$this->load->library('assignment');

			$joins[1]['table'] = 'users';
			// $joins[2]['table'] = 'units';

			$joins[1]['on'] = 'employees.user_id = users.user_id';
			// $joins[2]['on'] = 'contracts.unit_id = units.unit_id';

			if($this->input->get('division') != NULL && $this->input->get('division') != '')
			{
				$filters[1]['operator'] = 'where_in';
				
				$filters[1]['field'] = 'division';

				$filters[1]['value'] = explode(',', urldecode($this->input->get('division')));
			}
			else
			{
				$filters[1]['operator'] = 'where_not_in';
				
				$filters[1]['field'] = 'division';

				$filters[1]['value'] = array('SUPER USER', 'CUSTOMER SERVICE', 'INSTRUKTUR');
			}

			if($this->input->get('user_status') != NULL && $this->input->get('user_status') != '')
			{
				$filters[2]['operator'] = 'where_in';
				
				$filters[2]['field'] = 'user_status';

				$filters[2]['value'] = explode(',', urldecode($this->input->get('user_status')));
			}
			else
			{
				$filters[2]['operator'] = 'where';
				
				$filters[2]['field'] = 'user_status <>';

				$filters[2]['value'] = 'Dihapus';
			}

			$filter_counter = 2;

			if($this->input->get('name') != NULL && $this->input->get('name') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'users.name';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('name'));
			}

			if($this->input->get('email_address') != NULL && $this->input->get('email_address') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'email_address';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('email_address'));
			}

			if($this->input->get('age') != NULL && $this->input->get('age') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where';
				
				$filters[$filter_counter]['field'] = '';

				$filters[$filter_counter]['value'] = 'TIMESTAMPDIFF(YEAR,birthday,CURDATE()) = '.$this->input->get('age');
			}

			if($this->input->get('address') != NULL && $this->input->get('address') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'address';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('address'));
			}

			if($this->input->get('last_education') != NULL && $this->input->get('last_education') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where_in';
				
				$filters[$filter_counter]['field'] = 'last_education';

				$filters[$filter_counter]['value'] = explode(',', urldecode($this->input->get('last_education')));
			}

			if($this->input->get('major') != NULL && $this->input->get('major') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'major';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('major'));
			}

			if($this->input->get('expertise') != NULL && $this->input->get('expertise') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'expertise';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('expertise'));
			}
			
			$page_count = ceil($this->general_model->read('select', 'employee_id', 'employees', $joins, $filters, array(), 0, 0, 'num_rows') / $limit);
                
            $data['page_number'] = $page_number;
			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				$pagination = $this->assignment->table_template_pagination($page_count, $page_number);
				
				$data = array_merge($data, $pagination);
			}

			echo $this->load->view('templates/dashboard/list/pagination', $data, TRUE);
		}

		public function ekspor()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'HRD')
				redirect();

			if($this->input->post('submit') == NULL)
            {
				require 'Options.php';

                $this->load->helper('form');

				$data['header'] = 'Unduh Data Karyawan';
				
				$data['title'] = ':: Sister JSO :: '.$data['header'];

				$data['breadcrumbs'] = 2;

				$data['breadcrumb']['item'][1] = 'Karyawan';
                
                $data['vendor_css_links'] = array(
                    'bootstrap/css/bootstrap.min.css',
                    'font-awesome/css/font-awesome.min.css',
                    'animate-css/animate.min.css'
                );

				$data['columns'] = 2;

				$data['label'][1][1][1][1] = 'Jenis Kontrak';
				$data['label'][1][1][1][2] = 'Status Karyawan';

				$data['input']['id'][1][1][1][1][1] = 'contract-type-select';
				$data['input']['id'][1][1][1][2][1] = 'user-status-select';

				$data['input']['name'][1][1][1][1] = 'contract_type[]';
				$data['input']['name'][1][1][1][2] = 'user_status[]';

				$data['input']['options'][1][1][1][1] = $contract_types;
	
				$data['input']['options'][1][1][1][2] = array(
					'Calon karyawan'	=> 'Calon karyawan',
					'Aktif'				=> 'Aktif',
					'SP 3'				=> 'SP 3',
					'Resign'			=> 'Resign'
				);

				$data['input']['data-placeholder'][1][1][1][1] = 'Semua Jenis Kontrak';
				$data['input']['data-placeholder'][1][1][1][2] = 'Semua Status Karyawan';
                
                $data['js_links'] = array(
                    'assets/bundles/libscripts.bundle.js',
                    'assets/bundles/vendorscripts.bundle.js',
                    'assets/bundles/mainscripts.bundle.js',
					'assets/js/pages/employee/export.js'
                );

                // Render view on main layout
                $this->load->view('templates/dashboard/top', $data);
                $this->load->view('pages/employees/export', $data);
                $this->load->view('templates/dashboard/bottom', $data);
            }
			else
			{
				$this->load->model('general_model');
				
				$spreadsheet = new Spreadsheet();
				
				$sheet = $spreadsheet->getActiveSheet();

				$sheet->setCellValue('A1', 'Nomor');
				$sheet->setCellValue('B1', 'Alamat email');
				$sheet->setCellValue('C1', 'Nama Lengkap');
				$sheet->setCellValue('D1', 'Nama Panggilan');
				$sheet->setCellValue('E1', 'Nomor KTP');
				$sheet->setCellValue('F1', 'Tempat Lahir');
				$sheet->setCellValue('G1', 'Tanggal Lahir');
				$sheet->setCellValue('H1', 'Umur');
				$sheet->setCellValue('I1', 'Posisi');
				$sheet->setCellValue('J1', 'Jenis Kelamin');
				$sheet->setCellValue('K1', 'Agama');
				$sheet->setCellValue('L1', 'Alamat KTP(lengkap)');
				$sheet->setCellValue('M1', 'Alamat KTP(kota)');
				$sheet->setCellValue('N1', 'Alamat Tempat Tinggal(lengkap)');
				$sheet->setCellValue('O1', 'Alamat Tempat Tinggal(kota)');
				$sheet->setCellValue('P1', 'Nomor HP Pribadi');
				$sheet->setCellValue('Q1', 'Jenjang Pendidikan Terakhir');
				$sheet->setCellValue('R1', 'Jurusan Pendidikan Terakhir');
				$sheet->setCellValue('S1', 'Nomer Rekening');
				$sheet->setCellValue('T1', 'Atas Nama Rekening');
				$sheet->setCellValue('U1', 'Status Marital');
				$sheet->setCellValue('V1', 'Nama Istri / Suami');
				$sheet->setCellValue('W1', 'Nomor HP Istri / Suami');
				$sheet->setCellValue('X1', 'Pekerjaan Istri / Suami');
				$sheet->setCellValue('Y1', 'Nama Ibu');
				$sheet->setCellValue('Z1', 'Nomor HP Ibu');
				$sheet->setCellValue('AA1', 'Pekerjaan Ibu');
				$sheet->setCellValue('AB1', 'Nama Ayah');
				$sheet->setCellValue('AC1', 'Nomor HP Ayah');
				$sheet->setCellValue('AD1', 'Pekerjaan Ayah');
				// $sheet->setCellValue('AE1', 'Keahlian sesuai posisi yang dilamar');
				// $sheet->setCellValue('AF1', 'Yang diketahui tentang perusahaan');
				// $sheet->setCellValue('AG1', 'Alasan melamar ke perusahaan');
				// $sheet->setCellValue('AH1', 'Alasan memilih posisi yang dilamar');
				// $sheet->setCellValue('AI1', 'Kesediaan ditempatkan di posisi selain yang dilamar');
				// $sheet->setCellValue('AJ1', 'Kesediaan melakukan lembur & alasannya');
				// $sheet->setCellValue('AK1', 'Kesediaan menjalani masa percobaan & alasannya');
				// $sheet->setCellValue('AL1', 'Ambisi pribadi');
				// $sheet->setCellValue('AM1', 'Hal - hal positif dalam diri');
				// $sheet->setCellValue('AN1', 'Hal - hal negatif dalam diri');
				// $sheet->setCellValue('AO1', 'Alasan kuat yang membuat perusahaan harus merekrut');
				// $sheet->setCellValue('AP1', 'Yang akan dilakukan dalam 1 bulan pertama');
				// $sheet->setCellValue('AQ1', 'Relasi yang dapat mereferensikan');
				// $sheet->setCellValue('AR1', 'Status');
				$sheet->setCellValue('AE1', 'Berkas KTP');
				$sheet->setCellValue('AF1', 'Foto Terbaru');
				$sheet->setCellValue('AG1', 'Jenis Kontrak');
				$sheet->setCellValue('AH1', 'Status');

				$joins[1]['table'] = 'users';
				// $joins[2]['table'] = 'units';

				$joins[1]['on'] = 'employees.user_id = users.user_id';
				// $joins[2]['on'] = 'contracts.unit_id = units.unit_id';

				$filters[1]['operator'] = 'where_not_in';
				
				$filters[1]['field'] = 'division';

				$filters[1]['value'] = array('SUPER USER', 'CUSTOMER SERVICE', 'INSTRUKTUR');

				if($this->input->post('user_status') != NULL && $this->input->post('user_status') != '')
				{
					$filters[2]['operator'] = 'where_in';
					
					$filters[2]['field'] = 'user_status';

					$filters[2]['value'] = explode(',', urldecode($this->input->post('user_status')));
				}
				else
				{
					$filters[2]['operator'] = 'where';
					
					$filters[2]['field'] = 'user_status <>';

					$filters[2]['value'] = 'Dihapus';
				}

				$orders[1]['field'] = 'name';

				$orders[1]['direction'] = 'ASC';
				
				$employees = $this->general_model->read('select', '*, TIMESTAMPDIFF(YEAR,birthday,CURDATE()) as age', 'employees', $joins, $filters, $orders, 0, 0, 'result_array');

				$filters[1]['operator'] = 'where';
				$filters[2]['operator'] = 'where';
				
				$filters[1]['field'] = 'user_id';
				$filters[2]['field'] = 'status';
				
				$filters[2]['value'] = 'Valid';

				if($this->input->post('contract_type') != NULL && $this->input->post('contract_type') != '')
				{
					$filters[3]['operator'] = 'where_in';
					
					$filters[3]['field'] = 'contract_type';

					$filters[3]['value'] = explode(',', urldecode($this->input->post('contract_type')));
				}

				$orders[1]['field'] = 'contract_id';

				$orders[1]['direction'] = 'DESC';
				
				$number = 1;

				foreach($employees as &$employee)
				{
					$filters[1]['value'] = $employee['user_id'];
					
					$contract = $this->general_model->read('select', 'contract_type', 'contracts', array(), $filters, $orders);

					if(isset($contract))
					{
						$sheet->setCellValue('A'.($number + 1), $number);
						$sheet->setCellValue('B'.($number + 1), $employee['email_address']);
						$sheet->setCellValue('C'.($number + 1), $employee['name']);
						$sheet->setCellValue('D'.($number + 1), $employee['nickname']);
						$sheet->setCellValueExplicit('E'.($number + 1), $employee['id_card_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
						$sheet->setCellValue('F'.($number + 1), $employee['birthplace']);
						$sheet->setCellValue('G'.($number + 1), substr($employee['birthday'], -2).'-'.substr($employee['birthday'], 5, 2).'-'.substr($employee['birthday'], 0, 4));
						// $sheet->setCellValue('H'.($number + 1), date_diff(date_create($employee['birthday']), date_create(date('Y-m-d')))->format('%y'));
						$sheet->setCellValue('H'.($number + 1), $employee['age']);
						$sheet->setCellValue('I'.($number + 1), $employee['division']);
						$sheet->setCellValue('J'.($number + 1), $employee['gender']);
						$sheet->setCellValue('K'.($number + 1), $employee['religion']);
						$sheet->setCellValue('L'.($number + 1), $employee['id_card_address']);
						$sheet->setCellValue('M'.($number + 1), $employee['id_card_city']);
						$sheet->setCellValue('N'.($number + 1), $employee['address']);
						$sheet->setCellValue('O'.($number + 1), $employee['city']);
						$sheet->setCellValueExplicit('P'.($number + 1), $employee['phone_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
						$sheet->setCellValue('Q'.($number + 1), $employee['last_education']);
						$sheet->setCellValue('R'.($number + 1), $employee['major']);
						$sheet->setCellValueExplicit('S'.($number + 1), $employee['account_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
						$sheet->setCellValue('T'.($number + 1), $employee['accountee']);
						$sheet->setCellValue('U'.($number + 1), $employee['marital_status']);
						$sheet->setCellValue('V'.($number + 1), $employee['mate_name']);
						$sheet->setCellValueExplicit('W'.($number + 1), $employee['mate_phone_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
						$sheet->setCellValue('X'.($number + 1), $employee['mate_occupation']);
						$sheet->setCellValue('Y'.($number + 1), $employee['mother_name']);
						$sheet->setCellValueExplicit('Z'.($number + 1), $employee['mother_phone_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
						$sheet->setCellValue('AA'.($number + 1), $employee['mother_occupation']);
						$sheet->setCellValue('AB'.($number + 1), $employee['father_name']);
						$sheet->setCellValueExplicit('AC'.($number + 1), $employee['father_phone_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
						$sheet->setCellValue('AD'.($number + 1), $employee['father_occupation']);
						// $sheet->setCellValue('AE'.($number + 1), $employee['expertise']);
						// $sheet->setCellValue('AF'.($number + 1), $employee['company_profile_knowledge']);
						// $sheet->setCellValue('AG'.($number + 1), $employee['interest_to_company']);
						// $sheet->setCellValue('AH'.($number + 1), $employee['interest_to_division']);
						// $sheet->setCellValue('AI'.($number + 1), $employee['other_divisions']);
						// $sheet->setCellValue('AJ'.($number + 1), $employee['overtime']);
						// $sheet->setCellValue('AK'.($number + 1), $employee['probation']);
						// $sheet->setCellValue('AL'.($number + 1), $employee['ambitions']);
						// $sheet->setCellValue('AM'.($number + 1), $employee['positive_attitudes']);
						// $sheet->setCellValue('AN'.($number + 1), $employee['negative_attitudes']);
						// $sheet->setCellValue('AO'.($number + 1), $employee['recruit_reasons']);
						// $sheet->setCellValue('AP'.($number + 1), $employee['to_dos']);
						// $sheet->setCellValue('AQ'.($number + 1), $employee['referral']);
						// $sheet->setCellValue('AR'.($number + 1), $employee['user_status']);
						$sheet->setCellValue('AE'.($number + 1), $employee['id_card']);
						$sheet->getCell('AE'.($number + 1))->getHyperlink()->setUrl(base_url('uploads/'.$employee['id_card']));

						$sheet->setCellValue('AF'.($number + 1), $employee['photo']);
						$sheet->getCell('AF'.($number + 1))->getHyperlink()->setUrl(base_url('uploads/'.$employee['photo']));

						$sheet->setCellValue('AG'.($number + 1), $contract['contract_type']);
						$sheet->setCellValue('AH'.($number + 1), $employee['user_status']);

						$number++;
					}
				}

				$sheet->getColumnDimension('A')->setAutoSize(true);
				$sheet->getColumnDimension('B')->setAutoSize(true);
				$sheet->getColumnDimension('C')->setAutoSize(true);
				$sheet->getColumnDimension('D')->setAutoSize(true);
				$sheet->getColumnDimension('E')->setAutoSize(true);
				$sheet->getColumnDimension('F')->setAutoSize(true);
				$sheet->getColumnDimension('G')->setAutoSize(true);
				$sheet->getColumnDimension('H')->setAutoSize(true);
				$sheet->getColumnDimension('I')->setAutoSize(true);
				$sheet->getColumnDimension('J')->setAutoSize(true);
				$sheet->getColumnDimension('K')->setAutoSize(true);
				$sheet->getColumnDimension('L')->setAutoSize(true);
				$sheet->getColumnDimension('M')->setAutoSize(true);
				$sheet->getColumnDimension('N')->setAutoSize(true);
				$sheet->getColumnDimension('O')->setAutoSize(true);
				$sheet->getColumnDimension('P')->setAutoSize(true);
				$sheet->getColumnDimension('Q')->setAutoSize(true);
				$sheet->getColumnDimension('R')->setAutoSize(true);
				$sheet->getColumnDimension('S')->setAutoSize(true);
				$sheet->getColumnDimension('T')->setAutoSize(true);
				$sheet->getColumnDimension('U')->setAutoSize(true);
				$sheet->getColumnDimension('V')->setAutoSize(true);
				$sheet->getColumnDimension('W')->setAutoSize(true);
				$sheet->getColumnDimension('X')->setAutoSize(true);
				$sheet->getColumnDimension('Y')->setAutoSize(true);
				$sheet->getColumnDimension('Z')->setAutoSize(true);
				$sheet->getColumnDimension('AA')->setAutoSize(true);
				$sheet->getColumnDimension('AB')->setAutoSize(true);
				$sheet->getColumnDimension('AC')->setAutoSize(true);
				$sheet->getColumnDimension('AD')->setAutoSize(true);
				$sheet->getColumnDimension('AE')->setAutoSize(true);
				$sheet->getColumnDimension('AF')->setAutoSize(true);
				$sheet->getColumnDimension('AG')->setAutoSize(true);
				$sheet->getColumnDimension('AH')->setAutoSize(true);
				// $sheet->getColumnDimension('AI')->setAutoSize(true);
				// $sheet->getColumnDimension('AJ')->setAutoSize(true);
				// $sheet->getColumnDimension('AK')->setAutoSize(true);
				// $sheet->getColumnDimension('AL')->setAutoSize(true);
				// $sheet->getColumnDimension('AM')->setAutoSize(true);
				// $sheet->getColumnDimension('AN')->setAutoSize(true);
				// $sheet->getColumnDimension('AO')->setAutoSize(true);
				// $sheet->getColumnDimension('AP')->setAutoSize(true);
				// $sheet->getColumnDimension('AQ')->setAutoSize(true);
				// $sheet->getColumnDimension('AR')->setAutoSize(true);
				
				$writer = new Xlsx($spreadsheet);
		
				$filename = 'Data Karyawan '.date("d-m-Y H.i").' WIB';
		
				header('Content-Type: application/vnd.ms-excel');
				header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
				header('Cache-Control: max-age=0');
				
				$writer->save('php://output'); // download file
			}
	    }
	}
?>