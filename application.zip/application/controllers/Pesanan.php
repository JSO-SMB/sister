<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	use PhpOffice\PhpSpreadsheet\Spreadsheet;
	use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
	
	class Pesanan extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}
        }
        
        public function tambah_ubah($order_id = 0)
	    {
			if($this->input->post('submit') != NULL)
			{
				$this->load->model('order_model');

				$uri = 'pesanan/tambah_ubah/';
	
				if($order_id > 0)
					$uri = $uri.$order_id;
				
				if($_FILES['proof']['size'] > 0)
				{
					$config['upload_path']          = './uploads/';
					$config['allowed_types']        = 'jpg|jpeg';
	
                    $this->load->library('upload', $config);
                    
                    if(!$this->upload->do_upload('proof'))
					{
						$this->session->set_flashdata('error_messages', $this->upload->display_errors());
						
						redirect($uri);
					}
					else
						$proof = $this->upload->data('file_name');
                }
                else
                    $proof = '';

                $this->order_model->create_update_order($proof, $order_id);
                
				$this->session->set_flashdata('operation_result', 'order data saved');
				
				redirect($uri);
					
				/*$user_role = $this->employee_model->read_users_roles('', 2);
				
				$message = 'Yth. HRD JSO SMB,<br /><br />';
				$message = $message.'Terdapat data registrasi seleksi calon karyawan baru yang masuk untuk posisi & pilihan jadwal wawancara berikut:<br /><br />';
				$message = $message.'<b>Nama: '.$this->input->post('name').'<br />';
				$message = $message.'Alamat email: '.$this->input->post('email_address').'<br />';
				$message = $message.'Posisi & pilihan jadwal wawancara: '.$this->input->post('division').'</b><br /><br />';
				$message = $message.'Anda dapat melihat detail dari data registrasi tersebut pada <a href="'.base_url('pesanan/tambah_ubah/'.rawurlencode($this->input->post('email_address'))).'" target="_blank">tautan ini</a>.<br /><br />';
				$message = $message.'Salam,<br />SISTER JSO SMB';

				$this->load->library('email');
				
				// Sending to an account, for activation (username, password)
				$this->email->from('sister.jsosmboffice@gmail.com', 'SISTER JSO');	
				$this->email->to($user_role['email_address']);

				//$this->email->cc('another@another-example.com');
				//$this->email->bcc('them@their-example.com');
				$this->email->subject('Data Registrasi Seleksi Calon Karyawan');
				$this->email->message($message);

				$this->email->send();*/
			}
			else
			{
				$this->load->model('employee_model');
				$this->load->model('unit_model');
                $this->load->helper('form');

				require 'Options.php';

				if($order_id > 0)
				{
					$this->load->model('order_model');

					if($this->session->userdata('role_id') < 2)
						$role_specific_table = 'employees';
					else
						$role_specific_table = 'vendors';
				
					$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, $role_specific_table);

					if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['role_id'] != 2 && !($data['logged_in_user']['role_id'] == 1 && $data['logged_in_user']['division'] == 'LOGISTIK'))
						redirect();
					
					$header = 'Ubah Data Order';
					
					$order = $this->order_model->read_users_orders('*, orders.notes as order_notes, users.name as vendor_name', 0, 0, 'row_array', '', $order_id);

					$data['order_date'] = $order['order_date'];
					$data['nearest_city'] = $order['nearest_city'];
					$data['proof'] = $order['proof'];
					$data['total_bill'] = $order['total_bill'];
					$data['item'] = $order['item'];
					$data['quantity'] = $order['quantity'];
					$data['price'] = $order['price'];
					$data['estimated_completion_date'] = $order['estimated_completion_date'];
					$data['notes'] = $order['order_notes'];
					$data['unit_id'] = $order['unit_id'];
					$data['vendor_id'] = $order['vendor_id'];
					$data['good_receipt_notes'] = $order['vendor_name'].'/'.$order['total_bill'].'/'.$order['item'].' : '.$order['quantity'].' : '.$order['price'].'. Order Tgl '.substr($order['order_date'], -2).'/'.substr($order['order_date'], 5, 2).'/'.substr($order['order_date'], 0, 4).' - Selesai '.substr($order['estimated_completion_date'], -2).'/'.substr($order['estimated_completion_date'], 5, 2).'/'.substr($order['estimated_completion_date'], 0, 4);
					$data['approval_status'] = $order['approval_status'];
				}
				else
				{
					if($this->session->userdata('role_id') < 2)
						redirect('pesanan/daftar');
					
					$role_specific_table = 'vendors';
				
					$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, $role_specific_table);

					if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['role_id'] != 2 && !($data['logged_in_user']['role_id'] == 1 && $data['logged_in_user']['position'] == 'Manajer' && $data['logged_in_user']['division'] == 'LOGISTIK'))
						redirect();

                    $header = 'Order Baru';
					
					$data['order_date'] = date('Y-m-d');
                    $data['nearest_city'] = 'Yogyakarta & sekitarnya';
                    $data['proof'] = '';
                    $data['total_bill'] = 100;
                    $data['item'] = '';
                    $data['quantity'] = 1;
                    $data['price'] = 100;
                    $data['estimated_completion_date'] = date('Y-m-d');
                    $data['notes'] = '';
                    $data['good_receipt_notes'] = $data['total_bill'].'/'.$data['item'].' : '.$data['quantity'].' : '.$data['price'].'. Order Tgl '.substr($data['order_date'], -2).'/'.substr($data['order_date'], 5, 2).'/'.substr($data['order_date'], 0, 4).' - Selesai '.substr($data['estimated_completion_date'], -2).'/'.substr($data['estimated_completion_date'], 5, 2).'/'.substr($data['estimated_completion_date'], 0, 4);
					$data['approval_status'] = 'Menunggu persetujuan';
				}
                    
				$data['title'] = ':: Sister JSO :: '.$header;
				
				$data['vendor_css_links'] = array(
					'bootstrap/css/bootstrap.min.css',
					'font-awesome/css/font-awesome.min.css',
					'animate-css/animate.min.css',
					'bootstrap-multiselect/bootstrap-multiselect.css',
					'bootstrap-datepicker/css/bootstrap-datepicker3.min.css',
					'bootstrap-colorpicker/css/bootstrap-colorpicker.css',
					'multi-select/css/multi-select.css',
					'bootstrap-tagsinput/bootstrap-tagsinput.css',
					'nouislider/nouislider.min.css',
					'toastr/toastr.min.css',
                    'dropify/css/dropify.min.css'
                );
				
                $data['header'] = $header;
                
                if(($order_id < 1) || ($order_id > 0 && $this->session->userdata('role_id') > 1))
                {
                    $data['vendors'][$data['logged_in_user']['vendor_id']] = $data['logged_in_user']['name'];
                    $data['vendor_id'] = $data['logged_in_user']['vendor_id'];
				}
				else
					$data['vendors'][$order['vendor_id']] = $order['vendor_name'];
                
                $data['nearest_cities'] = $nearest_cities;

				$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
			
				foreach($unit_list as &$unit)
				{
					$units[$unit['unit_id']] = $unit['name'];
				}

				$data['units'] = $units;
				
				if($header == 'Order Baru')
					$data['unit_id'] = $unit['unit_id'];
				
				$data['items'] = $items;
				
				$data['approval_statuses'] = array(
					'Menunggu persetujuan' => 'Menunggu persetujuan',
					'Disetujui' => 'Disetujui'
				);
				
				$data['js_links'] = array(
					'assets/bundles/libscripts.bundle.js',
					'assets/bundles/vendorscripts.bundle.js',
					'vendor/bootstrap-colorpicker/js/bootstrap-colorpicker.js',
					'vendor/jquery-inputmask/jquery.inputmask.bundle.js',
					'vendor/jquery-mask/jquery.mask.min.js',
					'vendor/multi-select/js/jquery.multi-select.js',
					'vendor/bootstrap-multiselect/bootstrap-multiselect.js',
					'vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js',
					'vendor/bootstrap-tagsinput/bootstrap-tagsinput.js',
					'vendor/nouislider/nouislider.js',
					'vendor/toastr/toastr.js',
                    'vendor/dropify/js/dropify.min.js',
					'assets/bundles/mainscripts.bundle.js',
					'assets/js/pages/forms/advanced-form-elements.js',
                    'assets/js/pages/forms/dropify.js',
					'assets/js/pages/order/create_update.js'
				);

				// Render view on main layout
				$this->load->view('templates/dashboard/top', $data);
				$this->load->view('pages/orders/create_update', $data);
				$this->load->view('templates/dashboard/bottom', $data);
			}
	    }

		public function daftar($view = 'pesanan')
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			if($view == 'stok')
			{
				if($this->session->userdata('role_id') > 1)
					redirect('pesanan/daftar');
				
				$data['title'] = ':: Sister JSO :: Data Stok Logistik';
			}
			else
				$data['title'] = ':: Sister JSO :: Data Order';

			$this->load->model('employee_model');
			$this->load->helper('form');

            if($this->session->userdata('role_id') < 2)
                $role_specific_table = 'employees';
            else
                $role_specific_table = 'vendors';
				
			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, $role_specific_table);

			if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['role_id'] != 2 && !($data['logged_in_user']['role_id'] == 1 && $data['logged_in_user']['division'] == 'LOGISTIK'))
				redirect();
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);

			$data['role_id'] = $this->session->userdata('role_id');
			$data['view'] = $view;
			$data['division'] = $data['logged_in_user']['division'];
			$data['office_location'] = $data['logged_in_user']['office_location'];
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'assets/js/pages/order/list.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/orders/list/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		public function data($role_id, $page_number, $view = 'pesanan', $query = '', $division = '', $office_location = '')
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

            $this->load->model('employee_model');
            $this->load->model('order_model');
			$this->load->helper('form');

			$data['role_id'] = $role_id;
			$data['view'] = $view;

            if($role_id < 2)
            {
				$this->load->model('unit_model');

				$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
				
				$units[0] = 'Semua Unit';

				foreach($unit_list as &$unit)
				{
					$units[$unit['unit_id']] = $unit['name'];
				}

				$data['units'] = $units;

				$data['office_locations'] = array();

				if(urldecode($division) != 'LOGISTIK')
					$data['office_locations']['Semua Gudang'] = 'Semua Gudang';

				if(urldecode($division) != 'LOGISTIK' || (urldecode($division) == 'LOGISTIK' && urldecode($office_location) == 'Yogyakarta & sekitarnya'))
					$data['office_locations']['Yogyakarta & sekitarnya'] = 'Yogyakarta';
				
				if(urldecode($division) != 'LOGISTIK' || (urldecode($division) == 'LOGISTIK' && urldecode($office_location) == 'Jakarta & sekitarnya'))
					$data['office_locations']['Jakarta & sekitarnya'] = 'Jakarta';
					
				if($view == 'pesanan')
				{
					/*$this->load->model('vendor_model');
					
					$users_vendors = $this->vendor_model->read_users_vendors('user', 0, 'result_array', '', 0);
					
					$vendors[0] = 'Semua Vendor';
					
					foreach($users_vendors as &$user_vendor)
					{
						$vendors[$user_vendor['vendor_id']] = $user_vendor['name'];
					}
					
					$data['vendors'] = $vendors;*/
					
					$data['users_orders'] = $this->order_model->read_users_orders('*, orders.notes as order_notes, users.name as vendor_name', 0, $page_number, 'result_array', '', 0, '', urldecode($query), 'Menunggu persetujuan', urldecode($office_location));
					
					$page_count = ceil($this->order_model->read_users_orders('*', 0, 0, 'num_rows', '', 0, '', urldecode($query), 'Menunggu persetujuan', urldecode($office_location)) / 5);
				}
				else
				{
					$this->load->model('event_model');

					$item[10] = 'Sertifikat';
					$item[11] = 'Map Setifikat';
					$item[12] = 'Amplop';
					$item[13] = 'Tas Eksklusif';
					$item[14] = 'Tas Ekonomis';
					$item[15] = 'Oleh-oleh';
					$item[16] = 'Batik';
					$item[17] = 'Kaos';
					$item[18] = 'Powerbank';
					$item[19] = 'Jaket';
					$item[20] = 'Plakat';
					$item[21] = 'Souvenir';
					$item[22] = 'Name Tag';
					$item[23] = 'Goody Bag';
					$item[24] = 'Ballpoint';
					$item[25] = 'Blocknote';
					$item[26] = 'Flashdisk';
					$item[27] = 'CD';

					$column[10] = 'certificate_quantity';
					$column[11] = 'folder_quantity';
					$column[12] = 'envelope_quantity';
					$column[13] = 'exclusive_bag_quantity';
					$column[14] = 'economic_bag_quantity';
					$column[15] = 'gift_quantity';
					$column[16] = 'batik_quantity';
					$column[17] = 'shirt_quantity';
					$column[18] = 'powerbank_quantity';
					$column[19] = 'jacket_quantity';
					$column[20] = 'placard_quantity';
					$column[21] = 'souvenir_quantity';
					$column[22] = 'name_tag_quantity';
					$column[23] = 'goody_bag_quantity';
					$column[24] = 'ballpoint_quantity';
					$column[25] = 'blocknote_quantity';
					$column[26] = 'flashdisk_quantity';
					$column[27] = 'cd_quantity';

					for($item_counter = 10; $item_counter < 28; $item_counter++)
					{
						$data['items_stock'][$item_counter]['item'] = $item[$item_counter];

						$order = $this->order_model->read_users_orders('AVG(price) as price, SUM(quantity) as quantity', 0, 0, 'row_array', '', 0, $item[$item_counter], urldecode($query), 'Disetujui', urldecode($office_location));

						$data['items_stock'][$item_counter]['price'] = $order['price'] + (10 / 100 * $order['price']);

						$event = $this->event_model->read_events_vendors_clients('SUM('.$column[$item_counter].') as quantity', '', 0, 'row_array', 'Fixed', urldecode($query), 0, 0, '', urldecode($office_location));

						$data['items_stock'][$item_counter]['quantity'] = $order['quantity'] - $event['quantity'];
						$data['items_stock'][$item_counter]['total'] = $data['items_stock'][$item_counter]['price'] * $data['items_stock'][$item_counter]['quantity'];
					}
					
					$page_count = 1;
				}
            }
            else
            {
                $logged_in_user = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'vendors');
                
                $data['users_orders'] = $this->order_model->read_users_orders('*, orders.notes as order_notes, users.name as vendor_name', $logged_in_user['vendor_id'], $page_number, 'result_array', urldecode($query));

                $page_count = ceil($this->order_model->read_users_orders('*', $logged_in_user['vendor_id'], 0, 'num_rows', urldecode($query)) / 5);
            }
                
            $data['query'] = urldecode($query);
			$data['office_location'] = urldecode($office_location);
			$data['page_number'] = $page_number;
			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				if($page_count > 10)
				{
					if($page_number > 6)
					{
						if(($page_count - $page_number) >= 4)
							$next_page_count = 4;
						else
							$next_page_count = $page_count - $page_number;
						
						$previous_page_count = 9 - $next_page_count;
					}
					else
					{
						$previous_page_count = $page_number - 1;
						$next_page_count = 9 - $previous_page_count;
					}
				}
				else
				{
					$previous_page_count = $page_number - 1;
					$next_page_count = $page_count - $page_number;
				}

				$data['previous_page_count'] = $previous_page_count;
				$data['next_page_count'] = $next_page_count;
			}

			echo $this->load->view('pages/orders/list/dynamic_content', $data, TRUE);
		}
		
		public function inventaris()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->helper('form');

			$data['title'] = ':: Sister JSO :: Inventaris';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'assets/js/pages/order/inventories.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/orders/inventories/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		public function data_inventaris($page_number)
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('unit_model');
			$this->load->model('order_model');
			$this->load->helper('form');

			$data['units'] = array(
				'' => 'Semua Unit'
			);

			$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
			
			foreach($unit_list as &$unit)
			{
				$data['units'][$unit['unit_id']] = $unit['name'];
			}

			$data['unit_id'] = $this->input->get('unit_id');
			$data['transaction_date'] = urldecode($this->input->get('transaction_date'));
			//$data['ordering'] = $this->input->get('ordering');

			$data['inventories'] = $this->order_model->read_inventories($page_number);
			
			$data['page_number'] = $page_number;
            
			$page_count = ceil($this->order_model->read_inventories(0, 'num_rows') / 5);

			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				if($page_count > 10)
				{
					if($page_number > 6)
					{
						if(($page_count - $page_number) >= 4)
							$next_page_count = 4;
						else
							$next_page_count = $page_count - $page_number;
						
						$previous_page_count = 9 - $next_page_count;
					}
					else
					{
						$previous_page_count = $page_number - 1;
						$next_page_count = 9 - $previous_page_count;
					}
				}
				else
				{
					$previous_page_count = $page_number - 1;
					$next_page_count = $page_count - $page_number;
				}

				$data['previous_page_count'] = $previous_page_count;
				$data['next_page_count'] = $next_page_count;
			}

			echo $this->load->view('pages/orders/inventories/dynamic_content', $data, TRUE);
		}

		public function ekspor()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			if($this->session->userdata('role_id') > 1)
				redirect('pesanan/daftar');

			$this->load->model('employee_model');
			$this->load->model('order_model');
				
			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, $role_specific_table);

			if($this->session->userdata('user_id') != 1 && !($data['logged_in_user']['position'] == 'Manajer' && $data['logged_in_user']['division'] == 'LOGISTIK'))
				redirect();

			$spreadsheet = new Spreadsheet();
			
			$sheet = $spreadsheet->getActiveSheet();

			$sheet->setCellValue('A1', 'Nomor');
			$sheet->setCellValue('B1', 'GRN');
			$sheet->setCellValue('C1', 'Tanggal Order');
			$sheet->setCellValue('D1', 'Nama Vendor');
			$sheet->setCellValue('E1', 'Kota Domisili Terdekat dengan Anda');
			$sheet->setCellValue('F1', 'Nominal Total Tagihan (Invoice)');
			$sheet->setCellValue('G1', 'Nama Item');
			$sheet->setCellValue('H1', 'Jumlah');
			$sheet->setCellValue('I1', 'Harga per pc');
			$sheet->setCellValue('J1', 'Tanggal Estimasi Jadi');
			$sheet->setCellValue('K1', 'Keterangan Lainnya');
			$sheet->setCellValue('L1', 'Nama Perusahaan Pemesan');

			$users_orders = $this->order_model->read_users_orders('*, orders.notes as order_notes, users.name as vendor_name, units.name as unit_name');
			
			$number = 1;

			foreach($users_orders as &$user_order)
			{
				$order_date = substr($user_order['order_date'], -2).'/'.substr($user_order['order_date'], 5, 2).'/'.substr($user_order['order_date'], 0, 4);
				$estimated_completion_date = substr($user_order['estimated_completion_date'], -2).'/'.substr($user_order['estimated_completion_date'], 5, 2).'/'.substr($user_order['estimated_completion_date'], 0, 4);
													
				$sheet->setCellValue('A'.($number + 1), $number);
				$sheet->setCellValue('B'.($number + 1), $user_order['vendor_name'].'/'.$user_order['total_bill'].'/'.$user_order['item'].' : '.$user_order['quantity'].' : '.$user_order['price'].'. Order Tgl '.$order_date.' - Selesai '.$estimated_completion_date);
				$sheet->setCellValue('C'.($number + 1), $order_date);
				$sheet->setCellValue('D'.($number + 1), $user_order['vendor_name']);
				$sheet->setCellValue('E'.($number + 1), $user_order['nearest_city']);
				$sheet->setCellValue('F'.($number + 1), 'Rp'.number_format($user_order['total_bill'], 0, ",", ".").',00');
				$sheet->setCellValue('G'.($number + 1), $user_order['item']);
				$sheet->setCellValue('H'.($number + 1), $user_order['quantity']);
				$sheet->setCellValue('I'.($number + 1), 'Rp'.number_format($user_order['price'], 0, ",", ".").',00');
				$sheet->setCellValue('J'.($number + 1), $estimated_completion_date);
				$sheet->setCellValue('K'.($number + 1), $user_order['order_notes']);
				$sheet->setCellValue('L'.($number + 1), $user_order['unit_name']);

				$number++;
			}

			$sheet->getColumnDimension('A')->setAutoSize(true);
			$sheet->getColumnDimension('B')->setAutoSize(true);
			$sheet->getColumnDimension('C')->setAutoSize(true);
			$sheet->getColumnDimension('D')->setAutoSize(true);
			$sheet->getColumnDimension('E')->setAutoSize(true);
			$sheet->getColumnDimension('F')->setAutoSize(true);
			$sheet->getColumnDimension('G')->setAutoSize(true);
			$sheet->getColumnDimension('H')->setAutoSize(true);
			$sheet->getColumnDimension('I')->setAutoSize(true);
			$sheet->getColumnDimension('J')->setAutoSize(true);
			$sheet->getColumnDimension('K')->setAutoSize(true);
			
			$writer = new Xlsx($spreadsheet);
	
			$filename = 'Data Order '.date("d-m-Y H.i").' WIB';
	
			header('Content-Type: application/vnd.ms-excel');
			header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
			header('Cache-Control: max-age=0');
			
			$writer->save('php://output'); // download file
	    }
	}
?>