<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	//use PhpOffice\PhpSpreadsheet\Spreadsheet;
	//use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
	
	class Unit extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}
        }
        
        public function tambah_ubah($unit_id = 0)
	    {
			if($this->input->post('submit') != NULL)
			{
				$this->load->model('unit_model');

                $input_names = array(
                    'director_id_card',
                    'director_tax_id_number_card',
                    'commissioner_1_id_card',
                    'commissioner_1_tax_id_number_card',
                    'commissioner_2_id_card',
                    'commissioner_2_tax_id_number_card',
                    'commissioner_3_id_card',
                    'commissioner_3_tax_id_number_card',
                    'commissioner_4_id_card',
                    'commissioner_4_tax_id_number_card',
                    'commissioner_5_id_card',
                    'commissioner_5_tax_id_number_card',
                    'certificate_of_company_registration',
                    'business_license',
                    'domicile_of_business',
                    'hinder_ordonantie',
                    'brand_certificate',
                    'certificate_of_competence',
                    'health_social_security_administrator',
                    'institution_of_social_security_employment',
                    'willingness_obedient_letter',
                    'virtual_office_statement',
                    'statement_of_environmental_management',
                    'tax_id_number_card',
                    'certification_of_registration',
                    'taxable_employer_confirmation_letter',
                    'saving_book_a',
                    'saving_book_b',
                    'saving_book_c',
                    'saving_book_d',
                    'saving_book_e',
                    'logo',
                    'masthead_format'
                );

                $skip = 0;
                $uri = 'unit/tambah_ubah/';
                
				if($unit_id < 1)
                {
                    $this->load->library('upload');
                    
                    $images = 1;
                    
                    $unit = $this->unit_model->read_units('unit_id');

                    $folder_name = $unit['unit_id'] + 1;
                    
                    mkdir('uploads/units/'.$folder_name);
                }
                else
                {
                    $images = 0;
                    
                    foreach($input_names as &$input_name)
                    {
                        if($_FILES[$input_name]['size'] > 0)
                        {
                            $this->load->library('upload');

                            $images++;

                            break;
                        }
                        else
                            $skip++;
                    }

                    $folder_name = $unit_id;
                    $uri = $uri.$unit_id;
                }
                
                if($images > 0)
                {
                    foreach($input_names as &$input_name)
                    {
                        if($skip > 0)
                        {
                            $skip--;

                            $file_names[$input_name] = '';
                        }
                        else
                        {
                            if($_FILES[$input_name]['size'] > 0)
                            {
                                $config['upload_path']      = './uploads/units/'.$folder_name;
                                $config['allowed_types']    = 'jpg|jpeg|png|pdf';
                                
                                if($_FILES[$input_name]['type'] == 'image/jpeg')
                                    $config['file_name']    = $input_name.'.jpg';
                                else if($_FILES[$input_name]['type'] == 'image/png')
                                    $config['file_name']    = $input_name.'.png';
                                else
                                    $config['file_name']    = $input_name.'.pdf';

                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload($input_name))
                                {
                                    $this->session->set_flashdata('error_messages', $this->upload->display_errors());
                                    
                                    redirect($uri);
                                }
                                else
                                    $file_names[$input_name] = $this->upload->data('file_name');
                            }
                            else
                                $file_names[$input_name] = '';
                        }
                    }
                }
                else
                {
                    foreach($input_names as &$input_name)
                    {
                        $file_names[$input_name] = '';
                    }
                }
                
                $input_names = array(
                    'deed_of_incorporation',
                    'deed_of_amendment_a',
                    'deed_of_amendment_b',
                    'deed_of_amendment_c',
                    'deed_of_amendment_d',
                    'building_permit',
                    'company_profile'
                );

                if($unit_id < 1)
                    $pdfs = 1;
                else
                {
                    $pdfs = 0;
                    $skip = 0;

                    foreach($input_names as &$input_name)
                    {
                        if($_FILES[$input_name]['size'] > 0)
                        {
                            if($images < 1)
                                $this->load->library('upload');

                            $pdfs++;
                            
                            break;
                        }
                        else
                            $skip++;
                    }
                }
                
                if($pdfs > 0)
                {
                    foreach($input_names as &$input_name)
                    {
                        if($skip > 0)
                        {
                            $skip--;

                            $file_names[$input_name] = '';
                        }
                        else
                        {
                            if($_FILES[$input_name]['size'] > 0)
                            {
                                $config['upload_path']      = './uploads/units/'.$folder_name;
                                $config['allowed_types']    = 'pdf';
                                $config['file_name']        = $input_name.'.pdf';

                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload($input_name))
                                {
                                    $this->session->set_flashdata('error_messages', $this->upload->display_errors());
                                    
                                    redirect($uri);
                                }
                                else
                                    $file_names[$input_name] = $this->upload->data('file_name');
                            }
                            else
                                $file_names[$input_name] = '';
                        }
                    }
                }
                else
                {
                    foreach($input_names as &$input_name)
                    {
                        $file_names[$input_name] = '';
                    }
                }
                
                $input_names = array(
                    'proposal_format',
                    'registration_form_format',
                    'confirmation_letter_example',
                    'invoice_format',
                    'receipt_format',
                    'certificate_of_non_taxable_company_format',
                    'attendance_list_design',
                    'training_evaluation_form_design',
                    'instructor_evaluation_form_design'
                );

                $docs = 0;
                $skip = 0;

                foreach($input_names as &$input_name)
                {
                    if($_FILES[$input_name]['size'] > 0)
                    {
                        if($images < 1 && $pdfs < 1)
                            $this->load->library('upload');

                        $docs++;
                        
                        break;
                    }
                    else
                        $skip++;
                }
                
                if($docs > 0)
                {
                    foreach($input_names as &$input_name)
                    {
                        if($skip > 0)
                        {
                            $skip--;

                            $file_names[$input_name] = '';
                        }
                        else
                        {
                            if($_FILES[$input_name]['size'] > 0)
                            {
                                $config['upload_path']      = './uploads/units/'.$folder_name;
                                $config['allowed_types']    = 'docx|doc';
                                
                                if($_FILES[$input_name]['type'] == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
                                    $config['file_name']    = $input_name.'.docx';
                                else
                                    $config['file_name']    = $input_name.'.doc';

                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload($input_name))
                                {
                                    $this->session->set_flashdata('error_messages', $this->upload->display_errors());
                                    
                                    redirect($uri);
                                }
                                else
                                    $file_names[$input_name] = $this->upload->data('file_name');
                            }
                            else
                                $file_names[$input_name] = '';
                        }
                    }
                }
                else
                {
                    foreach($input_names as &$input_name)
                    {
                        $file_names[$input_name] = '';
                    }
                }

                $input_names = array(
                    'x_banner_design',
                    'certificate_design',
                    'folder_design',
                    'social_media_flyer_design',
                    'poster_design',
                    'module_design',
                    'envelope_design'
                );

                $anyfiles = 0;
                $skip = 0;

                foreach($input_names as &$input_name)
                {
                    if($_FILES[$input_name]['size'] > 0)
                    {
                        if($images < 1 && $pdfs < 1 && $docs < 1)
                            $this->load->library('upload');

                        $anyfiles++;
                        
                        break;
                    }
                    else
                        $skip++;
                }
                
                if($anyfiles > 0)
                {
                    foreach($input_names as &$input_name)
                    {
                        if($skip > 0)
                        {
                            $skip--;

                            $file_names[$input_name] = '';
                        }
                        else
                        {
                            if($_FILES[$input_name]['size'] > 0)
                            {
                                $config['upload_path']      = './uploads/units/'.$folder_name;
                                $config['allowed_types']    = '*';

                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload($input_name))
                                {
                                    $this->session->set_flashdata('error_messages', $this->upload->display_errors());
                                    
                                    redirect($uri);
                                }
                                else
                                    $file_names[$input_name] = $this->upload->data('file_name');
                            }
                            else
                                $file_names[$input_name] = '';
                        }
                    }
                }
                else
                {
                    foreach($input_names as &$input_name)
                    {
                        $file_names[$input_name] = '';
                    }
                }

                $this->unit_model->create_update_unit($file_names, $unit_id);
                
				$this->session->set_flashdata('operation_result', 'unit data saved');
				
                redirect($uri);
			}
			else
			{
				$this->load->model('employee_model');
                $this->load->helper('form');

                $data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

				if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'IT')
					redirect();
				
                if($unit_id < 1)
				{
					$header = 'Data Unit Baru';
					
					$data['name'] = '';
                    $data['code'] = '';
                    $data['address'] = '';
                    $data['market'] = '';
                    $data['director'] = '';
                    $data['director_id_card'] = '';
                    $data['director_tax_id_number_card'] = '';
                    $data['commissioner_1'] = '';
                    $data['commissioner_1_id_card'] = '';
                    $data['commissioner_1_tax_id_number_card'] = '';
                    $data['commissioner_2'] = '';
                    $data['commissioner_2_id_card'] = '';
                    $data['commissioner_2_tax_id_number_card'] = '';
                    $data['commissioner_3'] = '';
                    $data['commissioner_3_id_card'] = '';
                    $data['commissioner_3_tax_id_number_card'] = '';
                    $data['commissioner_4'] = '';
                    $data['commissioner_4_id_card'] = '';
                    $data['commissioner_4_tax_id_number_card'] = '';
                    $data['commissioner_5'] = '';
                    $data['commissioner_5_id_card'] = '';
                    $data['commissioner_5_tax_id_number_card'] = '';
                    $data['deed_of_incorporation_number'] = '';
                    $data['incorporation_date'] = '';
                    $data['notary_name'] = '';
                    $data['deed_of_incorporation'] = '';
                    $data['deed_of_amendment_a_number'] = '';
                    $data['amendment_date_a'] = '';
                    $data['notary_name_a'] = '';
                    $data['deed_of_amendment_a'] = '';
                    $data['deed_of_amendment_b_number'] = '';
                    $data['amendment_date_b'] = '';
                    $data['notary_name_b'] = '';
                    $data['deed_of_amendment_b'] = '';
                    $data['deed_of_amendment_c_number'] = '';
                    $data['amendment_date_c'] = '';
                    $data['notary_name_c'] = '';
                    $data['deed_of_amendment_c'] = '';
                    $data['deed_of_amendment_d_number'] = '';
                    $data['amendment_date_d'] = '';
                    $data['notary_name_d'] = '';
                    $data['deed_of_amendment_d'] = '';
                    $data['certificate_of_company_registration_number'] = '';
                    $data['certificate_of_company_registration'] = '';
                    $data['business_license_number'] = '';
                    $data['business_license'] = '';
                    $data['domicile_of_business_number'] = '';
                    $data['domicile_of_business'] = '';
                    $data['hinder_ordonantie_number'] = '';
                    $data['hinder_ordonantie'] = '';
                    $data['brand_certificate'] = '';
                    $data['certificate_of_competence'] = '';
                    $data['health_social_security_administrator'] = '';
                    $data['institution_of_social_security_employment'] = '';
                    $data['willingness_obedient_letter'] = '';
                    $data['virtual_office_statement'] = '';
                    $data['statement_of_environmental_management'] = '';
                    $data['building_permit'] = '';
                    $data['oss_username'] = '';
                    $data['oss_password'] = '';
                    $data['tax_id_number'] = '';
                    $data['tax_id_number_card'] = '';
                    $data['certification_of_registration_number'] = '';
                    $data['certification_of_registration'] = '';
                    $data['taxable_employer_confirmation_letter_number'] = '';
                    $data['taxable_employer_confirmation_letter'] = '';
                    $data['electronic_filing_identification_number'] = '';
                    $data['e_nofa_number'] = '';
                    $data['djponline_username'] = '';
                    $data['djponline_password'] = '';
                    $data['email_address'] = '';
                    $data['e_faktur'] = '';
                    $data['taxable_employers'] = '';
                    $data['sse3'] = '';
                    $data['tax_object_mobile_number'] = '62';
                    $data['bank_a'] = '';
                    $data['account_type_a'] = '';
                    $data['account_number_a'] = '';
                    $data['branch_a'] = '';
                    $data['saving_book_a'] = '';
                    $data['saving_book_holder_a'] = '';
                    $data['atm_card_holder_a'] = '';
                    $data['internet_banking_username_a'] = '';
                    $data['internet_banking_password_a'] = '';
                    $data['internet_banking_company_id_a'] = '';
                    $data['internet_banking_notes_a'] = '';
                    $data['pin_a'] = '';
                    $data['internet_banking_mobile_number_token_a'] = '';
                    $data['bank_b'] = '';
                    $data['account_type_b'] = '';
                    $data['account_number_b'] = '';
                    $data['branch_b'] = '';
                    $data['saving_book_b'] = '';
                    $data['saving_book_holder_b'] = '';
                    $data['atm_card_holder_b'] = '';
                    $data['internet_banking_username_b'] = '';
                    $data['internet_banking_password_b'] = '';
                    $data['internet_banking_company_id_b'] = '';
                    $data['internet_banking_notes_b'] = '';
                    $data['pin_b'] = '';
                    $data['internet_banking_mobile_number_token_b'] = '';
                    $data['bank_c'] = '';
                    $data['account_type_c'] = '';
                    $data['account_number_c'] = '';
                    $data['branch_c'] = '';
                    $data['saving_book_c'] = '';
                    $data['saving_book_holder_c'] = '';
                    $data['atm_card_holder_c'] = '';
                    $data['internet_banking_username_c'] = '';
                    $data['internet_banking_password_c'] = '';
                    $data['internet_banking_company_id_c'] = '';
                    $data['internet_banking_notes_c'] = '';
                    $data['pin_c'] = '';
                    $data['internet_banking_mobile_number_token_c'] = '';
                    $data['bank_d'] = '';
                    $data['account_type_d'] = '';
                    $data['account_number_d'] = '';
                    $data['branch_d'] = '';
                    $data['saving_book_d'] = '';
                    $data['saving_book_holder_d'] = '';
                    $data['atm_card_holder_d'] = '';
                    $data['internet_banking_username_d'] = '';
                    $data['internet_banking_password_d'] = '';
                    $data['internet_banking_company_id_d'] = '';
                    $data['internet_banking_notes_d'] = '';
                    $data['pin_d'] = '';
                    $data['internet_banking_mobile_number_token_d'] = '';
                    $data['bank_e'] = '';
                    $data['account_type_e'] = '';
                    $data['account_number_e'] = '';
                    $data['branch_e'] = '';
                    $data['saving_book_e'] = '';
                    $data['saving_book_holder_e'] = '';
                    $data['atm_card_holder_e'] = '';
                    $data['internet_banking_username_e'] = '';
                    $data['internet_banking_password_e'] = '';
                    $data['internet_banking_company_id_e'] = '';
                    $data['internet_banking_notes_e'] = '';
                    $data['pin_e'] = '';
                    $data['internet_banking_mobile_number_token_e'] = '';
                    $data['proposal_format'] = '';
                    $data['registration_form_format'] = '';
                    $data['confirmation_letter_example'] = '';
                    $data['company_profile'] = '';
                    $data['invoice_format'] = '';
                    $data['receipt_format'] = '';
                    $data['certificate_of_non_taxable_company_format'] = '';
                    $data['logo'] = '';
                    $data['masthead_format'] = '';
                    $data['x_banner_design'] = '';
                    $data['certificate_design'] = '';
                    $data['folder_design'] = '';
                    $data['social_media_flyer_design'] = '';
                    $data['poster_design'] = '';
                    $data['module_design'] = '';
                    $data['envelope_design'] = '';
                    $data['attendance_list_design'] = '';
                    $data['training_evaluation_form_design'] = '';
                    $data['instructor_evaluation_form_design'] = '';
				}
				else
				{
					$this->load->model('unit_model');

					$header = 'Ubah Data Unit';
					
					$unit = $this->unit_model->read_units('*', 'row_array', '', 0, $unit_id);

					$data['name'] = $unit['name'];
                    $data['code'] = $unit['code'];
                    $data['address'] = $unit['address'];
                    $data['market'] = $unit['market'];
                    $data['director'] = $unit['director'];
                    $data['director_id_card'] = $unit['director_id_card'];
                    $data['director_tax_id_number_card'] = $unit['director_tax_id_number_card'];
                    $data['commissioner_1'] = $unit['commissioner_1'];
                    $data['commissioner_1_id_card'] = $unit['commissioner_1_id_card'];
                    $data['commissioner_1_tax_id_number_card'] = $unit['commissioner_1_tax_id_number_card'];
                    $data['commissioner_2'] = $unit['commissioner_2'];
                    $data['commissioner_2_id_card'] = $unit['commissioner_2_id_card'];
                    $data['commissioner_2_tax_id_number_card'] = $unit['commissioner_2_tax_id_number_card'];
                    $data['commissioner_3'] = $unit['commissioner_3'];
                    $data['commissioner_3_id_card'] = $unit['commissioner_3_id_card'];
                    $data['commissioner_3_tax_id_number_card'] = $unit['commissioner_3_tax_id_number_card'];
                    $data['commissioner_4'] = $unit['commissioner_4'];
                    $data['commissioner_4_id_card'] = $unit['commissioner_4_id_card'];
                    $data['commissioner_4_tax_id_number_card'] = $unit['commissioner_4_tax_id_number_card'];
                    $data['commissioner_5'] = $unit['commissioner_5'];
                    $data['commissioner_5_id_card'] = $unit['commissioner_5_id_card'];
                    $data['commissioner_5_tax_id_number_card'] = $unit['commissioner_5_tax_id_number_card'];
                    $data['deed_of_incorporation_number'] = $unit['deed_of_incorporation_number'];
                    $data['incorporation_date'] = $unit['incorporation_date'];
                    $data['notary_name'] = $unit['notary_name'];
                    $data['deed_of_incorporation'] = $unit['deed_of_incorporation'];
                    $data['deed_of_amendment_a_number'] = $unit['deed_of_amendment_a_number'];
                    $data['amendment_date_a'] = $unit['amendment_date_a'];
                    $data['notary_name_a'] = $unit['notary_name_a'];
                    $data['deed_of_amendment_a'] = $unit['deed_of_amendment_a'];
                    $data['deed_of_amendment_b_number'] = $unit['deed_of_amendment_b_number'];
                    $data['amendment_date_b'] = $unit['amendment_date_b'];
                    $data['notary_name_b'] = $unit['notary_name_b'];
                    $data['deed_of_amendment_b'] = $unit['deed_of_amendment_b'];
                    $data['deed_of_amendment_c_number'] = $unit['deed_of_amendment_c_number'];
                    $data['amendment_date_c'] = $unit['amendment_date_c'];
                    $data['notary_name_c'] = $unit['notary_name_c'];
                    $data['deed_of_amendment_c'] = $unit['deed_of_amendment_c'];
                    $data['deed_of_amendment_d_number'] = $unit['deed_of_amendment_d_number'];
                    $data['amendment_date_d'] = $unit['amendment_date_d'];
                    $data['notary_name_d'] = $unit['notary_name_d'];
                    $data['deed_of_amendment_d'] = $unit['deed_of_amendment_d'];
                    $data['certificate_of_company_registration_number'] = $unit['certificate_of_company_registration_number'];
                    $data['certificate_of_company_registration'] = $unit['certificate_of_company_registration'];
                    $data['business_license_number'] = $unit['business_license_number'];
                    $data['business_license'] = $unit['business_license'];
                    $data['domicile_of_business_number'] = $unit['domicile_of_business_number'];
                    $data['domicile_of_business'] = $unit['domicile_of_business'];
                    $data['hinder_ordonantie_number'] = $unit['hinder_ordonantie_number'];
                    $data['hinder_ordonantie'] = $unit['hinder_ordonantie'];
                    $data['brand_certificate'] = $unit['brand_certificate'];
                    $data['certificate_of_competence'] = $unit['certificate_of_competence'];
                    $data['health_social_security_administrator'] = $unit['health_social_security_administrator'];
                    $data['institution_of_social_security_employment'] = $unit['institution_of_social_security_employment'];
                    $data['willingness_obedient_letter'] = $unit['willingness_obedient_letter'];
                    $data['virtual_office_statement'] = $unit['virtual_office_statement'];
                    $data['statement_of_environmental_management'] = $unit['statement_of_environmental_management'];
                    $data['building_permit'] = $unit['building_permit'];
                    $data['oss_username'] = $unit['oss_username'];
                    $data['oss_password'] = $unit['oss_password'];
                    $data['tax_id_number'] = $unit['tax_id_number'];
                    $data['tax_id_number_card'] = $unit['tax_id_number_card'];
                    $data['certification_of_registration_number'] = $unit['certification_of_registration_number'];
                    $data['certification_of_registration'] = $unit['certification_of_registration'];
                    $data['taxable_employer_confirmation_letter_number'] = $unit['taxable_employer_confirmation_letter_number'];
                    $data['taxable_employer_confirmation_letter'] = $unit['taxable_employer_confirmation_letter'];
                    $data['electronic_filing_identification_number'] = $unit['electronic_filing_identification_number'];
                    $data['e_nofa_number'] = $unit['e_nofa_number'];
                    $data['e_faktur'] = $unit['e_faktur'];
                    $data['djponline_username'] = $unit['djponline_username'];
                    $data['djponline_password'] = $unit['djponline_password'];
                    $data['email_address'] = $unit['email_address'];
                    $data['tax_object_mobile_number'] = $unit['tax_object_mobile_number'];
                    $data['taxable_employers'] = $unit['taxable_employers'];
                    $data['sse3'] = $unit['sse3'];
                    $data['bank_a'] = $unit['bank_a'];
                    $data['account_type_a'] = $unit['account_type_a'];
                    $data['account_number_a'] = $unit['account_number_a'];
                    $data['branch_a'] = $unit['branch_a'];
                    $data['saving_book_a'] = $unit['saving_book_a'];
                    $data['saving_book_holder_a'] = $unit['saving_book_holder_a'];
                    $data['atm_card_holder_a'] = $unit['atm_card_holder_a'];
                    $data['internet_banking_username_a'] = $unit['internet_banking_username_a'];
                    $data['internet_banking_password_a'] = $unit['internet_banking_password_a'];
                    $data['internet_banking_company_id_a'] = $unit['internet_banking_company_id_a'];
                    $data['internet_banking_notes_a'] = $unit['internet_banking_notes_a'];
                    $data['pin_a'] = $unit['pin_a'];
                    $data['internet_banking_mobile_number_token_a'] = $unit['internet_banking_mobile_number_token_a'];
                    $data['bank_b'] = $unit['bank_b'];
                    $data['account_type_b'] = $unit['account_type_b'];
                    $data['account_number_b'] = $unit['account_number_b'];
                    $data['branch_b'] = $unit['branch_b'];
                    $data['saving_book_b'] = $unit['saving_book_b'];
                    $data['saving_book_holder_b'] = $unit['saving_book_holder_b'];
                    $data['atm_card_holder_b'] = $unit['atm_card_holder_b'];
                    $data['internet_banking_username_b'] = $unit['internet_banking_username_b'];
                    $data['internet_banking_password_b'] = $unit['internet_banking_password_b'];
                    $data['internet_banking_company_id_b'] = $unit['internet_banking_company_id_b'];
                    $data['internet_banking_notes_b'] = $unit['internet_banking_notes_b'];
                    $data['pin_b'] = $unit['pin_b'];
                    $data['internet_banking_mobile_number_token_b'] = $unit['internet_banking_mobile_number_token_b'];
                    $data['bank_c'] = $unit['bank_c'];
                    $data['account_type_c'] = $unit['account_type_c'];
                    $data['account_number_c'] = $unit['account_number_c'];
                    $data['branch_c'] = $unit['branch_c'];
                    $data['saving_book_c'] = $unit['saving_book_c'];
                    $data['saving_book_holder_c'] = $unit['saving_book_holder_c'];
                    $data['atm_card_holder_c'] = $unit['atm_card_holder_c'];
                    $data['internet_banking_username_c'] = $unit['internet_banking_username_c'];
                    $data['internet_banking_password_c'] = $unit['internet_banking_password_c'];
                    $data['internet_banking_company_id_c'] = $unit['internet_banking_company_id_c'];
                    $data['internet_banking_notes_c'] = $unit['internet_banking_notes_c'];
                    $data['pin_c'] = $unit['pin_c'];
                    $data['internet_banking_mobile_number_token_c'] = $unit['internet_banking_mobile_number_token_c'];
                    $data['bank_d'] = $unit['bank_d'];
                    $data['account_type_d'] = $unit['account_type_d'];
                    $data['account_number_d'] = $unit['account_number_d'];
                    $data['branch_d'] = $unit['branch_d'];
                    $data['saving_book_d'] = $unit['saving_book_d'];
                    $data['saving_book_holder_d'] = $unit['saving_book_holder_d'];
                    $data['atm_card_holder_d'] = $unit['atm_card_holder_d'];
                    $data['internet_banking_username_d'] = $unit['internet_banking_username_d'];
                    $data['internet_banking_password_d'] = $unit['internet_banking_password_d'];
                    $data['internet_banking_company_id_d'] = $unit['internet_banking_company_id_d'];
                    $data['internet_banking_notes_d'] = $unit['internet_banking_notes_d'];
                    $data['pin_d'] = $unit['pin_d'];
                    $data['internet_banking_mobile_number_token_d'] = $unit['internet_banking_mobile_number_token_d'];
                    $data['bank_e'] = $unit['bank_e'];
                    $data['account_type_e'] = $unit['account_type_e'];
                    $data['account_number_e'] = $unit['account_number_e'];
                    $data['branch_e'] = $unit['branch_e'];
                    $data['saving_book_e'] = $unit['saving_book_e'];
                    $data['saving_book_holder_e'] = $unit['saving_book_holder_e'];
                    $data['atm_card_holder_e'] = $unit['atm_card_holder_e'];
                    $data['internet_banking_username_e'] = $unit['internet_banking_username_e'];
                    $data['internet_banking_password_e'] = $unit['internet_banking_password_e'];
                    $data['internet_banking_company_id_e'] = $unit['internet_banking_company_id_e'];
                    $data['internet_banking_notes_e'] = $unit['internet_banking_notes_e'];
                    $data['pin_e'] = $unit['pin_e'];
                    $data['internet_banking_mobile_number_token_e'] = $unit['internet_banking_mobile_number_token_e'];
                    $data['proposal_format'] = $unit['proposal_format'];
                    $data['registration_form_format'] = $unit['registration_form_format'];
                    $data['confirmation_letter_example'] = $unit['confirmation_letter_example'];
                    $data['company_profile'] = $unit['company_profile'];
                    $data['invoice_format'] = $unit['invoice_format'];
                    $data['receipt_format'] = $unit['receipt_format'];
                    $data['certificate_of_non_taxable_company_format'] = $unit['certificate_of_non_taxable_company_format'];
                    $data['logo'] = $unit['logo'];
                    $data['masthead_format'] = $unit['masthead_format'];
                    $data['x_banner_design'] = $unit['x_banner_design'];
                    $data['certificate_design'] = $unit['certificate_design'];
                    $data['folder_design'] = $unit['folder_design'];
                    $data['social_media_flyer_design'] = $unit['social_media_flyer_design'];
                    $data['poster_design'] = $unit['poster_design'];
                    $data['module_design'] = $unit['module_design'];
                    $data['envelope_design'] = $unit['envelope_design'];
                    $data['attendance_list_design'] = $unit['attendance_list_design'];
                    $data['training_evaluation_form_design'] = $unit['training_evaluation_form_design'];
                    $data['instructor_evaluation_form_design'] = $unit['instructor_evaluation_form_design'];

                    $data['shareholders_documents_update_link'] = base_url('unit/ubah_dokumen_pesero/');
				}
                    
				$data['title'] = ':: Sister JSO :: '.$header;
				
				$data['vendor_css_links'] = array(
					'bootstrap/css/bootstrap.min.css',
					'font-awesome/css/font-awesome.min.css',
					'animate-css/animate.min.css',
					'bootstrap-multiselect/bootstrap-multiselect.css',
					'bootstrap-datepicker/css/bootstrap-datepicker3.min.css',
					'bootstrap-colorpicker/css/bootstrap-colorpicker.css',
					'multi-select/css/multi-select.css',
					'bootstrap-tagsinput/bootstrap-tagsinput.css',
					'nouislider/nouislider.min.css',
                    'toastr/toastr.min.css',
                    'dropify/css/dropify.min.css'
                );
				
                $data['header'] = $header;
				$data['unit_id'] = $unit_id;
                
                $data['js_links'] = array(
					'assets/bundles/libscripts.bundle.js',
					'assets/bundles/vendorscripts.bundle.js',
					'vendor/bootstrap-colorpicker/js/bootstrap-colorpicker.js',
					'vendor/jquery-inputmask/jquery.inputmask.bundle.js',
					'vendor/jquery-mask/jquery.mask.min.js',
					'vendor/multi-select/js/jquery.multi-select.js',
					'vendor/bootstrap-multiselect/bootstrap-multiselect.js',
					'vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js',
					'vendor/bootstrap-tagsinput/bootstrap-tagsinput.js',
					'vendor/nouislider/nouislider.js',
                    'vendor/toastr/toastr.js',
                    'vendor/dropify/js/dropify.min.js',
					'assets/bundles/mainscripts.bundle.js',
                    'assets/js/pages/forms/advanced-form-elements.js',
                    'assets/js/pages/forms/dropify.js',
					'assets/js/pages/unit/create_update.js'
				);

				// Render view on main layout
				$this->load->view('templates/dashboard/top', $data);
				$this->load->view('pages/units/create_update', $data);
				$this->load->view('templates/dashboard/bottom', $data);
			}
	    }
	    
		public function ubah_dokumen_pesero($unit_id)
		{
			$this->load->model('unit_model');
			
			$this->unit_model->update_shareholders_documents($unit_id);
        }
        
		public function daftar()
	    {
			$this->load->model('employee_model');
			$this->load->helper('form');

            $data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

            if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'IT')
                redirect();

			$data['title'] = ':: Sister JSO :: Data Unit';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);
            
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'assets/js/pages/unit/list.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/units/list/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		public function data($page_number, $name = '')
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

            $this->load->model('unit_model');
			$this->load->helper('form');

            $data['units'] = $this->unit_model->read_units('unit_id, name, code, director, incorporation_date', 'result_array', urldecode($name), $page_number);
            
            $page_count = ceil($this->unit_model->read_units('unit_id, name, code, director, incorporation_date', 'num_rows', urldecode($name)) / 5);
                
            $data['name'] = urldecode($name);
            $data['page_number'] = $page_number;
			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				if($page_count > 10)
				{
					if($page_number > 6)
					{
						if(($page_count - $page_number) >= 4)
							$next_page_count = 4;
						else
							$next_page_count = $page_count - $page_number;
						
						$previous_page_count = 9 - $next_page_count;
					}
					else
					{
						$previous_page_count = $page_number - 1;
						$next_page_count = 9 - $previous_page_count;
					}
				}
				else
				{
					$previous_page_count = $page_number - 1;
					$next_page_count = $page_count - $page_number;
				}

				$data['previous_page_count'] = $previous_page_count;
				$data['next_page_count'] = $next_page_count;
			}

			echo $this->load->view('pages/units/list/dynamic_content', $data, TRUE);
		}

		public function unduh()
	    {
			if($this->input->post('submit') != NULL)
			{
                $this->load->library('zip');

                $this->zip->compression_level = 9;
                $this->zip->read_dir('./uploads/units/'.$this->input->post('unit_id'), FALSE);
                $this->zip->archive('./uploads/unit_'.$this->input->post('unit_id').'.zip');
                $this->zip->download('unit_'.$this->input->post('unit_id').'.zip');

                unlink('uploads/unit_'.$this->input->post('unit_id').'.zip');
            }
            else
            {
                $this->load->model('employee_model');
                $this->load->model('unit_model');
                $this->load->helper('form');

                $data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

				if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'IT')
					redirect();

                $data['title'] = ':: Sister JSO :: Unduh Dokumen Unit';
                
                $data['vendor_css_links'] = array(
                    'bootstrap/css/bootstrap.min.css',
                    'font-awesome/css/font-awesome.min.css',
                    'animate-css/animate.min.css'
                );

				$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
			
				foreach($unit_list as &$unit)
				{
					$units[$unit['unit_id']] = $unit['name'];
				}

				$data['units'] = $units;
                
                $data['js_links'] = array(
                    'assets/bundles/libscripts.bundle.js',
                    'assets/bundles/vendorscripts.bundle.js',
                    'assets/bundles/mainscripts.bundle.js'
                );

                // Render view on main layout
                $this->load->view('templates/dashboard/top', $data);
                $this->load->view('pages/units/download', $data);
                $this->load->view('templates/dashboard/bottom', $data);
            }
	    }
	}
?>