<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	//use PhpOffice\PhpSpreadsheet\Spreadsheet;
	//use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
	
	class Kegiatan extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}
        }
        
        public function tambah_ubah($event_id = 0)
	    {
			$this->load->model('employee_model');
			$this->load->model('event_model');

			if($this->input->post('submit') != NULL)
			{
				$this->event_model->create_update_event($event_id);

                $this->session->set_flashdata('operation_result', 'event data saved');
                
				if($event_id == 0)
                    redirect('kegiatan/tambah_ubah');
                else
                    redirect('kegiatan/tambah_ubah/'.$event_id);
			}
			else
			{
				$this->load->model('unit_model');
				$this->load->model('vendor_model');
				$this->load->helper('form');

                $data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

				require 'Options.php';

				if($event_id == 0)
				{
					if($data['logged_in_user']['division'] != 'MARKETING')
						redirect();

					$header = 'Tambah Data Progress Harian';
					
                    $data['name'] = '';
                    $data['category'] = 'Audit';
                    $data['type'] = 'Public';
					$data['status'] = 'Prospek';
                    $data['proposal_date'] = '';
                    $data['start_date'] = '';
                    $data['end_date'] = '';
                    $data['starting_hour'] = '';
                    $data['completion_hour'] = '';
                    $data['city'] = 'Yogyakarta';
					$data['marketing_user_id'] = $this->session->userdata('user_id');
                    $data['source'] = 'Website';
                    $data['notes'] = '';
					$data['clients_number'] = 1;
                    $data['meeting_room'] = '';
                    $data['accommodation'] = '';
                    $data['trip'] = '';
                    $data['custom_souvenir'] = '';
					$data['city_tour'] = '';
					$data['number_of_instructors'] = 1;
					$data['document_recipient'] = '';
					$data['company_address'] = '';
					$data['company_phone_number'] = '62';
					$data['document_delivery'] = 'Dikirim Kantor';
					$data['invoice_attachments'] = '';
					$data['payment_plan'] = '';
					$data['document_description'] = '';
                    $data['per_unit_instructor_a_honorarium'] = 0;
					$data['instructor_a_quantity'] = 0;
					$data['total_instructor_a_honorarium'] = 0;
					$data['per_unit_instructor_b_honorarium'] = 0;
					$data['instructor_b_quantity'] = 0;
					$data['total_instructor_b_honorarium'] = 0;
					$data['per_unit_meeting_room_budget'] = 0;
					$data['meeting_room_quantity'] = 0;
					$data['total_meeting_room_budget'] = 0;
					$data['per_unit_participant_accommodation_budget'] = 0;
					$data['participant_accommodation_quantity'] = 0;
					$data['total_participant_accommodation_budget'] = 0;
					$data['per_unit_certification_trip_budget'] = 0;
					$data['certification_trip_quantity'] = 0;
					$data['total_certification_trip_budget'] = 0;
					$data['per_unit_participant_transportation_budget'] = 0;
					$data['participant_transportation_quantity'] = 0;
					$data['total_participant_transportation_budget'] = 0;
					$data['per_unit_instructor_accommodation_budget'] = 0;
					$data['instructor_accommodation_quantity'] = 0;
					$data['total_instructor_accommodation_budget'] = 0;
					$data['per_unit_instructor_transportation_budget'] = 0;
					$data['instructor_transportation_quantity'] = 0;
					$data['total_instructor_transportation_budget'] = 0;
					$data['per_unit_module_budget'] = 0;
					$data['module_quantity'] = 0;
					$data['total_module_budget'] = 0;
					$data['per_unit_certificate_budget'] = 0;
					$data['certificate_quantity'] = 0;
					$data['total_certificate_budget'] = 0;
					$data['per_unit_folder_budget'] = 0;
					$data['folder_quantity'] = 0;
					$data['total_folder_budget'] = 0;
					$data['per_unit_envelope_budget'] = 0;
					$data['envelope_quantity'] = 0;
					$data['total_envelope_budget'] = 0;
					$data['per_unit_exclusive_bag_budget'] = 0;
					$data['exclusive_bag_quantity'] = 0;
					$data['total_exclusive_bag_budget'] = 0;
					$data['per_unit_economic_bag_budget'] = 0;
					$data['economic_bag_quantity'] = 0;
					$data['total_economic_bag_budget'] = 0;
					$data['per_unit_gift_budget'] = 0;
					$data['gift_quantity'] = 0;
					$data['total_gift_budget'] = 0;
					$data['per_unit_batik_budget'] = 0;
					$data['batik_quantity'] = 0;
					$data['total_batik_budget'] = 0;
					$data['per_unit_shirt_budget'] = 0;
					$data['shirt_quantity'] = 0;
					$data['total_shirt_budget'] = 0;
					$data['per_unit_powerbank_budget'] = 0;
					$data['powerbank_quantity'] = 0;
					$data['total_powerbank_budget'] = 0;
					$data['per_unit_jacket_budget'] = 0;
					$data['jacket_quantity'] = 0;
					$data['total_jacket_budget'] = 0;
					$data['per_unit_placard_budget'] = 0;
					$data['placard_quantity'] = 0;
					$data['total_placard_budget'] = 0;
					$data['per_unit_souvenir_budget'] = 0;
					$data['souvenir_quantity'] = 0;
					$data['total_souvenir_budget'] = 0;
					$data['per_unit_name_tag_budget'] = 0;
					$data['name_tag_quantity'] = 0;
					$data['total_name_tag_budget'] = 0;
					$data['per_unit_goody_bag_budget'] = 0;
					$data['goody_bag_quantity'] = 0;
					$data['total_goody_bag_budget'] = 0;
					$data['per_unit_ballpoint_budget'] = 0;
					$data['ballpoint_quantity'] = 0;
					$data['total_ballpoint_budget'] = 0;
					$data['per_unit_blocknote_budget'] = 0;
					$data['blocknote_quantity'] = 0;
					$data['total_blocknote_budget'] = 0;
					$data['per_unit_flashdisk_budget'] = 0;
					$data['flashdisk_quantity'] = 0;
					$data['total_flashdisk_budget'] = 0;
					$data['per_unit_cd_budget'] = 0;
					$data['cd_quantity'] = 0;
					$data['total_cd_budget'] = 0;
					$data['per_unit_documentation_budget'] = 0;
					$data['documentation_quantity'] = 0;
					$data['total_documentation_budget'] = 0;
					$data['per_unit_banner_budget'] = 0;
					$data['banner_quantity'] = 0;
					$data['total_banner_budget'] = 0;
					$data['per_unit_value_added_tax'] = 0;
                    $data['value_added_tax_quantity'] = 0;
					$data['total_value_added_tax'] = 0;
					$data['per_unit_agent_fee'] = 0;
					$data['agent_quantity'] = 0;
					$data['total_agent_fee'] = 0;
                    $data['per_unit_driver_fee'] = 0;
                    $data['driver_quantity'] = 0;
					$data['total_driver_fee'] = 0;
					$data['per_unit_cs_fee'] = 0;
                    $data['cs_quantity'] = 0;
					$data['total_cs_fee'] = 0;
					$data['per_unit_rental_cost'] = 0;
                    $data['rental_quantity'] = 0;
					$data['total_rental_cost'] = 0;
					$data['per_unit_meal_budget'] = 0;
					$data['meal_quantity'] = 0;
					$data['total_meal_budget'] = 0;
					$data['per_unit_city_tour_budget'] = 0;
					$data['city_tour_quantity'] = 0;
					$data['total_city_tour_budget'] = 0;
					$data['per_unit_operational_budget'] = 0;
					$data['operational_quantity'] = 0;
					$data['total_operational_budget'] = 0;
					$data['per_unit_team_accommodation_budget'] = 0;
					$data['team_accommodation_quantity'] = 0;
					$data['total_team_accommodation_budget'] = 0;
					$data['per_unit_team_transportation_budget'] = 0;
					$data['team_transportation_quantity'] = 0;
					$data['total_team_transportation_budget'] = 0;
					$data['per_unit_income_tax'] = 0;
					$data['income_tax_quantity'] = 0;
					$data['total_income_tax'] = 0;
					$data['per_unit_delivery_budget'] = 0;
					$data['delivery_quantity'] = 0;
					$data['total_delivery_budget'] = 0;
                    $data['price'] = 100;
					$data['turnover'] = 100;
					$data['total_expense'] = 0;
					$data['profit_nominal'] = 100;
					$data['profit_percentage'] = 100;
					$data['approval_status'] = 'Menunggu persetujuan';
					$data['nearest_city'] = 'Yogyakarta & sekitarnya';
				}
				else
				{
					if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'MARKETING' && $data['logged_in_user']['division'] != 'FINANCE' && $data['logged_in_user']['division'] != 'LOGISTIK')
						redirect();

					$header = 'Ubah Data Progress Harian';
					
                    $event = $this->event_model->read_events_vendors_clients('*', '', 0, 'row_array', '', '', $event_id);

					$data['proposal_date'] = $event['proposal_date'];
					$data['name'] = $event['name'];
					$data['category'] = $event['category'];
					$data['type'] = $event['type'];
					$data['status'] = $event['status'];
					$data['start_date'] = $event['start_date'];
					$data['end_date'] = $event['end_date'];
					$data['starting_hour'] = $event['starting_hour'];
					$data['completion_hour'] = $event['completion_hour'];
					$data['instructor_user_id'] = $event['instructor_user_id'];
					$data['number_of_instructors'] = $event['number_of_instructors'];
					$data['city'] = $event['city'];
					$data['hotel_vendor_id'] = $event['hotel_vendor_id'];
					$data['marketing_user_id'] = $event['marketing_user_id'];
					$data['cs_user_id'] = $event['cs_user_id'];
					$data['transportation_vendor_id'] = $event['transportation_vendor_id'];
					$data['driver_user_id'] = $event['driver_user_id'];
					$data['manager_user_id'] = $event['manager_user_id'];
					$data['source'] = $event['source'];
					$data['source_detail'] = $event['source_detail'];
					$data['client_id'] = $event['client_id'];
					$data['clients_number'] = $event['clients_number'];
					$data['meeting_room'] = $event['meeting_room'];
					$data['accommodation'] = $event['accommodation'];
					$data['logistic_user_id'] = $event['logistic_user_id'];
					$data['trip'] = $event['trip'];
					$data['custom_souvenir'] = $event['custom_souvenir'];
					$data['city_tour'] = $event['city_tour'];
					$data['document_recipient'] = $event['document_recipient'];
					$data['company_address'] = $event['company_address'];
					$data['company_phone_number'] = $event['company_phone_number'];
					$data['document_delivery'] = $event['document_delivery'];
					$data['invoice_attachments'] = $event['invoice_attachments'];

					if($event['payment_plan'] == '0000-00-00')
						$data['payment_plan'] = '';
					else
						$data['payment_plan'] = $event['payment_plan'];
					
					$data['document_description'] = $event['document_description'];
					$data['per_unit_instructor_a_honorarium'] = number_format($event['per_unit_instructor_a_honorarium'], 0, ',', '.');
					$data['instructor_a_quantity'] = number_format($event['instructor_a_quantity'], 0, ',', '.');
					$data['per_unit_instructor_b_honorarium'] = number_format($event['per_unit_instructor_b_honorarium'], 0, ',', '.');
					$data['instructor_b_quantity'] = number_format($event['instructor_b_quantity'], 0, ',', '.');
					$data['per_unit_meeting_room_budget'] = number_format($event['per_unit_meeting_room_budget'], 0, ',', '.');
					$data['meeting_room_quantity'] = number_format($event['meeting_room_quantity'], 0, ',', '.');
					$data['per_unit_participant_accommodation_budget'] = number_format($event['per_unit_participant_accommodation_budget'], 0, ',', '.');
					$data['participant_accommodation_quantity'] = number_format($event['participant_accommodation_quantity'], 0, ',', '.');
					$data['per_unit_certification_trip_budget'] = number_format($event['per_unit_certification_trip_budget'], 0, ',', '.');
					$data['certification_trip_quantity'] = number_format($event['certification_trip_quantity'], 0, ',', '.');
					$data['per_unit_participant_transportation_budget'] = number_format($event['per_unit_participant_transportation_budget'], 0, ',', '.');
					$data['participant_transportation_quantity'] = number_format($event['participant_transportation_quantity'], 0, ',', '.');
					$data['per_unit_instructor_accommodation_budget'] = number_format($event['per_unit_instructor_accommodation_budget'], 0, ',', '.');
					$data['instructor_accommodation_quantity'] = number_format($event['instructor_accommodation_quantity'], 0, ',', '.');
					$data['per_unit_instructor_transportation_budget'] = number_format($event['per_unit_instructor_transportation_budget'], 0, ',', '.');
					$data['instructor_transportation_quantity'] = number_format($event['instructor_transportation_quantity'], 0, ',', '.');
					$data['per_unit_module_budget'] = number_format($event['per_unit_module_budget'], 0, ',', '.');
					$data['module_quantity'] = number_format($event['module_quantity'], 0, ',', '.');
					$data['per_unit_certificate_budget'] = number_format($event['per_unit_certificate_budget'], 0, ',', '.');
					$data['certificate_quantity'] = number_format($event['certificate_quantity'], 0, ',', '.');
					$data['per_unit_folder_budget'] = number_format($event['per_unit_folder_budget'], 0, ',', '.');
					$data['folder_quantity'] = number_format($event['folder_quantity'], 0, ',', '.');
					$data['per_unit_envelope_budget'] = number_format($event['per_unit_envelope_budget'], 0, ',', '.');
					$data['envelope_quantity'] = number_format($event['envelope_quantity'], 0, ',', '.');
					$data['per_unit_exclusive_bag_budget'] = number_format($event['per_unit_exclusive_bag_budget'], 0, ',', '.');
					$data['exclusive_bag_quantity'] = number_format($event['exclusive_bag_quantity'], 0, ',', '.');
					$data['per_unit_economic_bag_budget'] = number_format($event['per_unit_economic_bag_budget'], 0, ',', '.');
					$data['economic_bag_quantity'] = number_format($event['economic_bag_quantity'], 0, ',', '.');
					$data['per_unit_gift_budget'] = number_format($event['per_unit_gift_budget'], 0, ',', '.');
					$data['gift_quantity'] = number_format($event['gift_quantity'], 0, ',', '.');
					$data['per_unit_batik_budget'] = number_format($event['per_unit_batik_budget'], 0, ',', '.');
					$data['batik_quantity'] = number_format($event['batik_quantity'], 0, ',', '.');
					$data['per_unit_shirt_budget'] = number_format($event['per_unit_shirt_budget'], 0, ',', '.');
					$data['shirt_quantity'] = number_format($event['shirt_quantity'], 0, ',', '.');
					$data['per_unit_powerbank_budget'] = number_format($event['per_unit_powerbank_budget'], 0, ',', '.');
					$data['powerbank_quantity'] = number_format($event['powerbank_quantity'], 0, ',', '.');
					$data['per_unit_jacket_budget'] = number_format($event['per_unit_jacket_budget'], 0, ',', '.');
					$data['jacket_quantity'] = number_format($event['jacket_quantity'], 0, ',', '.');
					$data['per_unit_placard_budget'] = number_format($event['per_unit_placard_budget'], 0, ',', '.');
					$data['placard_quantity'] = number_format($event['placard_quantity'], 0, ',', '.');
					$data['per_unit_souvenir_budget'] = number_format($event['per_unit_souvenir_budget'], 0, ',', '.');
					$data['souvenir_quantity'] = number_format($event['souvenir_quantity'], 0, ',', '.');
					$data['per_unit_name_tag_budget'] = number_format($event['per_unit_name_tag_budget'], 0, ',', '.');
					$data['name_tag_quantity'] = number_format($event['name_tag_quantity'], 0, ',', '.');
					$data['per_unit_goody_bag_budget'] = number_format($event['per_unit_goody_bag_budget'], 0, ',', '.');
					$data['goody_bag_quantity'] = number_format($event['goody_bag_quantity'], 0, ',', '.');
					$data['per_unit_ballpoint_budget'] = number_format($event['per_unit_ballpoint_budget'], 0, ',', '.');
					$data['ballpoint_quantity'] = number_format($event['ballpoint_quantity'], 0, ',', '.');
					$data['per_unit_blocknote_budget'] = number_format($event['per_unit_blocknote_budget'], 0, ',', '.');
					$data['blocknote_quantity'] = number_format($event['blocknote_quantity'], 0, ',', '.');
					$data['per_unit_flashdisk_budget'] = number_format($event['per_unit_flashdisk_budget'], 0, ',', '.');
					$data['flashdisk_quantity'] = number_format($event['flashdisk_quantity'], 0, ',', '.');
					$data['per_unit_cd_budget'] = number_format($event['per_unit_cd_budget'], 0, ',', '.');
					$data['cd_quantity'] = number_format($event['cd_quantity'], 0, ',', '.');
					$data['per_unit_documentation_budget'] = number_format($event['per_unit_documentation_budget'], 0, ',', '.');
					$data['documentation_quantity'] = number_format($event['documentation_quantity'], 0, ',', '.');
					$data['per_unit_banner_budget'] = number_format($event['per_unit_banner_budget'], 0, ',', '.');
					$data['banner_quantity'] = number_format($event['banner_quantity'], 0, ',', '.');
					$data['per_unit_value_added_tax'] = number_format($event['per_unit_value_added_tax'], 0, ',', '.');
					$data['value_added_tax_quantity'] = number_format($event['value_added_tax_quantity'], 0, ',', '.');
					$data['per_unit_agent_fee'] = number_format($event['per_unit_agent_fee'], 0, ',', '.');
					$data['agent_quantity'] = number_format($event['agent_quantity'], 0, ',', '.');
					$data['per_unit_driver_fee'] = number_format($event['per_unit_driver_fee'], 0, ',', '.');
					$data['driver_quantity'] = number_format($event['driver_quantity'], 0, ',', '.');
					$data['per_unit_cs_fee'] = number_format($event['per_unit_cs_fee'], 0, ',', '.');
					$data['cs_quantity'] = number_format($event['cs_quantity'], 0, ',', '.');
					$data['per_unit_rental_cost'] = number_format($event['per_unit_rental_cost'], 0, ',', '.');
					$data['rental_quantity'] = number_format($event['rental_quantity'], 0, ',', '.');
					$data['per_unit_meal_budget'] = number_format($event['per_unit_meal_budget'], 0, ',', '.');
					$data['meal_quantity'] = number_format($event['meal_quantity'], 0, ',', '.');
					$data['per_unit_city_tour_budget'] = number_format($event['per_unit_city_tour_budget'], 0, ',', '.');
					$data['city_tour_quantity'] = number_format($event['city_tour_quantity'], 0, ',', '.');
					$data['per_unit_operational_budget'] = number_format($event['per_unit_operational_budget'], 0, ',', '.');
					$data['operational_quantity'] = number_format($event['operational_quantity'], 0, ',', '.');
					$data['per_unit_team_accommodation_budget'] = number_format($event['per_unit_team_accommodation_budget'], 0, ',', '.');
					$data['team_accommodation_quantity'] = number_format($event['team_accommodation_quantity'], 0, ',', '.');
					$data['per_unit_team_transportation_budget'] = number_format($event['per_unit_team_transportation_budget'], 0, ',', '.');
					$data['team_transportation_quantity'] = number_format($event['team_transportation_quantity'], 0, ',', '.');
					$data['per_unit_income_tax'] = number_format($event['per_unit_income_tax'], 0, ',', '.');
					$data['income_tax_quantity'] = number_format($event['income_tax_quantity'], 0, ',', '.');
					$data['per_unit_delivery_budget'] = number_format($event['per_unit_delivery_budget'], 0, ',', '.');
					$data['delivery_quantity'] = number_format($event['delivery_quantity'], 0, ',', '.');
					$data['price'] = number_format($event['price'], 0, ',', '.');
					$data['notes'] = $event['notes'];
					$data['turnover'] = 100;
					$data['total_expense'] = 0;
					$data['profit_nominal'] = 100;
					$data['profit_percentage'] = 100;
					$data['approval_status'] = $event['approval_status'];
					$data['nearest_city'] = $event['nearest_city'];
				}
                    
				$data['title'] = ':: Sister JSO :: '.$header;
				
				$data['vendor_css_links'] = array(
					'bootstrap/css/bootstrap.min.css',
					'font-awesome/css/font-awesome.min.css',
					'animate-css/animate.min.css',
					'bootstrap-multiselect/bootstrap-multiselect.css',
					'bootstrap-datepicker/css/bootstrap-datepicker3.min.css',
					'bootstrap-colorpicker/css/bootstrap-colorpicker.css',
					'multi-select/css/multi-select.css',
					'bootstrap-tagsinput/bootstrap-tagsinput.css',
					'nouislider/nouislider.min.css',
					'toastr/toastr.min.css'
                );
				
				$data['header'] = $header;
				$data['event_types'] = $event_types;

				$users = $this->event_model->read_users_roles_contracts('INSTRUKTUR');

				foreach($users as &$user)
				{
					$instructors[$user['user_id']] = $user['name'];
				}
				
				$data['instructors'] = $instructors;

				if($event_id == 0)
					$data['instructor_user_id'] = $user['user_id'];
				
				$data['cities'] = $cities;

				$users_vendors = $this->vendor_model->read_users_vendors('user', 0, 'result_array', '', 0, 'Hotel');

				foreach($users_vendors as &$user_vendor)
				{
					$hotels[$user_vendor['vendor_id']] = $user_vendor['name'];
				}
				
				$data['hotels'] = $hotels;

				if($event_id == 0)
					$data['hotel_vendor_id'] = $user_vendor['vendor_id'];

				$users = $this->event_model->read_users_roles_contracts('CUSTOMER SERVICE');

				foreach($users as &$user)
				{
					$customer_services[$user['user_id']] = $user['name'];
				}
				
				$data['customer_services'] = $customer_services;

				if($event_id == 0)
					$data['cs_user_id'] = $user['user_id'];
				
				$users_vendors = $this->vendor_model->read_users_vendors('user', 0, 'result_array', '', 0, 'Transportasi');

				foreach($users_vendors as &$user_vendor)
				{
					$transportation_vendors[$user_vendor['vendor_id']] = $user_vendor['name'];
				}
				
				$data['transportation_vendors'] = $transportation_vendors;

				if($event_id == 0)
					$data['transportation_vendor_id'] = $user_vendor['vendor_id'];

				$users = $this->event_model->read_users_roles_contracts('DRIVER');

				foreach($users as &$user)
				{
					$drivers[$user['user_id']] = $user['name'];
				}
				
				$data['drivers'] = $drivers;

				if($event_id == 0)
					$data['driver_user_id'] = $user['user_id'];

				$users = $this->event_model->read_users_roles_contracts('LOGISTIK');

				foreach($users as &$user)
				{
					$logistics[$user['user_id']] = $user['name'];
				}
				
				$data['logistics'] = $logistics;

				if($event_id == 0)
				{
					$data['logistic_user_id'] = $user['user_id'];

					$user_id = $this->session->userdata('user_id');
				}
				else
					$user_id = 1;
				
				$user = $this->event_model->read_users_roles_contracts('', $user_id);

				$data['marketing'] = array(
					$user['user_id'] => $user['name']
				);

				$unit = $this->unit_model->read_units('name', 'row_array', '', 0, $user['unit_id']);

				$data['units'] = array(
					$user['unit_id'] => $unit['name']
				);

				$data['unit_id'] = $user['unit_id'];
				$data['categories'] = $categories;
				$data['event_status'] = $event_status;

				$users = $this->event_model->read_users_roles_contracts('MARKETING', 0, $user['unit_id']);

				foreach($users as &$user)
				{
					$managers[$user['user_id']] = $user['name'];
				}
				
				$data['managers'] = $managers;

				if($event_id == 0)
					$data['manager_user_id'] = $user['user_id'];

				$clients_list = $this->event_model->read_clients();

				foreach($clients_list as &$client)
				{
					$clients[$client['client_id']] = $client['name'].'('.$client['email_address'].')';
				}
				
				$data['clients'] = $clients;

				if($event_id == 0)
					$data['client_id'] = $client['client_id'];
				
				$data['client_sources'] = $client_sources;
				$data['set_source_detail_link'] = base_url('kegiatan/detail_sumber/');

				if($data['source'] == 'Website')
				{
					$data['websites'] = array(
						1 => 'https://jso-smb.co.id'
					);

                    $data['source_detail'] = 1;
				}
				else
					$data['source_detail'] = '';
                
				$data['document_delivery_methods'] = $document_delivery_methods;
				$data['nearest_cities'] = $nearest_cities;
				
				$data['approval_statuses'] = array(
					'Menunggu persetujuan' => 'Menunggu persetujuan',
					'Disetujui' => 'Disetujui'
				);
				
				$data['js_links'] = array(
					'assets/bundles/libscripts.bundle.js',
					'assets/bundles/vendorscripts.bundle.js',
					'vendor/bootstrap-colorpicker/js/bootstrap-colorpicker.js',
					'vendor/jquery-inputmask/jquery.inputmask.bundle.js',
					'vendor/jquery-mask/jquery.mask.min.js',
					'vendor/multi-select/js/jquery.multi-select.js',
					'vendor/bootstrap-multiselect/bootstrap-multiselect.js',
					'vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js',
					'vendor/bootstrap-tagsinput/bootstrap-tagsinput.js',
					'vendor/nouislider/nouislider.js',
					'vendor/toastr/toastr.js',
					'assets/bundles/mainscripts.bundle.js',
					'assets/js/pages/forms/advanced-form-elements.js',
					'assets/js/pages/event/create_update.js'
				);

				// Render view on main layout
				$this->load->view('templates/dashboard/top', $data);
				$this->load->view('pages/events/create_update/static_content', $data);
				$this->load->view('templates/dashboard/bottom', $data);
			}
	    }
		
	    public function detail_sumber($source)
	    {
			$this->load->helper('form');

			$data['source'] = $source;

			if($source == 'Website')
			{
				$data['label_text'] = 'Alamat Website';
				
				$data['websites'] = array(
					1 => 'https://jso-smb.co.id'
				);
				
				$data['selected'] = 1;
			}
			else
				$data['label_text'] = 'Nama Referal';
			
			echo $this->load->view('pages/events/create_update/source_detail', $data, TRUE);
		}

		public function daftar($status = 'all', $view = 'general')
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->helper('form');

			$logged_in_user = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'MARKETING' && $data['logged_in_user']['division'] != 'FINANCE' && $data['logged_in_user']['division'] != 'LOGISTIK')
				redirect();
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);

			if($status == 'all')
				$data['title'] = ':: Sister JSO :: Data Progress Harian';
			else
			{
				if($view == 'general')
				{
					if($logged_in_user['division'] == 'LOGISTIK')
						$data['title'] = ':: Sister JSO :: Data Sertifikat Kegiatan';
					else
						$data['title'] = ':: Sister JSO :: Data Kegiatan Fix Per CV';
				}
				else if($view == 'gcn')
					$data['title'] = ':: Sister JSO :: GCN';
			}

			$data['logged_in_user'] = $logged_in_user;
			$data['status'] = $status;
			$data['view'] = $view;
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'assets/js/pages/event/list.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/events/list/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		public function data($page_number, $status, $view, $division, $query = '', $office_location = 'Semua Gudang')
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('event_model');
			$this->load->helper('form');

			if($status == 'Fixed')
			{
				$this->load->model('unit_model');

				$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
				
				$units[0] = 'Semua Unit';

				foreach($unit_list as &$unit)
				{
					$units[$unit['unit_id']] = $unit['name'];
				}

				$data['units'] = $units;

				$data['office_locations'] = array();

				if(urldecode($division) != 'LOGISTIK')
					$data['office_locations']['Semua Gudang'] = 'Semua Gudang';

				if(urldecode($division) != 'LOGISTIK' || (urldecode($division) == 'LOGISTIK' && urldecode($office_location) == 'Yogyakarta & sekitarnya'))
					$data['office_locations']['Yogyakarta & sekitarnya'] = 'Yogyakarta';
				
				if(urldecode($division) != 'LOGISTIK' || (urldecode($division) == 'LOGISTIK' && urldecode($office_location) == 'Jakarta & sekitarnya'))
					$data['office_locations']['Jakarta & sekitarnya'] = 'Jakarta';
			}

			$data['query'] = urldecode($query);

			if($view == 'gcn')
				$approval_status = 'Menunggu persetujuan';
			else
				$approval_status = '';
            
            
			echo $approval_status;
			$data['events_users_vendors_clients'] = $this->event_model->read_events_vendors_clients('*, events.name as event_name, clients.name as client_name, units.name as unit_name', 'client,unit', $page_number, 'result_array', $status, urldecode($query), 0, 0, $approval_status, urldecode($office_location));
			$data['page_number'] = $page_number;
            $data['status'] = $status;
            $data['view'] = $view;
            $data['division'] = urldecode($division);
            $data['office_location'] = urldecode($office_location);
            
			$page_count = ceil($this->event_model->read_events_vendors_clients('*', '', 0, 'num_rows', $status, urldecode($query), 0, 0, $approval_status, urldecode($office_location)) / 5);

			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				if($page_count > 10)
				{
					if($page_number > 6)
					{
						if(($page_count - $page_number) >= 4)
							$next_page_count = 4;
						else
							$next_page_count = $page_count - $page_number;
						
						$previous_page_count = 9 - $next_page_count;
					}
					else
					{
						$previous_page_count = $page_number - 1;
						$next_page_count = 9 - $previous_page_count;
					}
				}
				else
				{
					$previous_page_count = $page_number - 1;
					$next_page_count = $page_count - $page_number;
				}

				$data['previous_page_count'] = $previous_page_count;
				$data['next_page_count'] = $next_page_count;
			}

			echo $this->load->view('pages/events/list/dynamic_content', $data, TRUE);
		}
        
        public function tambah_ubah_data_pembayaran($event_payment_id = 0)
	    {
	    	if($this->input->post('submit') != NULL)
			{
				$this->load->model('event_model');
				
				$input_names = array(
                    'proof_of_payment'
                );

                $skip = 0;
                $uri = 'kegiatan/tambah_ubah_data_pembayaran/';
                
				if($event_payment_id < 1)
                {
                    $this->load->library('upload');
                    
                    $anyfile = 1;

                    $folder_name = $this->input->post('event_id');
                    
                    mkdir('uploads/events/payments/'.$folder_name);
                }
                else
                {
                    $anyfile = 0;
                    
                    foreach($input_names as &$input_name)
                    {
                        if($_FILES[$input_name]['size'] > 0)
                        {
                            $this->load->library('upload');

                            $anyfile++;

                            break;
                        }
                        else
                            $skip++;
                    }

                    $folder_name = $this->input->post('event_id');
                    $uri = $uri.$event_payment_id;
                }
                
                if($anyfile > 0)
                {
                    foreach($input_names as &$input_name)
                    {
                        if($skip > 0)
                        {
                            $skip--;

                            $file_names[$input_name] = '';
                        }
                        else
                        {
                            if($_FILES[$input_name]['size'] > 0)
                            {
                                $config['upload_path']      = './uploads/events/payments/'.$folder_name;
                                $config['allowed_types']    = '*';

                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload($input_name))
                                {
                                    $this->session->set_flashdata('error_messages', $this->upload->display_errors());
                                    
                                    redirect($uri);
                                }
                                else
									$file_names[$input_name] = $this->upload->data('file_name');
                            }
                            else
                                $file_names[$input_name] = '';
                        }
                    }
                }
                else
                {
                    foreach($input_names as &$input_name)
                    {
                        $file_names[$input_name] = '';
                    }
                }

                $this->event_model->create_update_event_payment($file_names, $event_payment_id);
				
				$this->session->set_flashdata('operation_result', 'event payment saved');

				if($event_payment_id == '')
					redirect('kegiatan/tambah_ubah_data_pembayaran');
				else
					redirect('kegiatan/tambah_ubah_data_pembayaran/'.$event_payment_id);
			}
			else
			{
				/*if($user_role['user_status'] != 'Calon karyawan' && !$this->session->has_userdata('user_id'))
                {	
                    $this->session->set_userdata('previous_url', current_url());

                    redirect('otentikasi/masuk');
                }

                $logged_in_user_role = $this->employee_model->read_users_roles($this->session->userdata('user_id'));

				if(($user_id == 0) && ($this->session->userdata('role_id') != 1))
					redirect('karyawan/tambah_ubah/'.$this->session->userdata('user_id'));

				if ( ($logged_in_user_role['user_id'] != $user_id) && ($this->session->userdata('role_id') != 1) )
					redirect('karyawan/tambah_ubah/'.$this->session->userdata('user_id'));
				*/
				$this->load->model('employee_model');
				$this->load->model('event_model');
				$this->load->helper('form');

				if($event_payment_id == 0)
					$header = 'Tambah Data Pembayaran Kegiatan';
				else
				{
					$header = 'Ubah Data Pembayaran Kegiatan';
					
					$data['event_payment'] = $this->event_model->read_event_payments('*', $event_payment_id, '', 0, '', 0, 'row_array');
				}
                    
				$data['title'] = ':: Sister JSO :: '.$header;
				
				$data['vendor_css_links'] = array(
					'bootstrap/css/bootstrap.min.css',
					'font-awesome/css/font-awesome.min.css',
					'animate-css/animate.min.css',
					'bootstrap-multiselect/bootstrap-multiselect.css',
					//'bootstrap-datepicker/css/bootstrap-datepicker3.min.css',
					'toastr/toastr.min.css',
                    'dropify/css/dropify.min.css'
                );
                
				$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');
				$data['header'] = $header;
				
				$event_payments = $this->event_model->read_event_payments('event_payments.event_id as event_id', 0, 'Pelunasan');

				$event_ids = array();
				
				foreach($event_payments as &$event_payment)
				{
					$event_ids[] = $event_payment['event_id'];
				}
            
				$events_units_users = $this->event_model->read_events_units_users($event_ids);
	
				foreach($events_units_users as $event_unit_user)
				{
					$data['events'][$event_unit_user['event_id']] = $event_unit_user['event_name'].' ('.substr($event_unit_user['start_date'], -2).'/'.substr($event_unit_user['start_date'], 5, 2).'/'.substr($event_unit_user['start_date'], 0, 4).' - '.substr($event_unit_user['end_date'], -2).'/'.substr($event_unit_user['end_date'], 5, 2).'/'.substr($event_unit_user['end_date'], 0, 4).') '.$event_unit_user['unit_name'].' by '.$event_unit_user['marketing_name'];
				}
				
				//$data['reference_number_check_link'] = base_url('kontrak/cek_nomor_surat?nomor_surat=');

				$data['js_links'] = array(
					'assets/bundles/libscripts.bundle.js',
					'assets/bundles/vendorscripts.bundle.js',
					'vendor/bootstrap-colorpicker/js/bootstrap-colorpicker.js',
					'vendor/jquery-mask/jquery.mask.min.js',
					'vendor/jquery-inputmask/jquery.inputmask.bundle.js',
					//'vendor/jquery.maskedinput/jquery.maskedinput.min.js',
					'vendor/multi-select/js/jquery.multi-select.js',
					'vendor/bootstrap-multiselect/bootstrap-multiselect.js',
					'vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js',
					'vendor/nouislider/nouislider.js',
					'vendor/toastr/toastr.js',
                    'vendor/dropify/js/dropify.min.js',
					'assets/bundles/mainscripts.bundle.js',
					'assets/js/pages/forms/advanced-form-elements.js',
                    'assets/js/pages/forms/dropify.js',
					'assets/js/pages/event/payment/create_update.js'
				);

				// Render view on main layout
				$this->load->view('templates/dashboard/top', $data);
				$this->load->view('pages/events/payments/create_update/static_content', $data);
				$this->load->view('templates/dashboard/bottom', $data);
			}
	    }

		public function daftar_agregat_pembayaran()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->helper('form');

			$data['title'] = ':: Sister JSO :: Data Pembayaran Kegiatan';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'assets/js/pages/event/payment/list.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/events/payments/list/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		public function agregat_pembayaran($page_number)
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('unit_model');
			$this->load->model('event_model');
			$this->load->helper('form');

			$data['filter_columns'] = array(
				'payment_date,like' => 'Bulan & tahun pembayaran',
				'events.unit_id,where' => 'Unit',
				'payment_status,where' => 'Status Pembayaran'
			);

			$data['filter_column'] = urldecode($this->input->get('filter_column'));

			if($data['filter_column'] == 'payment_date,like')
			{
				$data['label'] = 'Bulan & Tahun';
				
				$data['filter_values'] = array();
			}
			else if($data['filter_column'] == 'events.unit_id,where')
			{
				$data['label'] = 'Nama Unit';

				$data['filter_values'] = array(
					'' => 'Semua Unit'
				);

				$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
				
				foreach($unit_list as &$unit)
				{
					$data['filter_values'][$unit['unit_id']] = $unit['name'];
				}
			}
			else
			{
				$data['label'] = 'Status Pembayaran';

				$data['filter_values'] = array(
					'' => 'Semua Status',
					1 => 'Baru DP',
					2 => 'Cicilan',
					3 => 'Sudah Lunas'
				);
			}

			$data['filter_value'] = urldecode($this->input->get('filter_value'));
			//$data['ordering_column'] = urldecode($this->input->get('ordering_column'));

			$event_payments = $this->event_model->read_event_payments('LEFT(MAX(payment_date), 7) as payment_month, MAX(payment_date) as payment_date, events.name as event_name, start_date, end_date, units.name as unit_name, users.name as marketing_name, SUM(nominal) as nominal, MAX(payment_status) as payment_status, event_payments.event_id as event_id', 0, '', 0, 'event_payments.event_id', $page_number);

			if($this->input->get('filter_value') != NULL && $this->input->get('filter_value') != '')
			{
				$filter_parameter = explode(',', urldecode($this->input->get('filter_column')));

				if($filter_parameter[0] == 'events.unit_id')
					$data['event_payments'] = $event_payments;
				else
				{
					$value = urldecode($this->input->get('filter_value'));
					
					$filtered_event_payments = array();

					foreach($event_payments as &$event_payment)
					{
						if($filter_parameter[1] == 'like')
						{
							if($event_payment['payment_month'] == $value)
								$filtered_event_payments[] = $event_payment;
						}
						else
						{
							if($event_payment['payment_status'] == $value)
								$filtered_event_payments[] = $event_payment;
						}
					}

					$data['event_payments'] = $filtered_event_payments;
				}
			}
			else
				$data['event_payments'] = $event_payments;

			$data['page_number'] = $page_number;
            
			$page_count = ceil($this->event_model->read_event_payments('*', 0, '', 0, 'event_payments.event_id', 0, 'num_rows') / 5);

			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				if($page_count > 10)
				{
					if($page_number > 6)
					{
						if(($page_count - $page_number) >= 4)
							$next_page_count = 4;
						else
							$next_page_count = $page_count - $page_number;
						
						$previous_page_count = 9 - $next_page_count;
					}
					else
					{
						$previous_page_count = $page_number - 1;
						$next_page_count = 9 - $previous_page_count;
					}
				}
				else
				{
					$previous_page_count = $page_number - 1;
					$next_page_count = $page_count - $page_number;
				}

				$data['previous_page_count'] = $previous_page_count;
				$data['next_page_count'] = $next_page_count;
			}

			echo $this->load->view('pages/events/payments/list/dynamic_content', $data, TRUE);
		}
	    
		public function opsi_nilai_filter_pembayaran()
		{
			$filter_column = urldecode($this->input->get('filter_column'));
			
			$options = '';
			
			if($filter_column == 'events.unit_id,where')
			{
				$this->load->model('unit_model');

				$options = $options.'<option value="">Semua Unit</option>';

				$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
				
				foreach($unit_list as &$unit)
				{
					$options = $options.'<option value="'.$unit['unit_id'].'">'.$unit['name'].'</option>';
				}
			}
			else
			{
				$options = $options.'<option value="">Semua Status</option>';
				
				$filter_values = array(
					1 => 'Baru DP',
					2 => 'Cicilan',
					3 => 'Sudah Lunas'
				);
				
				foreach($filter_values as $key => $value)
				{
					$options = $options.'<option value="'.$key.'">'.$value.'</option>';
				}
			}

			echo $options;
        }

		public function daftar_pembayaran($event_id)
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->model('event_model');
			$this->load->helper('form');

			$data['title'] = ':: Sister JSO :: Detail Pembayaran Kegiatan';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');
			$data['event_payments'] = $this->event_model->read_event_payments('*', 0, '', $event_id);
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'assets/js/pages/event/payment/list.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/events/payments/list/details', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }
        
        public function sertifikat($event_id)
	    {
			$this->load->model('event_model');
			
			if($this->input->post('submit') != NULL)
			{
				$this->event_model->update_certificates($event_id);

                $this->session->set_flashdata('operation_result', 'certificates data saved');
                
				redirect('kegiatan/sertifikat/'.$event_id);
			}
			else
			{
				$this->load->model('employee_model');
				$this->load->helper('form');

                $data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

				if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'MARKETING' && $data['logged_in_user']['division'] != 'LOGISTIK')
					redirect();

				$header = 'Data Sertifikat';

				$event = $this->event_model->read_events_vendors_clients('*', '', 0, 'row_array', '', '', $event_id);
				
				$data['number_of_instructors'] = $event['number_of_instructors'];
				$data['clients_number'] = $event['clients_number'];

				$data['certificates'] = $this->event_model->read_certificates($event_id);
                    
				$data['title'] = ':: Sister JSO :: '.$header;
				
				$data['vendor_css_links'] = array(
					'bootstrap/css/bootstrap.min.css',
					'font-awesome/css/font-awesome.min.css',
					'animate-css/animate.min.css',
					'bootstrap-multiselect/bootstrap-multiselect.css',
					'bootstrap-datepicker/css/bootstrap-datepicker3.min.css',
					'bootstrap-colorpicker/css/bootstrap-colorpicker.css',
					'multi-select/css/multi-select.css',
					'bootstrap-tagsinput/bootstrap-tagsinput.css',
					'nouislider/nouislider.min.css',
					'toastr/toastr.min.css'
                );
				
				$data['header'] = $header;
				
				$data['js_links'] = array(
					'assets/bundles/libscripts.bundle.js',
					'assets/bundles/vendorscripts.bundle.js',
					'vendor/jquery/jquery-3.3.1.min.js',
					'vendor/bootstrap-colorpicker/js/bootstrap-colorpicker.js',
					'vendor/jquery-inputmask/jquery.inputmask.bundle.js',
					'vendor/jquery-mask/jquery.mask.min.js',
					'vendor/multi-select/js/jquery.multi-select.js',
					'vendor/bootstrap-multiselect/bootstrap-multiselect.js',
					'vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js',
					'vendor/bootstrap-tagsinput/bootstrap-tagsinput.js',
					'vendor/nouislider/nouislider.js',
					'vendor/toastr/toastr.js',
					'assets/bundles/mainscripts.bundle.js',
					'assets/js/pages/forms/advanced-form-elements.js',
					'assets/js/pages/event/create_update.js'
				);

				// Render view on main layout
				$this->load->view('templates/dashboard/top', $data);
				$this->load->view('pages/certificates/update', $data);
				$this->load->view('templates/dashboard/bottom', $data);
			}
		}
		
		public function keuangan()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->helper('form');

			$data['title'] = ':: Sister JSO :: Data Keuangan Kegiatan';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			if($this->input->get('marketing_user_id') != NULL && $this->input->get('marketing_user_id') != '')
				$data['marketing_user_id'] = $this->input->get('marketing_user_id');
			else if($this->input->get('manager_user_id') != NULL && $this->input->get('manager_user_id') != '')
				$data['manager_user_id'] = $this->input->get('manager_user_id');
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'assets/js/pages/event/finance/list.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/events/finance/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		public function data_keuangan_kegiatan($page_number)
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('unit_model');
			$this->load->model('event_model');
			$this->load->helper('form');

			$data['units'] = array(
				'' => 'Semua Unit'
			);

			$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
			
			foreach($unit_list as &$unit)
			{
				$data['units'][$unit['unit_id']] = $unit['name'];
			}

			$data['staffs'] = array(
				'' => 'Semua Staf Marketing'
			);

			$staff_list = $this->event_model->read_users_contracts();
			
			foreach($staff_list as &$staff)
			{
				$data['staffs'][$staff['user_id']] = $staff['name'];
			}

			$data['managers'] = array(
				'' => 'Semua Manajer Marketing'
			);

			$manager_list = $this->event_model->read_users_contracts('Manajer');
			
			foreach($manager_list as &$manager)
			{
				$data['managers'][$manager['user_id']] = $manager['name'];
			}

			$data['unit_id'] = $this->input->get('unit_id');
			$data['marketing_user_id'] = $this->input->get('marketing_user_id');
			$data['manager_user_id'] = $this->input->get('manager_user_id');
			$data['start_date'] = urldecode($this->input->get('start_date'));
			$data['ordering'] = $this->input->get('ordering');

			$data['events'] = $this->event_model->read_events_financial_data($page_number);
			
			$data['page_number'] = $page_number;
            
			$page_count = ceil($this->event_model->read_events_financial_data(0, 'num_rows') / 5);

			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				if($page_count > 10)
				{
					if($page_number > 6)
					{
						if(($page_count - $page_number) >= 4)
							$next_page_count = 4;
						else
							$next_page_count = $page_count - $page_number;
						
						$previous_page_count = 9 - $next_page_count;
					}
					else
					{
						$previous_page_count = $page_number - 1;
						$next_page_count = 9 - $previous_page_count;
					}
				}
				else
				{
					$previous_page_count = $page_number - 1;
					$next_page_count = $page_count - $page_number;
				}

				$data['previous_page_count'] = $previous_page_count;
				$data['next_page_count'] = $next_page_count;
			}

			echo $this->load->view('pages/events/finance/dynamic_content', $data, TRUE);
		}
	    
		public function staf_marketing()
		{
			$this->load->model('event_model');

			$options = '';

			$options = $options.'<option value="">Semua Staf Marketing</option>';

			$staff_list = $this->event_model->read_users_contracts();
			
			foreach($staff_list as &$staff)
			{
				$options = $options.'<option value="'.$staff['user_id'].'">'.$staff['name'].'</option>';
			}

			echo $options;
		}
	    
		public function manajer_marketing()
		{
			$this->load->model('event_model');

			$options = '';

			$options = $options.'<option value="">Semua Manajer Marketing</option>';

			$manager_list = $this->event_model->read_users_contracts('Manajer');
			
			foreach($manager_list as &$manager)
			{
				$options = $options.'<option value="'.$manager['user_id'].'">'.$manager['name'].'</option>';
			}

			echo $options;
        }

		public function remunerasi($event_id)
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->model('event_model');
			$this->load->helper('form');

			$data['title'] = ':: Sister JSO :: Remunerasi';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');
			
			$data['remuneration'] = $this->event_model->read_remuneration($event_id);
			$data['revenue'] = $this->input->get('revenue');
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				//'assets/js/pages/event/payment/list.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/events/finance/remuneration', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		/*public function ekspor()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('event_model');

			$spreadsheet = new Spreadsheet();
			
			$sheet = $spreadsheet->getActiveSheet();

			$sheet->setCellValue('A1', 'Nomor');
			$sheet->setCellValue('B1', 'Tanggal');
			$sheet->setCellValue('C1', 'Event');
			$sheet->setCellValue('D1', 'Kategori');
			$sheet->setCellValue('E1', 'Jenis');
			$sheet->setCellValue('F1', 'Status');
			$sheet->setCellValue('G1', 'Tayang');
			$sheet->setCellValue('H1', 'Tanggal Mulai Pelatihan');
			$sheet->setCellValue('I1', 'Tanggal Berakhir Pelatihan');
			$sheet->setCellValue('J1', 'Jam Mulai');
			$sheet->setCellValue('K1', 'Jam Selesai');
			$sheet->setCellValue('L1', 'Instruktur');
			$sheet->setCellValue('M1', 'Kota');
			$sheet->setCellValue('N1', 'Hotel');
			$sheet->setCellValue('O1', 'Penyelenggara');
			$sheet->setCellValue('P1', 'Marketing');
			$sheet->setCellValue('Q1', 'CS');
			$sheet->setCellValue('R1', 'Driver');
			$sheet->setCellValue('S1', 'Logistik');
			$sheet->setCellValue('T1', 'Sumber');
			$sheet->setCellValue('U1', 'Harga');
			$sheet->setCellValue('V1', 'Jumlah');
			$sheet->setCellValue('W1', 'Total');
			$sheet->setCellValue('X1', 'Peserta');
			$sheet->setCellValue('Y1', 'Email');
			$sheet->setCellValue('Z1', 'Perusahaan');
			$sheet->setCellValue('AA1', 'Posisi');
			$sheet->setCellValue('AB1', 'HP');
			$sheet->setCellValue('AC1', 'Telp Kantor');
			$sheet->setCellValue('AD1', 'Keterangan');			

			$events_users_vendors_clients = $this->event_model->read_events_vendors_clients('*, events.name as event_name, clients.name as client_name', 'client');
			
			$number = 1;

			foreach($events_users_vendors_clients as &$event_user_vendor_client)
			{
				$sheet->setCellValue('A'.($number + 1), $number);
				$sheet->setCellValue('B'.($number + 1), substr($event_user_vendor_client['proposal_date'], -2).'-'.substr($event_user_vendor_client['proposal_date'], 5, 2).'-'.substr($event_user_vendor_client['proposal_date'], 0, 4));
				$sheet->setCellValue('C'.($number + 1), $event_user_vendor_client['event_name']);
				$sheet->setCellValue('D'.($number + 1), $event_user_vendor_client['category']);
				$sheet->setCellValue('E'.($number + 1), $event_user_vendor_client['type']);
				$sheet->setCellValue('F'.($number + 1), $event_user_vendor_client['status']);

				if($event_user_vendor_client['status'] == 'Fixed')
					$aired = 'V';
				else
					$aired = '';
				
				$sheet->setCellValue('G'.($number + 1), $aired);
				$sheet->setCellValue('H'.($number + 1), substr($event_user_vendor_client['start_date'], -2).'-'.substr($event_user_vendor_client['start_date'], 5, 2).'-'.substr($event_user_vendor_client['start_date'], 0, 4));
				$sheet->setCellValue('I'.($number + 1), substr($event_user_vendor_client['end_date'], -2).'-'.substr($event_user_vendor_client['end_date'], 5, 2).'-'.substr($event_user_vendor_client['end_date'], 0, 4));
				$sheet->setCellValue('J'.($number + 1), $event_user_vendor_client['starting_hour']);
				$sheet->setCellValue('K'.($number + 1), $event_user_vendor_client['completion_hour']);
				$sheet->setCellValue('L'.($number + 1), $event_user_vendor_client['instructor_name']);
				$sheet->setCellValue('M'.($number + 1), $event_user_vendor_client['city']);
				$sheet->setCellValue('N'.($number + 1), $event_user_vendor_client['hotel_vendor_id']);
				$sheet->setCellValue('O'.($number + 1), 'PT JSO SMB');
				$sheet->setCellValue('P'.($number + 1), $event_user_vendor_client['marketing_name']);
				$sheet->setCellValue('Q'.($number + 1), $event_user_vendor_client['cs_name']);
				$sheet->setCellValue('R'.($number + 1), $event_user_vendor_client['driver_name']);
				$sheet->setCellValue('S'.($number + 1), $event_user_vendor_client['logistic_name']);
				$sheet->setCellValue('T'.($number + 1), $event_user_vendor_client['source']);
				$sheet->setCellValue('U'.($number + 1), $event_user_vendor_client['price']);
				$sheet->setCellValue('V'.($number + 1), $event_user_vendor_client['clients_number']);
				$sheet->setCellValue('W'.($number + 1), ($event_user_vendor_client['price'] * $event_user_vendor_client['clients_number']));
				$sheet->setCellValue('X'.($number + 1), $event_user_vendor_client['client_name']);
				$sheet->setCellValue('Y'.($number + 1), $event_user_vendor_client['email_address']);
				$sheet->setCellValue('Z'.($number + 1), $event_user_vendor_client['company']);
				$sheet->setCellValue('AA'.($number + 1), $event_user_vendor_client['position']);
				$sheet->setCellValueExplicit('AB'.($number + 1), $event_user_vendor_client['mobile_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
				$sheet->setCellValueExplicit('AC'.($number + 1), $event_user_vendor_client['phone_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
				$sheet->setCellValue('AD'.($number + 1), $event_user_vendor_client['notes']);				

				$number++;
			}

			$sheet->getColumnDimension('A')->setAutoSize(true);
			$sheet->getColumnDimension('B')->setAutoSize(true);
			$sheet->getColumnDimension('C')->setAutoSize(true);
			$sheet->getColumnDimension('D')->setAutoSize(true);
			$sheet->getColumnDimension('E')->setAutoSize(true);
			$sheet->getColumnDimension('F')->setAutoSize(true);
			$sheet->getColumnDimension('G')->setAutoSize(true);
			$sheet->getColumnDimension('H')->setAutoSize(true);
			$sheet->getColumnDimension('I')->setAutoSize(true);
			$sheet->getColumnDimension('J')->setAutoSize(true);
			$sheet->getColumnDimension('K')->setAutoSize(true);
			$sheet->getColumnDimension('L')->setAutoSize(true);
			$sheet->getColumnDimension('M')->setAutoSize(true);
			$sheet->getColumnDimension('N')->setAutoSize(true);
			$sheet->getColumnDimension('O')->setAutoSize(true);
			$sheet->getColumnDimension('P')->setAutoSize(true);
			$sheet->getColumnDimension('Q')->setAutoSize(true);
			$sheet->getColumnDimension('R')->setAutoSize(true);
			$sheet->getColumnDimension('S')->setAutoSize(true);
			$sheet->getColumnDimension('T')->setAutoSize(true);
			$sheet->getColumnDimension('U')->setAutoSize(true);
			$sheet->getColumnDimension('V')->setAutoSize(true);
			$sheet->getColumnDimension('W')->setAutoSize(true);
			$sheet->getColumnDimension('X')->setAutoSize(true);
			$sheet->getColumnDimension('Y')->setAutoSize(true);
			$sheet->getColumnDimension('Z')->setAutoSize(true);
			$sheet->getColumnDimension('AA')->setAutoSize(true);
			$sheet->getColumnDimension('AB')->setAutoSize(true);
			$sheet->getColumnDimension('AC')->setAutoSize(true);
			$sheet->getColumnDimension('AD')->setAutoSize(true);
			
			$writer = new Xlsx($spreadsheet);
	
			$filename = 'Data Progress Harian '.date("d-m-Y H.i").' WIB';
	
			header('Content-Type: application/vnd.ms-excel');
			header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
			header('Cache-Control: max-age=0');
			
			$writer->save('php://output'); // download file
	    }*/
	}
?>