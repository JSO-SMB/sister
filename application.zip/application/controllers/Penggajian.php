<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	use PhpOffice\PhpSpreadsheet\Spreadsheet;
	use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
	
	class Penggajian extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->model('payroll_model');
        }
        
        public function tambah_ubah_data($payroll_data_id = 0)
	    {
	    	if($this->input->post('submit') != NULL)
			{
				$this->load->model('payroll_model');
				
				$this->payroll_model->update_payroll($payroll_data_id);
				
				$this->session->set_flashdata('operation_result', 'payroll updated');

				if($payroll_data_id == '')
					redirect('penggajian/tambah_ubah_data');
				else
					redirect('penggajian/tambah_ubah_data/'.$payroll_data_id);
			}
			else
			{
				$this->load->model('payroll_model');
				$this->load->model('unit_model');
				$this->load->helper('form');

                $data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

				require 'Options.php';

				if($payroll_data_id == 0)
				{
					if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'HRD')
						redirect();

					$header = 'Tambah Data Payroll';
				}
				else
				{
					if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'HRD' && $data['logged_in_user']['division'] != 'FINANCE')
						redirect();

					$header = 'Ubah Data Payroll';
					
					$data['payroll_data'] = $this->payroll_model->read_payroll('*', $payroll_data_id, '', 0, 0, 0, 'row_array');
				}
                    
				$data['title'] = ':: Sister JSO :: '.$header;
				
				$data['vendor_css_links'] = array(
					'bootstrap/css/bootstrap.min.css',
					'font-awesome/css/font-awesome.min.css',
					'animate-css/animate.min.css',
					'bootstrap-multiselect/bootstrap-multiselect.css',
					//'bootstrap-datepicker/css/bootstrap-datepicker3.min.css',
					'toastr/toastr.min.css',
                    //'dropify/css/dropify.min.css'
                );
				$data['header'] = $header;
				
				$users_contracts = $this->payroll_model->read_users_contracts('contract_id, name, reference_number');
				
				foreach($users_contracts as &$user_contract)
				{
					$data['contracts'][$user_contract['contract_id']] = $user_contract['name'].'('.$user_contract['reference_number'].')';
				}
				
				//$data['reference_number_check_link'] = base_url('kontrak/cek_nomor_surat?nomor_surat=');*/

				$data['js_links'] = array(
					'assets/bundles/libscripts.bundle.js',
					'assets/bundles/vendorscripts.bundle.js',
					'vendor/bootstrap-colorpicker/js/bootstrap-colorpicker.js',
					'vendor/jquery-mask/jquery.mask.min.js',
					'vendor/jquery-inputmask/jquery.inputmask.bundle.js',
					//'vendor/jquery.maskedinput/jquery.maskedinput.min.js',
					'vendor/multi-select/js/jquery.multi-select.js',
					'vendor/bootstrap-multiselect/bootstrap-multiselect.js',
					'vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js',
					'vendor/nouislider/nouislider.js',
					'vendor/toastr/toastr.js',
                    //'vendor/dropify/js/dropify.min.js',
					'assets/bundles/mainscripts.bundle.js',
					'assets/js/pages/forms/advanced-form-elements.js',
                    //'assets/js/pages/forms/dropify.js',
					'assets/js/pages/payroll/create_update.js'
				);

				// Render view on main layout
				$this->load->view('templates/dashboard/top', $data);
				$this->load->view('pages/payroll/create_update/static_content', $data);
				$this->load->view('templates/dashboard/bottom', $data);
			}
	    }

		public function hapus()
		{
			$this->load->library('authorization');
			
			$this->authorization->is_logged_in();
			
			if($this->input->post('submission') != NULL)
			{
				$this->load->model('general_model');

                $columns = array();
				
				$this->general_model->create_update('payroll_data_id', 'payroll', $columns);
                
				$this->session->set_flashdata('operation_result', 'data deleted');
				
                redirect('penggajian');
			}
		}

		public function index()
	    {
			$this->load->library('authorization');
			
			$this->authorization->is_logged_in();

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'HRD' && $data['logged_in_user']['division'] != 'FINANCE')
				redirect();

			require 'Options.php';
			
			$this->load->model('general_model');
			$this->load->helper('form');
			
			$data['header'] = 'Payroll';
			
			$data['title'] = ':: Sister JSO :: '.$data['header'];

			$data['breadcrumbs'] = 2;

			$data['breadcrumb']['item'][1] = 'Karyawan';

			$data['table']['order']['input']['options'] = array(
				''						=> '',
				'payday,ASC'			=> 'Tanggal Payroll(ASC)',
				'payday,DESC'			=> 'Tanggal Payroll(DESC)',
				'users.name,ASC'		=> 'Nama(A-Z)',
				'users.name,DESC'		=> 'Nama(Z-A)',
				'position,ASC'			=> 'Jabatan(A-Z)',
				'position,DESC'			=> 'Jabatan(Z-A)',
				// 'division,ASC'			=> 'Divisi(A-Z)',
				// 'division,DESC'			=> 'Divisi(Z-A)',
				'units.name,ASC'		=> 'Unit Kerja(A-Z)',
				'units.name,DESC'		=> 'Unit Kerja(Z-A)',
				'reference_number,ASC'	=> 'Kontrak Kerja(A-Z)',
				'reference_number,DESC'	=> 'Kontrak Kerja(Z-A)'
			);

			$data['columns'] = 7;

			$data['table']['header'][1] = '#';
			$data['table']['header'][2] = 'TANGGAL PAYROLL';
			$data['table']['header'][3] = 'NAMA KARYAWAN';
			$data['table']['header'][4] = 'POSISI';
			$data['table']['header'][5] = 'UNIT KERJA';
			$data['table']['header'][6] = 'KONTRAK KERJA';
			$data['table']['header'][7] = 'OPERASI';

			$data['table']['filter']['input']['id'][2] = 'payday-input';
			$data['table']['filter']['input']['id'][3] = 'name-input';
			$data['table']['filter']['input']['id'][4] = 'position-select';
			// $data['table']['filter']['input']['id'][4] = 'division-select';
			$data['table']['filter']['input']['id'][5] = 'unit-id-select';
			$data['table']['filter']['input']['id'][6] = 'reference-number-input';

			$data['table']['filter']['input']['type'][2] = 'month';
			$data['table']['filter']['input']['type'][3] = 'text';
			$data['table']['filter']['input']['type'][4] = 'multiselect';
			$data['table']['filter']['input']['type'][5] = 'multiselect';
			$data['table']['filter']['input']['type'][6] = 'text';
				
			$data['table']['filter']['input']['options'][4] = $positions;
			// $data['table']['filter']['input']['options'][4] = array(
			// 	'DRIVER' => 'DRIVER',
			// 	'OFFICE BOY' => 'OFFICE BOY',
			// 	'VIDEOGRAFER' => 'VIDEOGRAFER',
			// 	// 'CUSTOMER SERVICE' => 'CUSTOMER SERVICE',
			// 	'HRD' => 'HRD',
			// 	'RND' => 'RND',
			// 	'IT' => 'IT',
			// 	'CONTENT WRITER' => 'CONTENT WRITER',
			// 	'FINANCE' => 'FINANCE',
			// 	'LOGISTIK' => 'LOGISTIK',
			// 	'MARKETING' => 'MARKETING',
			// 	// 'INSTRUKTUR' => 'INSTRUKTUR',
			// 	'MANAJEMEN' => 'MANAJEMEN'
			// );

			$orders[1]['field'] = 'name';

			$orders[1]['direction'] = 'ASC';
			
			$units = $this->general_model->read('select', 'unit_id, name', 'units', array(), array(), $orders, 0, 0, 'result_array');

			foreach($units as &$unit)
			{
				$unit_options[$unit['unit_id']] = $unit['name'];
			}

			$data['table']['filter']['input']['options'][5] = $unit_options;

			$data['table']['filter']['input']['value'][4] = array();
			$data['table']['filter']['input']['value'][5] = array();

			$data['table']['filter']['input']['onchange'][4] = 'getTableData(1)';
			$data['table']['filter']['input']['onchange'][5] = 'getTableData(1)';

			$data['table']['filter']['input']['oninput'][2] = 'getTableData(1)';
			$data['table']['filter']['input']['oninput'][3] = 'getTableData(1)';
			$data['table']['filter']['input']['oninput'][6] = 'getTableData(1)';

			// $data['table']['bulk_action']['input']['options'] = array(
			// 	'Dijual'		=> 'Ubah status menjadi "Dijual"',
			// 	'Tidak dijual'	=> 'Ubah status menjadi "Tidak dijual"',
			// 	'Dihapus'		=> 'Hapus'
			// );

			// $data['table']['bulk_action']['input']['value'] = 'Dijual';

			// $data['table']['bulk_action']['input']['id'] = 'bulk-action-select';

			$data['button']['link'] = base_url('penggajian/tambah_ubah');

			$data['hidden_input']['value'][1] = base_url('penggajian');
			$data['hidden_input']['value'][2] = base_url('member/produk/tambah_ubah?status=');

			$data['hidden_input']['id'][1] = 'controller-link';
			$data['hidden_input']['id'][2] = 'formaction';
			
			$data['hidden_inputs'] = 2;
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css',
				'toastr/toastr.min.css'
			);
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'vendor/toastr/toastr.js',
				'assets/js/pages/payroll/list.js',
				'assets/js/templates/table.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('templates/dashboard/list/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
		}

		public function table_data($page_number, $limit)
	    {
			$this->load->model('general_model');
			$this->load->helper('html');
			$this->load->helper('form');

			$joins[1]['table'] = 'contracts';
			$joins[2]['table'] = 'users';
			$joins[3]['table'] = 'units';

			$joins[1]['on'] = 'payroll.contract_id = contracts.contract_id';
			$joins[2]['on'] = 'contracts.user_id = users.user_id';
			$joins[3]['on'] = 'contracts.unit_id = units.unit_id';

			$filters[1]['operator'] = 'where';
			$filters[2]['operator'] = 'where';
			$filters[3]['operator'] = 'where';
				
			$filters[1]['field'] = 'payroll.status';
			$filters[2]['field'] = 'contracts.status';
			$filters[3]['field'] = 'user_status <>';

			$filters[1]['value'] = 'Valid';
			$filters[2]['value'] = 'Valid';
			$filters[3]['value'] = 'Dihapus';

			// if($this->input->get('division') != NULL && $this->input->get('division') != '')
			// {
			// 	$filters[1]['operator'] = 'where_in';
				
			// 	$filters[1]['field'] = 'division';

			// 	$filters[1]['value'] = explode(',', urldecode($this->input->get('division')));
			// }
			// else
			// {
				$filters[4]['operator'] = 'where_not_in';
				
				$filters[4]['field'] = 'division';

				$filters[4]['value'] = array('SUPER USER', 'CUSTOMER SERVICE', 'INSTRUKTUR');
			// }

			$filter_counter = 4;

			if($this->input->get('payday') != NULL && $this->input->get('payday') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'payday';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('name'));
			}

			if($this->input->get('name') != NULL && $this->input->get('name') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'users.name';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('name'));
			}

			if($this->input->get('position') != NULL && $this->input->get('position') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where_in';
				
				$filters[$filter_counter]['field'] = 'position';

				$filters[$filter_counter]['value'] = explode(',', urldecode($this->input->get('position')));
			}

			if($this->input->get('unit_id') != NULL && $this->input->get('unit_id') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where_in';
				
				$filters[$filter_counter]['field'] = 'contracts.unit_id';

				$filters[$filter_counter]['value'] = explode(',', urldecode($this->input->get('unit_id')));
			}

			if($this->input->get('reference_number') != NULL && $this->input->get('reference_number') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'reference_number';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('reference_number'));
			}

			if($this->input->get('order_by') != NULL && $this->input->get('order_by') != '')
			{	
				$order = explode(',', urldecode($this->input->get('order_by')));

				$orders[1]['field'] = $order[0];

				$orders[1]['direction'] = $order[1];
			}
			else
				$orders = array();
			
			$data['records'] = $this->general_model->read('select', '*, users.name as employee_name, units.name as unit_name', 'payroll', $joins, $filters, $orders, $page_number, $limit, 'result_array');

			$data['columns'] = 7;

			if(!empty($data['records']))
            {
				$data['table']['data'][2] = 'payday';
				$data['table']['data'][3] = 'employee_name';
				$data['table']['data'][4] = 'position';
				// $data['table']['data'][5] = 'division';
				$data['table']['data'][5] = 'unit_name';
				$data['table']['data'][6] = 'reference_number';

				$data['buttons'] = 2;

                $button['link'] = base_url('penggajian/');
                $button['class'] = 'btn btn-sm ';

				$num_rows = $this->general_model->read('select', 'payroll_data_id', 'payroll', $joins, $filters, array(), $page_number, $limit, 'num_rows');
                
                for($record_counter = 0; $record_counter < $num_rows; $record_counter++)
                {
                    $data['records'][$record_counter]['payday'] = substr($data['records'][$record_counter]['payday'], -2).'-'.substr($data['records'][$record_counter]['payday'], 5, 2).'-'.substr($data['records'][$record_counter]['payday'], 0, 4);
					
					$data['records'][$record_counter]['button']['type'][1] = 'button';
                    
                    $data['records'][$record_counter]['button']['title'][1] = 'Ubah';
                    
                    $data['records'][$record_counter]['button']['link'][1] = $button['link'].'tambah_ubah_data/'.$data['records'][$record_counter]['payroll_data_id'];

                    $data['records'][$record_counter]['button']['formaction'][1] = '';

                    $data['records'][$record_counter]['button']['class'][1] = $button['class'].'btn-primary';

                    $data['records'][$record_counter]['button']['onclick'][1] = '';

                    // $data['records'][$record_counter]['button']['icon'][1] = 'mdi mdi-square-edit-outline';
					$data['records'][$record_counter]['button']['icon'][1] = 'Ubah';

                    $data['records'][$record_counter]['button']['type'][2] = 'submit';

                    $data['records'][$record_counter]['button']['title'][2] = 'Hapus';

                    $data['records'][$record_counter]['button']['link'][2] = 'javascript:void(0)';
                    
                    $data['records'][$record_counter]['button']['formaction'][2] = $button['link'].'hapus?payroll_data_id='.$data['records'][$record_counter]['payroll_data_id'].'&status=Dihapus';

                    $data['records'][$record_counter]['button']['class'][2] = $button['class'].'btn-danger';

                    $data['records'][$record_counter]['button']['onclick'][2] = 'return confirmDeletion()';

                    // $data['records'][$record_counter]['button']['icon'][2] = 'mdi mdi-delete';
					$data['records'][$record_counter]['button']['icon'][2] = 'Hapus';
                }
            }

			echo $this->load->view('templates/dashboard/list/data', $data, TRUE);
		}

		public function pagination($page_number, $limit)
	    {
			$this->load->model('general_model');
			$this->load->library('assignment');

			$joins[1]['table'] = 'contracts';
			$joins[2]['table'] = 'users';
			$joins[3]['table'] = 'units';

			$joins[1]['on'] = 'payroll.contract_id = contracts.contract_id';
			$joins[2]['on'] = 'contracts.user_id = users.user_id';
			$joins[3]['on'] = 'contracts.unit_id = units.unit_id';

			$filters[1]['operator'] = 'where';
			$filters[2]['operator'] = 'where';
			$filters[3]['operator'] = 'where';
				
			$filters[1]['field'] = 'payroll.status';
			$filters[2]['field'] = 'contracts.status';
			$filters[3]['field'] = 'user_status <>';

			$filters[1]['value'] = 'Valid';
			$filters[2]['value'] = 'Valid';
			$filters[3]['value'] = 'Dihapus';

			// if($this->input->get('division') != NULL && $this->input->get('division') != '')
			// {
			// 	$filters[1]['operator'] = 'where_in';
				
			// 	$filters[1]['field'] = 'division';

			// 	$filters[1]['value'] = explode(',', urldecode($this->input->get('division')));
			// }
			// else
			// {
				$filters[4]['operator'] = 'where_not_in';
				
				$filters[4]['field'] = 'division';

				$filters[4]['value'] = array('SUPER USER', 'CUSTOMER SERVICE', 'INSTRUKTUR');
			// }

			$filter_counter = 4;

			if($this->input->get('payday') != NULL && $this->input->get('payday') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'payday';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('name'));
			}

			if($this->input->get('name') != NULL && $this->input->get('name') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'users.name';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('name'));
			}

			if($this->input->get('position') != NULL && $this->input->get('position') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where_in';
				
				$filters[$filter_counter]['field'] = 'position';

				$filters[$filter_counter]['value'] = explode(',', urldecode($this->input->get('position')));
			}

			if($this->input->get('unit_id') != NULL && $this->input->get('unit_id') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where_in';
				
				$filters[$filter_counter]['field'] = 'contracts.unit_id';

				$filters[$filter_counter]['value'] = explode(',', urldecode($this->input->get('unit_id')));
			}

			if($this->input->get('reference_number') != NULL && $this->input->get('reference_number') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'reference_number';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('reference_number'));
			}
			
			$page_count = ceil($this->general_model->read('select', 'payroll_data_id', 'payroll', $joins, $filters, array(), 0, 0, 'num_rows') / $limit);
                
            $data['page_number'] = $page_number;
			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				$pagination = $this->assignment->table_template_pagination($page_count, $page_number);
				
				$data = array_merge($data, $pagination);
			}

			echo $this->load->view('templates/dashboard/list/pagination', $data, TRUE);
		}

		/*public function slip($payroll_data_id)
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			//if($this->session->userdata('role_id') > 1)
            //	redirect('pesanan/daftar');
            
            $this->load->model('payroll_model');

			$spreadsheet = new Spreadsheet();
			
			$sheet = $spreadsheet->getActiveSheet();

			$payroll_data = $this->payroll_model->read_payroll('*, units.name as unit_name, units.address as unit_address, users.name as employee_name, users.address as employee_address, contracts.division as employee_division', $payroll_data_id, 0, 0, 'row_array');

			$sheet->setCellValue('A1', $payroll_data['unit_name']);
			$sheet->setCellValue('C1', 'SLIP GAJI');
			$sheet->setCellValue('D1', 'Tanggal');
			$sheet->setCellValue('E1', substr($payroll_data['payday'], -2).'/'.substr($payroll_data['payday'], 5, 2).'/'.substr($payroll_data['payday'], 0, 4));

			$sheet->setCellValue('A2', $payroll_data['unit_address']);
			$sheet->setCellValue('D2', 'Jabatan');
			$sheet->setCellValue('E2', $payroll_data['position'].' '.$payroll_data['employee_division']);

			$sheet->setCellValue('D3', 'NIK');
			$sheet->setCellValue('E3', str_pad($payroll_data['employee_id'], 6, "0", STR_PAD_LEFT));

			$sheet->setCellValue('D4', 'Jumlah Izin');
			$sheet->setCellValue('E4', ($payroll_data['paid_leave'] + $payroll_data['sick_leave']));

			$sheet->setCellValue('A5', 'Nama');
			$sheet->setCellValue('B5', $payroll_data['employee_name']);
			$sheet->setCellValue('D5', 'Sisa Cuti');
			$sheet->setCellValue('E5', $payroll_data['paid_leave_granted']);

			$sheet->setCellValue('A6', 'Alamat');
			$sheet->setCellValue('B6', $payroll_data['employee_address']);
			$sheet->setCellValue('D6', 'Nomor HP');
			$sheet->setCellValueExplicit('E6', '+'.$payroll_data['phone_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);

			$sheet->setCellValue('A8', 'NO.');
			$sheet->setCellValue('B8', 'KETERANGAN');
			$sheet->setCellValue('C8', 'QTY');
			$sheet->setCellValue('D8', 'JUMLAH');

			$sheet->setCellValue('A9', 1);
			$sheet->setCellValue('B9', 'Gaji Pokok');
			$sheet->setCellValue('C9', 1);
			$sheet->setCellValue('D9', $payroll_data['basic_salary']);

			$row_counter = 9;
			$total_salary = $payroll_data['basic_salary'];

			$salary_components = array(
				'Dinas Dalam Kota (1)',
				'Dinas Luar Kota (2)',
				'Lembur Biasa (1)',
				'Lembur Extra (2)',
				'Bonus 1 Tunjangan Jabatan',
				'Bonus 2 Pulsa',
				'Bonus 3 Tunjangan Prestasi',
				'THR',
				'Pesangon',
				$payroll_data['other_bonus_component'],
				'Alpha',
				'Terlambat',
				'BPJS',
				$payroll_data['other_salary_cut_component'],
				'Simpanan Pokok',
				'Simpanan Wajib',
				'Simpanan Sukarela',
				'Potongan Pinjaman Koperasi',
				'Zakat',
				'Infaq',
				'Shodaqoh',
				'Wakaf'
			);

			$multipliers = array(
				$payroll_data['in_town_duty'],
				$payroll_data['out_town_duty'],
				$payroll_data['regular_overtime'],
				$payroll_data['extra_overtime'],
				1,
				1,
				($payroll_data['performance_allowance_percentage'] / 100),
				$payroll_data['holiday_allowance_distribution'],
				1,
				1,
				$payroll_data['absence'],
				$payroll_data['hours_late'],
				1,
				1,
				1,
				1,
				1,
				1,
				1,
				1,
				1,
				1
			);

			$salary_components_denomination = array(
				$payroll_data['in_town_duty_per_diem'],
				$payroll_data['out_town_duty_per_diem'],
				$payroll_data['regular_overtime_pay'],
				$payroll_data['extra_overtime_pay'],
				$payroll_data['positional_allowance'],
				$payroll_data['credit_allowance'],
				$payroll_data['performance_allowance'],
				$payroll_data['holiday_allowance'],
				$payroll_data['severance_pay'],
				$payroll_data['other_bonus'],
				(-1 * $payroll_data['absence_cuts_per_day']),
				(-1 * $payroll_data['late_charge_per_hour']),
				(-1 * $payroll_data['insurance']),
				(-1 * $payroll_data['other_salary_cut']),
				(-1 * $payroll_data['principal_savings']),
				(-1 * $payroll_data['mandatory_savings']),
				(-1 * $payroll_data['voluntary_savings']),
				(-1 * $payroll_data['cooperative_loan_installment']),
				(-1 * $payroll_data['zakat']),
				(-1 * $payroll_data['infaq']),
				(-1 * $payroll_data['alms']),
				(-1 * $payroll_data['waqf'])
			);

			for($salary_component_counter = 0;$salary_component_counter < 22;$salary_component_counter++)
			{
				if($multipliers[$salary_component_counter] > 0 && $salary_components_denomination[$salary_component_counter] != 0)
				{
					$sheet->setCellValue('A'.($row_counter + 1), ($row_counter - 8));
					$sheet->setCellValue('B'.($row_counter + 1), $salary_components[$salary_component_counter]);
					$sheet->setCellValue('C'.($row_counter + 1), $multipliers[$salary_component_counter]);
					
					$salary_component_nominal = $multipliers[$salary_component_counter] * $salary_components_denomination[$salary_component_counter];

					$sheet->setCellValue('D'.($row_counter + 1), $salary_component_nominal);

					$total_salary = $total_salary + $salary_component_nominal;

					$sheet->mergeCells('D'.($row_counter + 1).':E'.($row_counter + 1));
					
					$row_counter++;
				}
			}

			$sheet->setCellValue('C'.($row_counter + 1), 'TOTAL');
			$sheet->setCellValue('D'.($row_counter + 1), $total_salary);
			//$sheet->setCellValue('D'.($row_counter + 1), 0);

			$sheet->mergeCells('D'.($row_counter + 1).':E'.($row_counter + 1));

			$sheet->setCellValue('B'.($row_counter + 4), 'Penerima');
			$sheet->setCellValue('D'.($row_counter + 4), 'Yogyakarta, '.substr($payroll_data['payday'], -2).'/'.substr($payroll_data['payday'], 5, 2).'/'.substr($payroll_data['payday'], 0, 4));

			$sheet->mergeCells('D'.($row_counter + 4).':E'.($row_counter + 4));

			$sheet->setCellValue('B'.($row_counter + 9), $payroll_data['employee_name']);
			$sheet->setCellValue('D'.($row_counter + 9), 'PT Sinergi Membangun Bangsa');

			$sheet->mergeCells('D'.($row_counter + 9).':E'.($row_counter + 9));

			$sheet->getColumnDimension('A')->setAutoSize(true);
			$sheet->getColumnDimension('B')->setWidth(36);
			$sheet->getColumnDimension('C')->setAutoSize(true);
			$sheet->getColumnDimension('D')->setAutoSize(true);
			$sheet->getColumnDimension('E')->setWidth(24);

			$sheet->mergeCells('A1:B1');
			$sheet->mergeCells('C1:C6');
			$sheet->mergeCells('A2:B3');
			$sheet->mergeCells('D8:E8');
			$sheet->mergeCells('D9:E9');

			$sheet->getStyle('A2')->getAlignment()->setWrapText(true);
			
			$writer = new Xlsx($spreadsheet);
	
			$filename = 'Slip Gaji '.$payroll_data['employee_name'];
	
			header('Content-Type: application/vnd.ms-excel');
			header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
			header('Cache-Control: max-age=0');
			
			$writer->save('php://output'); // download file
	    }*/

		public function slip()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			//if($this->session->userdata('role_id') > 1)
            //	redirect('pesanan/daftar');
            
            if($this->input->post('submit') != NULL)
			{
                $this->load->model('payroll_model');

				$spreadsheet = new Spreadsheet();

				$spreadsheet->getDefaultStyle()->getFont()->setName('Arial');
				$spreadsheet->getDefaultStyle()->getFont()->setSize(10);
				
				$sheet = $spreadsheet->getActiveSheet();

				$payroll = $this->payroll_model->read_payroll('*, units.name as unit_name, units.address as unit_address, users.name as employee_name, users.address as employee_address, contracts.division as employee_division', 0, $this->input->post('payday'));

				$row_counter = 0;

				foreach($payroll as &$payroll_data)
				{
					$sheet->mergeCells('A'.($row_counter + 1).':B'.($row_counter + 1));
					$sheet->mergeCells('C'.($row_counter + 1).':C'.($row_counter + 6));
					$sheet->mergeCells('A'.($row_counter + 2).':B'.($row_counter + 3));
					$sheet->mergeCells('D'.($row_counter + 8).':E'.($row_counter + 8));
					$sheet->mergeCells('D'.($row_counter + 9).':E'.($row_counter + 9));

					$row_counter++;

					$sheet->setCellValue('A'.$row_counter, $payroll_data['unit_name']);
					$sheet->setCellValue('C'.$row_counter, 'SLIP GAJI');
					$sheet->setCellValue('D'.$row_counter, 'Tanggal');
					$sheet->setCellValue('E'.$row_counter, substr($payroll_data['payday'], -2).'/'.substr($payroll_data['payday'], 5, 2).'/'.substr($payroll_data['payday'], 0, 4));

					$sheet->getStyle('A'.$row_counter)->getFont()->setBold(true);
					$sheet->getStyle('C'.$row_counter)->getFont()->setBold(true);
					$sheet->getStyle('C'.$row_counter)->getFont()->setSize(20);
					$sheet->getStyle('C'.$row_counter)->getAlignment()->setWrapText(true);
					$sheet->getStyle('C'.$row_counter)->getAlignment()->setVertical(\PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER);

					$row_counter++;

					$sheet->setCellValue('A'.$row_counter, $payroll_data['unit_address']);
					$sheet->setCellValue('D'.$row_counter, 'Jabatan');
					$sheet->setCellValue('E'.$row_counter, $payroll_data['position'].' '.$payroll_data['employee_division']);

					$sheet->getStyle('A'.$row_counter)->getAlignment()->setWrapText(true);

					$row_counter++;

					$sheet->setCellValue('D'.$row_counter, 'NIK');
					$sheet->setCellValue('E'.$row_counter, str_pad($payroll_data['employee_id'], 6, "0", STR_PAD_LEFT));

					$row_counter++;

					$sheet->setCellValue('D'.$row_counter, 'Jumlah Izin');
					$sheet->setCellValue('E'.$row_counter, ($payroll_data['paid_leave'] + $payroll_data['sick_leave']));

					$row_counter++;

					$paid_sick_leave = $this->payroll_model->read_payroll('(SUM(paid_leave) + SUM(sick_leave)) as current_total', 0, $this->input->post('payday'), $payroll_data['contract_id'], 0, 0, 'row_array');

					if($payroll_data['paid_leave_granted'] - $paid_sick_leave['current_total'] > 0)
						$paid_leave_remainder = $payroll_data['paid_leave_granted'] - $paid_sick_leave['current_total'];
					else
						$paid_leave_remainder = 0;

					$sheet->setCellValue('A'.$row_counter, 'Nama');
					$sheet->setCellValue('B'.$row_counter, $payroll_data['employee_name']);
					$sheet->setCellValue('D'.$row_counter, 'Sisa Cuti');
					$sheet->setCellValue('E'.$row_counter, $paid_leave_remainder);

					$row_counter++;

					$sheet->setCellValue('A'.$row_counter, 'Alamat');
					$sheet->setCellValue('B'.$row_counter, $payroll_data['employee_address']);
					$sheet->setCellValue('D'.$row_counter, 'Nomor HP');
					$sheet->setCellValueExplicit('E'.$row_counter, '+'.$payroll_data['phone_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);

					$row_counter++;
					$row_counter++;

					$sheet->setCellValue('A'.$row_counter, 'NO.');
					$sheet->setCellValue('B'.$row_counter, 'KETERANGAN');
					$sheet->setCellValue('C'.$row_counter, 'QTY');
					$sheet->setCellValue('D'.$row_counter, 'JUMLAH');

					$sheet->getStyle('A'.$row_counter.':E'.$row_counter)->getBorders()->getallBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);

					$row_counter++;

					$sheet->setCellValue('A'.$row_counter, 1);
					$sheet->setCellValue('B'.$row_counter, 'Gaji Pokok');
					$sheet->setCellValue('C'.$row_counter, 1);
					$sheet->setCellValue('D'.$row_counter, $payroll_data['basic_salary']);

					$sheet->getStyle('A'.$row_counter.':E'.$row_counter)->getBorders()->getallBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);

					$total_salary = $payroll_data['basic_salary'];

					$salary_components = array(
						'Dinas Dalam Kota (1)',
						'Dinas Luar Kota (2)',
						'Lembur Biasa (1)',
						'Lembur Extra (2)',
						'Bonus 1 Tunjangan Jabatan',
						'Bonus 2 Pulsa',
						'Bonus 3 Tunjangan Prestasi',
						'THR',
						'Pesangon',
						$payroll_data['other_bonus_component'],
						'Alpha',
						'Terlambat',
						'BPJS',
						$payroll_data['other_salary_cut_component'],
						'Simpanan Pokok',
						'Simpanan Wajib',
						'Simpanan Sukarela',
						'Potongan Pinjaman Koperasi',
						'Zakat',
						'Infaq',
						'Shodaqoh',
						'Wakaf'
					);

					$total_absence = $payroll_data['absence'];

					if($paid_sick_leave['current_total'] > $payroll_data['paid_leave_granted'])
					{
						if($paid_sick_leave['current_total'] - $payroll_data['paid_leave_granted'] < $payroll_data['paid_leave'] + $payroll_data['sick_leave'])
							$total_absence = $total_absence + $paid_sick_leave['current_total'] - $payroll_data['paid_leave_granted'];
						else
							$total_absence = $total_absence + $payroll_data['paid_leave'] + $payroll_data['sick_leave'];
					}

					$multipliers = array(
						$payroll_data['in_town_duty'],
						$payroll_data['out_town_duty'],
						$payroll_data['regular_overtime'],
						$payroll_data['extra_overtime'],
						1,
						1,
						($payroll_data['performance_allowance_percentage'] / 100),
						$payroll_data['holiday_allowance_distribution'],
						1,
						1,
						$total_absence,
						$payroll_data['hours_late'],
						1,
						1,
						1,
						1,
						1,
						1,
						1,
						1,
						1,
						1
					);

					$salary_components_denomination = array(
						$payroll_data['in_town_duty_per_diem'],
						$payroll_data['out_town_duty_per_diem'],
						$payroll_data['regular_overtime_pay'],
						$payroll_data['extra_overtime_pay'],
						$payroll_data['positional_allowance'],
						$payroll_data['credit_allowance'],
						$payroll_data['performance_allowance'],
						$payroll_data['holiday_allowance'],
						$payroll_data['severance_pay'],
						$payroll_data['other_bonus'],
						(-1 * $payroll_data['absence_cuts_per_day']),
						(-1 * $payroll_data['late_charge_per_hour']),
						(-1 * $payroll_data['insurance']),
						(-1 * $payroll_data['other_salary_cut']),
						(-1 * $payroll_data['principal_savings']),
						(-1 * $payroll_data['mandatory_savings']),
						(-1 * $payroll_data['voluntary_savings']),
						(-1 * $payroll_data['cooperative_loan_installment']),
						(-1 * $payroll_data['zakat']),
						(-1 * $payroll_data['infaq']),
						(-1 * $payroll_data['alms']),
						(-1 * $payroll_data['waqf'])
					);

					$counted_salary_component = 1;

					for($salary_component_counter = 0;$salary_component_counter < 22;$salary_component_counter++)
					{
						if($multipliers[$salary_component_counter] > 0 && $salary_components_denomination[$salary_component_counter] != 0)
						{
							$row_counter++;
							$counted_salary_component++;
							
							$sheet->setCellValue('A'.$row_counter, $counted_salary_component);
							$sheet->setCellValue('B'.$row_counter, $salary_components[$salary_component_counter]);
							$sheet->setCellValue('C'.$row_counter, $multipliers[$salary_component_counter]);
							
							$salary_component_nominal = $multipliers[$salary_component_counter] * $salary_components_denomination[$salary_component_counter];

							$sheet->setCellValue('D'.$row_counter, $salary_component_nominal);

							$total_salary = $total_salary + $salary_component_nominal;

							$sheet->mergeCells('D'.$row_counter.':E'.$row_counter);
							
							$sheet->getStyle('A'.$row_counter.':E'.$row_counter)->getBorders()->getallBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);
						}
					}

					$row_counter++;

					$sheet->setCellValue('C'.$row_counter, 'TOTAL');
					$sheet->setCellValue('D'.$row_counter, $total_salary);

					$sheet->getStyle('C'.$row_counter)->getFont()->setBold(true);
					$sheet->getStyle('C'.$row_counter.':E'.$row_counter)->getBorders()->getallBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);
					$sheet->mergeCells('D'.$row_counter.':E'.$row_counter);

					$row_counter++;
					$row_counter++;
					$row_counter++;

					$sheet->setCellValue('B'.$row_counter, 'Penerima');
					$sheet->setCellValue('D'.$row_counter, 'Yogyakarta, '.substr($payroll_data['payday'], -2).'/'.substr($payroll_data['payday'], 5, 2).'/'.substr($payroll_data['payday'], 0, 4));

					$sheet->mergeCells('D'.$row_counter.':E'.$row_counter);

					$row_counter++;
					$row_counter++;
					$row_counter++;
					$row_counter++;
					$row_counter++;

					$sheet->setCellValue('B'.$row_counter, $payroll_data['employee_name']);
					$sheet->setCellValue('D'.$row_counter, 'PT Sinergi Membangun Bangsa');

					$sheet->mergeCells('D'.$row_counter.':E'.$row_counter);

					$row_counter++;
					$row_counter++;

					if($payroll_data['employee_division'] == 'MARKETING')
					{
						$marketing_user_id = 0;
						$manager_user_id = 0;
						
						if($payroll_data['position'] == 'Staff')
							$marketing_user_id = $payroll_data['user_id'];
						else
							$manager_user_id = $payroll_data['user_id'];
						
						$monthly_fees = $this->payroll_model->read_monthly_fees($payroll_data['unit_id'], $marketing_user_id, $manager_user_id);

						$monthly_fee_attained = FALSE;

						foreach($monthly_fees as &$monthly_fee)
						{
							if((($monthly_fee['profit_loss'] / $monthly_fee['revenue']) * 100) >= $payroll_data['profit_target_d'])
							{
								$monthly_fee_attained = TRUE;

								break;
							}
						}

						$payday_month = substr($this->input->post('payday'), -2);

						if($payday_month == '04' || $payday_month == '08' || $payday_month == '12')
						{
							$turnover_attainment = $this->payroll_model->read_events_turnover($payroll_data['unit_id'], $marketing_user_id, $manager_user_id);

							if(($payday_month == '04' && $turnover_attainment >= ($payroll_data['turnover_target'] / 3)) || ($payday_month == '08' && $turnover_attainment >= ((2 / 3) * $payroll_data['turnover_target'])) || ($payday_month == '12' && $turnover_attainment >= $payroll_data['turnover_target']))
							{
								$quarterly_fees = $this->payroll_model->read_quarterly_fees($payroll_data['unit_id'], $marketing_user_id, $manager_user_id);

								$quarterly_fee_attained = FALSE;
								
								foreach($quarterly_fees as &$quarterly_fee)
								{
									if((($quarterly_fee['profit_loss'] / $quarterly_fee['revenue']) * 100) >= $payroll_data['profit_target_d'])
									{
										$quarterly_fee_attained = TRUE;

										break;
									}
								}
							}

							if($payday_month == '12' && $turnover_attainment >= $payroll_data['turnover_target'])
							{
								$annual_fees = $this->payroll_model->read_annual_fees($payroll_data['unit_id'], $marketing_user_id, $manager_user_id);

								$annual_fee_attained = FALSE;
								
								foreach($annual_fees as &$annual_fee)
								{
									if((($annual_fee['profit_loss'] / $annual_fee['revenue']) * 100) >= $payroll_data['profit_target_d'])
									{
										$annual_fee_attained = TRUE;

										break;
									}
								}
							}
						}

						if($monthly_fee_attained || $quarterly_fee_attained || $annual_fee_attained)
						{
							$sheet->mergeCells('A'.($row_counter + 1).':B'.($row_counter + 1));
							$sheet->mergeCells('C'.($row_counter + 1).':C'.($row_counter + 6));
							$sheet->mergeCells('A'.($row_counter + 2).':B'.($row_counter + 3));
							$sheet->mergeCells('D'.($row_counter + 8).':E'.($row_counter + 8));
							$sheet->mergeCells('D'.($row_counter + 9).':E'.($row_counter + 9));

							$row_counter++;

							$sheet->setCellValue('A'.$row_counter, $payroll_data['unit_name']);
							$sheet->setCellValue('C'.$row_counter, 'DAFTAR EVENT');
							$sheet->setCellValue('D'.$row_counter, 'Tanggal');
							$sheet->setCellValue('E'.$row_counter, substr($payroll_data['payday'], -2).'/'.substr($payroll_data['payday'], 5, 2).'/'.substr($payroll_data['payday'], 0, 4));

							$sheet->getStyle('A'.$row_counter)->getFont()->setBold(true);
							$sheet->getStyle('C'.$row_counter)->getFont()->setBold(true);
							$sheet->getStyle('C'.$row_counter)->getFont()->setSize(20);
							$sheet->getStyle('C'.$row_counter)->getAlignment()->setWrapText(true);
							$sheet->getStyle('C'.$row_counter)->getAlignment()->setVertical(\PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER);

							$row_counter++;

							$sheet->setCellValue('A'.$row_counter, $payroll_data['unit_address']);
							$sheet->setCellValue('D'.$row_counter, 'Jabatan');
							$sheet->setCellValue('E'.$row_counter, $payroll_data['position'].' '.$payroll_data['employee_division']);

							$sheet->getStyle('A'.$row_counter)->getAlignment()->setWrapText(true);

							$row_counter++;

							$sheet->setCellValue('D'.$row_counter, 'NIK');
							$sheet->setCellValue('E'.$row_counter, str_pad($payroll_data['employee_id'], 6, "0", STR_PAD_LEFT));

							$row_counter++;
							$row_counter++;

							$paid_sick_leave = $this->payroll_model->read_payroll('(SUM(paid_leave) + SUM(sick_leave)) as current_total', 0, $this->input->post('payday'), $payroll_data['contract_id'], 0, 0, 'row_array');

							if($payroll_data['paid_leave_granted'] - $paid_sick_leave['current_total'] > 0)
								$paid_leave_remainder = $payroll_data['paid_leave_granted'] - $paid_sick_leave['current_total'];
							else
								$paid_leave_remainder = 0;

							$sheet->setCellValue('A'.$row_counter, 'Nama');
							$sheet->setCellValue('B'.$row_counter, $payroll_data['employee_name']);

							$row_counter++;

							$sheet->setCellValue('A'.$row_counter, 'Alamat');
							$sheet->setCellValue('B'.$row_counter, $payroll_data['employee_address']);

							$row_counter++;
							$row_counter++;

							$sheet->setCellValue('A'.$row_counter, 'NO.');
							$sheet->setCellValue('B'.$row_counter, 'KETERANGAN');
							$sheet->setCellValue('C'.$row_counter, 'QTY');
							$sheet->setCellValue('D'.$row_counter, 'JUMLAH');

							$sheet->getStyle('A'.$row_counter.':E'.$row_counter)->getBorders()->getallBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);

							$row_counter++;

							$sheet->setCellValue('A'.$row_counter, 1);
							$sheet->setCellValue('B'.$row_counter, 'Gaji Pokok');
							$sheet->setCellValue('C'.$row_counter, 1);
							$sheet->setCellValue('D'.$row_counter, $payroll_data['basic_salary']);

							$sheet->getStyle('A'.$row_counter.':E'.$row_counter)->getBorders()->getallBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);

							$total_salary = $payroll_data['basic_salary'];

							$salary_components = array(
								'Dinas Dalam Kota (1)',
								'Dinas Luar Kota (2)',
								'Lembur Biasa (1)',
								'Lembur Extra (2)',
								'Bonus 1 Tunjangan Jabatan',
								'Bonus 2 Pulsa',
								'Bonus 3 Tunjangan Prestasi',
								'THR',
								'Pesangon',
								$payroll_data['other_bonus_component'],
								'Alpha',
								'Terlambat',
								'BPJS',
								$payroll_data['other_salary_cut_component'],
								'Simpanan Pokok',
								'Simpanan Wajib',
								'Simpanan Sukarela',
								'Potongan Pinjaman Koperasi',
								'Zakat',
								'Infaq',
								'Shodaqoh',
								'Wakaf'
							);

							$total_absence = $payroll_data['absence'];

							if($paid_sick_leave['current_total'] > $payroll_data['paid_leave_granted'])
							{
								if($paid_sick_leave['current_total'] - $payroll_data['paid_leave_granted'] < $payroll_data['paid_leave'] + $payroll_data['sick_leave'])
									$total_absence = $total_absence + $paid_sick_leave['current_total'] - $payroll_data['paid_leave_granted'];
								else
									$total_absence = $total_absence + $payroll_data['paid_leave'] + $payroll_data['sick_leave'];
							}

							$multipliers = array(
								$payroll_data['in_town_duty'],
								$payroll_data['out_town_duty'],
								$payroll_data['regular_overtime'],
								$payroll_data['extra_overtime'],
								1,
								1,
								($payroll_data['performance_allowance_percentage'] / 100),
								$payroll_data['holiday_allowance_distribution'],
								1,
								1,
								$total_absence,
								$payroll_data['hours_late'],
								1,
								1,
								1,
								1,
								1,
								1,
								1,
								1,
								1,
								1
							);

							$salary_components_denomination = array(
								$payroll_data['in_town_duty_per_diem'],
								$payroll_data['out_town_duty_per_diem'],
								$payroll_data['regular_overtime_pay'],
								$payroll_data['extra_overtime_pay'],
								$payroll_data['positional_allowance'],
								$payroll_data['credit_allowance'],
								$payroll_data['performance_allowance'],
								$payroll_data['holiday_allowance'],
								$payroll_data['severance_pay'],
								$payroll_data['other_bonus'],
								(-1 * $payroll_data['absence_cuts_per_day']),
								(-1 * $payroll_data['late_charge_per_hour']),
								(-1 * $payroll_data['insurance']),
								(-1 * $payroll_data['other_salary_cut']),
								(-1 * $payroll_data['principal_savings']),
								(-1 * $payroll_data['mandatory_savings']),
								(-1 * $payroll_data['voluntary_savings']),
								(-1 * $payroll_data['cooperative_loan_installment']),
								(-1 * $payroll_data['zakat']),
								(-1 * $payroll_data['infaq']),
								(-1 * $payroll_data['alms']),
								(-1 * $payroll_data['waqf'])
							);

							$counted_salary_component = 1;

							for($salary_component_counter = 0;$salary_component_counter < 22;$salary_component_counter++)
							{
								if($multipliers[$salary_component_counter] > 0 && $salary_components_denomination[$salary_component_counter] != 0)
								{
									$row_counter++;
									$counted_salary_component++;
									
									$sheet->setCellValue('A'.$row_counter, $counted_salary_component);
									$sheet->setCellValue('B'.$row_counter, $salary_components[$salary_component_counter]);
									$sheet->setCellValue('C'.$row_counter, $multipliers[$salary_component_counter]);
									
									$salary_component_nominal = $multipliers[$salary_component_counter] * $salary_components_denomination[$salary_component_counter];

									$sheet->setCellValue('D'.$row_counter, $salary_component_nominal);

									$total_salary = $total_salary + $salary_component_nominal;

									$sheet->mergeCells('D'.$row_counter.':E'.$row_counter);
									
									$sheet->getStyle('A'.$row_counter.':E'.$row_counter)->getBorders()->getallBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);
								}
							}

							$row_counter++;

							$sheet->setCellValue('C'.$row_counter, 'TOTAL');
							$sheet->setCellValue('D'.$row_counter, $total_salary);

							$sheet->getStyle('C'.$row_counter)->getFont()->setBold(true);
							$sheet->getStyle('C'.$row_counter.':E'.$row_counter)->getBorders()->getallBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);
							$sheet->mergeCells('D'.$row_counter.':E'.$row_counter);

							$row_counter++;
							$row_counter++;
						}
					}
				}

				$sheet->getColumnDimension('A')->setAutoSize(true);
				$sheet->getColumnDimension('B')->setWidth(36);
				$sheet->getColumnDimension('C')->setWidth(11);
				$sheet->getColumnDimension('D')->setAutoSize(true);
				$sheet->getColumnDimension('E')->setWidth(19);
					
				$writer = new Xlsx($spreadsheet);
		
				$filename = 'Slip-Gaji-'.substr($this->input->post('payday'), -2).'-'.substr($payroll_data['payday'], 0, 4);
		
				header('Content-Type: application/vnd.ms-excel');
				header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
				header('Cache-Control: max-age=0');
				
				$writer->save('php://output'); // download file
			}
            else
            {
				$this->load->model('employee_model');
                $this->load->helper('form');

				$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');
	
				if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'HRD' && $data['logged_in_user']['division'] != 'FINANCE')
					redirect();
				
				$data['title'] = ':: Sister JSO :: Unduh Slip Gaji';
                
                $data['vendor_css_links'] = array(
                    'bootstrap/css/bootstrap.min.css',
                    'font-awesome/css/font-awesome.min.css',
                    'animate-css/animate.min.css'
                );
                
                $data['js_links'] = array(
                    'assets/bundles/libscripts.bundle.js',
                    'assets/bundles/vendorscripts.bundle.js',
                    'assets/bundles/mainscripts.bundle.js'
                );

                // Render view on main layout
                $this->load->view('templates/dashboard/top', $data);
                $this->load->view('pages/payroll/download', $data);
                $this->load->view('templates/dashboard/bottom', $data);
            }
	    }
	}
?>