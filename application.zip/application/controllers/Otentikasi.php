<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Otentikasi extends CI_Controller
	{
		public function masuk()
	    {
	        if($this->session->has_userdata('user_id') == TRUE)
				redirect();

	    	if($this->input->post('email_address') != NULL)
			{
				$this->load->model('authentication_model');
				
				$user = $this->authentication_model->read_user($this->input->post('email_address'));
            	
				if(isset($user))
				{
					if($user['user_status'] == 'Aktif')
					{
						if(password_verify($this->input->post('password'), $user['hashed_password']))
						{
							$this->session->set_userdata($user);
							$this->session->set_userdata('password', $this->input->post('password'));
							$this->session->set_userdata('login_date', date('Y-m-d'));
							$this->session->set_userdata('expiring_contracts_check', FALSE);
							
							if ($this->session->has_userdata('previous_url')) 
							{
								redirect($this->session->userdata('previous_url'));	
							}
							else
								redirect();
						}
						else
							$this->session->set_flashdata('operation_result', 'password invalid');
					}
					else
						$this->session->set_flashdata('operation_result', 'account inactive');
				}
				else
					$this->session->set_flashdata('operation_result', 'email address unregistered');
			}

			$this->load->helper('form');

			// Set title page
			$data['title'] = ':: SIP JSO :: Login';
			$data['lead'] = 'Login ke akun Anda';

	        // Render view on main layout
			$this->load->view('templates/authentication/top', $data);
			$this->load->view('pages/authentication/login', $data);
			$this->load->view('templates/authentication/bottom', $data);
	    }

	    public function lupa_password()
	    {
	        if($this->session->has_userdata('user_id') == TRUE)
				redirect();
	        
	        if($this->input->post('email_address') != NULL)
			{
				$this->load->model('authentication_model');
				
				$user = $this->authentication_model->read_user($this->input->post('email_address'));

				if(isset($user))
				{
					if($user['user_status'] == 'Aktif')
					{
						$this->load->library('encryption');
						$this->load->library('email');
						
						$this->encryption->initialize(array('key' => $this->encryption->create_key(16)));

						$ciphered_email_address = $this->encryption->encrypt($this->input->post('email_address'));
						
						$this->email->from('system@jso-smb.co.id', 'Sistem Informasi Perusahaan JSO');
						$this->email->to($this->input->post('email_address'));
						//$this->email->cc('another@another-example.com');
						//$this->email->bcc('them@their-example.com');
						$this->email->subject('Reset Password Sistem Informasi Perusahaan JSO');
						$this->email->message('Email ini dikirim berdasarkan permintaan reset password pada Sistem Informasi Perusahaan JSO.<br /><br />Silakan buka <a href="'.base_url('otentikasi/lupa_password?cea='.urlencode($ciphered_email_address)).'">tautan ini</a> untuk mengatur ulang password Anda.<br /><br />Salam,<br />Sistem Informasi Perusahaan JSO');
						$this->email->send();

						$this->authentication_model->update_ciphered_email_address($this->input->post('email_address'), $ciphered_email_address);
						
						$this->session->set_flashdata('operation_result', 'password reset initiated');
					}
					else
						$this->session->set_flashdata('operation_result', 'account inactive');
				}
				else
					$this->session->set_flashdata('operation_result', 'email address unregistered');
			}

			if($this->input->get('cea') != NULL)
			{
				$this->load->model('authentication_model');
				
				$user = $this->authentication_model->read_user('', $this->input->get('cea'));

				if(isset($user))
				{
					if($user['user_status'] == 'Aktif')
					{
						$password = bin2hex(openssl_random_pseudo_bytes(7));
						
						$password_hash_options['cost'] = 9;
						
						$hashed_password = password_hash($password, PASSWORD_DEFAULT, $password_hash_options);
						
						// Setting email feature
						$this->load->library('email');

						$this->email->from('system@jso-smb.co.id', 'Sistem Informasi Perusahaan JSO');
						$this->email->to($user['email_address']);
						//$this->email->cc('another@another-example.com');
						//$this->email->bcc('them@their-example.com');
						$this->email->subject('Password Baru untuk Sistem Informasi Perusahaan JSO');
						$this->email->message('Proses reset password untuk akun Anda pada Sistem Informasi Perusahaan JSO telah berhasil dilakukan.<br /><br />Password baru Anda adalah <b>'.$password.'</b><br /><br />Salam,<br />Sistem Informasi Perusahaan JSO');
						$this->email->send();

						$this->authentication_model->update_ciphered_email_address($user['email_address']);
						$this->authentication_model->update_hashed_password($user['email_address'], $hashed_password);
						
						$this->session->set_flashdata('operation_result', 'password reset done');

						redirect('otentikasi/masuk');
					}
					else
						$this->session->set_flashdata('operation_result', 'account inactive');
				}
				else
					$this->session->set_flashdata('operation_result', 'password reset link invalid');
			}

			$this->load->helper('form');

			// Set title page
			$data['title'] = ':: SIP JSO :: Lupa Password';
			$data['lead'] = 'Reset Password';

	        // Render view on main layout
			$this->load->view('templates/authentication/top', $data);
			$this->load->view('pages/authentication/forgot_password', $data);
			$this->load->view('templates/authentication/bottom', $data);
	    }
		
	    public function keluar()
	    {
	        $this->session->sess_destroy();
	        
	        redirect('otentikasi/masuk');
		}
	}