<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	use PhpOffice\PhpSpreadsheet\Spreadsheet;
	use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
	
	class Kontrak extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->model('contract_model');
        }
        
        public function tambah_ubah($contract_id = '')
	    {
	    	if($this->input->post('submit') != NULL)
			{
				$this->load->model('contract_model');
				
				/*if($this->input->post('password') == '')
					$hashed_password = $this->input->post('password');
				else
				{
					$password_hash_options['cost'] = 9;
					
					$hashed_password = password_hash($this->input->post('password'), PASSWORD_DEFAULT, $password_hash_options);
				}*/				
				
				if($contract_id == '')
				{
					$config['upload_path'] = './uploads/';
					$config['allowed_types'] = 'pdf';
	
					$this->load->library('upload', $config);
					
					if(!$this->upload->do_upload('specific_period_work_agreement'))
					{
						$this->session->set_flashdata('error_messages', $this->upload->display_errors());
						
						redirect('kontrak/tambah_ubah');
					}
					else
						$specific_period_work_agreement = $this->upload->data('file_name');

					$this->contract_model->create_update_contract($specific_period_work_agreement);
					
					$this->session->set_flashdata('operation_result', 'contract saved');
					$this->session->set_userdata('expiring_contracts_check', FALSE);

					redirect('kontrak/tambah_ubah');
				}
				else
				{
					if($_FILES['specific_period_work_agreement']['size'] > 0 || $_FILES['resignation_letter']['size'] > 0 || $_FILES['transfer_letter']['size'] > 0 || $_FILES['warning_letter']['size'] > 0)
					{
						$config['upload_path']          = './uploads/';
						$config['allowed_types']        = 'pdf';
		
						$this->load->library('upload', $config);
					}

					if($_FILES['specific_period_work_agreement']['size'] > 0)
					{
						if(!$this->upload->do_upload('specific_period_work_agreement'))
						{
							$this->session->set_flashdata('error_messages', $this->upload->display_errors());
							
							redirect('kontrak/tambah_ubah/'.$contract_id);
						}
						else
							$specific_period_work_agreement = $this->upload->data('file_name');
					}
					else
						$specific_period_work_agreement = '';
					
					if($_FILES['resignation_letter']['size'] > 0)
					{	
						if(!$this->upload->do_upload('resignation_letter'))
						{
							$this->session->set_flashdata('error_messages', $this->upload->display_errors());
							
							redirect('kontrak/tambah_ubah/'.$contract_id);
						}
						else
							$resignation_letter = $this->upload->data('file_name');
					}
					else
						$resignation_letter = '';
					
					if($_FILES['transfer_letter']['size'] > 0)
					{	
						if(!$this->upload->do_upload('transfer_letter'))
						{
							$this->session->set_flashdata('error_messages', $this->upload->display_errors());
							
							redirect('kontrak/tambah_ubah/'.$contract_id);
						}
						else
							$transfer_letter = $this->upload->data('file_name');
					}
					else
						$transfer_letter = '';
					
					if($_FILES['warning_letter']['size'] > 0)
					{	
						if(!$this->upload->do_upload('warning_letter'))
						{
							$this->session->set_flashdata('error_messages', $this->upload->display_errors());
							
							redirect('kontrak/tambah_ubah/'.$contract_id);
						}
						else
							$warning_letter = $this->upload->data('file_name');
					}
					else
						$warning_letter = '';
					
					$this->contract_model->create_update_contract($specific_period_work_agreement, $resignation_letter, $transfer_letter, $warning_letter, $contract_id);
					
					$this->session->set_flashdata('operation_result', 'contract saved');
					$this->session->set_userdata('expiring_contracts_check', FALSE);

					redirect('kontrak/tambah_ubah/'.$contract_id);
				}
			}
			else
			{
				$this->load->model('contract_model');
				$this->load->model('unit_model');
				$this->load->helper('form');

                $data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

				require 'Options.php';

				if($contract_id == '')
				{
					if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'HRD')
						redirect();
					
					$header = 'Kontrak Baru';
					
                    $data['division'] = 'DRIVER';
                    $data['position'] = 'Staff';
					$data['company_representative_division'] = 'HRD';
					$data['company_representative_position'] = 'Manajer';
                    $data['contract_type'] = 'Freelance';
                    $data['office_location'] = 'Yogyakarta & sekitarnya';
                    $data['reference_number'] = '';
                    $data['basic_salary'] = 0;
                    $data['regular_overtime_pay'] = 0;
                    $data['extra_overtime_pay'] = 0;
                    $data['out of town duty'] = 0;
                    $data['in_town_duty_per_diem'] = 0;
                    $data['out_town_duty_per_diem'] = 0;
                    $data['turnover_target'] = 0;
                    $data['positional_allowance'] = 0;
                    $data['credit_allowance'] = 0;
                    $data['performance_allowance'] = 0;
                    $data['insurance_allowance'] = 0;
                    $data['holiday_allowance'] = 0;
                    $data['absence_cuts_per_day'] = 0;
                    $data['late_charge_per_hour'] = 0;
                    $data['paid_leave_granted'] = 0;
                    $data['monthly_fee_a'] = 0;
                    $data['quarterly_fee_a'] = 0;
                    $data['annual_fee_a'] = 0;
                    $data['profit_target_a'] = 0;
                    $data['monthly_fee_b'] = 0;
                    $data['quarterly_fee_b'] = 0;
                    $data['annual_fee_b'] = 0;
                    $data['profit_target_b'] = 0;
                    $data['monthly_fee_c'] = 0;
                    $data['quarterly_fee_c'] = 0;
                    $data['annual_fee_c'] = 0;
                    $data['profit_target_c'] = 0;
                    $data['monthly_fee_d'] = 0;
                    $data['quarterly_fee_d'] = 0;
                    $data['annual_fee_d'] = 0;
                    $data['profit_target_d'] = 0;
                    $data['effective_date'] = '0000-00-00';
                    $data['expiry_date'] = '0000-00-00';
					$data['validity_period'] = 0;
                    $data['notes'] = '';
				}
				else
				{
					if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'HRD')
						redirect();
					
					$header = 'Ubah Kontrak';
					
                    $user_contract = $this->contract_model->read_contracts('', 'row_array', 'user', $contract_id);

					$data['contract_id'] = $user_contract['contract_id'];
					$data['reference_number'] = $user_contract['reference_number'];
					$data['user_id'] = $user_contract['user_id'];
					$data['division'] = $user_contract['division'];
					$data['position'] = $user_contract['position'];
					$data['company_representative_user_id'] = $user_contract['company_representative_user_id'];
					$data['company_representative_division'] = $user_contract['company_representative_division'];
					$data['company_representative_position'] = $user_contract['company_representative_position'];
					$data['unit_id'] = $user_contract['unit_id'];
					$data['contract_type'] = $user_contract['contract_type'];
                    $data['office_location'] = $user_contract['office_location'];
					$data['basic_salary'] = $user_contract['basic_salary'];
					$data['regular_overtime_pay'] = $user_contract['regular_overtime_pay'];
					$data['extra_overtime_pay'] = $user_contract['extra_overtime_pay'];
					$data['in_town_duty_per_diem'] = $user_contract['in_town_duty_per_diem'];
					$data['out_town_duty_per_diem'] = $user_contract['out_town_duty_per_diem'];
					$data['turnover_target'] = $user_contract['turnover_target'];
					$data['positional_allowance'] = $user_contract['positional_allowance'];
					$data['credit_allowance'] = $user_contract['credit_allowance'];
					$data['performance_allowance'] = $user_contract['performance_allowance'];
					$data['insurance_allowance'] = $user_contract['insurance_allowance'];
					$data['holiday_allowance'] = $user_contract['holiday_allowance'];
					$data['absence_cuts_per_day'] = $user_contract['absence_cuts_per_day'];
					$data['late_charge_per_hour'] = $user_contract['late_charge_per_hour'];
					$data['paid_leave_granted'] = $user_contract['paid_leave_granted'];
					$data['monthly_fee_a'] = $user_contract['monthly_fee_a'];
					$data['quarterly_fee_a'] = $user_contract['quarterly_fee_a'];
					$data['annual_fee_a'] = $user_contract['annual_fee_a'];
					$data['profit_target_a'] = $user_contract['profit_target_a'];
					$data['monthly_fee_b'] = $user_contract['monthly_fee_b'];
					$data['quarterly_fee_b'] = $user_contract['quarterly_fee_b'];
					$data['annual_fee_b'] = $user_contract['annual_fee_b'];
					$data['profit_target_b'] = $user_contract['profit_target_b'];
					$data['monthly_fee_c'] = $user_contract['monthly_fee_c'];
					$data['quarterly_fee_c'] = $user_contract['quarterly_fee_c'];
					$data['annual_fee_c'] = $user_contract['annual_fee_c'];
					$data['profit_target_c'] = $user_contract['profit_target_c'];
					$data['monthly_fee_d'] = $user_contract['monthly_fee_d'];
					$data['quarterly_fee_d'] = $user_contract['quarterly_fee_d'];
					$data['annual_fee_d'] = $user_contract['annual_fee_d'];
					$data['profit_target_d'] = $user_contract['profit_target_d'];
					$data['specific_period_work_agreement'] = $user_contract['specific_period_work_agreement'];
					$data['effective_date'] = $user_contract['effective_date'];
					$data['expiry_date'] = $user_contract['expiry_date'];
					
					$date_diff = date_diff(date_create($user_contract['effective_date']), date_create($user_contract['expiry_date']));
					
					$data['validity_period'] = $date_diff->format('%y') * 12 + $date_diff->format('%m');

					if($user_contract['resignation_letter'] != '')
						$data['resignation_letter'] = $user_contract['resignation_letter'];
					
					$data['receipt_date'] = $user_contract['receipt_date'];
					$data['dismissal_date'] = $user_contract['dismissal_date'];
					$data['reason'] = $user_contract['reason'];
					$data['notes'] = $user_contract['notes'];

					$transfer_letters = $this->contract_model->read_transfer_letters($contract_id);

					if(!empty($transfer_letters))
						$data['transfer_letters'] = $transfer_letters;
					
					$warning_letter = $this->contract_model->read_warning_letter($contract_id);
					
					if(isset($warning_letter))
					{
						if($warning_letter['letter_type'] == 'SP 1' || $warning_letter['letter_type'] == 'SP 2')
						{
							$date = date_create($warning_letter['date_of_issue']);

							if($warning_letter['letter_type'] == 'SP 1')
								date_add($date, date_interval_create_from_date_string('3 months'));
							else
								date_add($date, date_interval_create_from_date_string('6 months'));
						}

						if($warning_letter['letter_type'] == 'SP 3' || date("Y-m-d") < date_format($date, 'Y-m-d'))
							$data['warning_letter'] = $warning_letter;
					}
				}
                    
				$data['title'] = ':: Sister JSO :: '.$header;
				
				$data['vendor_css_links'] = array(
					'bootstrap/css/bootstrap.min.css',
					'font-awesome/css/font-awesome.min.css',
					'animate-css/animate.min.css',
					'bootstrap-datepicker/css/bootstrap-datepicker3.min.css',
					'toastr/toastr.min.css',
                    'dropify/css/dropify.min.css'
                );
                
				$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');
				$data['header'] = $header;
				
				$users_contracts = $this->contract_model->read_users();
				
				foreach($users_contracts as &$user_contract)
				{
					$employees[$user_contract['user_id']] = $user_contract['name'].'('.$user_contract['email_address'].')';
				}

				$data['employees'] = $employees;
				
				if($header == 'Kontrak Baru')
					$data['user_id'] = $user_contract['user_id'];
				
				$data['positions'] = $positions;
				$data['contract_types'] = $contract_types;
				$data['office_locations'] = $office_locations;
				
				$users_contracts = $this->contract_model->read_users('contracts', 'Aktif');

				foreach($users_contracts as &$user_contract)
				{
					$company_representatives[$user_contract['user_id']] = $user_contract['name'].'('.$user_contract['email_address'].')';
				}
				
				$data['company_representatives'] = $company_representatives;

				if($header == 'Kontrak Baru')
					$data['company_representative_user_id'] = $user_contract['user_id'];

				$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
			
				foreach($unit_list as &$unit)
				{
					$units[$unit['unit_id']] = $unit['name'];
				}

				$data['units'] = $units;
				
				if($header == 'Kontrak Baru')
					$data['unit_id'] = $unit['unit_id'];
				
				$data['reference_number_check_link'] = base_url('kontrak/cek_nomor_surat?nomor_surat=');

				$data['js_links'] = array(
					'assets/bundles/libscripts.bundle.js',
					'assets/bundles/vendorscripts.bundle.js',
					'vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js',
					'vendor/toastr/toastr.js',
                    'vendor/dropify/js/dropify.min.js',
					'assets/bundles/mainscripts.bundle.js',
                    'assets/js/pages/forms/dropify.js',
					'assets/js/pages/contract/create_update.js'
				);

				// Render view on main layout
				$this->load->view('templates/dashboard/top', $data);
				$this->load->view('pages/contracts/create_update/static_content', $data);
				$this->load->view('templates/dashboard/bottom', $data);
			}
	    }
	    
		public function cek_nomor_surat()
		{
			$this->load->model('contract_model');
			
			echo $this->contract_model->read_contracts(urldecode($this->input->get('nomor_surat')));
		}
		
	    public function wawancara()
	    {
			$this->load->helper('form');

			if($this->input->get('position_schedule') != NULL)
				$data['position_schedule'] = $this->input->get('position_schedule');
			else
				$data['position_schedule'] = '';
			
			echo $this->load->view('pages/employees/create_update/interview_schedules', $data, TRUE);
		}

		public function hapus()
		{
			$this->load->library('authorization');
			
			$this->authorization->is_logged_in();
			
			if($this->input->post('submission') != NULL)
			{
				$this->load->model('general_model');

                $columns = array();
				
				$this->general_model->create_update('contract_id', 'contracts', $columns);

				$filters[1]['operator'] = 'where';
				
				$filters[1]['field'] = 'contract_id';
	
				$filters[1]['value'] = $this->input->get('contract_id');
				
				$contract = $this->general_model->read('select', 'user_id', 'contracts', array(), $filters);

				$filters[1]['operator'] = 'where';
				$filters[2]['operator'] = 'where';
				$filters[3]['operator'] = 'where';
				
				$filters[1]['field'] = 'user_id';
				$filters[2]['field'] = 'expiry_date >=';
				$filters[3]['field'] = 'status';
	
				$filters[1]['value'] = $contract['user_id'];
				$filters[2]['value'] = date('Y-m-d');
				$filters[3]['value'] = 'Valid';
				
				$active_contract = $this->general_model->read('select', 'contract_id', 'contracts', array(), $filters, array(), 0, 0, 'num_rows');

				if($active_contract == 0)
				{
					$this->load->model('contract_model');

					$this->contract_model->update_user_status($contract['user_id'], 'Calon karyawan');
				}
				
				// if($this->input->post('status') == 'Dihapus' || $this->input->get('status') == 'Dihapus')
				// 	$operation_result = 'product(s) data deleted';
				// else
				// 	$operation_result = 'product(s) data saved';
                
				$this->session->set_flashdata('operation_result', 'data deleted');
				
                redirect('kontrak');
			}
		}

		public function daftar($user_status = 'all')
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('contract_model');
			$this->load->helper('form');

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'HRD')
				redirect();

			if($user_status == 'all')
				$data['title'] = ':: Sister JSO :: Data Kontrak';
			else
				$data['title'] = ':: Sister JSO :: Data Karyawan Aktif Per CV';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'/*,
				'toastr/toastr.min.css'*/
			);
			$data['user_status'] = $user_status;
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				//'vendor/toastr/toastr.js',
				'assets/js/pages/contract/list.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/contracts/list/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		public function data($page_number, $user_status, $query = '')
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('contract_model');
			$this->load->helper('form');

			$data['query'] = urldecode($query);

			$data['users_contracts'] = $this->contract_model->read_contracts('', 'result_array', 'user,unit', 0, urldecode($query), $user_status, $page_number, ', users.name as employee_name, units.name as unit_name');
			
			$data['page_number'] = $page_number;
			$data['user_status'] = $user_status;

			if($user_status == 'all')
				$page_count = ceil($this->contract_model->read_contracts('', 'num_rows', 'user,unit', 0, urldecode($query)) / 5);
			else
			{
				$this->load->model('unit_model');
				
				$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
				
				foreach($unit_list as &$unit)
				{
					$units[$unit['unit_id']] = $unit['name'];
				}
	
				$data['units'] = $units;

				$page_count = ceil($this->contract_model->read_contracts('', 'num_rows', 'user,unit', 0, urldecode($query), $user_status) / 5);
			}

			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				if($page_count > 10)
				{
					if($page_number > 6)
					{
						if(($page_count - $page_number) >= 4)
							$next_page_count = 4;
						else
							$next_page_count = $page_count - $page_number;
						
						$previous_page_count = 9 - $next_page_count;
					}
					else
					{
						$previous_page_count = $page_number - 1;
						$next_page_count = 9 - $previous_page_count;
					}
				}
				else
				{
					$previous_page_count = $page_number - 1;
					$next_page_count = $page_count - $page_number;
				}

				$data['previous_page_count'] = $previous_page_count;
				$data['next_page_count'] = $next_page_count;
			}

			echo $this->load->view('pages/contracts/list/dynamic_content', $data, TRUE);
	    }

		public function index()
	    {
			$this->load->library('authorization');
			
			$this->authorization->is_logged_in();

			$this->load->model('general_model');
			$this->load->model('employee_model');

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'HRD')
				redirect();

			if($this->input->get('user_status') == NULL)
				$data['header'] = 'Data Kontrak';
			else
			{
				if($this->input->get('user_status') == 'Aktif')
					$data['header'] = 'Data Karyawan Aktif Per CV';
				else
					redirect('kontrak');
			}
			
			$this->load->helper('form');

			require 'Options.php';
			
			$data['title'] = ':: Sister JSO :: '.$data['header'];

			$data['breadcrumbs'] = 2;

			$data['breadcrumb']['item'][1] = 'Kontrak';

			$data['table']['order']['input']['options'] = array(
				''						=> '',
				'users.name,ASC'		=> 'Nama(A-Z)',
				'users.name,DESC'		=> 'Nama(Z-A)',
				'position,ASC'			=> 'Jabatan(A-Z)',
				'position,DESC'			=> 'Jabatan(Z-A)',
				'division,ASC'			=> 'Divisi(A-Z)',
				'division,DESC'			=> 'Divisi(Z-A)',
				'expiry_date,ASC'		=> 'Tanggal Selesai Kontrak(ASC)',
				'expiry_date,DESC'		=> 'Tanggal Selesai Kontrak(DESC)',
				'units.name,ASC'		=> 'Unit Kerja(A-Z)',
				'units.name,DESC'		=> 'Unit Kerja(Z-A)',
				'contract_type,ASC'		=> 'Jenis Kontrak(A-Z)',
				'contract_type,DESC'	=> 'Jenis Kontrak(Z-A)',
				'user_status,ASC'		=> 'Status(A-Z)',
				'user_status,DESC'		=> 'Status(Z-A)'
			);

			$data['columns'] = 9;

			$data['table']['header'][1] = '#';
			$data['table']['header'][2] = 'NAMA';
			$data['table']['header'][3] = 'JABATAN';
			$data['table']['header'][4] = 'DIVISI';
			$data['table']['header'][5] = 'TANGGAL SELESAI KONTRAK';
			$data['table']['header'][6] = 'UNIT KERJA';
			$data['table']['header'][7] = 'JENIS KONTRAK';
			$data['table']['header'][8] = 'STATUS';
			$data['table']['header'][9] = 'OPERASI';

			$data['table']['filter']['input']['id'][2] = 'name-input';
			$data['table']['filter']['input']['id'][3] = 'position-select';
			$data['table']['filter']['input']['id'][4] = 'division-select';
			$data['table']['filter']['input']['id'][5] = 'expiry-date-input';
			$data['table']['filter']['input']['id'][6] = 'unit-id-select';
			$data['table']['filter']['input']['id'][7] = 'contract-type-select';
			$data['table']['filter']['input']['id'][8] = 'user-status-select';

			$data['table']['filter']['input']['type'][2] = 'text';
			$data['table']['filter']['input']['type'][3] = 'multiselect';
			$data['table']['filter']['input']['type'][4] = 'multiselect';
			$data['table']['filter']['input']['type'][5] = 'date';
			$data['table']['filter']['input']['type'][6] = 'multiselect';
			$data['table']['filter']['input']['type'][7] = 'multiselect';
			$data['table']['filter']['input']['type'][8] = 'multiselect';
				
			$data['table']['filter']['input']['options'][3] = $positions;
			$data['table']['filter']['input']['options'][4] = array(
				'DRIVER' => 'DRIVER',
				'OFFICE BOY' => 'OFFICE BOY',
				'VIDEOGRAFER' => 'VIDEOGRAFER',
				// 'CUSTOMER SERVICE' => 'CUSTOMER SERVICE',
				'HRD' => 'HRD',
				'RND' => 'RND',
				'IT' => 'IT',
				'CONTENT WRITER' => 'CONTENT WRITER',
				'FINANCE' => 'FINANCE',
				'LOGISTIK' => 'LOGISTIK',
				'MARKETING' => 'MARKETING',
				// 'INSTRUKTUR' => 'INSTRUKTUR',
				'MANAJEMEN' => 'MANAJEMEN'
			);

			$orders[1]['field'] = 'name';

			$orders[1]['direction'] = 'ASC';
			
			$units = $this->general_model->read('select', 'unit_id, name', 'units', array(), array(), $orders, 0, 0, 'result_array');

			foreach($units as &$unit)
			{
				$unit_options[$unit['unit_id']] = $unit['name'];
			}

			$data['table']['filter']['input']['options'][6] = $unit_options;

			$data['table']['filter']['input']['options'][7] = $contract_types;

			$data['table']['filter']['input']['options'][8] = array(
				'Calon karyawan'	=> 'Calon karyawan',
				'Aktif'				=> 'Aktif',
				'SP 3'				=> 'SP 3',
				'Resign'			=> 'Resign'
			);

			$data['table']['filter']['input']['value'][3] = array();
			$data['table']['filter']['input']['value'][4] = array();
			$data['table']['filter']['input']['value'][6] = array();
			$data['table']['filter']['input']['value'][7] = array();
			$data['table']['filter']['input']['value'][8] = array();

			$data['table']['filter']['input']['onchange'][3] = 'getTableData(1)';
			$data['table']['filter']['input']['onchange'][4] = 'getTableData(1)';
			$data['table']['filter']['input']['onchange'][6] = 'getTableData(1)';
			$data['table']['filter']['input']['onchange'][7] = 'getTableData(1)';
			$data['table']['filter']['input']['onchange'][8] = 'getTableData(1)';

			$data['table']['filter']['input']['oninput'][2] = 'getTableData(1)';
			$data['table']['filter']['input']['oninput'][5] = 'getTableData(1)';

			// $data['table']['bulk_action']['input']['options'] = array(
			// 	'Dijual'		=> 'Ubah status menjadi "Dijual"',
			// 	'Tidak dijual'	=> 'Ubah status menjadi "Tidak dijual"',
			// 	'Dihapus'		=> 'Hapus'
			// );

			// $data['table']['bulk_action']['input']['value'] = 'Dijual';

			// $data['table']['bulk_action']['input']['id'] = 'bulk-action-select';

			$data['button']['link'] = base_url('kontrak/tambah_ubah');

			$data['hidden_input']['value'][1] = base_url('kontrak');
			$data['hidden_input']['value'][2] = base_url('member/produk/tambah_ubah?status=');

			$data['hidden_input']['id'][1] = 'controller-link';
			$data['hidden_input']['id'][2] = 'formaction';
			
			$data['hidden_inputs'] = 2;
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css',
				'toastr/toastr.min.css'
			);
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'vendor/toastr/toastr.js',
				'assets/js/pages/contract/list.js',
				'assets/js/templates/table.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('templates/dashboard/list/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
		}

		public function table_data($page_number, $limit)
	    {
			$this->load->model('general_model');
			$this->load->helper('html');
			$this->load->helper('form');

			$joins[1]['table'] = 'users';
			$joins[2]['table'] = 'units';

			$joins[1]['on'] = 'contracts.user_id = users.user_id';
			$joins[2]['on'] = 'contracts.unit_id = units.unit_id';

			if($this->input->get('division') != NULL && $this->input->get('division') != '')
			{
				$filters[1]['operator'] = 'where_in';
				
				$filters[1]['field'] = 'division';

				$filters[1]['value'] = explode(',', urldecode($this->input->get('division')));
			}
			else
			{
				$filters[1]['operator'] = 'where_not_in';
				
				$filters[1]['field'] = 'division';

				$filters[1]['value'] = array('SUPER USER', 'CUSTOMER SERVICE', 'INSTRUKTUR');
			}

			$filters[2]['operator'] = 'where';
				
			$filters[2]['field'] = 'status';

			$filters[2]['value'] = 'Valid';

			$filter_counter = 2;

			if($this->input->get('name') != NULL && $this->input->get('name') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'users.name';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('name'));
			}

			if($this->input->get('position') != NULL && $this->input->get('position') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where_in';
				
				$filters[$filter_counter]['field'] = 'position';

				$filters[$filter_counter]['value'] = explode(',', urldecode($this->input->get('position')));
			}

			if($this->input->get('expiry_date') != NULL && $this->input->get('expiry_date') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where';
				
				$filters[$filter_counter]['field'] = 'expiry_date';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('expiry_date'));
			}

			if($this->input->get('unit_id') != NULL && $this->input->get('unit_id') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where_in';
				
				$filters[$filter_counter]['field'] = 'contracts.unit_id';

				$filters[$filter_counter]['value'] = explode(',', urldecode($this->input->get('unit_id')));
			}

			if($this->input->get('contract_type') != NULL && $this->input->get('contract_type') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where_in';
				
				$filters[$filter_counter]['field'] = 'contract_type';

				$filters[$filter_counter]['value'] = explode(',', urldecode($this->input->get('contract_type')));
			}

			if($this->input->get('user_status') != NULL && $this->input->get('user_status') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where_in';
				
				$filters[$filter_counter]['field'] = 'user_status';

				$filters[$filter_counter]['value'] = explode(',', urldecode($this->input->get('user_status')));
			}

			if($this->input->get('order_by') != NULL && $this->input->get('order_by') != '')
			{	
				$order = explode(',', urldecode($this->input->get('order_by')));

				$orders[1]['field'] = $order[0];

				$orders[1]['direction'] = $order[1];
			}
			else
				$orders = array();
			
			$data['records'] = $this->general_model->read('select', '*, users.name as employee_name, units.name as unit_name', 'contracts', $joins, $filters, $orders, $page_number, $limit, 'result_array');

			$data['columns'] = 9;

			if(!empty($data['records']))
            {
				$data['table']['data'][2] = 'employee_name';
				$data['table']['data'][3] = 'position';
				$data['table']['data'][4] = 'division';
				$data['table']['data'][5] = 'expiry_date';
				$data['table']['data'][6] = 'unit_name';
				$data['table']['data'][7] = 'contract_type';
				$data['table']['data'][8] = 'user_status';

				$data['buttons'] = 2;

                $button['link'] = base_url('kontrak/');
                $button['class'] = 'btn btn-sm ';

				$num_rows = $this->general_model->read('select', 'contract_id', 'contracts', $joins, $filters, array(), $page_number, $limit, 'num_rows');
                
                for($record_counter = 0; $record_counter < $num_rows; $record_counter++)
                {
                    $data['records'][$record_counter]['expiry_date'] = substr($data['records'][$record_counter]['expiry_date'], -2).'-'.substr($data['records'][$record_counter]['expiry_date'], 5, 2).'-'.substr($data['records'][$record_counter]['expiry_date'], 0, 4);
					
					$data['records'][$record_counter]['button']['type'][1] = 'button';
                    
                    $data['records'][$record_counter]['button']['title'][1] = 'Ubah';
                    
                    $data['records'][$record_counter]['button']['link'][1] = $button['link'].'tambah_ubah/'.$data['records'][$record_counter]['contract_id'];

                    $data['records'][$record_counter]['button']['formaction'][1] = '';

                    $data['records'][$record_counter]['button']['class'][1] = $button['class'].'btn-primary';

                    $data['records'][$record_counter]['button']['onclick'][1] = '';

                    // $data['records'][$record_counter]['button']['icon'][1] = 'mdi mdi-square-edit-outline';
					$data['records'][$record_counter]['button']['icon'][1] = 'Ubah';

                    $data['records'][$record_counter]['button']['type'][2] = 'submit';

                    $data['records'][$record_counter]['button']['title'][2] = 'Hapus';

                    $data['records'][$record_counter]['button']['link'][2] = 'javascript:void(0)';
                    
                    $data['records'][$record_counter]['button']['formaction'][2] = $button['link'].'hapus?contract_id='.$data['records'][$record_counter]['contract_id'].'&status=Dihapus';

                    $data['records'][$record_counter]['button']['class'][2] = $button['class'].'btn-danger';

                    $data['records'][$record_counter]['button']['onclick'][2] = 'return confirmDeletion()';

                    // $data['records'][$record_counter]['button']['icon'][2] = 'mdi mdi-delete';
					$data['records'][$record_counter]['button']['icon'][2] = 'Hapus';
                }
            }

			echo $this->load->view('templates/dashboard/list/data', $data, TRUE);
		}

		public function pagination($page_number, $limit)
	    {
			$this->load->model('general_model');
			$this->load->library('assignment');

			$joins[1]['table'] = 'users';
			$joins[2]['table'] = 'units';

			$joins[1]['on'] = 'contracts.user_id = users.user_id';
			$joins[2]['on'] = 'contracts.unit_id = units.unit_id';

			if($this->input->get('division') != NULL && $this->input->get('division') != '')
			{
				$filters[1]['operator'] = 'where_in';
				
				$filters[1]['field'] = 'division';

				$filters[1]['value'] = explode(',', urldecode($this->input->get('division')));
			}
			else
			{
				$filters[1]['operator'] = 'where_not_in';
				
				$filters[1]['field'] = 'division';

				$filters[1]['value'] = array('SUPER USER', 'CUSTOMER SERVICE', 'INSTRUKTUR');
			}

			$filters[2]['operator'] = 'where';
				
			$filters[2]['field'] = 'status';

			$filters[2]['value'] = 'Valid';

			$filter_counter = 2;

			if($this->input->get('name') != NULL && $this->input->get('name') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'like';
				
				$filters[$filter_counter]['field'] = 'users.name';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('name'));
			}

			if($this->input->get('position') != NULL && $this->input->get('position') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where_in';
				
				$filters[$filter_counter]['field'] = 'position';

				$filters[$filter_counter]['value'] = explode(',', urldecode($this->input->get('position')));
			}

			if($this->input->get('expiry_date') != NULL && $this->input->get('expiry_date') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where';
				
				$filters[$filter_counter]['field'] = 'expiry_date';

				$filters[$filter_counter]['value'] = urldecode($this->input->get('expiry_date'));
			}

			if($this->input->get('unit_id') != NULL && $this->input->get('unit_id') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where_in';
				
				$filters[$filter_counter]['field'] = 'contracts.unit_id';

				$filters[$filter_counter]['value'] = explode(',', urldecode($this->input->get('unit_id')));
			}

			if($this->input->get('contract_type') != NULL && $this->input->get('contract_type') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where_in';
				
				$filters[$filter_counter]['field'] = 'contract_type';

				$filters[$filter_counter]['value'] = explode(',', urldecode($this->input->get('contract_type')));
			}

			if($this->input->get('user_status') != NULL && $this->input->get('user_status') != '')
			{
				$filter_counter++;
				
				$filters[$filter_counter]['operator'] = 'where_in';
				
				$filters[$filter_counter]['field'] = 'user_status';

				$filters[$filter_counter]['value'] = explode(',', urldecode($this->input->get('user_status')));
			}
			
			$page_count = ceil($this->general_model->read('select', 'contract_id', 'contracts', $joins, $filters, array(), 0, 0, 'num_rows') / $limit);
                
            $data['page_number'] = $page_number;
			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				$pagination = $this->assignment->table_template_pagination($page_count, $page_number);
				
				$data = array_merge($data, $pagination);
			}

			echo $this->load->view('templates/dashboard/list/pagination', $data, TRUE);
		}

		public function remunerasi()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			//$this->load->model('contract_model');
			$this->load->helper('form');

			$data['title'] = ':: Sister JSO :: Data Remunerasi';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'/*,
				'toastr/toastr.min.css'*/
			);

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');
			//$data['user_status'] = $user_status;
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				//'vendor/toastr/toastr.js',
				'assets/js/pages/contract/remuneration.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/contracts/remuneration/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		public function data_remunerasi($page_number)
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('contract_model');
			//$this->load->model('project_management_model');
			//$this->load->helper('form');

			/*$data['units'] = array(
				'' => 'Semua Unit'
			);

			$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
			
			foreach($unit_list as &$unit)
			{
				$data['units'][$unit['unit_id']] = $unit['name'];
			}

			$data['unit_id'] = $this->input->get('unit_id');
			$data['project_status'] = urldecode($this->input->get('project_status'));
			$data['start_date'] = urldecode($this->input->get('start_date'));*/

			$data['remuneration_list'] = $this->contract_model->read_remuneration($page_number);
			
			$data['page_number'] = $page_number;
            
			$page_count = ceil($this->contract_model->read_remuneration(0, 'num_rows') / 5);

			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				if($page_count > 10)
				{
					if($page_number > 6)
					{
						if(($page_count - $page_number) >= 4)
							$next_page_count = 4;
						else
							$next_page_count = $page_count - $page_number;
						
						$previous_page_count = 9 - $next_page_count;
					}
					else
					{
						$previous_page_count = $page_number - 1;
						$next_page_count = 9 - $previous_page_count;
					}
				}
				else
				{
					$previous_page_count = $page_number - 1;
					$next_page_count = $page_count - $page_number;
				}

				$data['previous_page_count'] = $previous_page_count;
				$data['next_page_count'] = $next_page_count;
			}

			echo $this->load->view('pages/contracts/remuneration/dynamic_content', $data, TRUE);
		}

		public function ekspor()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->model('contract_model');

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'HRD')
				redirect();

			$spreadsheet = new Spreadsheet();
			
			$sheet = $spreadsheet->getActiveSheet();

			$sheet->setCellValue('A1', 'Nomor');
			$sheet->setCellValue('B1', 'No Surat');
			$sheet->setCellValue('C1', 'Nama Karyawan');
			$sheet->setCellValue('D1', 'Nama Panggilan');
			$sheet->setCellValue('E1', 'Status Karyawan');
			$sheet->setCellValue('F1', 'NIK');
			$sheet->setCellValue('G1', 'Divisi');
			$sheet->setCellValue('H1', 'Jabatan');
			$sheet->setCellValue('I1', 'Jenis Kontrak');
			$sheet->setCellValue('J1', 'Perwakilan Perusahaan');
			$sheet->setCellValue('K1', 'Divisi');
			$sheet->setCellValue('L1', 'Jabatan');
			$sheet->setCellValue('M1', 'Link Berkas SPKWT');
			$sheet->setCellValue('N1', 'Gaji Pokok');
			$sheet->setCellValue('O1', 'Lembur 1 (Biasa)');
			$sheet->setCellValue('P1', 'Lembur 2 (Extra)');
			$sheet->setCellValue('Q1', 'Dinas 1 (Dalkot)');
			$sheet->setCellValue('R1', 'Dinas 2 (Luar Kota)');
			$sheet->setCellValue('S1', 'Target Omzet');
			$sheet->setCellValue('T1', 'Bonus 1 Tunjangan Jabatan');
			$sheet->setCellValue('U1', 'Bonus 2 Pulsa');
			$sheet->setCellValue('V1', 'Bonus 3 Tunjangan Prestasi');
			$sheet->setCellValue('W1', 'Iuran BPJS');
			$sheet->setCellValue('X1', 'TUNJANGAN HARI RAYA');
			$sheet->setCellValue('Y1', 'FASILITAS LAINNYA');
			$sheet->setCellValue('Z1', 'Potongan Per Hari Alpha');
			$sheet->setCellValue('AA1', 'Denda Keterlambatan per Jam');
			$sheet->setCellValue('AB1', 'Jumlah Cuti Diberikan');
			$sheet->setCellValue('AC1', 'KETERANGAN');
			$sheet->setCellValue('AD1', 'Masa Berlaku dalam Bulan');
			$sheet->setCellValue('AE1', 'Tanggal Mulai Kontrak Kerja');
			$sheet->setCellValue('AF1', 'Tanggal Berakhir Kontrak Kerja');
			$sheet->setCellValue('AG1', 'Resign');
			$sheet->setCellValue('AH1', 'SP 3');
			$sheet->setCellValue('AI1', 'Fee 1 (%) Bulanan A');
			$sheet->setCellValue('AJ1', 'Fee 2 (%) Triwulan A');
			$sheet->setCellValue('AK1', 'Fee 3 (%) Tahunan A');
			$sheet->setCellValue('AL1', 'Target Profit dalam % A');
			$sheet->setCellValue('AM1', 'Fee 1 (%) Bulanan B');
			$sheet->setCellValue('AN1', 'Fee 2 (%) Triwulan B');
			$sheet->setCellValue('AO1', 'Fee 3 (%) Tahunan B');
			$sheet->setCellValue('AP1', 'Target Profit dalam % B');
			$sheet->setCellValue('AQ1', 'Fee 1 (%) Bulanan C');
			$sheet->setCellValue('AR1', 'Fee 2 (%) Triwulan C');
			$sheet->setCellValue('AS1', 'Fee 3 (%) Tahunan C');
			$sheet->setCellValue('AT1', 'Target Profit dalam % C');
			$sheet->setCellValue('AU1', 'Fee 1 (%) Bulanan D');
			$sheet->setCellValue('AV1', 'Fee 2 (%) Triwulan D');
			$sheet->setCellValue('AW1', 'Fee 3 (%) Tahunan D');
			$sheet->setCellValue('AX1', 'Target Profit dalam % D');
			$sheet->setCellValue('AY1', 'Unit Kerja');

			$users_roles_contracts = $this->contract_model->read_contracts('', 'result_array', 'user,unit', 0, '', '', 0, ', users.name as employee_name, units.name as unit_name');;

			$number = 1;

			foreach($users_roles_contracts as &$user_role_contract)
			{
				$sheet->setCellValue('A'.($number + 1), $number);
				$sheet->setCellValue('B'.($number + 1), $user_role_contract['reference_number']);
				$sheet->setCellValue('C'.($number + 1), $user_role_contract['employee_name']);
				$sheet->setCellValue('D'.($number + 1), $user_role_contract['nickname']);
				$sheet->setCellValue('E'.($number + 1), $user_role_contract['user_status']);
				$sheet->setCellValueExplicit('F'.($number + 1), $user_role_contract['id_card_number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
				$sheet->setCellValue('G'.($number + 1), $user_role_contract['division']);
				$sheet->setCellValue('H'.($number + 1), $user_role_contract['position']);
				$sheet->setCellValue('I'.($number + 1), $user_role_contract['contract_type']);

				$user = $this->contract_model->read_users('', '', $user_role_contract['company_representative_user_id']);
				
				$sheet->setCellValue('J'.($number + 1), $user['name']);
				$sheet->setCellValue('K'.($number + 1), $user_role_contract['company_representative_division']);
				$sheet->setCellValue('L'.($number + 1), $user_role_contract['company_representative_position']);
				$sheet->setCellValue('M'.($number + 1), base_url('uploads/'.$user_role_contract['specific_period_work_agreement']));
				$sheet->setCellValue('N'.($number + 1), $user_role_contract['basic_salary']);
				$sheet->setCellValue('O'.($number + 1), $user_role_contract['regular_overtime_pay']);
				$sheet->setCellValue('P'.($number + 1), $user_role_contract['extra_overtime_pay']);
				$sheet->setCellValue('Q'.($number + 1), $user_role_contract['in_town_duty_per_diem']);
				$sheet->setCellValue('R'.($number + 1), $user_role_contract['out_town_duty_per_diem']);
				$sheet->setCellValue('S'.($number + 1), $user_role_contract['turnover_target']);
				$sheet->setCellValue('T'.($number + 1), $user_role_contract['positional_allowance']);
				$sheet->setCellValue('U'.($number + 1), $user_role_contract['credit_allowance']);
				$sheet->setCellValue('V'.($number + 1), $user_role_contract['performance_allowance']);
				$sheet->setCellValue('W'.($number + 1), $user_role_contract['insurance_allowance']);
				$sheet->setCellValue('X'.($number + 1), $user_role_contract['holiday_allowance']);
				//$sheet->setCellValue('Y'.($number + 1), $user_role_contract['']);
				$sheet->setCellValue('Y'.($number + 1), '');
				$sheet->setCellValue('Z'.($number + 1), $user_role_contract['absence_cuts_per_day']);
				$sheet->setCellValue('AA'.($number + 1), $user_role_contract['late_charge_per_hour']);
				$sheet->setCellValue('AB'.($number + 1), $user_role_contract['paid_leave_granted']);
				$sheet->setCellValue('AC'.($number + 1), $user_role_contract['notes']);

				$date_diff = date_diff(date_create($user_role_contract['effective_date']), date_create($user_role_contract['expiry_date']));
				
				$sheet->setCellValue('AD'.($number + 1), $date_diff->format('%y') * 12 + $date_diff->format('%m'));
				$sheet->setCellValue('AE'.($number + 1), substr($user_role_contract['effective_date'], -2).'-'.substr($user_role_contract['effective_date'], 5, 2).'-'.substr($user_role_contract['effective_date'], 0, 4));
				$sheet->setCellValue('AF'.($number + 1), substr($user_role_contract['expiry_date'], -2).'-'.substr($user_role_contract['expiry_date'], 5, 2).'-'.substr($user_role_contract['expiry_date'], 0, 4));

				if($user_role_contract['reason'] == '')
					$sheet->setCellValue('AG'.($number + 1), 'Aktif');
				else
					$sheet->setCellValue('AG'.($number + 1), $user_role_contract['reason']);
				
				$warning_letter = $this->contract_model->read_warning_letter($user_role_contract['contract_id'], 'SP 3');
				
				if(isset($warning_letter))
					$sheet->setCellValue('AH'.($number + 1), $warning_letter['cause']);
				else
					$sheet->setCellValue('AH'.($number + 1), 'Aktif');
				
				$sheet->setCellValue('AI'.($number + 1), $user_role_contract['monthly_fee_a']);
				$sheet->setCellValue('AJ'.($number + 1), $user_role_contract['quarterly_fee_a']);
				$sheet->setCellValue('AK'.($number + 1), $user_role_contract['annual_fee_a']);
				$sheet->setCellValue('AL'.($number + 1), $user_role_contract['profit_target_a']);
				$sheet->setCellValue('AM'.($number + 1), $user_role_contract['monthly_fee_b']);
				$sheet->setCellValue('AN'.($number + 1), $user_role_contract['quarterly_fee_b']);
				$sheet->setCellValue('AO'.($number + 1), $user_role_contract['annual_fee_b']);
				$sheet->setCellValue('AP'.($number + 1), $user_role_contract['profit_target_b']);
				$sheet->setCellValue('AQ'.($number + 1), $user_role_contract['monthly_fee_c']);
				$sheet->setCellValue('AR'.($number + 1), $user_role_contract['quarterly_fee_c']);
				$sheet->setCellValue('AS'.($number + 1), $user_role_contract['annual_fee_c']);
				$sheet->setCellValue('AT'.($number + 1), $user_role_contract['profit_target_c']);
				$sheet->setCellValue('AU'.($number + 1), $user_role_contract['monthly_fee_d']);
				$sheet->setCellValue('AV'.($number + 1), $user_role_contract['quarterly_fee_d']);
				$sheet->setCellValue('AW'.($number + 1), $user_role_contract['annual_fee_d']);
				$sheet->setCellValue('AX'.($number + 1), $user_role_contract['profit_target_d']);
				$sheet->setCellValue('AY'.($number + 1), $user_role_contract['unit_name']);

				$number++;
			}

			$sheet->getColumnDimension('A')->setAutoSize(true);
			$sheet->getColumnDimension('B')->setAutoSize(true);
			$sheet->getColumnDimension('C')->setAutoSize(true);
			$sheet->getColumnDimension('D')->setAutoSize(true);
			$sheet->getColumnDimension('E')->setAutoSize(true);
			$sheet->getColumnDimension('F')->setAutoSize(true);
			$sheet->getColumnDimension('G')->setAutoSize(true);
			$sheet->getColumnDimension('H')->setAutoSize(true);
			$sheet->getColumnDimension('I')->setAutoSize(true);
			$sheet->getColumnDimension('J')->setAutoSize(true);
			$sheet->getColumnDimension('K')->setAutoSize(true);
			$sheet->getColumnDimension('L')->setAutoSize(true);
			$sheet->getColumnDimension('M')->setAutoSize(true);
			$sheet->getColumnDimension('N')->setAutoSize(true);
			$sheet->getColumnDimension('O')->setAutoSize(true);
			$sheet->getColumnDimension('P')->setAutoSize(true);
			$sheet->getColumnDimension('Q')->setAutoSize(true);
			$sheet->getColumnDimension('R')->setAutoSize(true);
			$sheet->getColumnDimension('S')->setAutoSize(true);
			$sheet->getColumnDimension('T')->setAutoSize(true);
			$sheet->getColumnDimension('U')->setAutoSize(true);
			$sheet->getColumnDimension('V')->setAutoSize(true);
			$sheet->getColumnDimension('W')->setAutoSize(true);
			$sheet->getColumnDimension('X')->setAutoSize(true);
			$sheet->getColumnDimension('Y')->setAutoSize(true);
			$sheet->getColumnDimension('Z')->setAutoSize(true);
			$sheet->getColumnDimension('AA')->setAutoSize(true);
			$sheet->getColumnDimension('AB')->setAutoSize(true);
			$sheet->getColumnDimension('AC')->setAutoSize(true);
			$sheet->getColumnDimension('AD')->setAutoSize(true);
			$sheet->getColumnDimension('AE')->setAutoSize(true);
			$sheet->getColumnDimension('AF')->setAutoSize(true);
			$sheet->getColumnDimension('AG')->setAutoSize(true);
			$sheet->getColumnDimension('AH')->setAutoSize(true);
			$sheet->getColumnDimension('AI')->setAutoSize(true);
			$sheet->getColumnDimension('AJ')->setAutoSize(true);
			$sheet->getColumnDimension('AK')->setAutoSize(true);
			$sheet->getColumnDimension('AL')->setAutoSize(true);
			$sheet->getColumnDimension('AM')->setAutoSize(true);
			$sheet->getColumnDimension('AN')->setAutoSize(true);
			$sheet->getColumnDimension('AO')->setAutoSize(true);
			$sheet->getColumnDimension('AP')->setAutoSize(true);
			$sheet->getColumnDimension('AQ')->setAutoSize(true);
			$sheet->getColumnDimension('AR')->setAutoSize(true);
			$sheet->getColumnDimension('AS')->setAutoSize(true);
			$sheet->getColumnDimension('AT')->setAutoSize(true);
			$sheet->getColumnDimension('AU')->setAutoSize(true);
			$sheet->getColumnDimension('AV')->setAutoSize(true);
			$sheet->getColumnDimension('AW')->setAutoSize(true);
			$sheet->getColumnDimension('AX')->setAutoSize(true);
			$sheet->getColumnDimension('AY')->setAutoSize(true);
			
			$writer = new Xlsx($spreadsheet);
	
			$filename = 'Data Kontrak '.date("d-m-Y H.i").' WIB';
	
			header('Content-Type: application/vnd.ms-excel');
			header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
			header('Cache-Control: max-age=0');
			
			$writer->save('php://output'); // download file
	    }
	}
?>