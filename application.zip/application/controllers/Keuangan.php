<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	use PhpOffice\PhpSpreadsheet\Spreadsheet;
	use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
	
	class Keuangan extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}
        }
        
        public function pengajuan($funding_submission_id = 0)
	    {
			if($this->input->post('submit') != NULL)
			{
				$this->load->model('finance_model');
				
				if(!empty(array_filter($_FILES['proof_of_payments']['name'])))
				{
					$config['upload_path']		= './uploads/finance/submissions/';
					$config['allowed_types']	= '*';

					$this->load->library('upload', $config);
				}

				$uri = 'keuangan/pengajuan/';
	
				if($funding_submission_id > 0)
					$uri = $uri.$funding_submission_id;

				$proof_of_payments = '';
				
				if(!empty(array_filter($_FILES['proof_of_payments']['name'])))
				{ 
					foreach($_FILES['proof_of_payments']['name'] as $key=>$value)
					{
						$_FILES['proof_of_payment']['name'] = $_FILES['proof_of_payments']['name'][$key];
						$_FILES['proof_of_payment']['type'] = $_FILES['proof_of_payments']['type'][$key];
						$_FILES['proof_of_payment']['tmp_name'] = $_FILES['proof_of_payments']['tmp_name'][$key];
						$_FILES['proof_of_payment']['error'] = $_FILES['proof_of_payments']['error'][$key];
						$_FILES['proof_of_payment']['size'] = $_FILES['proof_of_payments']['size'][$key];

						if(!$this->upload->do_upload('proof_of_payment'))
						{
							$this->session->set_flashdata('error_messages', $this->upload->display_errors());
							
							redirect($uri);
						}
						else
						{
							if($proof_of_payments == '')
								$proof_of_payments = $this->upload->data('file_name');
							else
								$proof_of_payments = $proof_of_payments.','.$this->upload->data('file_name');
						}
					}
				}

				$this->finance_model->create_update_funding_submission($proof_of_payments, $funding_submission_id);

				$this->session->set_flashdata('operation_result', 'funding submission data saved');
				
				redirect($uri);
					
				/*$user_role = $this->employee_model->read_users_roles('', 2);
				
				$message = 'Yth. HRD JSO SMB,<br /><br />';
				$message = $message.'Terdapat data registrasi seleksi calon karyawan baru yang masuk untuk posisi & pilihan jadwal wawancara berikut:<br /><br />';
				$message = $message.'<b>Nama: '.$this->input->post('name').'<br />';
				$message = $message.'Alamat email: '.$this->input->post('email_address').'<br />';
				$message = $message.'Posisi & pilihan jadwal wawancara: '.$this->input->post('division').'</b><br /><br />';
				$message = $message.'Anda dapat melihat detail dari data registrasi tersebut pada <a href="'.base_url('vendor/pengajuan/'.rawurlencode($this->input->post('email_address'))).'" target="_blank">tautan ini</a>.<br /><br />';
				$message = $message.'Salam,<br />SISTER JSO SMB';

				$this->load->library('email');
				
				// Sending to an account, for activation (username, password)
				$this->email->from('sister.jsosmboffice@gmail.com', 'SISTER JSO');	
				$this->email->to($user_role['email_address']);

				//$this->email->cc('another@another-example.com');
				//$this->email->bcc('them@their-example.com');
				$this->email->subject('Data Registrasi Seleksi Calon Karyawan');
				$this->email->message($message);

				$this->email->send();*/
			}
			else
			{
				if(!$this->session->has_userdata('user_id'))
				{	
					$this->session->set_userdata('previous_url', current_url());
					
					redirect('otentikasi/masuk');
				}
				
				$this->load->helper('form');
				$this->load->model('employee_model');
				$this->load->model('finance_model');
				$this->load->model('unit_model');

				require 'Options.php';

				$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');
	
				if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'LOGISTIK' && $data['logged_in_user']['division'] != 'IT' && $data['logged_in_user']['division'] != 'HRD' && $data['logged_in_user']['division'] != 'FINANCE' && !($data['logged_in_user']['position'] == 'Manajer' && $data['logged_in_user']['division'] == 'MARKETING'))
					redirect();

				if($funding_submission_id < 1)
				{
					$header = 'Form Pengajuan Finance';
					
					$data['applicant_user_id'] = $this->session->userdata('user_id');
					$data['financing_code'] = 'Bebkantor (Telp; Speedy; Listrik; Uang Sampah)';
					$data['nominal'] = 100;
					$data['accountee'] = '';
					$data['bank'] = '';
					$data['account_number'] = '';
					$data['transfer_information'] = '';
					$data['payment_deadline'] = '';
					$data['other_details'] = '';
					$data['utilizing_unit_id'] = $data['logged_in_user']['unit_id'];
					$data['proof_of_payments'] = '';
					$data['status'] = 'Sudah Diajukan';
				}
				else
				{
					$header = 'Ubah Data Pengajuan Finance';
					
					$funding_submission_user_unit = $this->finance_model->read_funding_submissions_users_units('*', 0, 'row_array', $funding_submission_id);

					$data['applicant_user_id'] = $funding_submission_user_unit['applicant_user_id'];
					$data['financing_code'] = $funding_submission_user_unit['financing_code'];
					$data['nominal'] = $funding_submission_user_unit['nominal'];
					$data['accountee'] =  $funding_submission_user_unit['accountee'];
					$data['bank'] =  $funding_submission_user_unit['bank'];
					$data['account_number'] =  $funding_submission_user_unit['account_number'];
					$data['transfer_information'] = $funding_submission_user_unit['transfer_information'];
					$data['payment_deadline'] = $funding_submission_user_unit['payment_deadline'];
					$data['other_details'] = $funding_submission_user_unit['other_details'];
					$data['utilizing_unit_id'] = $funding_submission_user_unit['utilizing_unit_id'];
					$data['proof_of_payments'] = explode(',', $funding_submission_user_unit['proof_of_payments']);
					$data['event_id'] = $funding_submission_user_unit['event_id'];
					$data['receiver_user_id'] = $funding_submission_user_unit['receiver_user_id'];
					$data['vendor_id'] = $funding_submission_user_unit['vendor_id'];
					$data['order_id'] = $funding_submission_user_unit['order_id'];
					$data['inventory_item'] = $funding_submission_user_unit['inventory_item'];
					$data['inventory_item_quantity'] = $funding_submission_user_unit['inventory_item_quantity'];
					$data['inventory_item_unit'] = $funding_submission_user_unit['inventory_item_unit'];
					$data['it_data_id'] = $funding_submission_user_unit['it_data_id'];
					$data['status'] = $funding_submission_user_unit['status'];
				}
                    
				$data['title'] = ':: Sister JSO :: '.$header;
				
				$data['vendor_css_links'] = array(
					'bootstrap/css/bootstrap.min.css',
					'font-awesome/css/font-awesome.min.css',
					'animate-css/animate.min.css',
					'bootstrap-multiselect/bootstrap-multiselect.css',
					'bootstrap-datepicker/css/bootstrap-datepicker3.min.css',
					'bootstrap-colorpicker/css/bootstrap-colorpicker.css',
					'multi-select/css/multi-select.css',
					'bootstrap-tagsinput/bootstrap-tagsinput.css',
					'nouislider/nouislider.min.css',
					'toastr/toastr.min.css',
                    'dropify/css/dropify.min.css'
                );
				
				$data['header'] = $header;
				$data['controller_link'] = base_url('keuangan/');
				
				if(($data['logged_in_user']['division'] == 'MARKETING') && ($data['logged_in_user']['position'] == 'Manajer'))
					$data['financing_codes'] = array(
						'Honor Instruktur 1' => 'Honor Instruktur 1',
						'Honor Instruktur 2' => 'Honor Instruktur 2',
						'Sertifikasi / Kunjungan' => 'Sertifikasi / Kunjungan',
						'Meeting Room' => 'Meeting Room',
						'Akomodasi Peserta' => 'Akomodasi Peserta',
						'Akomodasi Instruktur' => 'Akomodasi Instruktur',
						'Akomodasi Tim' => 'Akomodasi Tim',
						'Transportasi Peserta' => 'Transportasi Peserta',
						'Transportasi Instruktur' => 'Transportasi Instruktur',
						'City Tour' => 'City Tour',
						'Transportasi Tim' => 'Transportasi Tim',
						'Modul' => 'Modul',
						'Dokumentasi' => 'Dokumentasi',
						'Spanduk' => 'Spanduk',
						'Sewa' => 'Sewa',
						'Pengiriman' => 'Pengiriman',
						'Fee Agent' => 'Fee Agent',
						'Fee Driver' => 'Fee Driver',
						'Fee CS' => 'Fee CS',
						'Lunch / Dinner' => 'Lunch / Dinner',
						'Operasional' => 'Operasional'
					);
				else if($data['logged_in_user']['division'] == 'LOGISTIK')
					$data['financing_codes'] = array(
						'Kit (DP; Pelunasan; Training kit)' => 'Kit (DP; Pelunasan; Training kit)',
						'Inventaris (Pengadaan Barang Inventaris Perusahaan)' => 'Inventaris (Pengadaan Barang Inventaris Perusahaan)',
						//'ServisPer (Service Peralatan Kantor : PC, Laptop, Kamera, dll) & ServisKen (Service Kendaraan Kantor)' => 'ServisPer (Service Peralatan Kantor : PC, Laptop, Kamera, dll) & ServisKen (Service Kendaraan Kantor)'
					);
				else if($data['logged_in_user']['division'] == 'IT')
					$data['financing_codes'] = array(
						'IT (Hostdomain; Software)' => 'IT (Hostdomain; Software)'
					);
				
				$data['financing_codes']['Logistik (Bensin Kendaraan Kantor; ATK)'] = 'Logistik (Bensin Kendaraan Kantor; ATK)';
				$data['financing_codes']['Outing (Gathering; Sayembara) & CSR (Sumbangan)'] = 'Outing (Gathering; Sayembara) & CSR (Sumbangan)';
				$data['financing_codes']['Pulsa (Go-Jek; Pulsa HP Kantor)'] = 'Pulsa (Go-Jek; Pulsa HP Kantor)';
				$data['financing_codes']['Bebkantor (Telp; Speedy; Listrik; Uang Sampah)'] = 'Bebkantor (Telp; Speedy; Listrik; Uang Sampah)';

				if($data['financing_code'] == 'Honor Instruktur 1' || $data['financing_code'] == 'Honor Instruktur 2' || $data['financing_code'] == 'Sertifikasi / Kunjungan' || $data['financing_code'] == 'Meeting Room' || $data['financing_code'] == 'Akomodasi Peserta' || $data['financing_code'] == 'Akomodasi Instruktur' || $data['financing_code'] == 'Akomodasi Tim' || $data['financing_code'] == 'Transportasi Peserta' || $data['financing_code'] == 'Transportasi Instruktur' || $data['financing_code'] == 'City Tour' || $data['financing_code'] == 'Transportasi Tim' || $data['financing_code'] == 'Modul' || $data['financing_code'] == 'Dokumentasi' || $data['financing_code'] == 'Spanduk' || $data['financing_code'] == 'Sewa' || $data['financing_code'] == 'Pengiriman' || $data['financing_code'] == 'Fee Agent' || $data['financing_code'] == 'Fee Driver' || $data['financing_code'] == 'Fee CS' || $data['financing_code'] == 'Lunch / Dinner' || $data['financing_code'] == 'Operasional')
				{
					$events_units_users_clients = $this->finance_model->read_events_units_users_clients('event_id, events.name as event_name, start_date, end_date, units.name as unit_name, users.name as marketing_name, clients.company as client_company', 'unit,user,client', $data['logged_in_user']['unit_id']);
					
					foreach($events_units_users_clients as &$event_unit_user_client)
					{
						$data['events'][$event_unit_user_client['event_id']] = $event_unit_user_client['event_name'].' ('.substr($event_unit_user_client['start_date'], -2).'/'.substr($event_unit_user_client['start_date'], 5, 2).'/'.substr($event_unit_user_client['start_date'], 0, 4).' - '.substr($event_unit_user_client['end_date'], -2).'/'.substr($event_unit_user_client['end_date'], 5, 2).'/'.substr($event_unit_user_client['end_date'], 0, 4).') '.$event_unit_user_client['unit_name'].' by '.$event_unit_user_client['marketing_name'].' | '.$event_unit_user_client['client_company'];
					}

					$unit = $this->unit_model->read_units('unit_id, name', 'row_array', '', 0, $data['logged_in_user']['unit_id']);
					
					$data['units'][$unit['unit_id']] = $unit['name'];

					if($data['financing_code'] == 'Honor Instruktur 2' || $data['financing_code'] == 'Sertifikasi / Kunjungan')
					{
						$instructor_list = $this->finance_model->read_users_roles_contracts('INSTRUKTUR');

						foreach($instructor_list as &$instructor)
						{
							$data['instructors'][$instructor['user_id']] = $instructor['name'];
						}
					}
					else if($data['financing_code'] == 'Akomodasi Peserta' || $data['financing_code'] == 'Akomodasi Instruktur' || $data['financing_code'] == 'Akomodasi Tim' || $data['financing_code'] == 'Transportasi Instruktur' || $data['financing_code'] == 'City Tour' || $data['financing_code'] == 'Transportasi Tim' || $data['financing_code'] == 'Modul' || $data['financing_code'] == 'Dokumentasi' || $data['financing_code'] == 'Spanduk' || $data['financing_code'] == 'Sewa' || $data['financing_code'] == 'Pengiriman')
					{
						$this->load->model('vendor_model');
						
						if($data['financing_code'] == 'Akomodasi Peserta' || $data['financing_code'] == 'Akomodasi Instruktur' || $data['financing_code'] == 'Akomodasi Tim')
							$type = 'Hotel';
						else if($data['financing_code'] == 'Transportasi Instruktur' || $data['financing_code'] == 'City Tour' || $data['financing_code'] == 'Transportasi Tim')
							$type = 'Transportasi';
						else if($data['financing_code'] == 'Modul' || $data['financing_code'] == 'Spanduk')
							$type = 'Percetakan';
						else if($data['financing_code'] == 'Dokumentasi')
							$type = 'Dokumentasi';
						else if($data['financing_code'] == 'Sewa')
							$type = 'Laptop / LCD / Proyektor';
						else
							$type = 'Jasa Kurir';
						
						$users_vendors = $this->vendor_model->read_users_vendors('user', 0, 'result_array', '', 0, $type);

						foreach($users_vendors as &$user_vendor)
						{
							$data['vendors'][$user_vendor['vendor_id']] = $user_vendor['name'];
						}
					}
				}
				else if($data['financing_code'] == 'Kit (DP; Pelunasan; Training kit)')
				{
					$this->load->model('order_model');
					
					//$orders = $this->order_model->read_users_orders('*, users.name as vendor_name', 0, 0, 'row_array', '', $order_id);
					$orders = $this->order_model->read_users_orders('*, users.name as vendor_name');
					
					foreach($orders as &$order)
					{
						$data['grn_list'][$order['order_id']] = $order['vendor_name'].'/'.$order['total_bill'].'/'.$order['item'].' : '.$order['quantity'].' : '.$order['price'].'. Order Tgl '.substr($order['order_date'], -2).'/'.substr($order['order_date'], 5, 2).'/'.substr($order['order_date'], 0, 4).' - Selesai '.substr($order['estimated_completion_date'], -2).'/'.substr($order['estimated_completion_date'], 5, 2).'/'.substr($order['estimated_completion_date'], 0, 4);
					}

					$order = $this->order_model->read_users_orders('orders.unit_id as unit_id, units.name as name', 0, 0, 'row_array', '', $data['order_id']);
						
					$data['units'][$order['unit_id']] = $order['name'];
				}
				else if(($data['financing_code'] == 'IT (Hostdomain; Software)') || ($data['financing_code'] == 'Pulsa (Go-Jek; Pulsa HP Kantor)'))
				{
					$this->load->model('it_model');
					
					if($data['financing_code'] == 'IT (Hostdomain; Software)')
					{
						$it_data_list = $this->it_model->read_it_data('it_data_id, data_name', 0, 'Domain');

						if(!empty($it_data_list))
						{
							foreach($it_data_list as &$it_datum)
							{
								$data['it_data'][$it_datum['it_data_id']] = 'Domain '.$it_datum['data_name'];
							}
						}
						
						$it_data_list = $this->it_model->read_it_data('it_data_id, data_name', 0, 'Hosting');

						if(!empty($it_data_list))
						{
							foreach($it_data_list as &$it_datum)
							{
								$data['it_data'][$it_datum['it_data_id']] = 'Hosting '.$it_datum['data_name'];
							}
						}
					}
					else
					{
						$it_data_list = $this->it_model->read_it_data('it_data_id, mobile_number', 0, 'Nomor HP/Telepon');
						
						foreach($it_data_list as &$it_datum)
						{
							$data['it_data'][$it_datum['it_data_id']] = $it_datum['mobile_number'];
						}
					}

					$it_data = $this->it_model->read_it_data('it_data.unit_id as unit_id, name', 0, '', '', 'row_array', '', 0, $data['it_data_id']);
						
					$data['units'][$it_data['unit_id']] = $it_data['name'];
				}
				else if(($data['financing_code'] == 'Logistik (Bensin Kendaraan Kantor; ATK)') || ($data['financing_code'] == 'Inventaris (Pengadaan Barang Inventaris Perusahaan)') || ($data['financing_code'] == 'Bebkantor (Telp; Speedy; Listrik; Uang Sampah)'))
				{
					$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
					
					foreach($unit_list as &$unit)
					{
						$units[$unit['unit_id']] = $unit['name'];
					}

					$data['units'] = $units;
				}

				$data['statuses'] = array(
					'Sudah Diajukan' => 'Sudah Diajukan',
					'Sudah Diproses' => 'Sudah Diproses',
					'Sudah Di-DP' => 'Sudah Di-DP',
					'Sudah Lunas' => 'Sudah Lunas',
					'Butuh Perbaikan' => 'Butuh Perbaikan'
				);
				
				$data['js_links'] = array(
					'assets/bundles/libscripts.bundle.js',
					'assets/bundles/vendorscripts.bundle.js',
					'vendor/bootstrap-colorpicker/js/bootstrap-colorpicker.js',
					'vendor/jquery-inputmask/jquery.inputmask.bundle.js',
					'vendor/jquery-mask/jquery.mask.min.js',
					'vendor/multi-select/js/jquery.multi-select.js',
					'vendor/bootstrap-multiselect/bootstrap-multiselect.js',
					'vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js',
					'vendor/bootstrap-tagsinput/bootstrap-tagsinput.js',
					'vendor/nouislider/nouislider.js',
					'vendor/toastr/toastr.js',
                    'vendor/dropify/js/dropify.min.js',
					'assets/bundles/mainscripts.bundle.js',
					'assets/js/pages/forms/advanced-form-elements.js',
                    'assets/js/pages/forms/dropify.js',
					'assets/js/pages/finance/create_update.js'
				);

				// Render view on main layout
				$this->load->view('templates/dashboard/top', $data);
				$this->load->view('pages/finance/create_update/static_content', $data);
				$this->load->view('templates/dashboard/bottom', $data);
			}
	    }
		
	    public function detail_penggunaan()
	    {
			$this->load->helper('form');

			$financing_code = urldecode($this->input->get('kode'));

			$data['field']['label_text'][1] = '';
			$data['field']['label_text'][2] = '';
			$data['field']['label_text'][3] = '';

			if($financing_code == 'Honor Instruktur 1' || $financing_code == 'Honor Instruktur 2' || $financing_code == 'Sertifikasi / Kunjungan' || $financing_code == 'Meeting Room' || $financing_code == 'Akomodasi Peserta' || $financing_code == 'Akomodasi Instruktur' || $financing_code == 'Akomodasi Tim' || $financing_code == 'Transportasi Peserta' || $financing_code == 'Transportasi Instruktur' || $financing_code == 'City Tour' || $financing_code == 'Transportasi Tim' || $financing_code == 'Modul' || $financing_code == 'Dokumentasi' || $financing_code == 'Spanduk' || $financing_code == 'Sewa' || $financing_code == 'Pengiriman' || $financing_code == 'Fee Agent' || $financing_code == 'Fee Driver' || $financing_code == 'Fee CS' || $financing_code == 'Lunch / Dinner' || $financing_code == 'Operasional')
			{
				$this->load->model('employee_model');
				$this->load->model('finance_model');
				
				$logged_in_user = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

				$data['field']['label_text'][1] = 'Kegiatan';

				$data['field']['id'][1] = 'event-id-select';

				$data['field']['onchange'][1] = 'setUnitOptions()';

				$data['field']['type'][1] = 'select';

				$data['field']['name'][1] = 'event_id';

				$events_units_users_clients = $this->finance_model->read_events_units_users_clients('event_id, events.name as event_name, start_date, end_date, units.name as unit_name, users.name as marketing_name, clients.company as client_company', 'unit,user,client', $logged_in_user['unit_id']);
				
				foreach($events_units_users_clients as &$event_unit_user_client)
				{
					$events[$event_unit_user_client['event_id']] = $event_unit_user_client['event_name'].' ('.substr($event_unit_user_client['start_date'], -2).'/'.substr($event_unit_user_client['start_date'], 5, 2).'/'.substr($event_unit_user_client['start_date'], 0, 4).' - '.substr($event_unit_user_client['end_date'], -2).'/'.substr($event_unit_user_client['end_date'], 5, 2).'/'.substr($event_unit_user_client['end_date'], 0, 4).') '.$event_unit_user_client['unit_name'].' by '.$event_unit_user_client['marketing_name'].' | '.$event_unit_user_client['client_company'];
				}
				
				$data['field']['options'][1] = $events;
				
				$data['field']['selected'][1] = $event_unit_user_client['event_id'];

				if($financing_code == 'Honor Instruktur 2' || $financing_code == 'Sertifikasi / Kunjungan')
				{
					$data['field']['label_text'][2] = 'Instruktur';

					$data['field']['id'][2] = 'receiver-user-id-select';

					$data['field']['onchange'][2] = 'setBankAccount()';

					$data['field']['type'][2] = 'select';

					$data['field']['name'][2] = 'receiver_user_id';

					$instructor_list = $this->finance_model->read_users_roles_contracts('INSTRUKTUR');

					foreach($instructor_list as &$instructor)
					{
						$instructors[$instructor['user_id']] = $instructor['name'];
					}
					
					$data['field']['options'][2] = $instructors;
					
					$data['field']['selected'][2] = $instructor['user_id'];
				}
				else if($financing_code == 'Akomodasi Peserta' || $financing_code == 'Akomodasi Instruktur' || $financing_code == 'Akomodasi Tim' || $financing_code == 'Transportasi Instruktur' || $financing_code == 'City Tour' || $financing_code == 'Transportasi Tim' || $financing_code == 'Modul' || $financing_code == 'Dokumentasi' || $financing_code == 'Spanduk' || $financing_code == 'Sewa' || $financing_code == 'Pengiriman')
				{
					$this->load->model('vendor_model');

					$data['field']['label_text'][2] = 'Vendor';

					$data['field']['id'][2] = 'vendor-id-select';

					$data['field']['onchange'][2] = 'setBankAccount()';

					$data['field']['type'][2] = 'select';

					$data['field']['name'][2] = 'vendor_id';
						
					if($financing_code == 'Akomodasi Peserta' || $financing_code == 'Akomodasi Instruktur' || $financing_code == 'Akomodasi Tim')
						$type = 'Hotel';
					else if($financing_code == 'Transportasi Instruktur' || $financing_code == 'City Tour' || $financing_code == 'Transportasi Tim')
						$type = 'Transportasi';
					else if($financing_code == 'Modul' || $financing_code == 'Spanduk')
						$type = 'Percetakan';
					else if($financing_code == 'Dokumentasi')
						$type = 'Dokumentasi';
					else if($financing_code == 'Sewa')
						$type = 'Laptop / LCD / Proyektor';
					else
						$type = 'Jasa Kurir';

					$users_vendors = $this->vendor_model->read_users_vendors('user', 0, 'result_array', '', 0, $type);

					foreach($users_vendors as &$user_vendor)
					{
						$vendors[$user_vendor['vendor_id']] = $user_vendor['name'];
					}
					
					$data['field']['options'][2] = $vendors;
					
					$data['field']['selected'][2] = $user_vendor['vendor_id'];
				}
			}
			else if($financing_code == 'Kit (DP; Pelunasan; Training kit)')
			{
				$this->load->model('order_model');
				
				$data['field']['label_text'][1] = 'GRN';

				$data['field']['id'][1] = 'order-id-select';

				$data['field']['onchange'][1] = 'setUnitOptions()';

				$data['field']['type'][1] = 'select';

				$data['field']['name'][1] = 'order_id';

				$orders = $this->order_model->read_users_orders('*, users.name as vendor_name');
				
				foreach($orders as &$order)
				{
					$grn_list[$order['order_id']] = $order['vendor_name'].'/'.$order['total_bill'].'/'.$order['item'].' : '.$order['quantity'].' : '.$order['price'].'. Order Tgl '.substr($order['order_date'], -2).'/'.substr($order['order_date'], 5, 2).'/'.substr($order['order_date'], 0, 4).' - Selesai '.substr($order['estimated_completion_date'], -2).'/'.substr($order['estimated_completion_date'], 5, 2).'/'.substr($order['estimated_completion_date'], 0, 4);
				}
				
				$data['field']['options'][1] = $grn_list;
				
				$data['field']['selected'][1] = $order['order_id'];
			}
			else if(($financing_code == 'IT (Hostdomain; Software)') || ($financing_code == 'Pulsa (Go-Jek; Pulsa HP Kantor)'))
			{
				$this->load->model('it_model');
				
				if($financing_code == 'IT (Hostdomain; Software)')
					$data['field']['label_text'][1] = 'Nama Domain/ Hosting';
				else
					$data['field']['label_text'][1] = 'Nomor Telepon';

				$data['field']['id'][1] = 'it-data-id-select';

				$data['field']['onchange'][1] = 'setUnitOptions()';

				$data['field']['type'][1] = 'select';

				$data['field']['name'][1] = 'it_data_id';

				if($financing_code == 'IT (Hostdomain; Software)')
				{
					$it_data_list = $this->it_model->read_it_data('it_data_id, data_name', 0, 'Domain');

					if(!empty($it_data_list))
					{
						foreach($it_data_list as &$it_datum)
						{
							$it_data[$it_datum['it_data_id']] = 'Domain '.$it_datum['data_name'];
						}
					}
					
					$it_data_list = $this->it_model->read_it_data('it_data_id, data_name', 0, 'Hosting');

					if(!empty($it_data_list))
					{
						foreach($it_data_list as &$it_datum)
						{
							$it_data[$it_datum['it_data_id']] = 'Hosting '.$it_datum['data_name'];
						}
					}
				}
				else
				{
					$it_data_list = $this->it_model->read_it_data('it_data_id, mobile_number', 0, 'Nomor HP/Telepon');
					
					foreach($it_data_list as &$it_datum)
					{
						$it_data[$it_datum['it_data_id']] = $it_datum['mobile_number'];
					}
				}
				
				$data['field']['options'][1] = $it_data;
				
				$data['field']['selected'][1] = $it_datum['it_data_id'];
			}
			else if($financing_code == 'Inventaris (Pengadaan Barang Inventaris Perusahaan)')
			{
				$data['field']['label_text'][1] = 'Nama Item';
				$data['field']['label_text'][2] = 'Jumlah';
				$data['field']['label_text'][3] = 'Satuan';

				$data['field']['id'][1] = 'inventory-item-input';
				$data['field']['id'][2] = 'inventory-item-quantity-input';
				$data['field']['id'][3] = 'inventory-item-unit-input';

				$data['field']['type'][1] = 'text';
				$data['field']['type'][2] = 'number';
				$data['field']['type'][3] = 'text';

				$data['field']['name'][1] = 'inventory_item';
				$data['field']['name'][2] = 'inventory_item_quantity';
				$data['field']['name'][3] = 'inventory_item_unit';
			}
			
			echo $this->load->view('pages/finance/create_update/utilization_details', $data, TRUE);
		}
	    
		public function rekening_bank($reference, $reference_id)
		{
			$response_type = 'bank_account';

			if($reference == 'event' || $reference == 'it' || $reference == 'user')
			{
				$this->load->model('finance_model');

				if($reference == 'event' || $reference == 'it')
				{
					$this->load->model('vendor_model');
					
					if($reference == 'event')
					{
						$this->load->model('event_model');
				
						$reference_data = $this->event_model->read_events_vendors_clients(urldecode($this->input->get('columns')), '', 0, 'row_array', '', '', $reference_id);

						if(urldecode($this->input->get('columns')) == 'per_unit_agent_fee as per_unit_budget, agent_quantity as quantity' || urldecode($this->input->get('columns')) == 'per_unit_meal_budget as per_unit_budget, meal_quantity as quantity' || urldecode($this->input->get('columns')) == 'per_unit_operational_budget as per_unit_budget, operational_quantity as quantity')
							$response_type = 'submission_limit';
						else
							$response_type = 'composite';
						
						$response['submission_limit'] = $reference_data['per_unit_budget'] * $reference_data['quantity'];
					}
					else
					{
						$this->load->model('it_model');
						
						$reference_data = $this->it_model->read_it_data('vendor_id', 0, '', '', 'row_array', '', 0, $reference_id);
					}
						
					if(urldecode($this->input->get('columns')) == 'hotel_vendor_id as vendor_id, per_unit_meeting_room_budget as per_unit_budget, meeting_room_quantity as quantity' || urldecode($this->input->get('columns')) == 'transportation_vendor_id as vendor_id, per_unit_participant_transportation_budget as per_unit_budget, participant_transportation_quantity as quantity' || $this->input->get('vendor_id') != NULL || $reference == 'it')
					{
						if(urldecode($this->input->get('columns')) == 'hotel_vendor_id as vendor_id, per_unit_meeting_room_budget as per_unit_budget, meeting_room_quantity as quantity' || urldecode($this->input->get('columns')) == 'transportation_vendor_id as vendor_id, per_unit_participant_transportation_budget as per_unit_budget, participant_transportation_quantity as quantity' || $reference == 'it')
							$vendor_id = $reference_data['vendor_id'];
						else
							$vendor_id = $this->input->get('vendor_id');
						
						$vendor = $this->vendor_model->read_users_vendors('', 0, 'row_array', '', $vendor_id);
						
						$reference_id = $vendor['user_id'];
					}
					else if($this->input->get('receiver_user_id') != NULL)
						$reference_id = $this->input->get('receiver_user_id');
					else
						$reference_id = $reference_data['user_id'];
				}
				
				$user = $this->finance_model->read_users('accountee, bank, account_number', $reference_id);
			}
			else if($reference == 'order')
			{
				$this->load->model('order_model');
				
				$user = $this->order_model->read_users_orders('accountee, bank, account_number', 0, 0, 'row_array', '', $reference_id);
			}

			$response['bank_account'] = $user['accountee'].';'.$user['bank'].';'.$user['account_number'];
			
			if($response_type == 'composite')
				$response['composite'] = $response['bank_account'].';'.$response['submission_limit'];

			echo $response[$response_type];
        }
	    
		public function opsi_unit($reference, $reference_id = 0)
		{
			if($reference == 'order')
			{
				$this->load->model('order_model');
				
				$order_unit = $this->order_model->read_users_orders('orders.unit_id as unit_id, units.name as name', 0, 0, 'row_array', '', $reference_id);
					
				$options = '<option value="'.$order_unit['unit_id'].'">'.$order_unit['name'].'</option>';
			}
			else if($reference == 'unit')
			{
				$this->load->model('unit_model');

				$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');

				$options = '';
				
				foreach($unit_list as &$unit)
				{
					$options = $options.'<option value="'.$unit['unit_id'].'">'.$unit['name'].'</option>';
				}
			}
			else if($reference == 'it')
			{
				$this->load->model('it_model');
				
				$it_data_unit = $this->it_model->read_it_data('it_data.unit_id as unit_id, name', 0, '', '', 'row_array', '', 0, $reference_id);
				
				$options = '<option value="'.$it_data_unit['unit_id'].'">'.$it_data_unit['name'].'</option>';
			}
			else if($reference == 'user')
			{
				$this->load->model('finance_model');
				
				$contract_unit = $this->finance_model->read_contract_unit($reference_id);
				
				$options = '<option value="'.$contract_unit['unit_id'].'">'.$contract_unit['name'].'</option>';
			}

			echo $options;
        }

		public function daftar_transfer()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->helper('form');

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			if($this->session->userdata('user_id') != 1 && $data['logged_in_user']['division'] != 'LOGISTIK' && $data['logged_in_user']['division'] != 'IT' && $data['logged_in_user']['division'] != 'HRD' && $data['logged_in_user']['division'] != 'FINANCE' && !($data['logged_in_user']['position'] == 'Manajer' && $data['logged_in_user']['division'] == 'MARKETING'))
				redirect();

			$data['title'] = ':: Sister JSO :: Daftar Transfer';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'assets/js/pages/finance/transfer_list.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/finance/transfer_list/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		public function data_pengajuan($page_number)
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('finance_model');
			$this->load->model('unit_model');
			$this->load->helper('form');

			$data['filter_columns'] = array(
				'funding_submissions.status' => 'Status Pengajuan'
			);
			
			if($this->input->get('division') == 'FINANCE')
			{
				$data['filter_columns']['funding_submissions.utilizing_unit_id'] = 'Penggunaan untuk unit apa?';
				$data['filter_columns']['financing_code'] = 'Kode Pembiayaan';
			}

			$data['filter_column'] = urldecode($this->input->get('filter_column'));

			if($data['filter_column'] == 'funding_submissions.status')
			{
				$data['label'] = 'Status Pengajuan';

				$data['filter_values'] = array(
					'' => 'Semua Status',
					'Sudah Diajukan' => 'Sudah Diajukan',
					'Sudah Diproses' => 'Sudah Diproses',
					'Sudah Di-DP' => 'Sudah Di-DP',
					'Sudah Lunas' => 'Sudah Lunas',
					'Butuh Perbaikan' => 'Butuh Perbaikan'
				);
			}
			else if($data['filter_column'] == 'funding_submissions.utilizing_unit_id')
			{
				$data['label'] = 'Penggunaan untuk unit apa?';

				$units[''] = 'Semua Unit';

				$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
				
				foreach($unit_list as &$unit)
				{
					$units[$unit['unit_id']] = $unit['name'];
				}

				$data['filter_values'] = $units;
			}
			else
			{
				$data['label'] = 'Kode Pembiayaan';
				
				$data['filter_values'] = array(
					'' => 'Semua Kode',
					'Honor Instruktur 1' => 'Honor Instruktur 1',
					'Honor Instruktur 2' => 'Honor Instruktur 2',
					'Sertifikasi / Kunjungan' => 'Sertifikasi / Kunjungan',
					'Meeting Room' => 'Meeting Room',
					'Akomodasi Peserta' => 'Akomodasi Peserta',
					'Akomodasi Instruktur' => 'Akomodasi Instruktur',
					'Akomodasi Tim' => 'Akomodasi Tim',
					'Transportasi Peserta' => 'Transportasi Peserta',
					'Transportasi Instruktur' => 'Transportasi Instruktur',
					'City Tour' => 'City Tour',
					'Transportasi Tim' => 'Transportasi Tim',
					'Modul' => 'Modul',
					'Dokumentasi' => 'Dokumentasi',
					'Spanduk' => 'Spanduk',
					'Sewa' => 'Sewa',
					'Pengiriman' => 'Pengiriman',
					'Fee Agent' => 'Fee Agent',
					'Fee Driver' => 'Fee Driver',
					'Fee CS' => 'Fee CS',
					'Lunch / Dinner' => 'Lunch / Dinner',
					'Operasional' => 'Operasional',
					'Kit (DP; Pelunasan; Training kit)' => 'Kit (DP; Pelunasan; Training kit)',
					'Logistik (Bensin Kendaraan Kantor; ATK)' => 'Logistik (Bensin Kendaraan Kantor; ATK)',
					'Inventaris (Pengadaan Barang Inventaris Perusahaan)' => 'Inventaris (Pengadaan Barang Inventaris Perusahaan)',
					'IT (Hostdomain; Software)' => 'IT (Hostdomain; Software)',
					//'ServisPer (Service Peralatan Kantor : PC, Laptop, Kamera, dll) & ServisKen (Service Kendaraan Kantor)' => 'ServisPer (Service Peralatan Kantor : PC, Laptop, Kamera, dll) & ServisKen (Service Kendaraan Kantor)',
					'Outing (Gathering; Sayembara) & CSR (Sumbangan)' => 'Outing (Gathering; Sayembara) & CSR (Sumbangan)',
					'Pulsa (Go-Jek; Pulsa HP Kantor)' => 'Pulsa (Go-Jek; Pulsa HP Kantor)',
					'Bebkantor (Telp; Speedy; Listrik; Uang Sampah)' => 'Bebkantor (Telp; Speedy; Listrik; Uang Sampah)'
				);
			}

			$data['filter_value'] = urldecode($this->input->get('filter_value'));
			$data['ordering_column'] = urldecode($this->input->get('ordering_column'));

			$data['funding_submissions_users_units'] = $this->finance_model->read_funding_submissions_users_units('funding_submission_id, submission_date, users.name as applicant_name, financing_code, nominal, funding_submissions.account_number, funding_submissions.bank, funding_submissions.accountee, transfer_information, payment_deadline, units.name as unit_name', $page_number);
			$data['page_number'] = $page_number;
            
			$page_count = ceil($this->finance_model->read_funding_submissions_users_units('*', 0, 'num_rows') / 5);

			$data['page_count'] = $page_count;

			if($page_count > 1)
			{
				if($page_count > 10)
				{
					if($page_number > 6)
					{
						if(($page_count - $page_number) >= 4)
							$next_page_count = 4;
						else
							$next_page_count = $page_count - $page_number;
						
						$previous_page_count = 9 - $next_page_count;
					}
					else
					{
						$previous_page_count = $page_number - 1;
						$next_page_count = 9 - $previous_page_count;
					}
				}
				else
				{
					$previous_page_count = $page_number - 1;
					$next_page_count = $page_count - $page_number;
				}

				$data['previous_page_count'] = $previous_page_count;
				$data['next_page_count'] = $next_page_count;
			}

			echo $this->load->view('pages/finance/transfer_list/dynamic_content', $data, TRUE);
		}
	    
		public function opsi_nilai_filter_pengajuan($filter_column)
		{
			$options = '';
			
			if(urldecode($filter_column) == 'funding_submissions.status')
			{
				$options = $options.'<option value="">Semua Status</option>';
				
				$filter_values = array(
					'Sudah Diajukan',
					'Sudah Diproses',
					'Sudah Di-DP',
					'Sudah Lunas',
					'Butuh Perbaikan'
				);
				
				foreach($filter_values as &$filter_value)
				{
					$options = $options.'<option value="'.$filter_value.'">'.$filter_value.'</option>';
				}
			}
			else if(urldecode($filter_column) == 'funding_submissions.utilizing_unit_id')
			{
				$this->load->model('unit_model');

				$options = $options.'<option value="">Semua Unit</option>';

				$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
				
				foreach($unit_list as &$unit)
				{
					$options = $options.'<option value="'.$unit['unit_id'].'">'.$unit['name'].'</option>';
				}
			}
			else
			{
				$options = $options.'<option value="">Semua Kode</option>';
				
				$filter_values = array(
					'Honor Instruktur 1',
					'Honor Instruktur 2',
					'Sertifikasi / Kunjungan',
					'Meeting Room',
					'Akomodasi Peserta',
					'Akomodasi Instruktur',
					'Akomodasi Tim',
					'Transportasi Peserta',
					'Transportasi Instruktur',
					'City Tour',
					'Transportasi Tim',
					'Modul',
					'Dokumentasi',
					'Spanduk',
					'Sewa',
					'Pengiriman',
					'Fee Agent',
					'Fee Driver',
					'Fee CS',
					'Lunch / Dinner',
					'Operasional',
					'Kit (DP; Pelunasan; Training kit)',
					'Logistik (Bensin Kendaraan Kantor; ATK)',
					'Inventaris (Pengadaan Barang Inventaris Perusahaan)',
					'IT (Hostdomain; Software)',
					//'ServisPer (Service Peralatan Kantor : PC, Laptop, Kamera, dll) & ServisKen (Service Kendaraan Kantor)' => 'ServisPer (Service Peralatan Kantor : PC, Laptop, Kamera, dll) & ServisKen (Service Kendaraan Kantor)',
					'Outing (Gathering; Sayembara) & CSR (Sumbangan)',
					'Pulsa (Go-Jek; Pulsa HP Kantor)',
					'Bebkantor (Telp; Speedy; Listrik; Uang Sampah)'
				);
				
				foreach($filter_values as &$filter_value)
				{
					$options = $options.'<option value="'.$filter_value.'">'.$filter_value.'</option>';
				}
			}

			echo $options;
        }
		
		public function pendapatan()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->model('unit_model');
			$this->load->helper('form');

			$data['title'] = ':: Sister JSO :: Pendapatan';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			$data['units'] = array(
				'' => 'Semua Unit'
			);

			$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
			
			foreach($unit_list as &$unit)
			{
				$data['units'][$unit['unit_id']] = $unit['name'];
			}

			$data['unit_id'] = '';
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'assets/js/pages/finance/revenue.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/finance/revenue/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		public function data_pendapatan()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('finance_model');

			$data['projects'] = $this->finance_model->read_revenue();

			echo $this->load->view('pages/finance/revenue/dynamic_content', $data, TRUE);
		}
		
		public function piutang()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->model('unit_model');
			$this->load->helper('form');

			$data['title'] = ':: Sister JSO :: Piutang';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			$data['units'] = array(
				'' => 'Semua Unit'
			);

			$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
			
			foreach($unit_list as &$unit)
			{
				$data['units'][$unit['unit_id']] = $unit['name'];
			}

			$data['unit_id'] = '';
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'assets/js/pages/finance/credits.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/finance/credits/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }

		public function data_piutang()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('finance_model');

			$data['projects'] = $this->finance_model->read_credit();

			echo $this->load->view('pages/finance/credits/dynamic_content', $data, TRUE);
		}
		
		/*public function laporan_laba_rugi()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			$this->load->model('employee_model');
			$this->load->model('unit_model');
			$this->load->helper('form');

			$data['title'] = ':: Sister JSO :: Laporan Laba Rugi';
			
			$data['vendor_css_links'] = array(
				'bootstrap/css/bootstrap.min.css',
				'font-awesome/css/font-awesome.min.css',
				'animate-css/animate.min.css'
			);

			$data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

			$data['units'] = array(
				'' => 'Semua Unit'
			);

			$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
			
			foreach($unit_list as &$unit)
			{
				$data['units'][$unit['unit_id']] = $unit['name'];
			}

			$data['unit_id'] = '';
			
			$data['js_links'] = array(
				'assets/bundles/libscripts.bundle.js',
				'assets/bundles/vendorscripts.bundle.js',
				'assets/bundles/mainscripts.bundle.js',
				'assets/js/pages/finance/income_statement.js'
			);

			// Render view on main layout
			$this->load->view('templates/dashboard/top', $data);
			$this->load->view('pages/finance/income_statement/static_content', $data);
			$this->load->view('templates/dashboard/bottom', $data);
	    }*/
		
		public function laba_rugi_neraca()
	    {
			if(!$this->session->has_userdata('user_id'))
			{	
				$this->session->set_userdata('previous_url', current_url());
				
				redirect('otentikasi/masuk');
			}

			if($this->input->post('submit') == NULL)
            {
                $this->load->model('employee_model');
                $this->load->model('unit_model');
                $this->load->helper('form');

                $data['title'] = ':: Sister JSO :: Laporan Laba Rugi & Neraca';
                
                $data['vendor_css_links'] = array(
                    'bootstrap/css/bootstrap.min.css',
                    'font-awesome/css/font-awesome.min.css',
                    'animate-css/animate.min.css'
                );

                $data['logged_in_user'] = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');

				$unit_list = $this->unit_model->read_units('unit_id, name', 'result_array');
			
				foreach($unit_list as &$unit)
				{
					$units[$unit['unit_id']] = $unit['name'];
				}

				$data['units'] = $units;
                
                $data['js_links'] = array(
                    'assets/bundles/libscripts.bundle.js',
                    'assets/bundles/vendorscripts.bundle.js',
                    'assets/bundles/mainscripts.bundle.js'
                );

                // Render view on main layout
                $this->load->view('templates/dashboard/top', $data);
                $this->load->view('pages/finance/reports/download', $data);
                $this->load->view('templates/dashboard/bottom', $data);
            }
			else
			{
				$this->load->model('finance_model');
                $this->load->model('unit_model');

				$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
				$spreadsheet = $reader->load("assets/assets/data/Data-Keuangan.xlsx");
				
				$sheet = $spreadsheet->getActiveSheet();

				$transactions = $this->finance_model->read_journal();

				$mandiri = 0;
				$bri = 0;
				$bca = 0;
				$bni = 0;
				$cash_manager = 0;
				$gopay_balance = 0;
				$petty_cash = 0;
				$cash_car = 0;
				$hrd_cash = 0;
				$independent_checking_account = 0;
				$accounts_receivable = 0;
				$receivables_employee = 0;
				$other_accounts_receivable = 0;
				$equipment = 0;
				$supplies_that_have_been_used = 0;
				$office_inventory = 0;
				$office_transportation = 0;
				$office_building = 0;
				$bank_debt = 0;
				$accounts_payable = 0;
				$salary_debt = 0;
				$debt_vat = 0;
				$final_income_tax_debt = 0;
				$income_summary = 0;
				$initial_investment_capital = 0;
				$working_capital = 0;
				$last_year_retained_profit_loss = 0;
				$income_for_the_year = 0;
				$prive = 0;
				$accumulated_depreciation = 0;
				$operating_revenues = 0;
				$interest_income = 0;
				$prepaid_income = 0;
				$rental_income = 0;
				$operating_income = 0;
				$commission_income = 0;
				$other_income = 0;
				$revenue_outsourcing = 0;
				$transportation_income = 0;
				$warehouse_rental_income = 0;
				$office_rental_income = 0;
				$dividend_distribution = 0;
				$iki_professional_certification_agency_income = 0;
				$cv_expenses = 0;
				$customer_service_expenses = 0;
				$rental_expenses = 0;
				$consumption_expenses = 0;
				$operating_expenses = 0;
				$driver_expenses = 0;
				$training_expenses = 0;
				$expenses_hotel = 0;
				$transportation_expenses = 0;
				$instructor_expenses = 0;
				$send_expenses = 0;
				$expenses_returns = 0;
				$other_training_expenses = 0;
				$expenses_training_kit = 0;
				$marketing_fee_expenses = 0;
				$quarterly_fee = 0;
				$manager_fee_expense = 0;
				$salary_expense = 0;
				$office_monthly_expenses = 0;
				$official_travel_expenses = 0;
				$advertising_expenses_it = 0;
				$office_rental_expenses = 0;
				$expenses_of_family_gathering = 0;
				$electrical_expenses = 0;
				$logistics_expenses = 0;
				$meeting_expenses = 0;
				$organizational_expenses = 0;
				$pulse_expenses = 0;
				$csr_expenses = 0;
				$expenses_of_consumables = 0;
				$vehicle_service_expenses = 0;
				$office_equipment_service_expenses = 0;
				$telephone_expenses = 0;
				$maintenance_expenses = 0;
				$logistics_distribution_expenses = 0;
				$insurance_expense = 0;
				$unit_contribution_fee_expenses = 0;
				$parking_expenses = 0;
				$other_expenses = 0;
				$bad_debts_expense = 0;
				$depreciation_expense = 0;
				$equipment_expenses = 0;
				$bank_administrative_expenses = 0;
				$interest_expense = 0;
				$bank_tax_expense = 0;
				$vat_expenses = 0;
				$expenses_income_tax_23 = 0;
				$expenses_income_tax_21 = 0;
				$final_income_tax_expenses = 0;

				foreach($transactions as &$transaction)
				{
					if($transaction['debt_reference_code'] == 'mandiri') $mandiri = $mandiri + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'mandiri') $mandiri = $mandiri - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'bri') $bri = $bri + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'bri') $bri = $bri - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'bca') $bca = $bca + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'bca') $bca = $bca - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'bni') $bni = $bni + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'bni') $bni = $bni - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'kas manajer') $cash_manager = $cash_manager + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'kas manajer') $cash_manager = $cash_manager - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'saldo gopay') $gopay_balance = $gopay_balance + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'saldo gopay') $gopay_balance = $gopay_balance - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'petty cash') $petty_cash = $petty_cash + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'petty cash') $petty_cash = $petty_cash - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'kas mobil') $cash_car = $cash_car + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'kas mobil') $cash_car = $cash_car - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'kas hrd') $hrd_cash = $hrd_cash + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'kas hrd') $hrd_cash = $hrd_cash - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'mandiri giro') $independent_checking_account = $independent_checking_account + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'mandiri giro') $independent_checking_account = $independent_checking_account - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'piutang usaha') $accounts_receivable = $accounts_receivable + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'piutang usaha') $accounts_receivable = $accounts_receivable - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'piutang karyawan') $receivables_employee = $receivables_employee + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'piutang karyawan') $receivables_employee = $receivables_employee - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'piutang lain') $other_accounts_receivable = $other_accounts_receivable + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'piutang lain') $other_accounts_receivable = $other_accounts_receivable - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'perlengkapan') $equipment = $equipment + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'perlengkapan') $equipment = $equipment - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'persediaan yang sudah digunakan') $supplies_that_have_been_used = $supplies_that_have_been_used + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'persediaan yang sudah digunakan') $supplies_that_have_been_used = $supplies_that_have_been_used - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'inventaris kantor') $office_inventory = $office_inventory + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'inventaris kantor') $office_inventory = $office_inventory - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'kendaraan kantor') $office_transportation = $office_transportation + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'kendaraan kantor') $office_transportation = $office_transportation - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'gedung kantor') $office_building = $office_building + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'gedung kantor') $office_building = $office_building - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'utang bank') $bank_debt = $bank_debt + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'utang bank') $bank_debt = $bank_debt - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'utang usaha') $accounts_payable = $accounts_payable + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'utang usaha') $accounts_payable = $accounts_payable - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'utang gaji') $salary_debt = $salary_debt + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'utang gaji') $salary_debt = $salary_debt - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'utang ppn') $debt_vat = $debt_vat + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'utang ppn') $debt_vat = $debt_vat - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'utang pph final') $final_income_tax_debt = $final_income_tax_debt + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'utang pph final') $final_income_tax_debt = $final_income_tax_debt - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'ikhtisar laba/rugi') $income_summary = $income_summary + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'ikhtisar laba/rugi') $income_summary = $income_summary - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'modal investasi awal') $initial_investment_capital = $initial_investment_capital + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'modal investasi awal') $initial_investment_capital = $initial_investment_capital - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'modal kerja') $working_capital = $working_capital + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'modal kerja') $working_capital = $working_capital - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'laba/rugi ditahan tahun lalu') $last_year_retained_profit_loss = $last_year_retained_profit_loss + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'laba/rugi ditahan tahun lalu') $last_year_retained_profit_loss = $last_year_retained_profit_loss - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'laba/rugi tahun berjalan') $income_for_the_year = $income_for_the_year + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'laba/rugi tahun berjalan') $income_for_the_year = $income_for_the_year - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'prive') $prive = $prive + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'prive') $prive = $prive - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'akumulasi penyusutan') $accumulated_depreciation = $accumulated_depreciation + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'akumulasi penyusutan') $accumulated_depreciation = $accumulated_depreciation - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'pendapatan usaha') $operating_revenues = $operating_revenues + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'pendapatan usaha') $operating_revenues = $operating_revenues - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'pendapatan bunga') $interest_income = $interest_income + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'pendapatan bunga') $interest_income = $interest_income - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'pendapatan diterima dimuka') $prepaid_income = $prepaid_income + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'pendapatan diterima dimuka') $prepaid_income = $prepaid_income - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'pendapatan sewa') $rental_income = $rental_income + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'pendapatan sewa') $rental_income = $rental_income - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'pendapatan operasional') $operating_income = $operating_income + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'pendapatan operasional') $operating_income = $operating_income - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'pendapatan komisi') $commission_income = $commission_income + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'pendapatan komisi') $commission_income = $commission_income - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'pendapatan lain-lain') $other_income = $other_income + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'pendapatan lain-lain') $other_income = $other_income - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'pendapatan outsourcing') $revenue_outsourcing = $revenue_outsourcing + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'pendapatan outsourcing') $revenue_outsourcing = $revenue_outsourcing - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'pendapatan transportasi') $transportation_income = $transportation_income + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'pendapatan transportasi') $transportation_income = $transportation_income - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'pendapatan sewa gudang') $warehouse_rental_income = $warehouse_rental_income + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'pendapatan sewa gudang') $warehouse_rental_income = $warehouse_rental_income - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'pendapatan sewa kantor') $office_rental_income = $office_rental_income + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'pendapatan sewa kantor') $office_rental_income = $office_rental_income - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'pembagian dividen') $dividend_distribution = $dividend_distribution + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'pembagian dividen') $dividend_distribution = $dividend_distribution - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'pendapatan lsp iki') $iki_professional_certification_agency_income = $iki_professional_certification_agency_income + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'pendapatan lsp iki') $iki_professional_certification_agency_income = $iki_professional_certification_agency_income - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban cv') $cv_expenses = $cv_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban cv') $cv_expenses = $cv_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban customer service') $customer_service_expenses = $customer_service_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban customer service') $customer_service_expenses = $customer_service_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban sewa') $rental_expenses = $rental_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban sewa') $rental_expenses = $rental_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban konsumsi') $consumption_expenses = $consumption_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban konsumsi') $consumption_expenses = $consumption_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban operasional') $operating_expenses = $operating_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban operasional') $operating_expenses = $operating_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban driver') $driver_expenses = $driver_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban driver') $driver_expenses = $driver_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban training') $training_expenses = $training_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban training') $training_expenses = $training_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban hotel') $expenses_hotel = $expenses_hotel + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban hotel') $expenses_hotel = $expenses_hotel - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban transportasi') $transportation_expenses = $transportation_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban transportasi') $transportation_expenses = $transportation_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban instruktur') $instructor_expenses = $instructor_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban instruktur') $instructor_expenses = $instructor_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban kirim') $send_expenses = $send_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban kirim') $send_expenses = $send_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban retur') $expenses_returns = $expenses_returns + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban retur') $expenses_returns = $expenses_returns - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban training lain') $other_training_expenses = $other_training_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban training lain') $other_training_expenses = $other_training_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban training kit') $expenses_training_kit = $expenses_training_kit + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban training kit') $expenses_training_kit = $expenses_training_kit - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban fee marketing') $marketing_fee_expenses = $marketing_fee_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban fee marketing') $marketing_fee_expenses = $marketing_fee_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban fee triwulan') $quarterly_fee = $quarterly_fee + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban fee triwulan') $quarterly_fee = $quarterly_fee - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban fee manajer') $manager_fee_expense = $manager_fee_expense + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban fee manajer') $manager_fee_expense = $manager_fee_expense - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban gaji') $salary_expense = $salary_expense + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban gaji') $salary_expense = $salary_expense - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban bulanan kantor') $office_monthly_expenses = $office_monthly_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban bulanan kantor') $office_monthly_expenses = $office_monthly_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban perjalanan dinas') $official_travel_expenses = $official_travel_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban perjalanan dinas') $official_travel_expenses = $official_travel_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban iklan (it)') $advertising_expenses_it = $advertising_expenses_it + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban iklan (it)') $advertising_expenses_it = $advertising_expenses_it - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban sewa kantor') $office_rental_expenses = $office_rental_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban sewa kantor') $office_rental_expenses = $office_rental_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban family gathering') $expenses_of_family_gathering = $expenses_of_family_gathering + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban family gathering') $expenses_of_family_gathering = $expenses_of_family_gathering - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban listrik') $electrical_expenses = $electrical_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban listrik') $electrical_expenses = $electrical_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban logistik') $logistics_expenses = $logistics_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban logistik') $logistics_expenses = $logistics_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban meeting') $meeting_expenses = $meeting_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban meeting') $meeting_expenses = $meeting_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban organisasi') $organizational_expenses = $organizational_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban organisasi') $organizational_expenses = $organizational_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban pulsa') $pulse_expenses = $pulse_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban pulsa') $pulse_expenses = $pulse_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban csr') $csr_expenses = $csr_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban csr') $csr_expenses = $csr_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban barang habis pakai') $expenses_of_consumables = $expenses_of_consumables + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban barang habis pakai') $expenses_of_consumables = $expenses_of_consumables - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban servis kendaraan') $vehicle_service_expenses = $vehicle_service_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban servis kendaraan') $vehicle_service_expenses = $vehicle_service_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban servis peralatan kantor') $office_equipment_service_expenses = $office_equipment_service_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban servis peralatan kantor') $office_equipment_service_expenses = $office_equipment_service_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban telepon') $telephone_expenses = $telephone_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban telepon') $telephone_expenses = $telephone_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban perawatan') $maintenance_expenses = $maintenance_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban perawatan') $maintenance_expenses = $maintenance_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban distribusi logistik') $logistics_distribution_expenses = $logistics_distribution_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban distribusi logistik') $logistics_distribution_expenses = $logistics_distribution_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban bpjs') $insurance_expense = $insurance_expense + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban bpjs') $insurance_expense = $insurance_expense - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban fee kontribusi unit') $unit_contribution_fee_expenses = $unit_contribution_fee_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban fee kontribusi unit') $unit_contribution_fee_expenses = $unit_contribution_fee_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban parkir') $parking_expenses = $parking_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban parkir') $parking_expenses = $parking_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban lain-lain') $other_expenses = $other_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban lain-lain') $other_expenses = $other_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban piutang tak tertagih') $bad_debts_expense = $bad_debts_expense + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban piutang tak tertagih') $bad_debts_expense = $bad_debts_expense - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban penyusutan') $depreciation_expense = $depreciation_expense + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban penyusutan') $depreciation_expense = $depreciation_expense - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban perlengkapan') $equipment_expenses = $equipment_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban perlengkapan') $equipment_expenses = $equipment_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban administrasi bank') $bank_administrative_expenses = $bank_administrative_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban administrasi bank') $bank_administrative_expenses = $bank_administrative_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban bunga') $interest_expense = $interest_expense + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban bunga') $interest_expense = $interest_expense - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban pajak bank') $bank_tax_expense = $bank_tax_expense + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban pajak bank') $bank_tax_expense = $bank_tax_expense - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban ppn') $vat_expenses = $vat_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban ppn') $vat_expenses = $vat_expenses - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban pph 23') $expenses_income_tax_23 = $expenses_income_tax_23 + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban pph 23') $expenses_income_tax_23 = $expenses_income_tax_23 - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban pph 21') $expenses_income_tax_21 = $expenses_income_tax_21 + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban pph 21') $expenses_income_tax_21 = $expenses_income_tax_21 - $transaction['nominal'];
					else if($transaction['debt_reference_code'] == 'beban pph final') $final_income_tax_expenses = $final_income_tax_expenses + $transaction['nominal']; else if($transaction['credit_reference_code'] == 'beban pph final') $final_income_tax_expenses = $final_income_tax_expenses - $transaction['nominal'];
				}

				$sheet->setCellValue('E2', abs($mandiri));
				$sheet->setCellValue('E3', abs($bri));
				$sheet->setCellValue('E4', abs($bca));
				$sheet->setCellValue('E5', abs($bni));
				$sheet->setCellValue('E6', abs($cash_manager));
				$sheet->setCellValue('E7', abs($gopay_balance));
				$sheet->setCellValue('E8', abs($petty_cash));
				$sheet->setCellValue('E9', abs($cash_car));
				$sheet->setCellValue('E10', abs($hrd_cash));
				$sheet->setCellValue('E11', abs($independent_checking_account));
				$sheet->setCellValue('E12', abs($accounts_receivable));
				$sheet->setCellValue('E13', abs($receivables_employee));
				$sheet->setCellValue('E14', abs($other_accounts_receivable));
				$sheet->setCellValue('E15', abs($equipment));
				$sheet->setCellValue('E16', abs($supplies_that_have_been_used));
				$sheet->setCellValue('E17', abs($office_inventory));
				$sheet->setCellValue('E18', abs($office_transportation));
				$sheet->setCellValue('E19', abs($office_building));
				$sheet->setCellValue('E20', abs($bank_debt));
				$sheet->setCellValue('E21', abs($accounts_payable));
				$sheet->setCellValue('E22', abs($salary_debt));
				$sheet->setCellValue('E23', abs($debt_vat));
				$sheet->setCellValue('E24', abs($final_income_tax_debt));
				$sheet->setCellValue('E25', abs($income_summary));
				$sheet->setCellValue('E26', abs($initial_investment_capital));
				$sheet->setCellValue('E27', abs($working_capital));
				$sheet->setCellValue('E28', abs($last_year_retained_profit_loss));
				$sheet->setCellValue('E29', abs($income_for_the_year));
				$sheet->setCellValue('E30', abs($prive));
				$sheet->setCellValue('E31', abs($accumulated_depreciation));
				$sheet->setCellValue('E32', abs($operating_revenues));
				$sheet->setCellValue('E33', abs($interest_income));
				$sheet->setCellValue('E34', abs($prepaid_income));
				$sheet->setCellValue('E35', abs($rental_income));
				$sheet->setCellValue('E36', abs($operating_income));
				$sheet->setCellValue('E37', abs($commission_income));
				$sheet->setCellValue('E38', abs($other_income));
				$sheet->setCellValue('E39', abs($revenue_outsourcing));
				$sheet->setCellValue('E40', abs($transportation_income));
				$sheet->setCellValue('E41', abs($warehouse_rental_income));
				$sheet->setCellValue('E42', abs($office_rental_income));
				$sheet->setCellValue('E43', abs($dividend_distribution));
				$sheet->setCellValue('E44', abs($iki_professional_certification_agency_income));
				$sheet->setCellValue('E45', abs($cv_expenses));
				$sheet->setCellValue('E46', abs($customer_service_expenses));
				$sheet->setCellValue('E47', abs($rental_expenses));
				$sheet->setCellValue('E48', abs($consumption_expenses));
				$sheet->setCellValue('E49', abs($operating_expenses));
				$sheet->setCellValue('E50', abs($driver_expenses));
				$sheet->setCellValue('E51', abs($training_expenses));
				$sheet->setCellValue('E52', abs($expenses_hotel));
				$sheet->setCellValue('E53', abs($transportation_expenses));
				$sheet->setCellValue('E54', abs($instructor_expenses));
				$sheet->setCellValue('E55', abs($send_expenses));
				$sheet->setCellValue('E56', abs($expenses_returns));
				$sheet->setCellValue('E57', abs($other_training_expenses));
				$sheet->setCellValue('E58', abs($expenses_training_kit));
				$sheet->setCellValue('E59', abs($marketing_fee_expenses));
				$sheet->setCellValue('E60', abs($quarterly_fee));
				$sheet->setCellValue('E61', abs($manager_fee_expense));
				$sheet->setCellValue('E62', abs($salary_expense));
				$sheet->setCellValue('E63', abs($office_monthly_expenses));
				$sheet->setCellValue('E64', abs($official_travel_expenses));
				$sheet->setCellValue('E65', abs($advertising_expenses_it));
				$sheet->setCellValue('E66', abs($office_rental_expenses));
				$sheet->setCellValue('E67', abs($expenses_of_family_gathering));
				$sheet->setCellValue('E68', abs($electrical_expenses));
				$sheet->setCellValue('E69', abs($logistics_expenses));
				$sheet->setCellValue('E70', abs($meeting_expenses));
				$sheet->setCellValue('E71', abs($organizational_expenses));
				$sheet->setCellValue('E72', abs($pulse_expenses));
				$sheet->setCellValue('E73', abs($csr_expenses));
				$sheet->setCellValue('E74', abs($expenses_of_consumables));
				$sheet->setCellValue('E75', abs($vehicle_service_expenses));
				$sheet->setCellValue('E76', abs($office_equipment_service_expenses));
				$sheet->setCellValue('E77', abs($telephone_expenses));
				$sheet->setCellValue('E78', abs($maintenance_expenses));
				$sheet->setCellValue('E79', abs($logistics_distribution_expenses));
				$sheet->setCellValue('E80', abs($insurance_expense));
				$sheet->setCellValue('E81', abs($unit_contribution_fee_expenses));
				$sheet->setCellValue('E82', abs($parking_expenses));
				$sheet->setCellValue('E83', abs($other_expenses));
				$sheet->setCellValue('E84', abs($bad_debts_expense));
				$sheet->setCellValue('E85', abs($depreciation_expense));
				$sheet->setCellValue('E86', abs($equipment_expenses));
				$sheet->setCellValue('E87', abs($bank_administrative_expenses));
				$sheet->setCellValue('E88', abs($interest_expense));
				$sheet->setCellValue('E89', abs($bank_tax_expense));
				$sheet->setCellValue('E90', abs($vat_expenses));
				$sheet->setCellValue('E91', abs($expenses_income_tax_23));
				$sheet->setCellValue('E92', abs($expenses_income_tax_21));
				$sheet->setCellValue('E93', abs($final_income_tax_expenses));

				$sheet_names[1] = 'Neraca';
				$sheet_names[2] = 'Laporan LR';

				$unit = $this->unit_model->read_units('name', 'row_array', '', 0, $this->input->post('unit_id'));

				foreach($sheet_names as &$sheet_name)
				{
					$sheet = $spreadsheet->getSheetByName($sheet_name);

					$sheet->setCellValue('A2', $unit['name']);
					$sheet->setCellValue('A3', 'Tahun '.$this->input->post('transaction_year'));
				}

				$spreadsheet->setActiveSheetIndexByName('Laporan LR');

				$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
				$writer->setPreCalculateFormulas(false);
		
				$filename = 'Laba Rugi Neraca '.$unit['name'].' '.$this->input->post('transaction_year');
		
				header('Content-Type: application/vnd.ms-excel');
				header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
				header('Cache-Control: max-age=0');
				
				$writer->save('php://output'); // download file*/
			}
	    }
	}
?>