<?php
    // $config['protocol'] = 'smtp';
    // // $config['smtp_host'] = 'smtp.googlemail.com';
    // // $config['smtp_user'] = 'sister.jsosmboffice@gmail.com';
    // // $config['smtp_pass'] = '4kuk0kl4l1y0';
    // // $config['smtp_port'] = '465';
    // // $config['smtp_crypto'] = 'ssl';
    // $config['smtp_host'] = 'sister.jso-smb.co.id';
    // $config['smtp_user'] = 'system@sister.jso-smb.co.id';
    // $config['smtp_pass'] = 'Zv^!gT&Rl94%';
    // $config['smtp_port'] = '465';
    // $config['smtp_crypto'] = 'ssl';
    // $config['priority'] = 1;
    // //$config['charset'] = 'iso-8859-1';
    $config['crlf'] = "\r\n";
    $config['newline'] = "\r\n";
    $config['mailtype'] = 'html';