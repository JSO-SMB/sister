<?php
	class Project_management_model extends CI_Model
	{
		public function read_users_roles_contracts($division = '', $user_id = 0, $unit_id = 0, $user_status = '')
		{
			$this->db->select('*');
			$this->db->from('employees');
			$this->db->join('users', 'employees.user_id = users.user_id');
			
			if($user_id > 0 || $unit_id > 0)
			{
				$this->db->join('contracts', 'employees.user_id = contracts.user_id AND employees.division = contracts.division');

				if($user_id > 0)
				{
					$this->db->where('employees.user_id', $user_id);

					return $this->db->get()->row_array();
				}
				else
				{
					$this->db->where('unit_id', $unit_id);
					$this->db->where('position', 'Manajer');
					$this->db->where('expiry_date >', 'CURDATE()');
				}
			}
			
			if($division != '')
			{
				$this->db->where('employees.division', $division);
				$this->db->where('user_status', 'Aktif');
				
				return $this->db->get()->result_array();
			}
		}
		
		public function read_clients($client_id = 0, $return = 'row_array', $query = '', $category = 'general', $page_number = 0, $join_tables_list = '', $additional_fields = '')
		{
			$this->db->select('*');
            $this->db->from('clients');
			
			if($client_id != 0)
			{
				$this->db->where('client_id', $client_id);

				return $this->db->get()->row_array();
			}
			else
				return $this->db->get()->result_array();
		}
		
		public function read_events_vendors_clients($columns = '*', $join_tables_list = '', $page_number = 0, $return = 'result_array', $status = 'all', $query = '', $event_id = 0, $client_id = 0, $approval_status = '', $nearest_city = 'Semua Gudang')
		{
			$this->db->select($columns);
			$this->db->from('events');

			if($join_tables_list != '')
			{
				$join_tables = explode(',', $join_tables_list);
				
				foreach($join_tables as &$join_table)
				{
					$this->db->join($join_table.'s', 'events.'.$join_table.'_id = '.$join_table.'s.'.$join_table.'_id');
				}
			}
			
			if($event_id != 0)
				$this->db->where('event_id', $event_id);
			
			if($status == 'Fixed')
			{
				$this->db->join('contracts', 'events.marketing_user_id = contracts.user_id');
				
				if($query > 0)
					$this->db->where('events.unit_id', $query);
				
				$this->db->where('status', $status);
			}
			else if($query != '')
				$this->db->like('events.name', $query);
			
			if($client_id != 0)
				$this->db->where('client_id', $client_id);
			
			if($nearest_city != 'Semua Gudang')
				$this->db->where('nearest_city', $nearest_city);
			
			if($approval_status != '')
				$this->db->where('approval_status', $approval_status);

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
			{
				$this->db->order_by('end_date', 'DESC');

				if($return == 'result_array')
				{
					$this->load->model('vendor_model');
					
					$events = $this->db->get()->result_array();

					if(!empty($events))
					{
						for($event_counter = 0; $event_counter < $this->project_management_model->read_events_vendors_clients('*', '', 0, 'num_rows', $status, urldecode($query)); $event_counter++)
						{
							$marketing = $this->project_management_model->read_users_roles_contracts('', $events[$event_counter]['marketing_user_id']);
							
							$events[$event_counter]['marketing_name'] = $marketing['name'];

							$instructor = $this->project_management_model->read_users_roles_contracts('', $events[$event_counter]['instructor_user_id']);
							
							$events[$event_counter]['instructor_name'] = $instructor['name'];

							$cs = $this->project_management_model->read_users_roles_contracts('', $events[$event_counter]['cs_user_id']);
							
							$events[$event_counter]['cs_name'] = $cs['name'];

							$driver = $this->project_management_model->read_users_roles_contracts('', $events[$event_counter]['driver_user_id']);
							
							$events[$event_counter]['driver_name'] = $driver['name'];

							$logistic = $this->project_management_model->read_users_roles_contracts('', $events[$event_counter]['logistic_user_id']);
							
							$events[$event_counter]['logistic_name'] = $logistic['name'];

							$manager = $this->project_management_model->read_users_roles_contracts('', $events[$event_counter]['manager_user_id']);
							
							$events[$event_counter]['manager_name'] = $manager['name'];

							$hotel = $this->vendor_model->read_users_vendors('user', 0, 'row_array', '', $events[$event_counter]['hotel_vendor_id']);
							
							$events[$event_counter]['hotel'] = $hotel['name'];
						}
					}

					return $events;
				}
				else
					return $this->db->get()->row_array();
			}
		}

		public function read_event_payments($columns = '*', $event_payment_id = 0, $payment_status = '', $event_id = 0, $group_by = '', $page_number = 0, $return = 'result_array')
		{
			$this->db->select($columns);
			$this->db->from('event_payments');
			
			$this->db->join('events', 'event_payments.event_id = events.event_id');
			$this->db->join('units', 'events.unit_id = units.unit_id');
			$this->db->join('users', 'events.marketing_user_id = users.user_id');
            
            if($event_payment_id > 0)
				$this->db->where('event_payment_id', $event_payment_id);
			
            if($payment_status != '')
                $this->db->where('payment_status', $payment_status);
            
			if($event_id > 0)
				$this->db->where('event_payments.event_id', $event_id);
			
			/*if($this->input->get('filter_value') != NULL && $this->input->get('filter_value') != '')
			{
				$filter_parameter = explode(',', urldecode($this->input->get('filter_column')));
				$value = urldecode($this->input->get('filter_value'));

				if($filter_parameter[1] == 'where')
					$this->db->where($filter_parameter[0], $value);
				else
					$this->db->like($filter_parameter[0], $value);
			}*/
			
			if($this->input->get('filter_value') != NULL && $this->input->get('filter_value') != '')
			{
				$filter_parameter = explode(',', urldecode($this->input->get('filter_column')));

				if($filter_parameter[0] == 'events.unit_id')
				{
					$value = urldecode($this->input->get('filter_value'));
					
					if($filter_parameter[1] == 'where')
						$this->db->where($filter_parameter[0], $value);
					else
						$this->db->like($filter_parameter[0], $value);
				}
			}
			
            if($group_by != '')
				$this->db->group_by($group_by);

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			if($return == 'result_array')
			{
                if($this->input->get('ordering_column') != NULL && $this->input->get('ordering_column') != '')
					$this->db->order_by($this->input->get('ordering_column'), 'DESC');
				
				return $this->db->get()->result_array();
			}
			else if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
				return $this->db->get()->row_array();
		}
		
		public function read_events($columns = '*', $event_id = 0, $page_number = 0, $return = 'result_array', $view = '')
		{
			$this->db->select($columns);
            $this->db->from('events');
            
            if($event_id > 0)
                $this->db->where('event_id', $event_id);

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
            if($return == 'result_array' || ($return == 'row_array' && ($view == 'invoice' || $view == 'journal' || $view == 'tax' || $view == 'cashflow')))
            {
                $this->db->join('units', 'events.unit_id = units.unit_id');
                $this->db->join('users', 'events.marketing_user_id = users.user_id');
                $this->db->join('clients', 'events.client_id = clients.client_id');
					
				$this->db->order_by('start_date', 'ASC');
				$this->db->order_by('event_id', 'ASC');
				
				/*if($this->input->get('ordering_column') != NULL && $this->input->get('ordering_column') != '')
					$this->db->order_by($this->input->get('ordering_column'), 'DESC');*/
			
                if($return == 'result_array')
                {
                    if($this->input->get('start_date') != NULL && $this->input->get('start_date') != '')
						$this->db->like('start_date', urldecode($this->input->get('start_date')));
						
					if($this->input->get('unit_id') != NULL && $this->input->get('unit_id') != '')
						$this->db->where('events.unit_id', $this->input->get('unit_id'));

					if($this->input->get('project_status') != NULL && $this->input->get('project_status') != '')
					{
						$project_status = urldecode($this->input->get('project_status'));

						if($project_status == 'Lunas' || $project_status == 'Piutang')
						{
							$this->db->where('status', 'Fixed');
							
							$events = $this->db->get()->result_array();

							if(empty($events))
								return $events;
							else
							{
								if($project_status == 'Lunas')
									$paid_off_events = array();
								else
									$unpaid_events = array();

								for($event_counter = 0; $event_counter < $this->project_management_model->read_events('*', 0, $page_number, 'num_rows'); $event_counter++)
								{
									$turnover_transactions = $this->project_management_model->read_journal('debt_reference_code, credit_reference_code, nominal', $events[$event_counter]['event_id'], '"pendapatan usaha"');
									
									$turnover = 0;

									foreach($turnover_transactions as &$turnover_transaction)
									{
										if($turnover_transaction['credit_reference_code'] == 'pendapatan usaha')
											$turnover = $turnover + $turnover_transaction['nominal'];
										else if($turnover_transaction['debt_reference_code'] == 'pendapatan usaha')
											$turnover = $turnover - $turnover_transaction['nominal'];
									}

									if($project_status == 'Lunas')
									{
										if(($turnover / ($events[$event_counter]['price'] * $events[$event_counter]['clients_number'])) * 100 >= 90)
											$paid_off_events[$event_counter] = $events[$event_counter];
									}
									else
									{
										if(($turnover / ($events[$event_counter]['price'] * $events[$event_counter]['clients_number'])) * 100 < 90)
											$unpaid_events[$event_counter] = $events[$event_counter];
									}
								}

								if($project_status == 'Lunas')
									return $paid_off_events;
								else
									return $unpaid_events;
							}
						}
						else
						{
							if($project_status == 'Belum Running')
							{
								$this->db->where('start_date >', date('Y-m-d'));
								$this->db->where("(status = 'Almost' OR status = 'Fixed')");
							}
							else
							{
								$this->db->where('start_date <=', date('Y-m-d'));
								$this->db->where('status', 'Fixed');
							}

							return $this->db->get()->result_array();
						}
					}
					else
					{
						$this->db->where("(status = 'Almost' OR status = 'Fixed')");

						return $this->db->get()->result_array();
					}
                }
                else
                    return $this->db->get()->row_array();
			}
			else if($return == 'row_array' && $view == 'event')
			{
				$this->load->model('vendor_model');

				$this->db->join('units', 'events.unit_id = units.unit_id');
					
				$event = $this->db->get()->row_array();

				$marketing = $this->project_management_model->read_users_roles_contracts('', $event['marketing_user_id']);
							
				$event['marketing_name'] = $marketing['name'];

				$event['instructors'] = $this->project_management_model->read_certificates($event_id);

				$cs = $this->project_management_model->read_users_roles_contracts('', $event['cs_user_id']);
				
				$event['cs_name'] = $cs['name'];

				//$driver = $this->project_management_model->read_users_roles_contracts('', $event['driver_user_id']);
				
				//$event['driver_name'] = $driver['name'];

				$logistic = $this->project_management_model->read_users_roles_contracts('', $event['logistic_user_id']);
				
				$event['logistic_name'] = $logistic['name'];

				$manager = $this->project_management_model->read_users_roles_contracts('', $event['manager_user_id']);
				
				$event['manager_name'] = $manager['name'];

				$hotel = $this->vendor_model->read_users_vendors('user', 0, 'row_array', '', $event['hotel_vendor_id']);
				
				$event['hotel'] = $hotel['name'];
				
				return $event;
			}
			else if($return == 'row_array' && ($view == 'budget' || $view == 'logistic'))
            {
				$this->db->join('units', 'events.unit_id = units.unit_id');
				$this->db->join('users', 'events.marketing_user_id = users.user_id');
				
				return $this->db->get()->row_array();
			}
            else
            {
				if($this->input->get('start_date') != NULL && $this->input->get('start_date') != '')
					$this->db->like('start_date', urldecode($this->input->get('start_date')));
					
				if($this->input->get('unit_id') != NULL && $this->input->get('unit_id') != '')
					$this->db->where('events.unit_id', $this->input->get('unit_id'));

				if($this->input->get('project_status') != NULL && $this->input->get('project_status') != '')
				{
					$project_status = urldecode($this->input->get('project_status'));

					if($project_status == 'Belum Running')
					{
						$this->db->where('start_date >', date('Y-m-d'));
						$this->db->where("(status = 'Almost' OR status = 'Fixed')");
					}
					else
					{
						if($project_status == 'Sudah Running')
							$this->db->where('start_date <=', date('Y-m-d'));
						
						$this->db->where('status', 'Fixed');
					}
				}
				else
					$this->db->where("(status = 'Almost' OR status = 'Fixed')");

				return $this->db->get()->num_rows();
			}
		}

		public function read_journal($columns = '*', $event_id, $reference_codes, $return = 'result_array', $page_number = 0)
		{
			$this->db->select($columns);
			$this->db->from('journal');
			
			$this->db->where('transaction_type', 'IN: Event');
			$this->db->where('event_id', $event_id);
			$this->db->where('(debt_reference_code IN ('.$reference_codes.') OR credit_reference_code IN ('.$reference_codes.'))');
			$this->db->where('approval_status', 'Approved');
			
			/*if($this->input->get('filter_value') != NULL && $this->input->get('filter_value') != '')
			{
				$filter_parameter = explode(',', urldecode($this->input->get('filter_column')));
				$value = urldecode($this->input->get('filter_value'));

				if($filter_parameter[0] == 'unit_id')
				{
					$this->db->join('events', 'journal.event_id = events.event_id', 'left');
					$this->db->join('funding_submissions', 'journal.funding_submission_id = funding_submissions.funding_submission_id', 'left');

					$condition = "(((transaction_type = 'IN: Manual' OR transaction_type = 'OUT: Manual') AND journal.unit_id = ".$value.") OR (transaction_type = 'IN: Event' AND events.unit_id = ".$value.") OR (transaction_type = 'OUT: Pengajuan' AND funding_submissions.utilizing_unit_id = ".$value."))";
					
					$this->db->where($condition);
				}
				else
				{
					if($filter_parameter[1] == 'where')
						$this->db->where($filter_parameter[0], $value);
					else
						$this->db->like($filter_parameter[0], $value);
				}
			}

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));*/
			
			if($return == 'result_array')
			{
				/*$this->db->join('users', 'funding_submissions.applicant_user_id = users.user_id');
				$this->db->join('units', 'funding_submissions.utilizing_unit_id = units.unit_id');*/
				
				/*if($this->input->get('ordering_column') != NULL && $this->input->get('ordering_column') != '')
					$this->db->order_by($this->input->get('ordering_column'), 'DESC');*/
				
				return $this->db->get()->result_array();
			}
			else if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
				return $this->db->get()->row_array();
		}
		
		public function read_certificates($event_id)
		{
			$this->db->select('name');
			$this->db->from('certificates');
			$this->db->where('role', 'Instruktur');
			$this->db->where('event_id', $event_id);
			//$this->db->order_by('role', 'ASC');
			
			return $this->db->get()->result_array();
		}
		
		public function update_certificates($event_id)
		{
			$certificates = $this->project_management_model->read_certificates($event_id);

			foreach($certificates as &$certificate)
			{
				$certificate_data = array(
					'name' => $this->input->post('name['.$certificate['certificate_id'].']'),
					'company' => $this->input->post('company['.$certificate['certificate_id'].']'),
					'phone_number' => $this->input->post('phone_number['.$certificate['certificate_id'].']')
				);
				
				$this->db->where('certificate_id', $certificate['certificate_id']);
				$this->db->update('certificates', $certificate_data);
			}
		}
		
		public function delete($user_id)
		{
			if ($this->session->userdata('role_id') == 1) {
				$user_data = array(
					'user_status' => 'Dihapus'
				);
			
				$this->db->where('user_id', $user_id);
			
				return $this->db->update('users', $user_data);
			}
		}
	}
?>