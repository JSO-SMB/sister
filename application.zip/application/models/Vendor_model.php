<?php
	class Vendor_model extends CI_Model
	{
		public function create_update_vendor($hashed_password = '', $office_photo = '', $venues_photos = '', $vendor_id = 0)
		{
			$user_data = array(
				'name' => $this->input->post('name'),
				'phone_number' => $this->input->post('phone_number'),
				'email_address' => $this->input->post('email_address'),
				'city' => $this->input->post('city'),
				'address' => $this->input->post('address'),
				'bank' => $this->input->post('bank'),
				'account_number' => $this->input->post('account_number'),
				'accountee' => $this->input->post('accountee')
			);

			if($hashed_password != '')
				$user_data['hashed_password'] = $hashed_password;

			$vendor_data = array(
                'whatsapp_number' => $this->input->post('whatsapp_number'),
				'website' => $this->input->post('website'),
				'type' => $this->input->post('type'),
				'stars' => $this->input->post('stars'),
				'average_hotel_room_rates' => $this->input->post('average_hotel_room_rates'),
				'hotel_meeting_room_minimal_pax' => $this->input->post('hotel_meeting_room_minimal_pax'),
				'hotel_meeting_room_per_pax_rate' => $this->input->post('hotel_meeting_room_per_pax_rate'),
				'marketing_name' => $this->input->post('marketing_name'),
				'marketing_phone_number' => $this->input->post('marketing_phone_number'),
				'marketing_email_address' => $this->input->post('marketing_email_address'),
				'notes' => $this->input->post('notes')
			);

			if($office_photo != '')
				$vendor_data['office_photo'] = $office_photo;
			
			if($venues_photos != '')
				$vendor_data['venues_photos'] = $venues_photos;

			if($vendor_id > 0)
			{
				$this->db->where('user_id', $this->input->post('user_id'));
				$this->db->update('users', $user_data);

				$this->db->where('vendor_id', $vendor_id);
				$this->db->update('vendors', $vendor_data);
			}
			else
			{
				$this->load->model('employee_model');
				
				$user_data['role_id'] = 2;
				$user_data['user_status'] = 'Aktif';

				$this->db->insert('users', $user_data);

				$user_role = $this->employee_model->read_users_roles($this->input->post('email_address'));

				$vendor_data['user_id'] = $user_role['user_id'];

				$this->db->insert('vendors', $vendor_data);
			}
		}
		
		public function read_users_vendors($join_tables_list = '', $page_number = 0, $return = 'result_array', $query = '', $vendor_id = 0, $type = '')
		{
			$this->db->select('*');
			$this->db->from('vendors');

			if($join_tables_list != '')
			{
				$join_tables = explode(',', $join_tables_list);
				
				foreach($join_tables as &$join_table)
				{
					$this->db->join($join_table.'s', 'vendors.'.$join_table.'_id = '.$join_table.'s.'.$join_table.'_id');
				}
			}
			
			if($vendor_id > 0)
				$this->db->where('vendor_id', $vendor_id);
			
			if($query != '')
				$this->db->like('name', $query);

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			if($type != '')
				$this->db->where('type', $type);
			
			if($return == 'result_array')
			{
				$this->db->order_by('name', 'ASC');

				return $this->db->get()->result_array();
			}
			else if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
				return $this->db->get()->row_array();
		}
		
		public function delete($user_id)
		{
			if ($this->session->userdata('role_id') == 1) {
				$user_data = array(
					'user_status' => 'Dihapus'
				);
			
				$this->db->where('user_id', $user_id);
			
				return $this->db->update('users', $user_data);
			}	
		}
	}
?>