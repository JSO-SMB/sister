<?php
	class Contract_model extends CI_Model
	{
		public function read_roles()
		{
			$query = $this->db->get('roles');
			
			return $query->result_array();
		}

		public function read_email_address($email_address, $user_id = 0)
		{
			if($user_id == 0)
				$query = $this->db->get_where('users', array('email_address' => $email_address));
			else
			{
				$this->db->select('*');
				$this->db->from('users');
				$this->db->where('user_id <>', $user_id);
				$this->db->where('user_email_address', $user_email_address);
				$this->db->where('user_status', 'Aktif');
				
				$query = $this->db->get();
			}
			
			return $query->row_array();
		}
		
		public function create_update_contract($specific_period_work_agreement = '', $resignation_letter = '', $transfer_letter = '', $warning_letter = '', $contract_id = 0)
		{
			$contract_data = array(
				'reference_number' => $this->input->post('reference_number'),
				'user_id' => $this->input->post('user_id'),
				'position' => $this->input->post('position'),
				'company_representative_user_id' => $this->input->post('company_representative_user_id'),
				'company_representative_division' => $this->input->post('company_representative_division'),
				'company_representative_position' => $this->input->post('company_representative_position'),
				'unit_id' => $this->input->post('unit_id'),
				'contract_type' => $this->input->post('contract_type'),
				'office_location' => $this->input->post('office_location'),
				'basic_salary' => $this->input->post('basic_salary'),
				'regular_overtime_pay' => $this->input->post('regular_overtime_pay'),
				'extra_overtime_pay' => $this->input->post('extra_overtime_pay'),
				'in_town_duty_per_diem' => $this->input->post('in_town_duty_per_diem'),
				'out_town_duty_per_diem' => $this->input->post('out_town_duty_per_diem'),
				'turnover_target' => $this->input->post('turnover_target'),
				'positional_allowance' => $this->input->post('positional_allowance'),
				'credit_allowance' => $this->input->post('credit_allowance'),
				'performance_allowance' => $this->input->post('performance_allowance'),
				'insurance_allowance' => $this->input->post('insurance_allowance'),
				'holiday_allowance' => $this->input->post('holiday_allowance'),
				'absence_cuts_per_day' => $this->input->post('absence_cuts_per_day'),
				'late_charge_per_hour' => $this->input->post('late_charge_per_hour'),
				'paid_leave_granted' => $this->input->post('paid_leave_granted'),
				'monthly_fee_a' => $this->input->post('monthly_fee_a'),
				'quarterly_fee_a' => $this->input->post('quarterly_fee_a'),
				'annual_fee_a' => $this->input->post('annual_fee_a'),
				'profit_target_a' => $this->input->post('profit_target_a'),
				'monthly_fee_b' => $this->input->post('monthly_fee_b'),
				'quarterly_fee_b' => $this->input->post('quarterly_fee_b'),
				'annual_fee_b' => $this->input->post('annual_fee_b'),
				'profit_target_b' => $this->input->post('profit_target_b'),
				'monthly_fee_c' => $this->input->post('monthly_fee_c'),
				'quarterly_fee_c' => $this->input->post('quarterly_fee_c'),
				'annual_fee_c' => $this->input->post('annual_fee_c'),
				'profit_target_c' => $this->input->post('profit_target_c'),
				'monthly_fee_d' => $this->input->post('monthly_fee_d'),
				'quarterly_fee_d' => $this->input->post('quarterly_fee_d'),
				'annual_fee_d' => $this->input->post('annual_fee_d'),
				'profit_target_d' => $this->input->post('profit_target_d'),
				'notes' => $this->input->post('notes')
			);

			$employee_data = array(
				'division' => $this->input->post('division')
			);

			if($contract_id == 0)
			{
				$contract_data['division'] = $this->input->post('division');
				$contract_data['specific_period_work_agreement'] = $specific_period_work_agreement;
				$contract_data['effective_date'] = $this->input->post('effective_date');
				$contract_data['expiry_date'] = $this->input->post('expiry_date');
				$contract_data['status'] = 'Valid';

				$this->db->insert('contracts', $contract_data);

				$user_data = array(
					'user_status' => 'Aktif'
				);

				$this->db->where('user_id', $this->input->post('user_id'));
				$this->db->update('users', $user_data);

				$this->db->where('user_id', $this->input->post('user_id'));
				return $this->db->update('employees', $employee_data);
			}
			else
			{
				if($specific_period_work_agreement != '')
				{
					$contract_data['specific_period_work_agreement'] = $specific_period_work_agreement;
					$contract_data['effective_date'] = $this->input->post('effective_date');
					$contract_data['expiry_date'] = $this->input->post('expiry_date');
				}
				
				if($resignation_letter != '')
				{
					$contract_data['resignation_letter'] = $resignation_letter;
					$contract_data['receipt_date'] = $this->input->post('receipt_date');
					$contract_data['dismissal_date'] = $this->input->post('dismissal_date');
					$contract_data['reason'] = $this->input->post('reason');

					$user_data = array(
						'user_status' => 'Resign'
					);
				}

				if($transfer_letter != '')
				{
					$contract_data['division'] = $this->input->post('division');
					
					$transfer_data = array(
						'transfer_letter' => $transfer_letter,
						'information' => $this->input->post('information'),
						'contract_id' => $contract_id
					);
					
					$this->db->insert('transfer_letters', $transfer_data);

					$this->db->where('user_id', $this->input->post('user_id'));
					$this->db->update('employees', $employee_data);
				}

				$this->db->where('contract_id', $contract_id);
				$this->db->update('contracts', $contract_data);

				if($warning_letter != '')
				{
					$warning_letter_data = array(
						'warning_letter' => $warning_letter,
						'letter_type' => $this->input->post('letter_type'),
						'date_of_issue' => $this->input->post('date_of_issue'),
						'cause' => $this->input->post('cause'),
						'contract_id' => $contract_id
					);

					$this->db->insert('warning_letters', $warning_letter_data);

					if($this->input->post('letter_type') == 'SP 3')
						$user_data = array(
							'user_status' => 'SP 3'
						);
				}

				if($resignation_letter != '' || $this->input->post('letter_type') == 'SP 3')
				{
					$this->db->where('user_id', $this->input->post('user_id'));
					$this->db->update('users', $user_data);
				}
			}
		}
		
		public function read_users($join_table = '', $user_status = '', $user_id = 0)
		{
			$this->db->select('*');
			$this->db->from('users');
			$this->db->where('role_id', 1);
			
			if($join_table != '')
				$this->db->join($join_table, 'users.user_id = '.$join_table.'.user_id');
			
			if($user_status != '')
				$this->db->where('user_status', $user_status);
			
			if($user_id > 0)
            {
				$this->db->where('user_id', $user_id);

				return $this->db->get()->row_array();
			}
			else
            	return $this->db->get()->result_array();
		}
		
		public function read_contracts($reference_number = '', $return = 'num_rows', $join_tables_list = '', $contract_id = 0, $query = '', $user_status = 'all', $page_number = 0, $additional_columns = '')
		{
			$this->db->select('*'.$additional_columns);
			$this->db->from('contracts');

			if($join_tables_list != '')
			{
				$join_tables = explode(',', $join_tables_list);
				
				foreach($join_tables as &$join_table)
				{
					$this->db->join($join_table.'s', 'contracts.'.$join_table.'_id = '.$join_table.'s.'.$join_table.'_id');

					if($join_table == 'user')
						$this->db->join('employees', $join_table.'s.'.$join_table.'_id = employees.'.$join_table.'_id');
				}
			}
			
			if($contract_id != 0)
				$this->db->where('contract_id', $contract_id);
			
			if($reference_number != '')
				$this->db->where('reference_number', $reference_number);
			
			if($query != '')
			{
				if($user_status == 'all')
					$this->db->like('users.name', $query);
				else
				{
					$this->db->where('user_status', $user_status);
					$this->db->where('contracts.unit_id', $query);
				}
			}

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else if($return == 'result_array')
			{
				$this->db->order_by('users.name', 'ASC');

				return $this->db->get()->result_array();
			}
			else
				return $this->db->get()->row_array();
		}
		
		public function read_transfer_letters($contract_id)
		{
			$this->db->select('*');
			$this->db->from('transfer_letters');
			$this->db->where('contract_id', $contract_id);
			
			return $this->db->get()->result_array();
		}
		
		public function read_warning_letter($contract_id, $letter_type = '')
		{
			$this->db->select('*');
			$this->db->from('warning_letters');

			if($letter_type != '')
				$this->db->where('letter_type', $letter_type);
			
			$this->db->where('contract_id', $contract_id);
			$this->db->order_by('date_of_issue', 'DESC');
			
			return $this->db->get()->row_array();
		}
		
        public function update_interview_invitation($user_id)
		{
			$employee_data = array(
				'interview_invitation' => 1
			);
			
			$this->db->where('user_id', $user_id);
            $this->db->update('employees', $employee_data);
		}
		
		public function read_remuneration($page_number = 0, $return = 'result_array')
		{
			$this->db->select('contracts.user_id as user_id, position, name');
			$this->db->distinct();
			$this->db->from('contracts');
			$this->db->join('users', 'contracts.user_id = users.user_id');
			$this->db->where('division', 'MARKETING');
			$this->db->where('expiry_date >=', date('Y-m-d'));

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			if($return == 'result_array')
			{
				$remuneration = $this->db->get()->result_array();

				if(!empty($remuneration))
				{
					for($remuneration_counter = 0; $remuneration_counter < $this->contract_model->read_remuneration($page_number, 'num_rows'); $remuneration_counter++)
					{
						$user_id = $remuneration[$remuneration_counter]['user_id'];
						
						$this->db->select_min('effective_date');
						$this->db->from('contracts');
						$this->db->where('user_id', $user_id);

						$contract = $this->db->get()->row_array();

						$interval = date_diff(date_create($contract['effective_date']), date_create(date('Y-m-d')));

						$remuneration[$remuneration_counter]['years_of_service'] = $interval->format('%y tahun %m bulan');

						$this->db->select('turnover_target, name');
						$this->db->from('contracts');
						$this->db->join('units', 'contracts.unit_id = units.unit_id');
						$this->db->where('user_id', $user_id);
						$this->db->where('division', 'MARKETING');
						$this->db->where('expiry_date >=', date('Y-m-d'));

						$contracts_units = $this->db->get()->result_array();

						$remuneration[$remuneration_counter]['turnover_target_total'] = 0;
						$remuneration[$remuneration_counter]['unit_names'] = '';

						foreach($contracts_units as &$contract_unit)
						{
							$remuneration[$remuneration_counter]['turnover_target_total'] = $remuneration[$remuneration_counter]['turnover_target_total'] + $contract_unit['turnover_target'];
							
							if($remuneration[$remuneration_counter]['unit_names'] != '')
								$remuneration[$remuneration_counter]['unit_names'] = $remuneration[$remuneration_counter]['unit_names'].', ';
							
							$remuneration[$remuneration_counter]['unit_names'] = $remuneration[$remuneration_counter]['unit_names'].$contract_unit['name'];
						}

						$this->db->select('events.event_id as event_id, (clients_number * price) AS turnover, event_payments.submission_date AS submission_date');
						$this->db->distinct();
						$this->db->from('events');
						$this->db->join('event_payments', 'events.event_id = event_payments.event_id');
						$this->db->join('journal', 'events.event_id = journal.event_id');
						$this->db->where('payment_status', 3);
						$this->db->where('YEAR(event_payments.submission_date)', date('Y'));
						$this->db->where('transaction_type', 'IN: Event');
						$this->db->where('journal.approval_status', 'Approved');

						$event_payments = $this->db->get()->result_array();
						
						$remuneration[$remuneration_counter]['first_quarter_turnover'] = 0;
						$remuneration[$remuneration_counter]['second_quarter_turnover'] = 0;
						$remuneration[$remuneration_counter]['third_quarter_turnover'] = 0;

						if(!empty($event_payments))
						{
							foreach($event_payments as &$event_payment)
							{
								if($event_payment['submission_date'] < date('Y').'-05-01')
									$remuneration[$remuneration_counter]['first_quarter_turnover'] = $remuneration[$remuneration_counter]['first_quarter_turnover'] + $event_payment['turnover'];
								else if($event_payment['submission_date'] < date('Y').'-09-01')
									$remuneration[$remuneration_counter]['second_quarter_turnover'] = $remuneration[$remuneration_counter]['second_quarter_turnover'] + $event_payment['turnover'];
								else
									$remuneration[$remuneration_counter]['third_quarter_turnover'] = $remuneration[$remuneration_counter]['third_quarter_turnover'] + $event_payment['turnover'];
							}
						}

						$remuneration[$remuneration_counter]['annual_turnover'] = $remuneration[$remuneration_counter]['first_quarter_turnover'] + $remuneration[$remuneration_counter]['second_quarter_turnover'] + $remuneration[$remuneration_counter]['third_quarter_turnover'];
					}
				}

				return $remuneration;
			}
			else if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
				return $this->db->get()->row_array();
		}
		
		public function delete($user_id)
		{
			if ($this->session->userdata('role_id') == 1) {
				$user_data = array(
					'user_status' => 'Dihapus'
				);
			
				$this->db->where('user_id', $user_id);
			
				return $this->db->update('users', $user_data);
			}	
		}

		public function update_user_status($user_id, $user_status)
		{
			$this->db->where('user_id', $user_id);
			$this->db->update('users', array('user_status' => $user_status));
		}
	}
?>