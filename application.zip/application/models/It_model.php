<?php
	class It_model extends CI_Model
	{
		public function read_roles()
		{
			$query = $this->db->get('roles');
			
			return $query->result_array();
		}
		
		public function create_update_it_data($it_data_id = 0)
		{
			$type = $this->input->post('type');
			
			$it_data = array(
                'unit_id' => $this->input->post('unit_id'),
				'type' => $type
			);

			if($type == 'Hosting')
			{
				if(!empty($this->input->post('domain_it_data_id')))
					$it_data['domain_it_data_id'] = implode(',', $this->input->post('domain_it_data_id'));
				
				$it_data['last_update_date'] = $this->input->post('last_update_date');
				$it_data['space_total'] = $this->input->post('space_total');
				$it_data['space_used'] = $this->input->post('space_used');
				$it_data['cpanel_username'] = $this->input->post('cpanel_username');
				$it_data['cpanel_url'] = $this->input->post('cpanel_url');
				$it_data['cpanel_password'] = $this->input->post('cpanel_password');
				$it_data['ftp_username'] = $this->input->post('ftp_username');
				$it_data['ftp_password'] = $this->input->post('ftp_password');
			}
			else if($type == 'Domain')
			{
				$it_data['hosting_it_data_id'] = $this->input->post('hosting_it_data_id');
				$it_data['epp_code'] = $this->input->post('epp_code');
				$it_data['widget_backlink_text'] = $this->input->post('widget_backlink_text');
				$it_data['webmaster_tools_email_address_it_data_id'] = $this->input->post('webmaster_tools_email_address_it_data_id');
				$it_data['live_chat_username'] = $this->input->post('live_chat_username');
				$it_data['live_chat_email_address'] = $this->input->post('live_chat_email_address');
				$it_data['live_chat_password'] = $this->input->post('live_chat_password');
				$it_data['whois_privacy_price'] = str_replace('.', '', $this->input->post('whois_privacy_price'));
				$it_data['ssl_certificate_price'] = str_replace('.', '', $this->input->post('ssl_certificate_price'));
				$it_data['post_draft'] = $this->input->post('post_draft');
				$it_data['post_published'] = $this->input->post('post_published');
				$it_data['post_scheduled'] = $this->input->post('post_scheduled');
				$it_data['post_last_publish_date'] = $this->input->post('post_last_publish_date');
				$it_data['wp_username'] = $this->input->post('wp_username');
				$it_data['wp_admin_url'] = $this->input->post('wp_admin_url');
				$it_data['wp_password'] = $this->input->post('wp_password');
				$it_data['wp_theme'] = $this->input->post('wp_theme');
				$it_data['registrant_name'] = $this->input->post('registrant_name');
				$it_data['registrant_email_address'] = $this->input->post('registrant_email_address');
				$it_data['registrant_phone_number'] = $this->input->post('registrant_phone_number');
				$it_data['cp_a_user_id'] = $this->input->post('cp_a_user_id');
				$it_data['cp_a_mobile_number_it_data_id'] = $this->input->post('cp_a_mobile_number_it_data_id');
				$it_data['cp_a_email_address_it_data_id'] = $this->input->post('cp_a_email_address_it_data_id');
				$it_data['cp_b_user_id'] = $this->input->post('cp_b_user_id');
				$it_data['cp_b_mobile_number_it_data_id'] = $this->input->post('cp_b_mobile_number_it_data_id');
				$it_data['cp_b_email_address_it_data_id'] = $this->input->post('cp_b_email_address_it_data_id');
				$it_data['cp_c_user_id'] = $this->input->post('cp_c_user_id');
				$it_data['cp_c_mobile_number_it_data_id'] = $this->input->post('cp_c_mobile_number_it_data_id');
				$it_data['cp_c_email_address_it_data_id'] = $this->input->post('cp_c_email_address_it_data_id');
				$it_data['cp_d_user_id'] = $this->input->post('cp_d_user_id');
				$it_data['cp_d_mobile_number_it_data_id'] = $this->input->post('cp_d_mobile_number_it_data_id');
				$it_data['cp_d_email_address_it_data_id'] = $this->input->post('cp_d_email_address_it_data_id');
				$it_data['cp_e_user_id'] = $this->input->post('cp_e_user_id');
				$it_data['cp_e_mobile_number_it_data_id'] = $this->input->post('cp_e_mobile_number_it_data_id');
				$it_data['cp_e_email_address_it_data_id'] = $this->input->post('cp_e_email_address_it_data_id');
				$it_data['cp_f_user_id'] = $this->input->post('cp_f_user_id');
				$it_data['cp_f_mobile_number_it_data_id'] = $this->input->post('cp_f_mobile_number_it_data_id');
				$it_data['cp_f_email_address_it_data_id'] = $this->input->post('cp_f_email_address_it_data_id');
				$it_data['manager_user_id'] = $this->input->post('manager_user_id');
			}
			else if($type == 'email')
			{
				$it_data['email_username'] = $this->input->post('email_username');
				$it_data['email_password'] = $this->input->post('email_password');
				$it_data['email_mobile_number_it_data_id'] = $this->input->post('email_mobile_number_it_data_id');
				$it_data['email_notes'] = $this->input->post('email_notes');
				$it_data['division'] = $this->input->post('division');
			}
			else if($type == 'Nomor HP/Telepon')
			{
				$it_data['mobile_number'] = $this->input->post('mobile_number');
				$it_data['inventory_id'] = $this->input->post('inventory_id');
				$it_data['registration'] = $this->input->post('registration');
				$it_data['status'] = $this->input->post('status');
			}
			else
			{
				$it_data['social_media_name'] = $this->input->post('social_media_name');
				$it_data['social_media_link'] = $this->input->post('social_media_link');
				$it_data['social_media_email_address_it_data_id'] = $this->input->post('social_media_email_address_it_data_id');
				$it_data['account_username'] = $this->input->post('account_username');
				$it_data['account_password'] = $this->input->post('account_password');
			}

			if($type != 'Nomor HP/Telepon')
			{
				$it_data['data_name'] = $this->input->post('data_name');
				
				if($type == 'Hosting' || $type == 'Domain')
				{
					$it_data['vendor_id'] = $this->input->post('vendor_id');
					$it_data['purchase_date'] = $this->input->post('purchase_date');
					$it_data['annual_renewal_price'] = str_replace('.', '', $this->input->post('annual_renewal_price'));
				}
				else
					$it_data['creation_date'] = $this->input->post('creation_date');
			}

			if($type == 'email' || $type == 'Nomor HP/Telepon' || $type == 'Akun Medsos dll.')
				$it_data['pic_user_id'] = $this->input->post('pic_user_id');
			
			if($it_data_id < 1)
				$this->db->insert('it_data', $it_data);
			else
			{
                $this->db->where('it_data_id', $it_data_id);
				$this->db->update('it_data', $it_data);
			}
		}
		
		public function read_it_data($columns = '*', $unit_id = 0, $type = '', $account = '', $return = 'result_array', $query = '', $page_number = 0, $it_data_id = 0)
		{
			$this->db->select($columns);
            $this->db->from('it_data');
            $this->db->join('units', 'it_data.unit_id = units.unit_id');
            //$this->db->join('users', 'vendors.user_id = users.user_id');
			
			if($unit_id > 0)
                $this->db->where('it_data.unit_id', $unit_id);
			
			if($type != '')
				$this->db->where('type', $type);
			
			if($account != '')
			{
				if($type == 'Hosting' || $type == 'Domain')
					$column = 'data_name';
				else if($type == 'email')
					$column = 'email_username';
				else if($type == 'Nomor HP/Telepon')
					$column = 'mobile_number';
				else
					$column = 'social_media_link';
				
				$this->db->where($column, $account);
			}
			
			if($it_data_id > 0)
                $this->db->where('it_data_id', $it_data_id);
			
            if($query != '')
            {
				$this->db->like('data_name', $query);
				$this->db->or_like('mobile_number', $query);
			}

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			if($return == 'result_array')
			{
                // $this->db->group_by('type, it_data.unit_id');
                $this->db->order_by('type', 'ASC');
                $this->db->order_by('data_name', 'ASC');

				return $this->db->get()->result_array();
			}
			else if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
				return $this->db->get()->row_array();
		}
		
		public function read_users_roles_contracts($division = '', $position = '', $unit_id = 0, $user_status = '')
		{
			$this->db->select('*');
			$this->db->from('employees');
			$this->db->join('users', 'employees.user_id = users.user_id');
			
			if($position != '' || $unit_id > 0)
			{
				$this->db->join('contracts', 'employees.user_id = contracts.user_id AND employees.division = contracts.division');

				if($position != '')
				    $this->db->where('position', $position);
                
                if($unit_id > 0)
					$this->db->where('unit_id', $unit_id);
                
                $this->db->where('expiry_date >', date('Y-m-d'));
			}
			
			if($division != '')
			    $this->db->where('employees.division', $division);
            
            $this->db->where('user_status', 'Aktif');

			return $this->db->get()->result_array();
		}
		
		public function delete($user_id)
		{
			if ($this->session->userdata('role_id') == 1) {
				$user_data = array(
					'user_status' => 'Dihapus'
				);
			
				$this->db->where('user_id', $user_id);
			
				return $this->db->update('users', $user_data);
			}	
		}
	}
?>