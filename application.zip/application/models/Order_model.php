<?php
	class Order_model extends CI_Model
	{
		public function read_roles()
		{
			$query = $this->db->get('roles');
			
			return $query->result_array();
		}
		
		public function create_update_order($proof = '', $order_id = 0)
		{
			if($this->session->userdata('role_id') < 2)
				$order_data = array(
					'approval_status' => $this->input->post('approval_status')
				);
			else
			{
				$order_data = array(
					'nearest_city' => $this->input->post('nearest_city'),
					'total_bill' => str_replace('.', '', $this->input->post('total_bill')),
					'item' => $this->input->post('item'),
					'quantity' => $this->input->post('quantity'),
					'price' => str_replace('.', '', $this->input->post('price')),
					'estimated_completion_date' => $this->input->post('estimated_completion_date'),
					'unit_id' => $this->input->post('unit_id'),
					'notes' => $this->input->post('notes')
				);
				
				if($proof != '')
					$order_data['proof'] = $proof;
			}

			if($order_id > 0)
			{
				$this->db->where('order_id', $order_id);
				$this->db->update('orders', $order_data);
			}
			else
			{
                $order_data['order_date'] = date('Y-m-d');
                $order_data['vendor_id'] = $this->input->post('vendor_id');

				$this->db->insert('orders', $order_data);
			}
		}
		
		public function read_users_orders($columns = '*', $vendor_id = 0, $page_number = 0, $return = 'result_array', $order_date = '', $order_id = 0, $item = '', $unit_id = 0, $approval_status = '', $nearest_city = 'Semua Gudang')
		{
			$this->db->select($columns);
			$this->db->from('orders');

			$this->db->join('vendors', 'orders.vendor_id = vendors.vendor_id');
			$this->db->join('users', 'vendors.user_id = users.user_id');
			
			if($unit_id == 0)
            	$this->db->join('units', 'orders.unit_id = units.unit_id');
			else
				$this->db->where('orders.unit_id', $unit_id);
			
			if($order_id > 0)
                $this->db->where('order_id', $order_id);
			
            if($order_date != '')
                $this->db->where('order_date', $order_date);
			
			if($nearest_city != 'Semua Gudang')
				$this->db->where('nearest_city', $nearest_city);
			
			if($item != '')
				$this->db->where('item', $item);
            
			if($vendor_id > 0)
				$this->db->where('orders.vendor_id', $vendor_id);
			
			if($approval_status != '')
				$this->db->where('approval_status', $approval_status);

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			if($return == 'result_array')
			{
				$this->db->order_by('order_date', 'DESC');

				return $this->db->get()->result_array();
			}
			else if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
				return $this->db->get()->row_array();
		}
		
		public function read_inventories($page_number, $return = 'result_array')
		{
			$this->db->select('inventory_item, inventory_item_quantity, inventory_item_unit, users.name as pic, units.name as unit_name, transaction_date, journal.nominal as purchase_price');
			$this->db->from('funding_submissions');
			$this->db->join('users', 'funding_submissions.applicant_user_id = users.user_id');
			$this->db->join('units', 'funding_submissions.utilizing_unit_id = units.unit_id');
			$this->db->join('journal', 'funding_submissions.funding_submission_id = journal.funding_submission_id');
				
			if($this->input->get('utilizing_unit_id') != NULL && $this->input->get('utilizing_unit_id') != '')
				$this->db->where('utilizing_unit_id', $this->input->get('utilizing_unit_id'));
			
			$this->db->where('transaction_type', 'OUT: Pengajuan');
			$this->db->where('(debt_reference_code = "aset tetap" OR debt_reference_code = "inventaris kantor" OR debt_reference_code = "kendaraan kantor" OR debt_reference_code = "gedung kantor" OR credit_reference_code = "aset tetap" OR credit_reference_code = "inventaris kantor" OR credit_reference_code = "kendaraan kantor" OR credit_reference_code = "gedung kantor")');

			if($this->input->get('transaction_date') != NULL && $this->input->get('transaction_date') != '')
				$this->db->like('transaction_date', urldecode($this->input->get('transaction_date')));

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			if($return == 'result_array')
			{
				$this->db->order_by('transaction_date', 'DESC');

				return $this->db->get()->result_array();
			}
			else if($return == 'num_rows')
				return $this->db->get()->num_rows();
		}
		
		public function delete($user_id)
		{
			if ($this->session->userdata('role_id') == 1) {
				$user_data = array(
					'user_status' => 'Dihapus'
				);
			
				$this->db->where('user_id', $user_id);
			
				return $this->db->update('users', $user_data);
			}	
		}
	}
?>