<?php
	class Event_model extends CI_Model
	{
		public function create_update_event($event_id)
		{
			$logged_in_user = $this->employee_model->read_users_roles($this->session->userdata('email_address'), 0, 'employees');
			
			if($logged_in_user['division'] == 'LOGISTIK')
				$event_data = array(
					'approval_status' => $this->input->post('approval_status')
				);
			else
				$event_data = array(
					'proposal_date' => $this->input->post('proposal_date'),
					'name' => $this->input->post('name'),
					'category' => $this->input->post('category'),
					'type' => $this->input->post('type'),
					'status' => $this->input->post('status'),
					'start_date' => $this->input->post('start_date'),
					'end_date' => $this->input->post('end_date'),
					'starting_hour' => $this->input->post('starting_hour').':00',
					'completion_hour' => $this->input->post('completion_hour').':00',
					'instructor_user_id' => $this->input->post('instructor_user_id'),
					'number_of_instructors' => $this->input->post('number_of_instructors'),
					'city' => $this->input->post('city'),
					'hotel_vendor_id' => $this->input->post('hotel_vendor_id'),
					'marketing_user_id' => $this->input->post('marketing_user_id'),
					'cs_user_id' => $this->input->post('cs_user_id'),
					'transportation_vendor_id' => $this->input->post('transportation_vendor_id'),
					'driver_user_id' => $this->input->post('driver_user_id'),
					'manager_user_id' => $this->input->post('manager_user_id'),
					'source' => $this->input->post('source'),
					'source_detail' => $this->input->post('source_detail'),
					'client_id' => $this->input->post('client_id'),
					'clients_number' => $this->input->post('clients_number'),
					'meeting_room' => $this->input->post('meeting_room'),
					'accommodation' => $this->input->post('accommodation'),
					'logistic_user_id' => $this->input->post('logistic_user_id'),
					'trip' => $this->input->post('trip'),
					'custom_souvenir' => $this->input->post('custom_souvenir'),
					'city_tour' => $this->input->post('city_tour'),
					'document_recipient' => $this->input->post('document_recipient'),
					'company_address' => $this->input->post('company_address'),
					'company_phone_number' => $this->input->post('company_phone_number'),
					'document_delivery' => $this->input->post('document_delivery'),
					'invoice_attachments' => $this->input->post('invoice_attachments'),
					'payment_plan' => $this->input->post('payment_plan'),
					'document_description' => $this->input->post('document_description'),
					'per_unit_instructor_a_honorarium' => str_replace('.', '', $this->input->post('per_unit_instructor_a_honorarium')),
					'instructor_a_quantity' => $this->input->post('instructor_a_quantity'),
					'per_unit_instructor_b_honorarium' => str_replace('.', '', $this->input->post('per_unit_instructor_b_honorarium')),
					'instructor_b_quantity' => $this->input->post('instructor_b_quantity'),
					'per_unit_meeting_room_budget' => str_replace('.', '', $this->input->post('per_unit_meeting_room_budget')),
					'meeting_room_quantity' => $this->input->post('meeting_room_quantity'),
					'per_unit_participant_accommodation_budget' => str_replace('.', '', $this->input->post('per_unit_participant_accommodation_budget')),
					'participant_accommodation_quantity' => $this->input->post('participant_accommodation_quantity'),
					'per_unit_certification_trip_budget' => str_replace('.', '', $this->input->post('per_unit_certification_trip_budget')),
					'certification_trip_quantity' => $this->input->post('certification_trip_quantity'),
					'per_unit_participant_transportation_budget' => str_replace('.', '', $this->input->post('per_unit_participant_transportation_budget')),
					'participant_transportation_quantity' => $this->input->post('participant_transportation_quantity'),
					'per_unit_instructor_accommodation_budget' => str_replace('.', '', $this->input->post('per_unit_instructor_accommodation_budget')),
					'instructor_accommodation_quantity' => $this->input->post('instructor_accommodation_quantity'),
					'per_unit_instructor_transportation_budget' => str_replace('.', '', $this->input->post('per_unit_instructor_transportation_budget')),
					'instructor_transportation_quantity' => $this->input->post('instructor_transportation_quantity'),
					'per_unit_module_budget' => str_replace('.', '', $this->input->post('per_unit_module_budget')),
					'module_quantity' => $this->input->post('module_quantity'),
					'per_unit_certificate_budget' => str_replace('.', '', $this->input->post('per_unit_certificate_budget')),
					'certificate_quantity' => $this->input->post('certificate_quantity'),
					'per_unit_folder_budget' => str_replace('.', '', $this->input->post('per_unit_folder_budget')),
					'folder_quantity' => $this->input->post('folder_quantity'),
					'per_unit_envelope_budget' => str_replace('.', '', $this->input->post('per_unit_envelope_budget')),
					'envelope_quantity' => $this->input->post('envelope_quantity'),
					'per_unit_exclusive_bag_budget' => str_replace('.', '', $this->input->post('per_unit_exclusive_bag_budget')),
					'exclusive_bag_quantity' => $this->input->post('exclusive_bag_quantity'),
					'per_unit_economic_bag_budget' => str_replace('.', '', $this->input->post('per_unit_economic_bag_budget')),
					'economic_bag_quantity' => $this->input->post('economic_bag_quantity'),
					'per_unit_gift_budget' => str_replace('.', '', $this->input->post('per_unit_gift_budget')),
					'gift_quantity' => $this->input->post('gift_quantity'),
					'per_unit_batik_budget' => str_replace('.', '', $this->input->post('per_unit_batik_budget')),
					'batik_quantity' => $this->input->post('batik_quantity'),
					'per_unit_shirt_budget' => str_replace('.', '', $this->input->post('per_unit_shirt_budget')),
					'shirt_quantity' => $this->input->post('shirt_quantity'),
					'per_unit_powerbank_budget' => str_replace('.', '', $this->input->post('per_unit_powerbank_budget')),
					'powerbank_quantity' => $this->input->post('powerbank_quantity'),
					'per_unit_jacket_budget' => str_replace('.', '', $this->input->post('per_unit_jacket_budget')),
					'jacket_quantity' => $this->input->post('jacket_quantity'),
					'per_unit_placard_budget' => str_replace('.', '', $this->input->post('per_unit_placard_budget')),
					'placard_quantity' => $this->input->post('placard_quantity'),
					'per_unit_souvenir_budget' => str_replace('.', '', $this->input->post('per_unit_souvenir_budget')),
					'souvenir_quantity' => $this->input->post('souvenir_quantity'),
					'per_unit_name_tag_budget' => str_replace('.', '', $this->input->post('per_unit_name_tag_budget')),
					'name_tag_quantity' => $this->input->post('name_tag_quantity'),
					'per_unit_goody_bag_budget' => str_replace('.', '', $this->input->post('per_unit_goody_bag_budget')),
					'goody_bag_quantity' => $this->input->post('goody_bag_quantity'),
					'per_unit_ballpoint_budget' => str_replace('.', '', $this->input->post('per_unit_ballpoint_budget')),
					'ballpoint_quantity' => $this->input->post('ballpoint_quantity'),
					'per_unit_blocknote_budget' => str_replace('.', '', $this->input->post('per_unit_blocknote_budget')),
					'blocknote_quantity' => $this->input->post('blocknote_quantity'),
					'per_unit_flashdisk_budget' => str_replace('.', '', $this->input->post('per_unit_flashdisk_budget')),
					'flashdisk_quantity' => $this->input->post('flashdisk_quantity'),
					'per_unit_cd_budget' => str_replace('.', '', $this->input->post('per_unit_cd_budget')),
					'cd_quantity' => $this->input->post('cd_quantity'),
					'per_unit_documentation_budget' => str_replace('.', '', $this->input->post('per_unit_documentation_budget')),
					'documentation_quantity' => $this->input->post('documentation_quantity'),
					'per_unit_banner_budget' => str_replace('.', '', $this->input->post('per_unit_banner_budget')),
					'banner_quantity' => $this->input->post('banner_quantity'),
					'per_unit_value_added_tax' => str_replace('.', '', $this->input->post('per_unit_value_added_tax')),
					'value_added_tax_quantity' => $this->input->post('value_added_tax_quantity'),
					'per_unit_agent_fee' => str_replace('.', '', $this->input->post('per_unit_agent_tax')),
					'agent_quantity' => $this->input->post('agent_quantity'),
					'per_unit_driver_fee' => str_replace('.', '', $this->input->post('per_unit_driver_tax')),
					'driver_quantity' => $this->input->post('driver_quantity'),
					'per_unit_cs_fee' => str_replace('.', '', $this->input->post('per_unit_cs_tax')),
					'cs_quantity' => $this->input->post('cs_quantity'),
					'per_unit_rental_cost' => str_replace('.', '', $this->input->post('per_unit_rental_cost')),
					'rental_quantity' => $this->input->post('rental_quantity'),
					'per_unit_meal_budget' => str_replace('.', '', $this->input->post('per_unit_meal_budget')),
					'meal_quantity' => $this->input->post('meal_quantity'),
					'per_unit_city_tour_budget' => str_replace('.', '', $this->input->post('per_unit_city_tour_budget')),
					'city_tour_quantity' => $this->input->post('city_tour_quantity'),
					'per_unit_operational_budget' => str_replace('.', '', $this->input->post('per_unit_operational_budget')),
					'operational_quantity' => $this->input->post('operational_quantity'),
					'per_unit_team_accommodation_budget' => str_replace('.', '', $this->input->post('per_unit_team_accommodation_budget')),
					'team_accommodation_quantity' => $this->input->post('team_accommodation_quantity'),
					'per_unit_team_transportation_budget' => str_replace('.', '', $this->input->post('per_unit_team_transportation_budget')),
					'team_transportation_quantity' => $this->input->post('team_transportation_quantity'),
					'per_unit_income_tax' => str_replace('.', '', $this->input->post('per_unit_income_tax')),
					'income_tax_quantity' => $this->input->post('income_tax_quantity'),
					'per_unit_delivery_budget' => str_replace('.', '', $this->input->post('per_unit_delivery_budget')),
					'delivery_quantity' => $this->input->post('delivery_quantity'),
					'price' => str_replace('.', '', $this->input->post('price')),
					'notes' => $this->input->post('notes'),
					'nearest_city' => $this->input->post('nearest_city')
				);

			if($event_id == 0)
			{
				$event_data['unit_id'] = $this->input->post('unit_id');
				
				$this->db->insert('events', $event_data);

				$this->db->select_max('event_id');
				$this->db->from('events');
				
				$event = $this->db->get()->row_array();

				$role[1] = 'Peserta';
				$role[2] = 'Instruktur';

				$certificate_count[1] = $this->input->post('clients_number');
				$certificate_count[2] = $this->input->post('number_of_instructors');

				for($role_counter = 1; $role_counter < 3; $role_counter++)
				{
					$certificate_data = array(
						'role' => $role[$role_counter],
						'event_id' => $event['event_id']
					);

					for($certificate_counter = 1; $certificate_counter <= $certificate_count[$role_counter]; $certificate_counter++)
					{
						$this->db->insert('certificates', $certificate_data);
					}
				}
			}
			else
			{
				$this->db->where('event_id', $event_id);
				$this->db->update('events', $event_data);

				if($logged_in_user['division'] != 'LOGISTIK')
				{
					$this->db->select_max('event_id');
					$this->db->from('events');
					
					$event = $this->db->get()->row_array();

					$role[1] = 'Peserta';
					$role[2] = 'Instruktur';

					$new_certificate_count[1] = $this->input->post('clients_number');
					$new_certificate_count[2] = $this->input->post('number_of_instructors');

					for($role_counter = 1; $role_counter < 3; $role_counter++)
					{
						$this->db->select('*');
						$this->db->from('certificates');
						$this->db->where('role', $role[$role_counter]);
						$this->db->where('event_id', $event_id);

						$certificate_count = $this->db->get()->num_rows();

						if($new_certificate_count[$role_counter] > $certificate_count)
						{
							$certificate_data = array(
								'role' => $role[$role_counter],
								'event_id' => $event_id
							);

							$additional_certificate_count = $new_certificate_count[$role_counter] - $certificate_count;

							for($certificate_counter = 1; $certificate_counter <= $additional_certificate_count; $certificate_counter++)
							{
								$this->db->insert('certificates', $certificate_data);
							}
						}
						else if($new_certificate_count[$role_counter] < $certificate_count)
						{
							$certificate_data = array(
								'role' => $role[$role_counter],
								'event_id' => $event_id
							);

							$excess_certificate_count = $certificate_count - $new_certificate_count[$role_counter];

							for($certificate_counter = 1; $certificate_counter <= $excess_certificate_count; $certificate_counter++)
							{
								$this->db->select_max('certificate_id');
								$this->db->from('certificates');
								$this->db->where('role', $role[$role_counter]);
								$this->db->where('event_id', $event_id);
								
								$certificate = $this->db->get()->row_array();

								$this->db->delete('certificates', array('certificate_id' => $certificate['certificate_id']));
							}
						}
					}
				}
			}
		}
		
		public function read_users_roles_contracts($division = '', $user_id = 0, $unit_id = 0, $user_status = '')
		{
			$this->db->select('*');
			$this->db->from('employees');
			$this->db->join('users', 'employees.user_id = users.user_id');
			
			if($user_id > 0 || $unit_id > 0)
			{
				$this->db->join('contracts', 'employees.user_id = contracts.user_id AND employees.division = contracts.division');

				if($user_id > 0)
				{
					$this->db->where('employees.user_id', $user_id);

					return $this->db->get()->row_array();
				}
				else
				{
					$this->db->where('unit_id', $unit_id);
					$this->db->where('position', 'Manajer');
					$this->db->where('expiry_date >', 'CURDATE()');
				}
			}
			
			if($division != '')
			{
				$this->db->where('employees.division', $division);
				$this->db->where('user_status', 'Aktif');
				
				return $this->db->get()->result_array();
			}
		}
		
		public function read_clients($client_id = 0, $return = 'row_array', $query = '', $category = 'general', $page_number = 0, $join_tables_list = '', $additional_fields = '')
		{
			$this->db->select('*');
            $this->db->from('clients');
			
			if($client_id != 0)
			{
				$this->db->where('client_id', $client_id);

				return $this->db->get()->row_array();
			}
			else
				return $this->db->get()->result_array();
		}
		
		public function read_events_vendors_clients($columns = '*', $join_tables_list = '', $page_number = 0, $return = 'result_array', $status = 'all', $query = '', $event_id = 0, $client_id = 0, $approval_status = '', $nearest_city = 'Semua Gudang')
		{
			$this->db->select($columns);
			$this->db->from('events');

			if($join_tables_list != '')
			{
				$join_tables = explode(',', $join_tables_list);
				
				foreach($join_tables as &$join_table)
				{
					$this->db->join($join_table.'s', 'events.'.$join_table.'_id = '.$join_table.'s.'.$join_table.'_id');
				}
			}
			
			if($event_id != 0)
				$this->db->where('event_id', $event_id);
			
			if($status == 'Fixed')
			{
				$this->db->join('contracts', 'events.marketing_user_id = contracts.user_id');
				
				if($query > 0)
					$this->db->where('events.unit_id', $query);
				
				$this->db->where('status', $status);
			}
			else if($query != '')
				$this->db->like('events.name', $query);
			
			if($client_id != 0)
				$this->db->where('client_id', $client_id);
			
			if($nearest_city != 'Semua Gudang')
				$this->db->where('nearest_city', $nearest_city);
			
			if($approval_status != '')
				$this->db->where('approval_status', $approval_status);

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
			{
				$this->db->order_by('end_date', 'DESC');

				if($return == 'result_array')
				{
					$this->load->model('vendor_model');
					
					$events = $this->db->get()->result_array();

					if(!empty($events))
					{
						for($event_counter = 0; $event_counter < $this->event_model->read_events_vendors_clients('*', '', $page_number, 'num_rows', $status, urldecode($query)); $event_counter++)
						{
							$marketing = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['marketing_user_id']);
							
							$events[$event_counter]['marketing_name'] = $marketing['name'];

							$instructor = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['instructor_user_id']);
							
							$events[$event_counter]['instructor_name'] = $instructor['name'];

							$cs = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['cs_user_id']);
							
							$events[$event_counter]['cs_name'] = $cs['name'];

							$driver = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['driver_user_id']);
							
							$events[$event_counter]['driver_name'] = $driver['name'];

							$logistic = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['logistic_user_id']);
							
							$events[$event_counter]['logistic_name'] = $logistic['name'];

							$manager = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['manager_user_id']);
							
							$events[$event_counter]['manager_name'] = $manager['name'];

							$hotel = $this->vendor_model->read_users_vendors('user', 0, 'row_array', '', $events[$event_counter]['hotel_vendor_id']);
							
							$events[$event_counter]['hotel'] = $hotel['name'];
						}
					}

					return $events;
				}
				else
					return $this->db->get()->row_array();
			}
		}

		public function read_event_payments($columns = '*', $event_payment_id = 0, $payment_status = '', $event_id = 0, $group_by = '', $page_number = 0, $return = 'result_array')
		{
			$this->db->select($columns);
			$this->db->from('event_payments');
			
			$this->db->join('events', 'event_payments.event_id = events.event_id');
			$this->db->join('units', 'events.unit_id = units.unit_id');
			$this->db->join('users', 'events.marketing_user_id = users.user_id');
            
            if($event_payment_id > 0)
				$this->db->where('event_payment_id', $event_payment_id);
			
            if($payment_status != '')
                $this->db->where('payment_status', $payment_status);
            
			if($event_id > 0)
				$this->db->where('event_payments.event_id', $event_id);
			
			/*if($this->input->get('filter_value') != NULL && $this->input->get('filter_value') != '')
			{
				$filter_parameter = explode(',', urldecode($this->input->get('filter_column')));
				$value = urldecode($this->input->get('filter_value'));

				if($filter_parameter[1] == 'where')
					$this->db->where($filter_parameter[0], $value);
				else
					$this->db->like($filter_parameter[0], $value);
			}*/
			
			if($this->input->get('filter_value') != NULL && $this->input->get('filter_value') != '')
			{
				$filter_parameter = explode(',', urldecode($this->input->get('filter_column')));

				if($filter_parameter[0] == 'events.unit_id')
				{
					$value = urldecode($this->input->get('filter_value'));
					
					if($filter_parameter[1] == 'where')
						$this->db->where($filter_parameter[0], $value);
					else
						$this->db->like($filter_parameter[0], $value);
				}
			}
			
            if($group_by != '')
				$this->db->group_by($group_by);

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			if($return == 'result_array')
			{
                if($this->input->get('ordering_column') != NULL && $this->input->get('ordering_column') != '')
					$this->db->order_by($this->input->get('ordering_column'), 'DESC');
				
				return $this->db->get()->result_array();
			}
			else if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
				return $this->db->get()->row_array();
		}
		
		public function read_events_units_users($event_ids = array())
		{
			$this->db->select('event_id, events.name as event_name, start_date, end_date, units.name as unit_name, users.name as marketing_name');
			$this->db->from('events');

			$this->db->join('units', 'events.unit_id = units.unit_id');
			$this->db->join('users', 'events.marketing_user_id = users.user_id');

			if(!empty($event_ids))
				$this->db->where_not_in('event_id', $event_ids);
			
			$this->db->where('status', 'Fixed');
			
			$this->db->order_by('events.name', 'ASC');
			
			return $this->db->get()->result_array();
		}

		public function create_update_event_payment($file_names, $event_payment_id)
		{
			$columns = array(
				'payment_status',
				'payment_date',
				'event_id'
			);

			foreach($columns as &$column)
            {
				if($this->input->post($column) != NULL)
					$record_values[$column] = $this->input->post($column);
			}

			$record_values['nominal'] = str_replace('.', '', $this->input->post('nominal'));
            
            foreach($file_names as $key=>$value)
            {
                if($value != '')
                    $record_values[$key] = $value;
            }
			
			$table_name = 'event_payments';
			
			if($event_payment_id < 1)
			{
				$record_values['submission_date'] = date("Y-m-d");
				
				$this->db->insert($table_name, $record_values);
			}
			else
			{
				$this->db->where_in('event_payment_id', $event_payment_id);
				$this->db->update($table_name, $record_values);
			}
		}
		
		public function read_certificates($event_id)
		{
			$this->db->select('*');
			$this->db->from('certificates');
			$this->db->where('event_id', $event_id);
			$this->db->order_by('role', 'ASC');
			
			return $this->db->get()->result_array();
		}
		
		public function update_certificates($event_id)
		{
			$certificates = $this->event_model->read_certificates($event_id);

			foreach($certificates as &$certificate)
			{
				$certificate_data = array(
					'name' => $this->input->post('name['.$certificate['certificate_id'].']'),
					'company' => $this->input->post('company['.$certificate['certificate_id'].']'),
					'phone_number' => $this->input->post('phone_number['.$certificate['certificate_id'].']')
				);
				
				$this->db->where('certificate_id', $certificate['certificate_id']);
				$this->db->update('certificates', $certificate_data);
			}
		}

		//public function read_users_contracts($position = 'Staff', $page_number = 0, $return = 'result_array')
		public function read_users_contracts($position = 'Staff')
		{
			$this->db->select('contracts.user_id as user_id, name, monthly_fee_a, quarterly_fee_a, annual_fee_a, profit_target_a, monthly_fee_b, quarterly_fee_b, annual_fee_b, profit_target_b, monthly_fee_c, quarterly_fee_c, annual_fee_c, profit_target_c, monthly_fee_d, quarterly_fee_d, annual_fee_d, profit_target_d');
			$this->db->distinct();
			$this->db->from('contracts');
			$this->db->join('users', 'contracts.user_id = users.user_id');
			$this->db->where('division', 'MARKETING');
			$this->db->where('position', $position);
				
			if($this->input->get('unit_id') != NULL && $this->input->get('unit_id') != '')
				$this->db->where('unit_id', $this->input->get('unit_id'));
			
			$this->db->where('expiry_date >=', date('Y-m-d'));

			/*if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));*/
			
			//if($return == 'result_array')
				return $this->db->get()->result_array();
			//else
			//	return $this->db->get()->row_array();
		}
		
		public function read_events_financial_data($page_number = 0, $return = 'result_array')
		{
			$this->db->select('*, events.name as event_name, units.name as unit_name, users.name as marketing_name');
			$this->db->from('events');
			$this->db->join('units', 'events.unit_id = units.unit_id');
			$this->db->join('users', 'events.marketing_user_id = users.user_id');

			if($this->input->get('start_date') != NULL && $this->input->get('start_date') != '')
				$this->db->like('start_date', urldecode($this->input->get('start_date')));
				
			if($this->input->get('unit_id') != NULL && $this->input->get('unit_id') != '')
				$this->db->where('events.unit_id', $this->input->get('unit_id'));
				
			if($this->input->get('marketing_user_id') != NULL && $this->input->get('marketing_user_id') != '')
				$this->db->where('marketing_user_id', $this->input->get('marketing_user_id'));
			
			if($this->input->get('manager_user_id') != NULL && $this->input->get('manager_user_id') != '')
				$this->db->where('manager_user_id', $this->input->get('manager_user_id'));
			
			$this->db->where('status', 'Fixed');

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			//if($return == 'result_array' || ($return == 'row_array' && ($view == 'invoice' || $view == 'journal' || $view == 'tax' || $view == 'cashflow')))
			if($return == 'result_array')
            {
				$this->load->model('project_management_model');
				
				//$this->db->order_by('event_id', 'ASC');
				
				if($this->input->get('ordering') != NULL && $this->input->get('ordering') != '')
					$this->db->order_by('start_date', $this->input->get('ordering'));
				
				$events = $this->db->get()->result_array();

				if(empty($events))
					return $events;
				else
				{
					for($event_counter = 0; $event_counter < $this->event_model->read_events_financial_data($page_number, 'num_rows'); $event_counter++)
					{
						$training_kit_expenses = ($events[$event_counter]['per_unit_certificate_budget'] * $events[$event_counter]['certificate_quantity']) + ($events[$event_counter]['per_unit_folder_budget'] * $events[$event_counter]['folder_quantity']) + ($events[$event_counter]['per_unit_envelope_budget'] * $events[$event_counter]['envelope_quantity']) + ($events[$event_counter]['per_unit_exclusive_bag_budget'] * $events[$event_counter]['exclusive_bag_quantity']) + ($events[$event_counter]['per_unit_economic_bag_budget'] * $events[$event_counter]['economic_bag_quantity']) + ($events[$event_counter]['per_unit_gift_budget'] * $events[$event_counter]['gift_quantity']) + ($events[$event_counter]['per_unit_batik_budget'] * $events[$event_counter]['batik_quantity']) + ($events[$event_counter]['per_unit_shirt_budget'] * $events[$event_counter]['shirt_quantity']) + ($events[$event_counter]['per_unit_powerbank_budget'] * $events[$event_counter]['powerbank_quantity']) + ($events[$event_counter]['per_unit_jacket_budget'] * $events[$event_counter]['jacket_quantity']) + ($events[$event_counter]['per_unit_placard_budget'] * $events[$event_counter]['placard_quantity']) + ($events[$event_counter]['per_unit_souvenir_budget'] * $events[$event_counter]['souvenir_quantity']) + ($events[$event_counter]['per_unit_name_tag_budget'] * $events[$event_counter]['name_tag_quantity']) + ($events[$event_counter]['per_unit_goody_bag_budget'] * $events[$event_counter]['goody_bag_quantity']) + ($events[$event_counter]['per_unit_ballpoint_budget'] * $events[$event_counter]['ballpoint_quantity']) + ($events[$event_counter]['per_unit_blocknote_budget'] * $events[$event_counter]['blocknote_quantity']) + ($events[$event_counter]['per_unit_flashdisk_budget'] * $events[$event_counter]['flashdisk_quantity']) + ($events[$event_counter]['per_unit_cd_budget'] * $events[$event_counter]['cd_quantity']);
						
						$expenses_taxes_transactions = $this->project_management_model->read_journal('transaction_date, debt_reference_code, credit_reference_code, nominal', $events[$event_counter]['event_id'], '"beban instruktur", "beban hotel", "beban transportasi", "beban training", "beban ppn", "beban pph 23", "beban sewa", "beban konsumsi", "beban operasional", "beban kirim", "beban customer service", "beban driver", "beban training lain", "beban retur", "pendapatan usaha", "beban ppn", "beban pph 23", "beban pph 21", "beban pph final"');
						
						$total_expenses = 0;
						$instructor_expenses = 0;
						$hotel_expenses = 0;
						$transportation_expenses = 0;
						$training_expenses = 0;
						$rent_expenses = 0;
						$meal_expenses = 0;
						$operational_expenses = 0;
						$delivery_expenses = 0;
						$cs_expenses = 0;
						$driver_expenses = 0;
						$other_training_expenses = 0;
						$returns_expenses = 0;
						$value_added_tax_expenses = 0;
						$income_tax_article_23_expenses = 0;
						$events[$event_counter]['revenue'] = 0;

						foreach($expenses_taxes_transactions as &$expense_tax_transaction)
						{
							if($expense_tax_transaction['debt_reference_code'] == 'beban instruktur') {$instructor_expenses = $instructor_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban instruktur') {$instructor_expenses = $instructor_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban hotel') {$hotel_expenses = $hotel_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban hotel') {$hotel_expenses = $hotel_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban transportasi') {$transportation_expenses = $transportation_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban transportasi') {$transportation_expenses = $transportation_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban training') {$training_expenses = $training_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban training') {$training_expenses = $training_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban ppn')
							{
								$value_added_tax_expenses = $value_added_tax_expenses + $expense_tax_transaction['nominal'];
								$total_expenses = $total_expenses + $expense_tax_transaction['nominal'];
							}
							else if($expense_tax_transaction['credit_reference_code'] == 'beban ppn')
							{
								$value_added_tax_expenses = $value_added_tax_expenses - $expense_tax_transaction['nominal'];
								$total_expenses = $total_expenses - $expense_tax_transaction['nominal'];
							}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban pph 23')
							{
								$income_tax_article_23_expenses = $income_tax_article_23_expenses + $expense_tax_transaction['nominal'];
								$total_expenses = $total_expenses + $expense_tax_transaction['nominal'];
							}
							else if($expense_tax_transaction['credit_reference_code'] == 'beban pph 23')
							{
								$income_tax_article_23_expenses = $income_tax_article_23_expenses - $expense_tax_transaction['nominal'];
								$total_expenses = $total_expenses - $expense_tax_transaction['nominal'];
							}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban sewa') {$rent_expenses = $rent_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban sewa') {$rent_expenses = $rent_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban konsumsi') {$meal_expenses = $meal_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban konsumsi') {$meal_expenses = $meal_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban operasional') {$operational_expenses = $operational_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban operasional') {$operational_expenses = $operational_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban kirim') {$delivery_expenses = $delivery_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban kirim') {$delivery_expenses = $delivery_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban customer service') {$cs_expenses = $cs_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban customer service') {$cs_expenses = $cs_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban driver') {$driver_expenses = $driver_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban driver') {$driver_expenses = $driver_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban training lain') {$other_training_expenses = $other_training_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban training lain') {$other_training_expenses = $other_training_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban retur') {$returns_expenses = $returns_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban retur') {$returns_expenses = $returns_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['credit_reference_code'] == 'pendapatan usaha')
								$events[$event_counter]['revenue'] = $events[$event_counter]['revenue'] + $expense_tax_transaction['nominal'];
							else if($expense_tax_transaction['debt_reference_code'] == 'pendapatan usaha')
								$events[$event_counter]['revenue'] = $events[$event_counter]['revenue'] - $expense_tax_transaction['nominal'];
						}

						$real_expenses = $training_kit_expenses + $total_expenses;
						$events[$event_counter]['profit_loss'] = $events[$event_counter]['revenue'] - $real_expenses;

						$events[$event_counter]['event_payments'] = $this->event_model->read_event_payments('proof_of_payment', 0, '', $events[$event_counter]['event_id']);
					}

					return $events;
				}
			}
            else
            	return $this->db->get()->num_rows();
		}
		
		public function read_remuneration($event_id)
		{
			$this->db->select('*, events.name as event_name, units.name as unit_name, users.name as marketing_name');
			$this->db->from('events');
			$this->db->join('units', 'events.unit_id = units.unit_id');
			$this->db->join('users', 'events.marketing_user_id = users.user_id');
			$this->db->where('event_id', $event_id);

			$event = $this->db->get()->row_array();

			$this->db->select('monthly_fee_a, quarterly_fee_a, annual_fee_a, profit_target_a, monthly_fee_b, quarterly_fee_b, annual_fee_b, profit_target_b, monthly_fee_c, quarterly_fee_c, annual_fee_c, profit_target_c, monthly_fee_d, quarterly_fee_d, annual_fee_d, profit_target_d');
			$this->db->from('contracts');
			$this->db->where('user_id', $event['marketing_user_id']);
			$this->db->where('division', 'MARKETING');
			$this->db->where('position', 'Staff');
			$this->db->where('unit_id', $event['unit_id']);
			$this->db->where('expiry_date >=', date('Y-m-d'));

			$staff_contract = $this->db->get()->row_array();

			$profit_percentage = urldecode($this->input->get('profit_percentage'));

			if($staff_contract['profit_target_a'] >= $profit_percentage)
			{
				$event['staff_monthly_fee'] = $staff_contract['monthly_fee_a'];
				$event['staff_quarterly_fee'] = $staff_contract['quarterly_fee_a'];
				$event['staff_annual_fee'] = $staff_contract['annual_fee_a'];
			}
			else if($staff_contract['profit_target_b'] >= $profit_percentage)
			{
				$event['staff_monthly_fee'] = $staff_contract['monthly_fee_b'];
				$event['staff_quarterly_fee'] = $staff_contract['quarterly_fee_b'];
				$event['staff_annual_fee'] = $staff_contract['annual_fee_b'];
			}
			else if($staff_contract['profit_target_c'] >= $profit_percentage)
			{
				$event['staff_monthly_fee'] = $staff_contract['monthly_fee_c'];
				$event['staff_quarterly_fee'] = $staff_contract['quarterly_fee_c'];
				$event['staff_annual_fee'] = $staff_contract['annual_fee_c'];
			}
			else if($staff_contract['profit_target_d'] >= $profit_percentage)
			{
				$event['staff_monthly_fee'] = $staff_contract['monthly_fee_d'];
				$event['staff_quarterly_fee'] = $staff_contract['quarterly_fee_d'];
				$event['staff_annual_fee'] = $staff_contract['annual_fee_d'];
			}
			else
			{
				$event['staff_monthly_fee'] = 0;
				$event['staff_quarterly_fee'] = 0;
				$event['staff_annual_fee'] = 0;
			}

			$this->db->select('monthly_fee_a, quarterly_fee_a, annual_fee_a, profit_target_a, monthly_fee_b, quarterly_fee_b, annual_fee_b, profit_target_b, monthly_fee_c, quarterly_fee_c, annual_fee_c, profit_target_c, monthly_fee_d, quarterly_fee_d, annual_fee_d, profit_target_d');
			$this->db->from('contracts');
			$this->db->where('user_id', $event['manager_user_id']);
			$this->db->where('division', 'MARKETING');
			$this->db->where('position', 'Manajer');
			$this->db->where('unit_id', $event['unit_id']);
			$this->db->where('expiry_date >=', date('Y-m-d'));

			$manager_contract = $this->db->get()->row_array();

			if($manager_contract['profit_target_a'] >= $profit_percentage)
			{
				$event['manager_monthly_fee'] = $manager_contract['monthly_fee_a'];
				$event['manager_quarterly_fee'] = $manager_contract['quarterly_fee_a'];
				$event['manager_annual_fee'] = $manager_contract['annual_fee_a'];
			}
			else if($manager_contract['profit_target_b'] >= $profit_percentage)
			{
				$event['manager_monthly_fee'] = $manager_contract['monthly_fee_b'];
				$event['manager_quarterly_fee'] = $manager_contract['quarterly_fee_b'];
				$event['manager_annual_fee'] = $manager_contract['annual_fee_b'];
			}
			else if($manager_contract['profit_target_c'] >= $profit_percentage)
			{
				$event['manager_monthly_fee'] = $manager_contract['monthly_fee_c'];
				$event['manager_quarterly_fee'] = $manager_contract['quarterly_fee_c'];
				$event['manager_annual_fee'] = $manager_contract['annual_fee_c'];
			}
			else if($manager_contract['profit_target_d'] >= $profit_percentage)
			{
				$event['manager_monthly_fee'] = $manager_contract['monthly_fee_d'];
				$event['manager_quarterly_fee'] = $manager_contract['quarterly_fee_d'];
				$event['manager_annual_fee'] = $manager_contract['annual_fee_d'];
			}
			else
			{
				$event['manager_monthly_fee'] = 0;
				$event['manager_quarterly_fee'] = 0;
				$event['manager_annual_fee'] = 0;
			}
			
			return $event;
		}
		
		public function delete($user_id)
		{
			if ($this->session->userdata('role_id') == 1) {
				$user_data = array(
					'user_status' => 'Dihapus'
				);
			
				$this->db->where('user_id', $user_id);
			
				return $this->db->update('users', $user_data);
			}
		}
	}
?>