<?php
	class Payroll_model extends CI_Model
	{
		public function read_roles()
		{
			$query = $this->db->get('roles');
			
			return $query->result_array();
		}

		public function read_email_address($email_address, $user_id = 0)
		{
			if($user_id == 0)
				$query = $this->db->get_where('users', array('email_address' => $email_address));
			else
			{
				$this->db->select('*');
				$this->db->from('users');
				$this->db->where('user_id <>', $user_id);
				$this->db->where('user_email_address', $user_email_address);
				$this->db->where('user_status', 'Aktif');
				
				$query = $this->db->get();
			}
			
			return $query->row_array();
		}
		
		public function update_payroll($payroll_data_id = 0)
		{
			$payroll_data = array(
				'payday' => str_replace('.', '', $this->input->post('payday')),
                'contract_id' => str_replace('.', '', $this->input->post('contract_id')),
                'paid_leave' => str_replace('.', '', $this->input->post('paid_leave')),
                'sick_leave' => str_replace('.', '', $this->input->post('sick_leave')),
                'regular_overtime' => str_replace('.', '', $this->input->post('regular_overtime')),
                'extra_overtime' => str_replace('.', '', $this->input->post('extra_overtime')),
                'in_town_duty' => str_replace('.', '', $this->input->post('in_town_duty')),
                'out_town_duty' => str_replace('.', '', $this->input->post('out_town_duty')),
                'performance_allowance_percentage' => str_replace('.', '', $this->input->post('performance_allowance_percentage')),
                'holiday_allowance_distribution' => str_replace('.', '', $this->input->post('holiday_allowance_distribution')),
                'severance_pay' => str_replace('.', '', $this->input->post('severance_pay')),
                'other_bonus_component' => str_replace('.', '', $this->input->post('other_bonus_component')),
                'other_bonus' => str_replace('.', '', $this->input->post('other_bonus')),
                'insurance' => str_replace('.', '', $this->input->post('insurance')),
                'absence' => str_replace('.', '', $this->input->post('absence')),
                'hours_late' => str_replace('.', '', $this->input->post('hours_late')),
                'other_salary_cut_component' => str_replace('.', '', $this->input->post('other_salary_cut_component')),
                'other_salary_cut' => str_replace('.', '', $this->input->post('other_salary_cut')),
                'monthly_fee_a' => str_replace('.', '', $this->input->post('monthly_fee_a')),
                'quarterly_fee_a' => str_replace('.', '', $this->input->post('quarterly_fee_a')),
                'annual_fee_a' => str_replace('.', '', $this->input->post('annual_fee_a')),
                'profit_target_a' => str_replace('.', '', $this->input->post('profit_target_a')),
                'monthly_fee_b' => str_replace('.', '', $this->input->post('monthly_fee_b')),
                'quarterly_fee_b' => str_replace('.', '', $this->input->post('quarterly_fee_b')),
                'annual_fee_b' => str_replace('.', '', $this->input->post('annual_fee_b')),
                'profit_target_b' => str_replace('.', '', $this->input->post('profit_target_b')),
                'monthly_fee_c' => str_replace('.', '', $this->input->post('monthly_fee_c')),
                'quarterly_fee_c' => str_replace('.', '', $this->input->post('quarterly_fee_c')),
                'annual_fee_c' => str_replace('.', '', $this->input->post('annual_fee_c')),
                'profit_target_c' => str_replace('.', '', $this->input->post('profit_target_c')),
                'monthly_fee_d' => str_replace('.', '', $this->input->post('monthly_fee_d')),
                'quarterly_fee_d' => str_replace('.', '', $this->input->post('quarterly_fee_d')),
                'annual_fee_d' => str_replace('.', '', $this->input->post('annual_fee_d')),
                'principal_savings' => str_replace('.', '', $this->input->post('principal_savings')),
                'mandatory_savings' => str_replace('.', '', $this->input->post('mandatory_savings')),
                'voluntary_savings' => str_replace('.', '', $this->input->post('voluntary_savings')),
                'cooperative_loan_installment' => str_replace('.', '', $this->input->post('cooperative_loan_installment')),
                'zakat' => str_replace('.', '', $this->input->post('zakat')),
                'infaq' => str_replace('.', '', $this->input->post('infaq')),
                'alms' => str_replace('.', '', $this->input->post('alms')),
                'waqf' => str_replace('.', '', $this->input->post('waqf'))
			);

			if($payroll_data_id == 0)
			{
				$payroll_data['status'] = 'Valid';
				
				$this->db->insert('payroll', $payroll_data);
			}
			else
			{
				$this->db->where('payroll_data_id', $payroll_data_id);
				$this->db->update('payroll', $payroll_data);
			}
		}
		
		public function read_users($join_table = '', $user_status = '', $user_id = 0)
		{
			$this->db->select('*');
			$this->db->from('users');
			$this->db->where('role_id', 1);
			
			if($join_table != '')
				$this->db->join($join_table, 'users.user_id = '.$join_table.'.user_id');
			
			//if($user_status != '')
				// $this->db->where('user_status', 'Aktif');
			$this->db->where('user_status <>', 'Dihapus');
			$this->db->where('division <>', 'INSTRUKTUR');

			if($user_id > 0)
            {
				$this->db->where('user_id', $user_id);

				return $this->db->get()->row_array();
			}
			else
            {
                $this->db->order_by('name', 'ASC');

                return $this->db->get()->result_array();
            }
		}
		
		public function read_users_contracts($columns = '*', $return = 'result_array')
		{
			$this->db->select($columns);
			$this->db->from('contracts');

            $this->db->join('users', 'contracts.user_id = users.user_id');
            $this->db->where('expiry_date >', 'CURDATE()');
            $this->db->where('division <>', 'INSTRUKTUR');
			
			/*if($contract_id != 0)
				$this->db->where('contract_id', $contract_id);
			
			if($reference_number != '')
				$this->db->where('reference_number', $reference_number);
			
			if($query != '')
			{
				if($user_status == 'all')
					$this->db->like('employee_name', $query);
				else
				{
					$this->db->where('user_status', $user_status);
					$this->db->where('contracts.unit_id', $query);
				}
			}

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));*/
			
            if($return == 'result_array')
            {
                $this->db->order_by('name', 'ASC');

                return $this->db->get()->result_array();
            }
            else if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
				return $this->db->get()->row_array();
		}

		public function read_payroll($columns = '*', $payroll_data_id = 0, $payday = '', $contract_id = 0, $user_id = 0, $page_number = 0, $return = 'result_array')
		{
			$this->db->select($columns);
			$this->db->from('payroll');
			
			$this->db->join('contracts', 'payroll.contract_id = contracts.contract_id');
            $this->db->join('users', 'contracts.user_id = users.user_id');
            $this->db->join('units', 'contracts.unit_id = units.unit_id');
            $this->db->join('employees', 'contracts.user_id = employees.user_id');
            
            if($payroll_data_id > 0)
				$this->db->where('payroll_data_id', $payroll_data_id);
			
			if($contract_id > 0)
				$this->db->where('payroll.contract_id', $contract_id);
			
			if($payday != '')
				$this->db->like('payday', $payday);
			
            if($user_id > 0)
                $this->db->where('contracts.user_id', $user_id);
			
			if($this->input->get('filter_value') != NULL && $this->input->get('filter_value') != '')
			{
				$filter_parameter = explode(',', urldecode($this->input->get('filter_column')));
				$value = urldecode($this->input->get('filter_value'));

				if($filter_parameter[1] == 'where')
					$this->db->where($filter_parameter[0], $value);
				else
					$this->db->like($filter_parameter[0], $value);
			}

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			if($return == 'result_array')
			{
                if($this->input->get('ordering_column') != NULL && $this->input->get('ordering_column') != '')
					$this->db->order_by($this->input->get('ordering_column'), 'DESC');
				
				return $this->db->get()->result_array();
			}
			else if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
				return $this->db->get()->row_array();
		}
		
		public function read_monthly_fees($unit_id, $marketing_user_id = 0, $manager_user_id = 0, $return = 'result_array')
		{
			$this->db->select('events.event_id as event_id, (clients_number * price) AS turnover, event_payments.submission_date AS submission_date');
			$this->db->distinct();
			$this->db->from('events');
			$this->db->join('event_payments', 'events.event_id = event_payments.event_id');
			$this->db->join('journal', 'events.event_id = journal.event_id');
			$this->db->where('events.unit_id', $unit_id);
			
			if($marketing_user_id > 0)
			{
				$this->db->where('marketing_user_id', $marketing_user_id);
				$this->db->where('staff_monthly_fee_payment', '');
			}
			else
			{
				$this->db->where('manager_user_id', $manager_user_id);
				$this->db->where('manager_monthly_fee_payment', '');
			}
			
			$this->db->where('payment_status', 3);
			$this->db->like('event_payments.submission_date', $this->input->post('payday'));
			$this->db->where('transaction_type', 'IN: Event');
			$this->db->where('journal.approval_status', 'Approved');

			if($return == 'result_array')
            {
				$this->load->model('project_management_model');
				
				$events = $this->db->get()->result_array();

				if(empty($events))
					return $events;
				else
				{
					for($event_counter = 0; $event_counter < $this->payroll_model->read_monthly_fees($unit_id, $marketing_user_id, $manager_user_id, 'num_rows'); $event_counter++)
					{
						$training_kit_expenses = ($events[$event_counter]['per_unit_certificate_budget'] * $events[$event_counter]['certificate_quantity']) + ($events[$event_counter]['per_unit_folder_budget'] * $events[$event_counter]['folder_quantity']) + ($events[$event_counter]['per_unit_envelope_budget'] * $events[$event_counter]['envelope_quantity']) + ($events[$event_counter]['per_unit_exclusive_bag_budget'] * $events[$event_counter]['exclusive_bag_quantity']) + ($events[$event_counter]['per_unit_economic_bag_budget'] * $events[$event_counter]['economic_bag_quantity']) + ($events[$event_counter]['per_unit_gift_budget'] * $events[$event_counter]['gift_quantity']) + ($events[$event_counter]['per_unit_batik_budget'] * $events[$event_counter]['batik_quantity']) + ($events[$event_counter]['per_unit_shirt_budget'] * $events[$event_counter]['shirt_quantity']) + ($events[$event_counter]['per_unit_powerbank_budget'] * $events[$event_counter]['powerbank_quantity']) + ($events[$event_counter]['per_unit_jacket_budget'] * $events[$event_counter]['jacket_quantity']) + ($events[$event_counter]['per_unit_placard_budget'] * $events[$event_counter]['placard_quantity']) + ($events[$event_counter]['per_unit_souvenir_budget'] * $events[$event_counter]['souvenir_quantity']) + ($events[$event_counter]['per_unit_name_tag_budget'] * $events[$event_counter]['name_tag_quantity']) + ($events[$event_counter]['per_unit_goody_bag_budget'] * $events[$event_counter]['goody_bag_quantity']) + ($events[$event_counter]['per_unit_ballpoint_budget'] * $events[$event_counter]['ballpoint_quantity']) + ($events[$event_counter]['per_unit_blocknote_budget'] * $events[$event_counter]['blocknote_quantity']) + ($events[$event_counter]['per_unit_flashdisk_budget'] * $events[$event_counter]['flashdisk_quantity']) + ($events[$event_counter]['per_unit_cd_budget'] * $events[$event_counter]['cd_quantity']);
						
						$expenses_taxes_transactions = $this->project_management_model->read_journal('transaction_date, debt_reference_code, credit_reference_code, nominal', $events[$event_counter]['event_id'], '"beban instruktur", "beban hotel", "beban transportasi", "beban training", "beban ppn", "beban pph 23", "beban sewa", "beban konsumsi", "beban operasional", "beban kirim", "beban customer service", "beban driver", "beban training lain", "beban retur", "pendapatan usaha", "beban ppn", "beban pph 23", "beban pph 21", "beban pph final"');
						
						$total_expenses = 0;
						$instructor_expenses = 0;
						$hotel_expenses = 0;
						$transportation_expenses = 0;
						$training_expenses = 0;
						$rent_expenses = 0;
						$meal_expenses = 0;
						$operational_expenses = 0;
						$delivery_expenses = 0;
						$cs_expenses = 0;
						$driver_expenses = 0;
						$other_training_expenses = 0;
						$returns_expenses = 0;
						$value_added_tax_expenses = 0;
						$income_tax_article_23_expenses = 0;
						$events[$event_counter]['revenue'] = 0;

						foreach($expenses_taxes_transactions as &$expense_tax_transaction)
						{
							if($expense_tax_transaction['debt_reference_code'] == 'beban instruktur') {$instructor_expenses = $instructor_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban instruktur') {$instructor_expenses = $instructor_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban hotel') {$hotel_expenses = $hotel_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban hotel') {$hotel_expenses = $hotel_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban transportasi') {$transportation_expenses = $transportation_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban transportasi') {$transportation_expenses = $transportation_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban training') {$training_expenses = $training_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban training') {$training_expenses = $training_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban ppn')
							{
								$value_added_tax_expenses = $value_added_tax_expenses + $expense_tax_transaction['nominal'];
								$total_expenses = $total_expenses + $expense_tax_transaction['nominal'];
							}
							else if($expense_tax_transaction['credit_reference_code'] == 'beban ppn')
							{
								$value_added_tax_expenses = $value_added_tax_expenses - $expense_tax_transaction['nominal'];
								$total_expenses = $total_expenses - $expense_tax_transaction['nominal'];
							}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban pph 23')
							{
								$income_tax_article_23_expenses = $income_tax_article_23_expenses + $expense_tax_transaction['nominal'];
								$total_expenses = $total_expenses + $expense_tax_transaction['nominal'];
							}
							else if($expense_tax_transaction['credit_reference_code'] == 'beban pph 23')
							{
								$income_tax_article_23_expenses = $income_tax_article_23_expenses - $expense_tax_transaction['nominal'];
								$total_expenses = $total_expenses - $expense_tax_transaction['nominal'];
							}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban sewa') {$rent_expenses = $rent_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban sewa') {$rent_expenses = $rent_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban konsumsi') {$meal_expenses = $meal_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban konsumsi') {$meal_expenses = $meal_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban operasional') {$operational_expenses = $operational_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban operasional') {$operational_expenses = $operational_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban kirim') {$delivery_expenses = $delivery_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban kirim') {$delivery_expenses = $delivery_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban customer service') {$cs_expenses = $cs_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban customer service') {$cs_expenses = $cs_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban driver') {$driver_expenses = $driver_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban driver') {$driver_expenses = $driver_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban training lain') {$other_training_expenses = $other_training_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban training lain') {$other_training_expenses = $other_training_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban retur') {$returns_expenses = $returns_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban retur') {$returns_expenses = $returns_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['credit_reference_code'] == 'pendapatan usaha')
								$events[$event_counter]['revenue'] = $events[$event_counter]['revenue'] + $expense_tax_transaction['nominal'];
							else if($expense_tax_transaction['debt_reference_code'] == 'pendapatan usaha')
								$events[$event_counter]['revenue'] = $events[$event_counter]['revenue'] - $expense_tax_transaction['nominal'];
						}

						$real_expenses = $training_kit_expenses + $total_expenses;
						$events[$event_counter]['profit_loss'] = $events[$event_counter]['revenue'] - $real_expenses;
					}

					return $events;
				}
			}
            else
            	return $this->db->get()->num_rows();
		}
		
		public function read_events_turnover($unit_id, $marketing_user_id = 0, $manager_user_id = 0)
		{
			$this->db->select('events.event_id as event_id, (clients_number * price) AS turnover');
			$this->db->distinct();
			$this->db->from('events');
			$this->db->join('event_payments', 'events.event_id = event_payments.event_id');
			$this->db->join('journal', 'events.event_id = journal.event_id');
			$this->db->where('events.unit_id', $unit_id);
			
			if($marketing_user_id > 0)
				$this->db->where('marketing_user_id', $marketing_user_id);
			else
				$this->db->where('manager_user_id', $manager_user_id);
			
			$this->db->where('payment_status', 3);

			$payday_year = substr($this->input->post('payday'), 0, 4);
			
			$this->db->where('event_payments.submission_date >=', $payday_year.'-01-01');
			
			$payday_month = substr($this->input->post('payday'), -2);

			if(substr($this->input->post('payday'), -2) == '04')
				$this->db->where('event_payments.submission_date <=', $this->input->post('payday').'-30');
			else
				$this->db->where('event_payments.submission_date <=', $this->input->post('payday').'-31');
			
			$this->db->where('transaction_type', 'IN: Event');
			$this->db->where('journal.approval_status', 'Approved');
				
			$events = $this->db->get()->result_array();

			$turnover_attainment = 0;

			foreach($events as &$event)
			{
				$turnover_attainment = $turnover_attainment + $event['turnover'];
			}

			return $turnover_attainment;
		}
		
		public function read_quarterly_fees($unit_id, $marketing_user_id = 0, $manager_user_id = 0, $return = 'result_array')
		{
			$this->db->select('events.event_id as event_id, (clients_number * price) AS turnover, event_payments.submission_date AS submission_date');
			$this->db->distinct();
			$this->db->from('events');
			$this->db->join('event_payments', 'events.event_id = event_payments.event_id');
			$this->db->join('journal', 'events.event_id = journal.event_id');
			$this->db->where('events.unit_id', $unit_id);
			
			if($marketing_user_id > 0)
			{
				$this->db->where('marketing_user_id', $marketing_user_id);
				$this->db->where('staff_quarterly_fee_payment', '');
			}
			else
			{
				$this->db->where('manager_user_id', $manager_user_id);
				$this->db->where('manager_quarterly_fee_payment', '');
			}
			
			$this->db->where('payment_status', 3);

			$payday_year = substr($this->input->post('payday'), 0, 4);
			
			$this->db->where('event_payments.submission_date >=', $payday_year.'-01-01');
			
			$payday_month = substr($this->input->post('payday'), -2);

			if(substr($this->input->post('payday'), -2) == '04')
				$this->db->where('event_payments.submission_date <=', $this->input->post('payday').'-30');
			else
				$this->db->where('event_payments.submission_date <=', $this->input->post('payday').'-31');
			
			$this->db->where('transaction_type', 'IN: Event');
			$this->db->where('journal.approval_status', 'Approved');

			if($return == 'result_array')
            {
				$this->load->model('project_management_model');
				
				$events = $this->db->get()->result_array();

				if(empty($events))
					return $events;
				else
				{
					for($event_counter = 0; $event_counter < $this->payroll_model->read_monthly_fees($unit_id, $marketing_user_id, $manager_user_id, 'num_rows'); $event_counter++)
					{
						$training_kit_expenses = ($events[$event_counter]['per_unit_certificate_budget'] * $events[$event_counter]['certificate_quantity']) + ($events[$event_counter]['per_unit_folder_budget'] * $events[$event_counter]['folder_quantity']) + ($events[$event_counter]['per_unit_envelope_budget'] * $events[$event_counter]['envelope_quantity']) + ($events[$event_counter]['per_unit_exclusive_bag_budget'] * $events[$event_counter]['exclusive_bag_quantity']) + ($events[$event_counter]['per_unit_economic_bag_budget'] * $events[$event_counter]['economic_bag_quantity']) + ($events[$event_counter]['per_unit_gift_budget'] * $events[$event_counter]['gift_quantity']) + ($events[$event_counter]['per_unit_batik_budget'] * $events[$event_counter]['batik_quantity']) + ($events[$event_counter]['per_unit_shirt_budget'] * $events[$event_counter]['shirt_quantity']) + ($events[$event_counter]['per_unit_powerbank_budget'] * $events[$event_counter]['powerbank_quantity']) + ($events[$event_counter]['per_unit_jacket_budget'] * $events[$event_counter]['jacket_quantity']) + ($events[$event_counter]['per_unit_placard_budget'] * $events[$event_counter]['placard_quantity']) + ($events[$event_counter]['per_unit_souvenir_budget'] * $events[$event_counter]['souvenir_quantity']) + ($events[$event_counter]['per_unit_name_tag_budget'] * $events[$event_counter]['name_tag_quantity']) + ($events[$event_counter]['per_unit_goody_bag_budget'] * $events[$event_counter]['goody_bag_quantity']) + ($events[$event_counter]['per_unit_ballpoint_budget'] * $events[$event_counter]['ballpoint_quantity']) + ($events[$event_counter]['per_unit_blocknote_budget'] * $events[$event_counter]['blocknote_quantity']) + ($events[$event_counter]['per_unit_flashdisk_budget'] * $events[$event_counter]['flashdisk_quantity']) + ($events[$event_counter]['per_unit_cd_budget'] * $events[$event_counter]['cd_quantity']);
						
						$expenses_taxes_transactions = $this->project_management_model->read_journal('transaction_date, debt_reference_code, credit_reference_code, nominal', $events[$event_counter]['event_id'], '"beban instruktur", "beban hotel", "beban transportasi", "beban training", "beban ppn", "beban pph 23", "beban sewa", "beban konsumsi", "beban operasional", "beban kirim", "beban customer service", "beban driver", "beban training lain", "beban retur", "pendapatan usaha", "beban ppn", "beban pph 23", "beban pph 21", "beban pph final"');
						
						$total_expenses = 0;
						$instructor_expenses = 0;
						$hotel_expenses = 0;
						$transportation_expenses = 0;
						$training_expenses = 0;
						$rent_expenses = 0;
						$meal_expenses = 0;
						$operational_expenses = 0;
						$delivery_expenses = 0;
						$cs_expenses = 0;
						$driver_expenses = 0;
						$other_training_expenses = 0;
						$returns_expenses = 0;
						$value_added_tax_expenses = 0;
						$income_tax_article_23_expenses = 0;
						$events[$event_counter]['revenue'] = 0;

						foreach($expenses_taxes_transactions as &$expense_tax_transaction)
						{
							if($expense_tax_transaction['debt_reference_code'] == 'beban instruktur') {$instructor_expenses = $instructor_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban instruktur') {$instructor_expenses = $instructor_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban hotel') {$hotel_expenses = $hotel_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban hotel') {$hotel_expenses = $hotel_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban transportasi') {$transportation_expenses = $transportation_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban transportasi') {$transportation_expenses = $transportation_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban training') {$training_expenses = $training_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban training') {$training_expenses = $training_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban ppn')
							{
								$value_added_tax_expenses = $value_added_tax_expenses + $expense_tax_transaction['nominal'];
								$total_expenses = $total_expenses + $expense_tax_transaction['nominal'];
							}
							else if($expense_tax_transaction['credit_reference_code'] == 'beban ppn')
							{
								$value_added_tax_expenses = $value_added_tax_expenses - $expense_tax_transaction['nominal'];
								$total_expenses = $total_expenses - $expense_tax_transaction['nominal'];
							}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban pph 23')
							{
								$income_tax_article_23_expenses = $income_tax_article_23_expenses + $expense_tax_transaction['nominal'];
								$total_expenses = $total_expenses + $expense_tax_transaction['nominal'];
							}
							else if($expense_tax_transaction['credit_reference_code'] == 'beban pph 23')
							{
								$income_tax_article_23_expenses = $income_tax_article_23_expenses - $expense_tax_transaction['nominal'];
								$total_expenses = $total_expenses - $expense_tax_transaction['nominal'];
							}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban sewa') {$rent_expenses = $rent_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban sewa') {$rent_expenses = $rent_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban konsumsi') {$meal_expenses = $meal_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban konsumsi') {$meal_expenses = $meal_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban operasional') {$operational_expenses = $operational_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban operasional') {$operational_expenses = $operational_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban kirim') {$delivery_expenses = $delivery_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban kirim') {$delivery_expenses = $delivery_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban customer service') {$cs_expenses = $cs_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban customer service') {$cs_expenses = $cs_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban driver') {$driver_expenses = $driver_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban driver') {$driver_expenses = $driver_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban training lain') {$other_training_expenses = $other_training_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban training lain') {$other_training_expenses = $other_training_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban retur') {$returns_expenses = $returns_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban retur') {$returns_expenses = $returns_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['credit_reference_code'] == 'pendapatan usaha')
								$events[$event_counter]['revenue'] = $events[$event_counter]['revenue'] + $expense_tax_transaction['nominal'];
							else if($expense_tax_transaction['debt_reference_code'] == 'pendapatan usaha')
								$events[$event_counter]['revenue'] = $events[$event_counter]['revenue'] - $expense_tax_transaction['nominal'];
						}

						$real_expenses = $training_kit_expenses + $total_expenses;
						$events[$event_counter]['profit_loss'] = $events[$event_counter]['revenue'] - $real_expenses;
					}

					return $events;
				}
			}
            else
            	return $this->db->get()->num_rows();
		}
		
		public function read_annual_fees($unit_id, $marketing_user_id = 0, $manager_user_id = 0, $return = 'result_array')
		{
			$this->db->select('events.event_id as event_id, (clients_number * price) AS turnover, event_payments.submission_date AS submission_date');
			$this->db->distinct();
			$this->db->from('events');
			$this->db->join('event_payments', 'events.event_id = event_payments.event_id');
			$this->db->join('journal', 'events.event_id = journal.event_id');
			$this->db->where('events.unit_id', $unit_id);
			
			if($marketing_user_id > 0)
			{
				$this->db->where('marketing_user_id', $marketing_user_id);
				$this->db->where('staff_annual_fee_payment', '');
			}
			else
			{
				$this->db->where('manager_user_id', $manager_user_id);
				$this->db->where('manager_annual_fee_payment', '');
			}
			
			$this->db->where('payment_status', 3);

			$payday_year = substr($this->input->post('payday'), 0, 4);
			
			$this->db->where('YEAR(event_payments.submission_date)', $payday_year);
			$this->db->where('transaction_type', 'IN: Event');
			$this->db->where('journal.approval_status', 'Approved');

			if($return == 'result_array')
            {
				$this->load->model('project_management_model');
				
				$events = $this->db->get()->result_array();

				if(empty($events))
					return $events;
				else
				{
					for($event_counter = 0; $event_counter < $this->payroll_model->read_monthly_fees($unit_id, $marketing_user_id, $manager_user_id, 'num_rows'); $event_counter++)
					{
						$training_kit_expenses = ($events[$event_counter]['per_unit_certificate_budget'] * $events[$event_counter]['certificate_quantity']) + ($events[$event_counter]['per_unit_folder_budget'] * $events[$event_counter]['folder_quantity']) + ($events[$event_counter]['per_unit_envelope_budget'] * $events[$event_counter]['envelope_quantity']) + ($events[$event_counter]['per_unit_exclusive_bag_budget'] * $events[$event_counter]['exclusive_bag_quantity']) + ($events[$event_counter]['per_unit_economic_bag_budget'] * $events[$event_counter]['economic_bag_quantity']) + ($events[$event_counter]['per_unit_gift_budget'] * $events[$event_counter]['gift_quantity']) + ($events[$event_counter]['per_unit_batik_budget'] * $events[$event_counter]['batik_quantity']) + ($events[$event_counter]['per_unit_shirt_budget'] * $events[$event_counter]['shirt_quantity']) + ($events[$event_counter]['per_unit_powerbank_budget'] * $events[$event_counter]['powerbank_quantity']) + ($events[$event_counter]['per_unit_jacket_budget'] * $events[$event_counter]['jacket_quantity']) + ($events[$event_counter]['per_unit_placard_budget'] * $events[$event_counter]['placard_quantity']) + ($events[$event_counter]['per_unit_souvenir_budget'] * $events[$event_counter]['souvenir_quantity']) + ($events[$event_counter]['per_unit_name_tag_budget'] * $events[$event_counter]['name_tag_quantity']) + ($events[$event_counter]['per_unit_goody_bag_budget'] * $events[$event_counter]['goody_bag_quantity']) + ($events[$event_counter]['per_unit_ballpoint_budget'] * $events[$event_counter]['ballpoint_quantity']) + ($events[$event_counter]['per_unit_blocknote_budget'] * $events[$event_counter]['blocknote_quantity']) + ($events[$event_counter]['per_unit_flashdisk_budget'] * $events[$event_counter]['flashdisk_quantity']) + ($events[$event_counter]['per_unit_cd_budget'] * $events[$event_counter]['cd_quantity']);
						
						$expenses_taxes_transactions = $this->project_management_model->read_journal('transaction_date, debt_reference_code, credit_reference_code, nominal', $events[$event_counter]['event_id'], '"beban instruktur", "beban hotel", "beban transportasi", "beban training", "beban ppn", "beban pph 23", "beban sewa", "beban konsumsi", "beban operasional", "beban kirim", "beban customer service", "beban driver", "beban training lain", "beban retur", "pendapatan usaha", "beban ppn", "beban pph 23", "beban pph 21", "beban pph final"');
						
						$total_expenses = 0;
						$instructor_expenses = 0;
						$hotel_expenses = 0;
						$transportation_expenses = 0;
						$training_expenses = 0;
						$rent_expenses = 0;
						$meal_expenses = 0;
						$operational_expenses = 0;
						$delivery_expenses = 0;
						$cs_expenses = 0;
						$driver_expenses = 0;
						$other_training_expenses = 0;
						$returns_expenses = 0;
						$value_added_tax_expenses = 0;
						$income_tax_article_23_expenses = 0;
						$events[$event_counter]['revenue'] = 0;

						foreach($expenses_taxes_transactions as &$expense_tax_transaction)
						{
							if($expense_tax_transaction['debt_reference_code'] == 'beban instruktur') {$instructor_expenses = $instructor_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban instruktur') {$instructor_expenses = $instructor_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban hotel') {$hotel_expenses = $hotel_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban hotel') {$hotel_expenses = $hotel_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban transportasi') {$transportation_expenses = $transportation_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban transportasi') {$transportation_expenses = $transportation_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban training') {$training_expenses = $training_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban training') {$training_expenses = $training_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban ppn')
							{
								$value_added_tax_expenses = $value_added_tax_expenses + $expense_tax_transaction['nominal'];
								$total_expenses = $total_expenses + $expense_tax_transaction['nominal'];
							}
							else if($expense_tax_transaction['credit_reference_code'] == 'beban ppn')
							{
								$value_added_tax_expenses = $value_added_tax_expenses - $expense_tax_transaction['nominal'];
								$total_expenses = $total_expenses - $expense_tax_transaction['nominal'];
							}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban pph 23')
							{
								$income_tax_article_23_expenses = $income_tax_article_23_expenses + $expense_tax_transaction['nominal'];
								$total_expenses = $total_expenses + $expense_tax_transaction['nominal'];
							}
							else if($expense_tax_transaction['credit_reference_code'] == 'beban pph 23')
							{
								$income_tax_article_23_expenses = $income_tax_article_23_expenses - $expense_tax_transaction['nominal'];
								$total_expenses = $total_expenses - $expense_tax_transaction['nominal'];
							}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban sewa') {$rent_expenses = $rent_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban sewa') {$rent_expenses = $rent_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban konsumsi') {$meal_expenses = $meal_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban konsumsi') {$meal_expenses = $meal_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban operasional') {$operational_expenses = $operational_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban operasional') {$operational_expenses = $operational_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban kirim') {$delivery_expenses = $delivery_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban kirim') {$delivery_expenses = $delivery_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban customer service') {$cs_expenses = $cs_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban customer service') {$cs_expenses = $cs_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban driver') {$driver_expenses = $driver_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban driver') {$driver_expenses = $driver_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban training lain') {$other_training_expenses = $other_training_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban training lain') {$other_training_expenses = $other_training_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['debt_reference_code'] == 'beban retur') {$returns_expenses = $returns_expenses + $expense_tax_transaction['nominal'];  $total_expenses = $total_expenses + $expense_tax_transaction['nominal'];} else if($expense_tax_transaction['credit_reference_code'] == 'beban retur') {$returns_expenses = $returns_expenses - $expense_tax_transaction['nominal']; $total_expenses = $total_expenses - $expense_tax_transaction['nominal'];}
							else if($expense_tax_transaction['credit_reference_code'] == 'pendapatan usaha')
								$events[$event_counter]['revenue'] = $events[$event_counter]['revenue'] + $expense_tax_transaction['nominal'];
							else if($expense_tax_transaction['debt_reference_code'] == 'pendapatan usaha')
								$events[$event_counter]['revenue'] = $events[$event_counter]['revenue'] - $expense_tax_transaction['nominal'];
						}

						$real_expenses = $training_kit_expenses + $total_expenses;
						$events[$event_counter]['profit_loss'] = $events[$event_counter]['revenue'] - $real_expenses;
					}

					return $events;
				}
			}
            else
            	return $this->db->get()->num_rows();
		}
	}
?>