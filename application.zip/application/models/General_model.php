<?php
	class General_model extends CI_Model
	{
		public function read($select = 'select', $columns = '*', $table, $joins = array(), $filters = array(), $orders = array(), $page_number = 0, $limit = 0, $return = 'row_array')
		{
            if($select == 'select')
                $this->db->select($columns);
			else if($select == 'select_max')
				$this->db->select_max($columns);
			else if($select == 'select_sum')
			{
				$field = explode(',', $columns);

				if(array_key_exists(1, $field))
					$alias = $field[1];
				else
					$alias = '';
				
				$this->db->select_sum($field[0], $alias);
			}
			else if($select == 'select_distinct')
			{
				$this->db->select($columns);
				$this->db->distinct();
			}
            
			$this->db->from($table);
			
			if(!empty($joins))
			{
				foreach($joins as &$join)
				{
					if(array_key_exists('type', $join))
						$type = $join['type'];
					else
						$type = '';
					
					$this->db->join($join['table'], $join['on'], $type);
				}
			}

			if(!empty($filters))
			{
				foreach($filters as &$filter)
				{
					if($filter['operator'] == 'where')
					{
						if($filter['field'] == '')
							$this->db->where($filter['value']);
						else
							$this->db->where($filter['field'], $filter['value']);
					}
					else if($filter['operator'] == 'where_in')
						$this->db->where_in($filter['field'], $filter['value']);
					else if($filter['operator'] == 'where_not_in')
						$this->db->where_not_in($filter['field'], $filter['value']);
					else if($filter['operator'] == 'like')
					    $this->db->like($filter['field'], $filter['value']);
				}
			}
			
			if(!empty($orders))
			{
				foreach($orders as &$order)
				{
					$this->db->order_by($order['field'], $order['direction']);
				}
			}

            if($page_number > 0)
                $this->db->limit($limit, ($limit * ($page_number - 1)));
			
            if($return == 'num_rows')
                return $this->db->get()->num_rows();
            else if($return == 'result_array')
			    return $this->db->get()->result_array();
            else
                return $this->db->get()->row_array();
		}

		public function create_update($primary_key, $table_name, $columns, $file_names = array())
		{
			foreach($columns as &$column)
            {
				if($this->input->post($column) != NULL)
					$record_values[$column] = $this->input->post($column);
			}
            
            foreach($file_names as $key=>$value)
            {
                if($value != '')
                    $record_values[$key] = $value;
            }
			
			if($this->input->post('status') != NULL || $this->input->get('status') != NULL)
			{
				if($this->input->post('status') != NULL)
					$record_values['status'] = $this->input->post('status');
				else
					$record_values['status'] = $this->input->get('status');
			}

			if($this->input->post($primary_key) == NULL && $this->input->get($primary_key) == NULL)
			{
				$this->db->insert($table_name, $record_values);

				return $this->db->insert_id();
			}
			else
			{
				if($this->input->post($primary_key) != NULL)
					$record_id = $this->input->post($primary_key);
				else
					$record_id = $this->input->get($primary_key);

				$this->db->where_in($primary_key, $record_id);
				$this->db->update($table_name, $record_values);
			}
		}
	}
?>