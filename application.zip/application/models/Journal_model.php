<?php
	class Journal_model extends CI_Model
	{
		public function read_users_roles_contracts($division = '', $user_id = 0, $unit_id = 0, $user_status = '')
		{
			$this->db->select('*');
			$this->db->from('employees');
			$this->db->join('users', 'employees.user_id = users.user_id');
			
			if($user_id > 0 || $unit_id > 0)
			{
				$this->db->join('contracts', 'employees.user_id = contracts.user_id AND employees.division = contracts.division');

				if($user_id > 0)
				{
					$this->db->where('employees.user_id', $user_id);

					return $this->db->get()->row_array();
				}
				else
				{
					$this->db->where('unit_id', $unit_id);
					$this->db->where('position', 'Manajer');
					$this->db->where('expiry_date >', 'CURDATE()');
				}
			}
			
			if($division != '')
			{
				$this->db->where('employees.division', $division);
				$this->db->where('user_status', 'Aktif');
				
				return $this->db->get()->result_array();
			}
		}
		
		public function read_users($columns = '*', $user_id = 0, $unit_id = 0, $user_status = '')
		{
			$this->db->select($columns);
			$this->db->from('users');
			
			if($user_id > 0)
			{
				$this->db->where('user_id', $user_id);

				return $this->db->get()->row_array();
			}
		}
		
		public function read_contract_unit($user_id)
		{
			$this->db->select('contracts.unit_id as unit_id, name');
			$this->db->from('contracts');
			$this->db->join('units', 'contracts.unit_id = units.unit_id');
			$this->db->where('user_id', $user_id);
			$this->db->order_by('expiry_date', 'DESC');
			
			return $this->db->get()->row_array();
		}
		
		public function read_events_users()
		{
			$this->db->select('event_id, events.name as event_name, start_date, end_date, units.name as unit_name, users.name as marketing_name');
			$this->db->from('events');

			$this->db->join('units', 'events.unit_id = units.unit_id');
			$this->db->join('users', 'events.marketing_user_id = users.user_id');
			
			$this->db->where('status', 'Fixed');
			
			$this->db->order_by('events.name', 'ASC');
			
			return $this->db->get()->result_array();
		}

		public function read_funding_submissions_users_units($columns = '*', $page_number = 0, $return = 'result_array', $funding_submission_id = 0)
		{
			$this->db->select($columns);
			$this->db->from('funding_submissions');
			
			if($funding_submission_id > 0)
				$this->db->where('funding_submission_id', $funding_submission_id);
			
			/*if($this->input->get('filter_value') != NULL && $this->input->get('filter_value') != '')
				$this->db->where($this->input->get('filter_column'), urldecode($this->input->get('filter_value')));

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));*/
			
			if($return == 'result_array')
			{
				$this->db->join('users', 'funding_submissions.applicant_user_id = users.user_id');
				$this->db->join('units', 'funding_submissions.utilizing_unit_id = units.unit_id');
				
				//if($this->input->get('ordering_column') != NULL && $this->input->get('ordering_column') != '')
				//	$this->db->order_by($this->input->get('ordering_column'), 'DESC');
				
				return $this->db->get()->result_array();
			}
			else if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
				return $this->db->get()->row_array();
		}

		public function update($file_names)
		{
			$primary_key = 'transaction_id';
			$table_name = 'journal';
			
			$columns = array(
				'transaction_date',
				'transaction_type',
				'unit_id',
				'event_id',
				'funding_submission_id',
				'transaction_code',
				'bank',
				'account_number',
				'accountee',
				'notes',
				'debt_reference_code',
				'credit_reference_code',
				'nominal',
				'approval_status',
				'rejection_reason',
				'planned_transfer_date'
			);

			foreach($columns as &$column)
            {
				if($this->input->get($column) != NULL)
					$record_values[$column] = urldecode($this->input->get($column));
			}
            
            foreach($file_names as $key=>$value)
            {
                if($value != '')
                    $record_values[$key] = $value;
            }
			
			if($this->input->get($primary_key) == 0)
			{
				$record_values['submission_date'] = date("Y-m-d");
				
				$this->db->insert($table_name, $record_values);
			}
			else
			{
				$record_id = $this->input->get($primary_key);

				$this->db->where($primary_key, $record_id);
				$this->db->update($table_name, $record_values);
			}
		}

		public function read_journal($columns = '*', $page_number = 0, $return = 'result_array', $funding_submission_id = 0)
		{
			$this->db->select($columns);
			$this->db->from('journal');
			
			if($funding_submission_id > 0)
				$this->db->where('funding_submission_id', $funding_submission_id);
			
			if($this->input->get('unit_id') != NULL && $this->input->get('unit_id') != '')
			{
				$unit_id = $this->input->get('unit_id');

				$this->db->join('events', 'journal.event_id = events.event_id', 'left');
				$this->db->join('funding_submissions', 'journal.funding_submission_id = funding_submissions.funding_submission_id', 'left');

				$condition = "(((transaction_type = 'IN: Manual' OR transaction_type = 'OUT: Manual') AND journal.unit_id = ".$unit_id.") OR (transaction_type = 'IN: Event' AND events.unit_id = ".$unit_id.") OR (transaction_type = 'OUT: Pengajuan' AND funding_submissions.utilizing_unit_id = ".$unit_id."))";
				
				$this->db->where($condition);
			}

			if($this->input->get('debt_reference_code') != NULL && $this->input->get('debt_reference_code') != '')
				$this->db->where('debt_reference_code', $this->input->get('debt_reference_code'));

			if($this->input->get('credit_reference_code') != NULL && $this->input->get('credit_reference_code') != '')
				$this->db->where('credit_reference_code', $this->input->get('credit_reference_code'));

			if($this->input->get('submission_period') != NULL && $this->input->get('submission_period') != '')
			{
				$filter_parameter = explode(',', urldecode($this->input->get('submission_period_parameter')));
				$value = urldecode($this->input->get('submission_period'));
				
				if($filter_parameter[1] == 'where')
					$this->db->where($filter_parameter[0], $value);
				else
					$this->db->like($filter_parameter[0], $value);
			}

			if($this->input->get('transaction_period') != NULL && $this->input->get('transaction_period') != '')
			{
				$filter_parameter = explode(',', urldecode($this->input->get('transaction_period_parameter')));
				$value = urldecode($this->input->get('transaction_period'));
				
				if($filter_parameter[1] == 'where')
					$this->db->where($filter_parameter[0], $value);
				else
					$this->db->like($filter_parameter[0], $value);
			}

			/*if($this->input->get('filter_value') != NULL && $this->input->get('filter_value') != '')
			{
				$filter_parameter = explode(',', urldecode($this->input->get('filter_column')));
				$value = urldecode($this->input->get('filter_value'));

				if($filter_parameter[0] == 'unit_id')
				{
					$this->db->join('events', 'journal.event_id = events.event_id', 'left');
					$this->db->join('funding_submissions', 'journal.funding_submission_id = funding_submissions.funding_submission_id', 'left');

					$condition = "(((transaction_type = 'IN: Manual' OR transaction_type = 'OUT: Manual') AND journal.unit_id = ".$value.") OR (transaction_type = 'IN: Event' AND events.unit_id = ".$value.") OR (transaction_type = 'OUT: Pengajuan' AND funding_submissions.utilizing_unit_id = ".$value."))";
					
					$this->db->where($condition);
				}
				else
				{
					if($filter_parameter[1] == 'where')
						$this->db->where($filter_parameter[0], $value);
					else
						$this->db->like($filter_parameter[0], $value);
				}
			}*/

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			if($return == 'result_array')
			{
				/*$this->db->join('users', 'funding_submissions.applicant_user_id = users.user_id');
				$this->db->join('units', 'funding_submissions.utilizing_unit_id = units.unit_id');*/
				
				if($this->input->get('ordering_column') != NULL && $this->input->get('ordering_column') != '')
					$this->db->order_by($this->input->get('ordering_column'), 'DESC');
				
				return $this->db->get()->result_array();
			}
			else if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
				return $this->db->get()->row_array();
		}
		
		public function read_users_vendors($join_tables_list = '', $page_number = 0, $return = 'result_array', $query = '', $vendor_id = 0, $type = '')
		{
			$this->db->select('*');
			$this->db->from('vendors');

			if($join_tables_list != '')
			{
				$join_tables = explode(',', $join_tables_list);
				
				foreach($join_tables as &$join_table)
				{
					$this->db->join($join_table.'s', 'vendors.'.$join_table.'_id = '.$join_table.'s.'.$join_table.'_id');
				}
			}
			
			if($vendor_id > 0)
				$this->db->where('vendor_id', $vendor_id);
			
			if($query != '')
				$this->db->like('name', $query);

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			if($type != '')
				$this->db->where('type', $type);
			
			if($return == 'result_array')
			{
				$this->db->order_by('name', 'ASC');

				return $this->db->get()->result_array();
			}
			else if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
				return $this->db->get()->row_array();
		}

		public function read_events_units_users_clients($columns = '*', $join_tables_list = '', $unit_id = 0, $return = 'result_array', $page_number = 0, $status = 'all', $query = '', $event_id = 0, $client_id = 0, $approval_status = '', $nearest_city = 'Semua Gudang')
		{
			$this->db->select($columns);
			$this->db->from('events');

			if($join_tables_list != '')
			{
				$join_tables = explode(',', $join_tables_list);
				
				foreach($join_tables as &$join_table)
				{
					if($join_table == 'user')
						$this->db->join($join_table.'s', 'events.marketing_'.$join_table.'_id = '.$join_table.'s.'.$join_table.'_id');
					else
						$this->db->join($join_table.'s', 'events.'.$join_table.'_id = '.$join_table.'s.'.$join_table.'_id');
				}
			}
			
			if($event_id > 0)
				$this->db->where('event_id', $event_id);
			
			if($unit_id > 0)
				$this->db->where('events.unit_id', $unit_id);
			
			if($status == 'Fixed')
			{
				$this->db->join('contracts', 'events.marketing_user_id = contracts.user_id');
				
				if($query > 0)
					$this->db->where('events.unit_id', $query);
				
				$this->db->where('status', $status);
			}
			else if($query != '')
				$this->db->like('events.name', $query);
			
			if($client_id != 0)
				$this->db->where('client_id', $client_id);
			
			if($nearest_city != 'Semua Gudang')
				$this->db->where('nearest_city', $nearest_city);
			
			if($approval_status != '')
				$this->db->where('approval_status', $approval_status);

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
			{
				$this->db->order_by('end_date', 'DESC');

				if($return == 'result_array')
				{
					/*$this->load->model('vendor_model');
					
					$events = */return $this->db->get()->result_array();

					/*if(!empty($events))
					{
						for($event_counter = 0; $event_counter < $this->event_model->read_events_vendors_clients('*', '', 0, 'num_rows', $status, urldecode($query)); $event_counter++)
						{
							$marketing = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['marketing_user_id']);
							
							$events[$event_counter]['marketing_name'] = $marketing['name'];

							$instructor = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['instructor_user_id']);
							
							$events[$event_counter]['instructor_name'] = $instructor['name'];

							$cs = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['cs_user_id']);
							
							$events[$event_counter]['cs_name'] = $cs['name'];

							$driver = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['driver_user_id']);
							
							$events[$event_counter]['driver_name'] = $driver['name'];

							$logistic = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['logistic_user_id']);
							
							$events[$event_counter]['logistic_name'] = $logistic['name'];

							$manager = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['manager_user_id']);
							
							$events[$event_counter]['manager_name'] = $manager['name'];

							$hotel = $this->vendor_model->read_users_vendors('user', 0, 'row_array', '', $events[$event_counter]['hotel_vendor_id']);
							
							$events[$event_counter]['hotel'] = $hotel['name'];
						}
					}

					return $events;*/
				}
				else
					return $this->db->get()->row_array();
			}
		}
		
		public function delete($user_id)
		{
			if ($this->session->userdata('role_id') == 1) {
				$user_data = array(
					'user_status' => 'Dihapus'
				);
			
				$this->db->where('user_id', $user_id);
			
				return $this->db->update('users', $user_data);
			}	
		}
	}
?>