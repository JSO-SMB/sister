<?php
	class Unit_model extends CI_Model
	{
		public function read_roles()
		{
			$query = $this->db->get('roles');
			
			return $query->result_array();
		}
		
		public function create_update_unit($file_names, $unit_id = 0)
		{
			$unit_data = array(
                'name' => $this->input->post('name'),
                'code' => $this->input->post('code'),
                'address' => $this->input->post('address'),
                'market' => $this->input->post('market'),
                'director' => $this->input->post('director'),
                'commissioner_1' => $this->input->post('commissioner_1'),
                'commissioner_2' => $this->input->post('commissioner_2'),
                'commissioner_3' => $this->input->post('commissioner_3'),
                'commissioner_4' => $this->input->post('commissioner_4'),
                'commissioner_5' => $this->input->post('commissioner_5'),
                'deed_of_incorporation_number' => $this->input->post('deed_of_incorporation_number'),
                'incorporation_date' => $this->input->post('incorporation_date'),
                'notary_name' => $this->input->post('notary_name'),
                'deed_of_amendment_a_number' => $this->input->post('deed_of_amendment_a_number'),
                'amendment_date_a' => $this->input->post('amendment_date_a'),
                'notary_name_a' => $this->input->post('notary_name_a'),
                'deed_of_amendment_b_number' => $this->input->post('deed_of_amendment_b_number'),
                'amendment_date_b' => $this->input->post('amendment_date_b'),
                'notary_name_b' => $this->input->post('notary_name_b'),
                'deed_of_amendment_c_number' => $this->input->post('deed_of_amendment_c_number'),
                'amendment_date_c' => $this->input->post('amendment_date_c'),
                'notary_name_c' => $this->input->post('notary_name_c'),
                'deed_of_amendment_d_number' => $this->input->post('deed_of_amendment_d_number'),
                'amendment_date_d' => $this->input->post('amendment_date_d'),
                'notary_name_d' => $this->input->post('notary_name_d'),
                'certificate_of_company_registration_number' => $this->input->post('certificate_of_company_registration_number'),
                'business_license_number' => $this->input->post('business_license_number'),
                'domicile_of_business_number' => $this->input->post('domicile_of_business_number'),
                'hinder_ordonantie_number' => $this->input->post('hinder_ordonantie_number'),
                'oss_username' => $this->input->post('oss_username'),
                'oss_password' => $this->input->post('oss_password'),
                'tax_id_number' => $this->input->post('tax_id_number'),
                'certification_of_registration_number' => $this->input->post('certification_of_registration_number'),
                'taxable_employer_confirmation_letter_number' => $this->input->post('taxable_employer_confirmation_letter_number'),
                'electronic_filing_identification_number' => $this->input->post('electronic_filing_identification_number'),
                'e_nofa_number' => $this->input->post('e_nofa_number'),
                'djponline_username' => $this->input->post('djponline_username'),
                'djponline_password' => $this->input->post('djponline_password'),
                'email_address' => $this->input->post('email_address'),
                'e_faktur' => $this->input->post('e_faktur'),
                'taxable_employers' => $this->input->post('taxable_employers'),
                'sse3' => $this->input->post('sse3'),
                'tax_object_mobile_number' => $this->input->post('tax_object_mobile_number'),
                'bank_a' => $this->input->post('bank_a'),
                'account_type_a' => $this->input->post('account_type_a'),
                'account_number_a' => $this->input->post('account_number_a'),
                'branch_a' => $this->input->post('branch_a'),
                'saving_book_holder_a' => $this->input->post('saving_book_holder_a'),
                'atm_card_holder_a' => $this->input->post('atm_card_holder_a'),
                'internet_banking_username_a' => $this->input->post('internet_banking_username_a'),
                'internet_banking_password_a' => $this->input->post('internet_banking_password_a'),
                'internet_banking_company_id_a' => $this->input->post('internet_banking_company_id_a'),
                'internet_banking_notes_a' => $this->input->post('internet_banking_notes_a'),
                'pin_a' => $this->input->post('pin_a'),
                'internet_banking_mobile_number_token_a' => $this->input->post('internet_banking_mobile_number_token_a'),
                'bank_b' => $this->input->post('bank_b'),
                'account_type_b' => $this->input->post('account_type_b'),
                'account_number_b' => $this->input->post('account_number_b'),
                'branch_b' => $this->input->post('branch_b'),
                'saving_book_holder_b' => $this->input->post('saving_book_holder_b'),
                'atm_card_holder_b' => $this->input->post('atm_card_holder_b'),
                'internet_banking_username_b' => $this->input->post('internet_banking_username_b'),
                'internet_banking_password_b' => $this->input->post('internet_banking_password_b'),
                'internet_banking_company_id_b' => $this->input->post('internet_banking_company_id_b'),
                'internet_banking_notes_b' => $this->input->post('internet_banking_notes_b'),
                'pin_b' => $this->input->post('pin_b'),
                'internet_banking_mobile_number_token_b' => $this->input->post('internet_banking_mobile_number_token_b'),
                'bank_c' => $this->input->post('bank_c'),
                'account_type_c' => $this->input->post('account_type_c'),
                'account_number_c' => $this->input->post('account_number_c'),
                'branch_c' => $this->input->post('branch_c'),
                'saving_book_holder_c' => $this->input->post('saving_book_holder_c'),
                'atm_card_holder_c' => $this->input->post('atm_card_holder_c'),
                'internet_banking_username_c' => $this->input->post('internet_banking_username_c'),
                'internet_banking_password_c' => $this->input->post('internet_banking_password_c'),
                'internet_banking_company_id_c' => $this->input->post('internet_banking_company_id_c'),
                'internet_banking_notes_c' => $this->input->post('internet_banking_notes_c'),
                'pin_c' => $this->input->post('pin_c'),
                'internet_banking_mobile_number_token_c' => $this->input->post('internet_banking_mobile_number_token_c'),
                'bank_d' => $this->input->post('bank_d'),
                'account_type_d' => $this->input->post('account_type_d'),
                'account_number_d' => $this->input->post('account_number_d'),
                'branch_d' => $this->input->post('branch_d'),
                'saving_book_holder_d' => $this->input->post('saving_book_holder_d'),
                'atm_card_holder_d' => $this->input->post('atm_card_holder_d'),
                'internet_banking_username_d' => $this->input->post('internet_banking_username_d'),
                'internet_banking_password_d' => $this->input->post('internet_banking_password_d'),
                'internet_banking_company_id_d' => $this->input->post('internet_banking_company_id_d'),
                'internet_banking_notes_d' => $this->input->post('internet_banking_notes_d'),
                'pin_d' => $this->input->post('pin_d'),
                'internet_banking_mobile_number_token_d' => $this->input->post('internet_banking_mobile_number_token_d'),
                'bank_e' => $this->input->post('bank_e'),
                'account_type_e' => $this->input->post('account_type_e'),
                'account_number_e' => $this->input->post('account_number_e'),
                'branch_e' => $this->input->post('branch_e'),
                'saving_book_holder_e' => $this->input->post('saving_book_holder_e'),
                'atm_card_holder_e' => $this->input->post('atm_card_holder_e'),
                'internet_banking_username_e' => $this->input->post('internet_banking_username_e'),
                'internet_banking_password_e' => $this->input->post('internet_banking_password_e'),
                'internet_banking_company_id_e' => $this->input->post('internet_banking_company_id_e'),
                'internet_banking_notes_e' => $this->input->post('internet_banking_notes_e'),
                'pin_e' => $this->input->post('pin_e'),
                'internet_banking_mobile_number_token_e' => $this->input->post('internet_banking_mobile_number_token_e')
            );
            
            foreach($file_names as $key=>$value)
            {
                if($value != '')
                    $unit_data[$key] = $value;
            }

			if($unit_id < 1)
			{
                $this->db->insert('units', $unit_data);

                $this->db->select_max('unit_id');
				$this->db->from('units');
				
                return $this->db->get()->row_array();
            }
			else
			{
                $this->db->where('unit_id', $unit_id);
				$this->db->update('units', $unit_data);
			}
		}
		
		public function read_units($columns = '*', $return = 'row_array', $name = '', $page_number = 0, $unit_id = 0)
		{
            if($columns == 'unit_id')
                $this->db->select_max($columns);
            else
                $this->db->select($columns);
            
            $this->db->from('units');
            //$this->db->join('vendors', 'orders.vendor_id = vendors.vendor_id');
            //$this->db->join('users', 'vendors.user_id = users.user_id');
			
			if($unit_id > 0)
                $this->db->where('unit_id', $unit_id);
			
            if($name != '')
                $this->db->like('name', $name);

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
            if($return == 'row_array')
                return $this->db->get()->row_array();
            else if($return == 'result_array')
			    return $this->db->get()->result_array();
			else
				return $this->db->get()->num_rows();
		}
		
		public function update_shareholders_documents($unit_id)
		{
			$unit_data = array(
                'director_id_card' => '',
                'director_tax_id_number_card' => '',
                'commissioner_1_id_card' => '',
                'commissioner_1_tax_id_number_card' => '',
                'commissioner_2_id_card' => '',
                'commissioner_2_tax_id_number_card' => '',
                'commissioner_3_id_card' => '',
                'commissioner_3_tax_id_number_card' => '',
                'commissioner_4_id_card' => '',
                'commissioner_4_tax_id_number_card' => '',
                'commissioner_5_id_card' => '',
                'commissioner_5_tax_id_number_card' => ''
            );
            
            $this->db->where('unit_id', $unit_id);
            $this->db->update('units', $unit_data);
		}
		
		public function delete($user_id)
		{
			if ($this->session->userdata('role_id') == 1) {
				$user_data = array(
					'user_status' => 'Dihapus'
				);
			
				$this->db->where('user_id', $user_id);
			
				return $this->db->update('users', $user_data);
			}	
		}
	}
?>