<?php
	class Finance_model extends CI_Model
	{
		public function read_users_roles_contracts($division = '', $user_id = 0, $unit_id = 0, $user_status = '')
		{
			$this->db->select('*');
			$this->db->from('employees');
			$this->db->join('users', 'employees.user_id = users.user_id');
			
			if($user_id > 0 || $unit_id > 0)
			{
				$this->db->join('contracts', 'employees.user_id = contracts.user_id AND employees.division = contracts.division');

				if($user_id > 0)
				{
					$this->db->where('employees.user_id', $user_id);

					return $this->db->get()->row_array();
				}
				else
				{
					$this->db->where('unit_id', $unit_id);
					$this->db->where('position', 'Manajer');
					$this->db->where('expiry_date >', 'CURDATE()');
				}
			}
			
			if($division != '')
			{
				$this->db->where('employees.division', $division);
				$this->db->where('user_status', 'Aktif');
				
				return $this->db->get()->result_array();
			}
		}
		
		public function read_users($columns = '*', $user_id = 0, $unit_id = 0, $user_status = '')
		{
			$this->db->select($columns);
			$this->db->from('users');
			
			if($user_id > 0)
			{
				$this->db->where('user_id', $user_id);

				return $this->db->get()->row_array();
			}
		}
		
		public function read_contract_unit($user_id)
		{
			$this->db->select('contracts.unit_id as unit_id, name');
			$this->db->from('contracts');
			$this->db->join('units', 'contracts.unit_id = units.unit_id');
			$this->db->where('user_id', $user_id);
			$this->db->order_by('expiry_date', 'DESC');
			
			return $this->db->get()->row_array();
		}

		public function create_update_funding_submission($proof_of_payments, $funding_submission_id)
		{
			$funding_submission_data = array(
				'applicant_user_id' => $this->session->userdata('user_id'),
				'financing_code' => $this->input->post('financing_code'),
				'nominal' => $this->input->post('nominal'),
				'payment_deadline' => $this->input->post('payment_deadline'),
				'other_details' => $this->input->post('other_details'),
				'utilizing_unit_id' => $this->input->post('utilizing_unit_id'),
				'accountee' => $this->input->post('accountee'),
				'bank' => $this->input->post('bank'),
				'account_number' => $this->input->post('account_number'),
				'transfer_information' => $this->input->post('transfer_information'),
				'status' => $this->input->post('status')
			);
			
			if($proof_of_payments != '')
				$funding_submission_data['proof_of_payments'] = $proof_of_payments;
			
			if($this->input->post('event_id') != NULL)
				$funding_submission_data['event_id'] = $this->input->post('event_id');
			
			if($this->input->post('receiver_user_id') != NULL)
				$funding_submission_data['receiver_user_id'] = $this->input->post('receiver_user_id');
			
			if($this->input->post('vendor_id') != NULL)
				$funding_submission_data['vendor_id'] = $this->input->post('vendor_id');
			
			if($this->input->post('order_id') != NULL)
				$funding_submission_data['order_id'] = $this->input->post('order_id');
			
			if($this->input->post('inventory_item') != NULL)
				$funding_submission_data['inventory_item'] = $this->input->post('inventory_item');
		
			if($this->input->post('inventory_item_quantity') != NULL)
				$funding_submission_data['inventory_item_quantity'] = $this->input->post('inventory_item_quantity');
	
			if($this->input->post('inventory_item_unit') != NULL)
				$funding_submission_data['inventory_item_unit'] = $this->input->post('inventory_item_unit');
			
			if($this->input->post('it_data_id') != NULL)
				$funding_submission_data['it_data_id'] = $this->input->post('it_data_id');

			if($funding_submission_id < 1)
			{
				$funding_submission_data['submission_date'] = date("Y-m-d H:i:s");
				
				$this->db->insert('funding_submissions', $funding_submission_data);
			}
			else
			{
				$this->db->where('funding_submission_id', $funding_submission_id);
				$this->db->update('funding_submissions', $funding_submission_data);
			}
		}

		public function read_funding_submissions_users_units($columns = '*', $page_number = 0, $return = 'result_array', $funding_submission_id = 0)
		{
			$this->db->select($columns);
			$this->db->from('funding_submissions');
			
			if($funding_submission_id > 0)
				$this->db->where('funding_submission_id', $funding_submission_id);
			
			if($this->input->get('filter_value') != NULL && $this->input->get('filter_value') != '')
				$this->db->where($this->input->get('filter_column'), urldecode($this->input->get('filter_value')));

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			if($return == 'result_array')
			{
				$this->db->join('users', 'funding_submissions.applicant_user_id = users.user_id');
				$this->db->join('units', 'funding_submissions.utilizing_unit_id = units.unit_id');
				
				if($this->input->get('ordering_column') != NULL && $this->input->get('ordering_column') != '')
					$this->db->order_by($this->input->get('ordering_column'), 'DESC');
				
				return $this->db->get()->result_array();
			}
			else if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
				return $this->db->get()->row_array();
		}
		
		public function read_users_vendors($join_tables_list = '', $page_number = 0, $return = 'result_array', $query = '', $vendor_id = 0, $type = '')
		{
			$this->db->select('*');
			$this->db->from('vendors');

			if($join_tables_list != '')
			{
				$join_tables = explode(',', $join_tables_list);
				
				foreach($join_tables as &$join_table)
				{
					$this->db->join($join_table.'s', 'vendors.'.$join_table.'_id = '.$join_table.'s.'.$join_table.'_id');
				}
			}
			
			if($vendor_id > 0)
				$this->db->where('vendor_id', $vendor_id);
			
			if($query != '')
				$this->db->like('name', $query);

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			if($type != '')
				$this->db->where('type', $type);
			
			if($return == 'result_array')
			{
				$this->db->order_by('name', 'ASC');

				return $this->db->get()->result_array();
			}
			else if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
				return $this->db->get()->row_array();
		}

		public function read_events_units_users_clients($columns = '*', $join_tables_list = '', $unit_id = 0, $return = 'result_array', $page_number = 0, $status = 'all', $query = '', $event_id = 0, $client_id = 0, $approval_status = '', $nearest_city = 'Semua Gudang')
		{
			$this->db->select($columns);
			$this->db->from('events');

			if($join_tables_list != '')
			{
				$join_tables = explode(',', $join_tables_list);
				
				foreach($join_tables as &$join_table)
				{
					if($join_table == 'user')
						$this->db->join($join_table.'s', 'events.marketing_'.$join_table.'_id = '.$join_table.'s.'.$join_table.'_id');
					else
						$this->db->join($join_table.'s', 'events.'.$join_table.'_id = '.$join_table.'s.'.$join_table.'_id');
				}
			}
			
			if($event_id > 0)
				$this->db->where('event_id', $event_id);
			
			if($unit_id > 0)
				$this->db->where('events.unit_id', $unit_id);
			
			if($status == 'Fixed')
			{
				$this->db->join('contracts', 'events.marketing_user_id = contracts.user_id');
				
				if($query > 0)
					$this->db->where('events.unit_id', $query);
				
				$this->db->where('status', $status);
			}
			else if($query != '')
				$this->db->like('events.name', $query);
			
			if($client_id != 0)
				$this->db->where('client_id', $client_id);
			
			if($nearest_city != 'Semua Gudang')
				$this->db->where('nearest_city', $nearest_city);
			
			if($approval_status != '')
				$this->db->where('approval_status', $approval_status);

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
			if($return == 'num_rows')
				return $this->db->get()->num_rows();
			else
			{
				$this->db->order_by('end_date', 'DESC');

				if($return == 'result_array')
				{
					/*$this->load->model('vendor_model');
					
					$events = */return $this->db->get()->result_array();

					/*if(!empty($events))
					{
						for($event_counter = 0; $event_counter < $this->event_model->read_events_vendors_clients('*', '', 0, 'num_rows', $status, urldecode($query)); $event_counter++)
						{
							$marketing = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['marketing_user_id']);
							
							$events[$event_counter]['marketing_name'] = $marketing['name'];

							$instructor = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['instructor_user_id']);
							
							$events[$event_counter]['instructor_name'] = $instructor['name'];

							$cs = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['cs_user_id']);
							
							$events[$event_counter]['cs_name'] = $cs['name'];

							$driver = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['driver_user_id']);
							
							$events[$event_counter]['driver_name'] = $driver['name'];

							$logistic = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['logistic_user_id']);
							
							$events[$event_counter]['logistic_name'] = $logistic['name'];

							$manager = $this->event_model->read_users_roles_contracts('', $events[$event_counter]['manager_user_id']);
							
							$events[$event_counter]['manager_name'] = $manager['name'];

							$hotel = $this->vendor_model->read_users_vendors('user', 0, 'row_array', '', $events[$event_counter]['hotel_vendor_id']);
							
							$events[$event_counter]['hotel'] = $hotel['name'];
						}
					}

					return $events;*/
				}
				else
					return $this->db->get()->row_array();
			}
		}
		
		public function read_revenue($return = 'result_array')
		{
			$this->db->select('*, events.name as event_name, units.name as unit_name, users.name as marketing_name');
			$this->db->from('events');
			$this->db->join('units', 'events.unit_id = units.unit_id');
			$this->db->join('users', 'events.marketing_user_id = users.user_id');
			$this->db->join('clients', 'events.client_id = clients.client_id');
				
			if($this->input->get('project_status') != NULL && $this->input->get('project_status') != '')
			{
				if(urldecode($this->input->get('project_status')) == 'Belum Running')
				{
					$this->db->where('start_date >', date('Y-m-d'));
					$this->db->where("(status = 'Almost' OR events.status = 'Fixed')");
				}
				else
				{
					$this->db->where('start_date <=', date('Y-m-d'));
					$this->db->where('status', 'Fixed');
				}
			}
			else
				$this->db->where("(status = 'Almost' OR events.status = 'Fixed')");

			if($this->input->get('beginning_start_date') != NULL && $this->input->get('beginning_start_date') != '')
			{
				$this->db->where('start_date >=', urldecode($this->input->get('beginning_start_date')).'-01');
				$this->db->where('start_date <=', urldecode($this->input->get('ending_start_date')).'-31');
			}
				
			if($this->input->get('unit_id') != NULL && $this->input->get('unit_id') != '')
				$this->db->where('events.unit_id', $this->input->get('unit_id'));
			
			//if($return == 'result_array' || ($return == 'row_array' && ($view == 'invoice' || $view == 'journal' || $view == 'tax' || $view == 'cashflow')))
			if($return == 'result_array')
            {
				/*$this->db->order_by('event_id', 'ASC');
				
				if($this->input->get('ordering') != NULL && $this->input->get('ordering') != '')
					$this->db->order_by('start_date', $this->input->get('ordering'));*/
				
				$events = $this->db->get()->result_array();

				if(empty($events))
					return $events;
				else
				{
					$this->load->model('project_management_model');
				
					for($event_counter = 0; $event_counter < $this->finance_model->read_revenue('num_rows'); $event_counter++)
					{
						$revenue_transactions = $this->project_management_model->read_journal('debt_reference_code, credit_reference_code, nominal', $events[$event_counter]['event_id'], '"pendapatan usaha"');
						
						$events[$event_counter]['revenue'] = 0;

						foreach($revenue_transactions as &$revenue_transaction)
						{
							if($revenue_transaction['credit_reference_code'] == 'pendapatan usaha')
								$events[$event_counter]['revenue'] = $events[$event_counter]['revenue'] + $revenue_transaction['nominal'];
							else if($revenue_transaction['debt_reference_code'] == 'pendapatan usaha')
								$events[$event_counter]['revenue'] = $events[$event_counter]['revenue'] - $revenue_transaction['nominal'];
						}
					}

					return $events;
				}
			}
            else
            	return $this->db->get()->num_rows();
		}
		
		public function read_credit($return = 'result_array')
		{
			$this->db->select('*, events.name as event_name, units.name as unit_name, users.name as marketing_name');
			$this->db->from('events');
			$this->db->join('units', 'events.unit_id = units.unit_id');
			$this->db->join('users', 'events.marketing_user_id = users.user_id');
			$this->db->join('clients', 'events.client_id = clients.client_id');
				
			if($this->input->get('project_status') != NULL && $this->input->get('project_status') != '')
			{
				if(urldecode($this->input->get('project_status')) == 'Belum Running')
				{
					$this->db->where('start_date >', date('Y-m-d'));
					$this->db->where("(status = 'Almost' OR events.status = 'Fixed')");
				}
				else
				{
					$this->db->where('start_date <=', date('Y-m-d'));
					$this->db->where('status', 'Fixed');
				}
			}
			else
				$this->db->where("(status = 'Almost' OR events.status = 'Fixed')");

			if($this->input->get('beginning_start_date') != NULL && $this->input->get('beginning_start_date') != '')
			{
				$this->db->where('start_date >=', urldecode($this->input->get('beginning_start_date')).'-01');
				$this->db->where('start_date <=', urldecode($this->input->get('ending_start_date')).'-31');
			}
				
			if($this->input->get('unit_id') != NULL && $this->input->get('unit_id') != '')
				$this->db->where('events.unit_id', $this->input->get('unit_id'));
			
			//if($return == 'result_array' || ($return == 'row_array' && ($view == 'invoice' || $view == 'journal' || $view == 'tax' || $view == 'cashflow')))
			if($return == 'result_array')
            {
				/*$this->db->order_by('event_id', 'ASC');
				
				if($this->input->get('ordering') != NULL && $this->input->get('ordering') != '')
					$this->db->order_by('start_date', $this->input->get('ordering'));*/
				
				$events = $this->db->get()->result_array();

				if(empty($events))
					return $events;
				else
				{
					$this->load->model('project_management_model');
				
					for($event_counter = 0; $event_counter < $this->finance_model->read_revenue('num_rows'); $event_counter++)
					{
						$revenue_transactions = $this->project_management_model->read_journal('debt_reference_code, credit_reference_code, nominal', $events[$event_counter]['event_id'], '"pendapatan usaha"');
						
						$events[$event_counter]['revenue'] = 0;

						foreach($revenue_transactions as &$revenue_transaction)
						{
							if($revenue_transaction['credit_reference_code'] == 'pendapatan usaha')
								$events[$event_counter]['revenue'] = $events[$event_counter]['revenue'] + $revenue_transaction['nominal'];
							else if($revenue_transaction['debt_reference_code'] == 'pendapatan usaha')
								$events[$event_counter]['revenue'] = $events[$event_counter]['revenue'] - $revenue_transaction['nominal'];
						}
					}

					return $events;
				}
			}
            else
            	return $this->db->get()->num_rows();
		}

		public function read_journal()
		{
			$this->db->select('debt_reference_code, credit_reference_code, nominal');
			$this->db->from('journal');
			$this->db->like('transaction_date', $this->input->post('transaction_year'));
			$this->db->where('(transaction_type IN ("IN: Manual", "OUT: Manual") AND unit_id = '.$this->input->post('unit_id').')');
			$this->db->where('approval_status', 'Approved');

			$manual_transactions = $this->db->get()->result_array();
			
			$this->db->select('debt_reference_code, credit_reference_code, nominal');
			$this->db->from('journal');
			$this->db->join('events', 'journal.event_id = events.event_id');
			$this->db->like('transaction_date', $this->input->post('transaction_year'));
			$this->db->where('(transaction_type = "IN: Event" AND events.unit_id = '.$this->input->post('unit_id').')');
			$this->db->where('journal.approval_status', 'Approved');

			$events_transactions = $this->db->get()->result_array();
			
			$this->db->select('debt_reference_code, credit_reference_code, journal.nominal as nominal');
			$this->db->from('journal');
			$this->db->join('funding_submissions', 'journal.funding_submission_id = funding_submissions.funding_submission_id');
			$this->db->like('transaction_date', $this->input->post('transaction_year'));
			$this->db->where('(transaction_type = "OUT: Pengajuan" AND utilizing_unit_id = '.$this->input->post('unit_id').')');
			$this->db->where('approval_status', 'Approved');

			$funding_submissions_transactions = $this->db->get()->result_array();

			$transactions = array_merge($manual_transactions, $events_transactions, $funding_submissions_transactions);

			return $transactions;
		}
		
		public function delete($user_id)
		{
			if ($this->session->userdata('role_id') == 1) {
				$user_data = array(
					'user_status' => 'Dihapus'
				);
			
				$this->db->where('user_id', $user_id);
			
				return $this->db->update('users', $user_data);
			}	
		}
	}
?>