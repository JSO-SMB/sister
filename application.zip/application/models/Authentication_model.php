<?php
	class Authentication_model extends CI_Model
	{
		/*public function read_roles()
		{
	        $query = $this->db->get('roles');
	        
	        return $query->result_array();
		}

		public function read_latest_reg()
		{
	        $this->db->select_max('user_id');
			$this->db->from('users');
				
			$query = $this->db->get();
			
			return $query->row_array();
		}
		
		public function username_num_rows()
		{
	        $query = $this->db->get_where('users', array('username' => $this->input->post('username'), 'user_status' => 'Aktif'));
			
			return $query->num_rows();
		}
		
		public function check_active_account()
		{
	        $query = $this->db->get_where('users', array('email_address' => $this->input->post('email_address'), 'user_status' => 'Aktif'));
			
			return $query->num_rows();
		}

		public function admin_email_address_num_rows()
		{
	    	
			$this->db->select('*');
			$this->db->from('users');
			$this->db->where('user_status', 'Aktif');
			$this->db->where('role_id', '1');
				
			$query = $this->db->get();
			//$query = $this->db->get_where('users', array('role_id' => '1', 'user_status' => 'Aktif'));
				
	        return $query->result_array();
			//return $query->num_rows();
		}
		*/
		public function read_user($email_address, $ciphered_email_address = '')
		{
	        $this->db->select('*');
			$this->db->from('users');

			if($email_address == '')
			{
				$this->db->where('ciphered_email_address', $ciphered_email_address);
				$this->db->where('user_status', 'Aktif');
			}
			else
				$this->db->where('email_address', $email_address);
			
			return $this->db->get()->row_array();
		}
		
		public function update_ciphered_email_address($email_address, $ciphered_email_address = '')
		{
		    $user_data = array(
		        'ciphered_email_address' => $ciphered_email_address
			);
			
			$this->db->where('email_address', $email_address);
			$this->db->where('user_status', 'Aktif');
		
		    return $this->db->update('users', $user_data);
		}
		
		public function update_hashed_password($email_address, $hashed_password)
		{
		    $user_data = array(
		        'hashed_password' => $hashed_password
			);
			
			$this->db->where('email_address', $email_address);
			$this->db->where('user_status', 'Aktif');
		
		    return $this->db->update('users', $user_data);
		}
		/*
		public function update_status($user_status, $user_id)
		{
		    $user_data = array(
		        'user_status' => $user_status
			);
			
			$this->db->where('user_id', $user_id);
		
		    return $this->db->update('users', $user_data);
		}
		
		public function delete($user_id)
		{
		    $user_data = array(
			        'user_status' => 'Deleted'
			);
			
			$this->db->where('user_id', $user_id);
		
		    return $this->db->update('users', $user_data);
		}
		
		public function picture_remove($user_id)
		{
		    $user_data = array(
			        'user_picture' => ''
			);
			
			$this->db->where('user_id', $user_id);
		
		    return $this->db->update('users', $user_data);
		}
		*/
	}
?>