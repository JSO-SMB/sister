<?php
	class Employee_model extends CI_Model
	{
		public function read_roles()
		{
			$query = $this->db->get('roles');
			
			return $query->result_array();
		}

		public function read_email_address($email_address)
		{
			$query = $this->db->get_where('users', array('email_address' => $email_address));
			
			return $query->row_array();
		}
		
		public function create_update_user($id_card, $photo, $email_address = '')
		{
			$user_data = array(
				'name'			=> $this->input->post('name'),
                'phone_number'	=> $this->input->post('phone_number'),
				'email_address'	=> $this->input->post('email_address')
			);

			if($this->input->post('single_address') == 'Ya')
			{
				$user_data['city'] = $this->input->post('id_card_city');
				$user_data['address'] = $this->input->post('id_card_address');
			}
			else
			{
				$user_data['city'] = $this->input->post('city');
				$user_data['address'] = $this->input->post('address');
			}

			$employee_data = array(
                'nickname' => $this->input->post('nickname'),
                'birthplace' => $this->input->post('birthplace'),
                'birthday' => $this->input->post('birthday'),
                'religion' => $this->input->post('religion'),
				'marital_status' => $this->input->post('marital_status'),
                'last_education' => $this->input->post('last_education'),
				'major' => $this->input->post('major'),
				'gender' => $this->input->post('gender'),
				'id_card_city' => $this->input->post('id_card_city'),
                'id_card_address' => $this->input->post('id_card_address'),
				'father_phone_number' => $this->input->post('father_phone_number'),
				'division' => $this->input->post('division'),
				'expertise' => $this->input->post('expertise'),
				'company_profile_knowledge' => $this->input->post('company_profile_knowledge'),
				'interest_to_company' => $this->input->post('interest_to_company'),
				'interest_to_division' => $this->input->post('interest_to_division'),
				'other_divisions' => $this->input->post('other_divisions'),
				'overtime' => $this->input->post('overtime'),
				'probation' => $this->input->post('probation'),
				'ambitions' => $this->input->post('ambitions'),
				'positive_attitudes' => $this->input->post('positive_attitudes'),
				'negative_attitudes' => $this->input->post('negative_attitudes'),
				'recruit_reasons' => $this->input->post('recruit_reasons'),
				'to_dos' => $this->input->post('to_dos'),
				'referral' => $this->input->post('referral')
			);

			if($email_address == '')
			{
				//$user_data['email_address'] = $this->input->post('email_address');

				$password_hash_options['cost'] = 9;
					
				$user_data['hashed_password'] = password_hash('515t3r', PASSWORD_DEFAULT, $password_hash_options);

				$user_data['role_id'] = 1;
				$user_data['user_status'] = 'Calon karyawan';

				$this->db->insert('users', $user_data);

				$user_role = $this->employee_model->read_users_roles($this->input->post('email_address'));

				$employee_data['id_card'] = $id_card;
				$employee_data['photo'] = $photo;
				$employee_data['user_id'] = $user_role['user_id'];

				return $this->db->insert('employees', $employee_data);
			}
			else
			{
				if($this->session->has_userdata('user_id'))
				{
					if($this->input->post('password') != '')
					{
						$password_hash_options['cost'] = 9;
						
						$user_data['hashed_password'] = password_hash($this->input->post('password'), PASSWORD_DEFAULT, $password_hash_options);
					}

					$user_data['account_number'] = $this->input->post('account_number');
					$user_data['accountee'] = $this->input->post('accountee');
					
					$employee_data['mate_name'] = $this->input->post('mate_name');
					$employee_data['mate_phone_number'] = $this->input->post('mate_phone_number');
					$employee_data['mate_occupation'] = $this->input->post('mate_occupation');
					$employee_data['id_card_number'] = $this->input->post('id_card_number');
					$employee_data['mother_name'] = $this->input->post('mother_name');
					$employee_data['mother_phone_number'] = $this->input->post('mother_phone_number');
					$employee_data['mother_occupation'] = $this->input->post('mother_occupation');
					$employee_data['father_name'] = $this->input->post('father_name');
					$employee_data['father_occupation'] = $this->input->post('father_occupation');
				}
				
				$this->db->where('email_address', $email_address);
				$this->db->update('users', $user_data);

				if($id_card != '')
					$employee_data['id_card'] = $id_card;
				if($photo != '')
					$employee_data['photo'] = $photo;
				
				$user_role = $this->employee_model->read_users_roles($this->input->post('email_address'));

				$this->db->where('user_id', $user_role['user_id']);
				$this->db->update('employees', $employee_data);
			}
		}
		
		public function read_users_roles($email_address = '', $role_id = 0, $role_specific_table = '', $return = 'result_array', $page_number = 0, $name = '')
		{
			$this->db->select('*');
			$this->db->from('users');
			
			if($email_address == '' && $role_id == 0 && $role_specific_table == '')
			{
				$this->db->join('employees', 'users.user_id = employees.user_id');
				
				if($name != '')
					$this->db->like('name', $name);
				
				if($return == 'result_array')
				{
					$this->db->order_by('name', 'ASC');
					
					if($page_number > 0)
						$this->db->limit(5, (5 * ($page_number - 1)));
					
					return $this->db->get()->result_array();
				}
				else
					return $this->db->get()->num_rows();
			}
			else
			{
				if($email_address != '')
					$this->db->where('email_address', $email_address);
				
				if($role_id != 0)
				{
					$this->db->where('role_id', $role_id);
					$this->db->where('user_status', 'Aktif');
				}
				
				if($role_specific_table != '')
				{
					$this->db->join($role_specific_table, 'users.user_id = '.$role_specific_table.'.user_id');

					if($role_specific_table == 'employees')
					{
						$this->db->join('contracts', 'users.user_id = contracts.user_id AND employees.division = contracts.division');
						$this->db->order_by('expiry_date', 'DESC');
					}
				}

				//$this->db->join('roles', 'users.role_id = roles.role_id');
				//$this->db->where('users.user_id', $user_id);
				
				return $this->db->get()->row_array();
			}
		}
		
		public function read_users_roles_2($email_address = '', $role_id = 0, $role_specific_table = '', $return = 'result_array', $page_number = 0, $name = '')
		{
			$this->db->select('*');
			$this->db->from('users');
			
			if($email_address == '' && $role_id == 0 && $role_specific_table == '')
			{
				$this->db->join('employees', 'users.user_id = employees.user_id');
				
				if($name != '')
					$this->db->like('name', $name);
				
				if($return == 'result_array')
				{
					$this->db->order_by('name', 'ASC');
					
					if($page_number > 0)
						$this->db->limit(5, (5 * ($page_number - 1)));
					
					return $this->db->get()->result_array();
				}
				else
					return $this->db->get()->num_rows();
			}
			else
			{
				if($email_address != '')
					$this->db->where('email_address', $email_address);
				
				if($role_id != 0)
				{
					$this->db->where('role_id', $role_id);
					$this->db->where('user_status', 'Aktif');
				}
				
				if($role_specific_table != '')
					$this->db->join($role_specific_table, 'users.user_id = '.$role_specific_table.'.user_id');

				//$this->db->join('roles', 'users.role_id = roles.role_id');
				//$this->db->where('users.user_id', $user_id);
				
				return $this->db->get()->row_array();
			}
		}
		
        public function update_interview_invitation($user_id)
		{
			$employee_data = array(
				'interview_invitation' => 1
			);
			
			$this->db->where('user_id', $user_id);
            $this->db->update('employees', $employee_data);
		}
		
		public function delete($user_id)
		{
			$user_data = array(
				'user_status' => 'Dihapus'
			);
		
			$this->db->where('user_id', $user_id);
		
			$this->db->update('users', $user_data);
		}
	}
?>