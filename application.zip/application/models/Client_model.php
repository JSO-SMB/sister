<?php
	class Client_model extends CI_Model
	{
		public function read_roles()
		{
			$query = $this->db->get('roles');
			
			return $query->result_array();
		}

		public function read_email_address($email_address, $user_id = 0)
		{
			if($user_id == 0)
				$query = $this->db->get_where('users', array('email_address' => $email_address));
			else
			{
				$this->db->select('*');
				$this->db->from('users');
				$this->db->where('user_id <>', $user_id);
				$this->db->where('user_email_address', $user_email_address);
				$this->db->where('user_status', 'Aktif');
				
				$query = $this->db->get();
			}
			
			return $query->row_array();
		}
		
		public function create_update_client($client_id = 0)
		{
			$client_data = array(
				'greeting' => $this->input->post('greeting'),
                'name' => $this->input->post('name'),
                'email_address' => $this->input->post('email_address'),
                'mobile_number' => $this->input->post('mobile_number'),
                'whatsapp' => $this->input->post('whatsapp'),
                'marketing' => implode(',', $this->input->post('marketing')),
                'company' => $this->input->post('company'),
                'sector' => implode(',', $this->input->post('sector')),
                'address' => $this->input->post('address'),
                'phone_number' => $this->input->post('phone_number'),
                'position' => $this->input->post('position'),
                'boss' => $this->input->post('boss'),
                'hrd' => $this->input->post('hrd'),
                'user_id' => $this->session->userdata('user_id')
            );
            
            if($client_id == 0)
			    return $this->db->insert('clients', $client_data);
			else
			{
				$this->db->where('client_id', $client_id);
                
                return $this->db->update('clients', $client_data);
			}
		}
		
		public function read_users($join_table = '', $user_status = '', $user_id = 0)
		{
			$this->db->select('*');
            $this->db->from('users');
			
			if($join_table != '')
				$this->db->join($join_table, 'users.user_id = '.$join_table.'.user_id');
			
			if($user_status != '')
				$this->db->where('user_status', $user_status);
			
			if($user_id > 0)
            {
				$this->db->where('user_id', $user_id);

				return $this->db->get()->row_array();
			}
			else
            	return $this->db->get()->result_array();
		}
		
		public function read_clients($client_id = 0, $return = 'row_array', $query = '', $category = 'general', $page_number = 0, $join_tables_list = '', $additional_fields = '')
		{
			$this->db->select('*'.$additional_fields);
			$this->db->from('clients');

			if($join_tables_list != '')
			{
				$join_tables = explode(',', $join_tables_list);
				
				foreach($join_tables as &$join_table)
				{
					$this->db->join($join_table, 'clients.user_id = '.$join_table.'.user_id');
				}
			}
			
			if($client_id != 0)
				$this->db->where('client_id', $client_id);
			
			if($query != '')
			{
				if($category == 'general')
					$this->db->like('name', $query);
				else
					$this->db->where('unit_id', $query);
			}

			if($page_number > 0)
				$this->db->limit(5, (5 * ($page_number - 1)));
			
            if($return == 'row_array')
				return $this->db->get()->row_array();
            else if($return == 'result_array')
            {
				$this->db->order_by('name', 'ASC');

				if($category == 'general')
				{
					$this->load->model('event_model');
					
					$clients = $this->db->get()->result_array();

					for($client_counter = 0; $client_counter < $this->client_model->read_clients(0, 'num_rows', urldecode($query), $category, $page_number); $client_counter++)
					{
						$event = $this->event_model->read_events_vendors_clients('*, events.name as event_name', '', 0, 'row_array', '', '', 0, $clients[$client_counter]['client_id']);
						
						if (isset($event))
						{
							$clients[$client_counter]['event_id'] = $event['event_id'];
							$clients[$client_counter]['event_name'] = $event['event_name'];
							$clients[$client_counter]['event_date'] = substr($event['start_date'], -2).'/'.substr($event['start_date'], 5, 2).'/'.substr($event['start_date'], 0, 4);

							if($event['end_date'] > $event['start_date'])
								$clients[$client_counter]['event_date'] = $clients[$client_counter]['event_date'].' - '.substr($event['end_date'], -2).'/'.substr($event['end_date'], 5, 2).'/'.substr($event['end_date'], 0, 4);
						}
						else
							$clients[$client_counter]['event_id'] = 0;
					}

					return $clients;
				}
				else
					return $this->db->get()->result_array();
            }
			else
                return $this->db->get()->num_rows();
		}
		
		public function delete($user_id)
		{
			if ($this->session->userdata('role_id') == 1) {
				$user_data = array(
					'user_status' => 'Dihapus'
				);
			
				$this->db->where('user_id', $user_id);
			
				return $this->db->update('users', $user_data);
			}	
		}
	}
?>