<?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    class Assignment
    {
        protected $CI;

        // We'll use a constructor, as you can't directly call a function
        // from a property definition.
        // public function __construct()
        // {
        //     // Assign the CodeIgniter super-object
        //     $this->CI->load->library('session');
        //     $this->CI->load->helper('url');
        // }

        public function expiring_contracts()
        {
            $this->CI =& get_instance();
            
            $this->CI->load->model('general_model');
            
            $joins[1]['table'] = 'employees';
                    
            $joins[1]['on'] = 'users.user_id = employees.user_id';
            
            $filters[1]['operator'] = 'where';
            $filters[2]['operator'] = 'where';
            $filters[3]['operator'] = 'where_not_in';
            
            $filters[1]['field'] = 'role_id';
            $filters[2]['field'] = 'user_status';
            $filters[3]['field'] = 'division';

            $filters[1]['value'] = 1;
            $filters[2]['value'] = 'Aktif';
            $filters[3]['value'] = array('SUPER USER', 'CUSTOMER SERVICE', 'INSTRUKTUR');

            $active_employees = $this->CI->general_model->read('select', 'users.user_id as user_id', 'users', $joins, $filters, array(), 0, 0, 'result_array');

            $date = date_create(date('Y-m-d'));
            date_add($date,date_interval_create_from_date_string("7 days"));

            $max_expiry_date = date_format($date,'Y-m-d');
            
            $expiring_contracts = array();

            if(!empty($active_employees))
            {
                foreach($active_employees as &$active_employee)
                {
                    $joins[1]['table'] = 'users';
                            
                    $joins[1]['on'] = 'contracts.user_id = users.user_id';
                    
                    $filters[1]['operator'] = 'where';
                    $filters[2]['operator'] = 'where';
                    
                    $filters[1]['field'] = 'contracts.user_id';
                    $filters[2]['field'] = 'status';
        
                    $filters[1]['value'] = $active_employee['user_id'];
                    $filters[2]['value'] = 'Valid';

                    $orders[1]['field'] = 'expiry_date';
        
                    $orders[1]['direction'] = 'DESC';

                    $contract = $this->CI->general_model->read('select', 'contract_id, expiry_date, name', 'contracts', $joins, $filters, $orders);

                    if(isset($contract))
                    {
                        if($contract['expiry_date'] <= $max_expiry_date)
                            $expiring_contracts[] = $contract;
                    }
                }
            }

            return $expiring_contracts;
        }

        public function table_template_pagination($page_count, $page_number)
        {
            if($page_count > 10)
            {
                if($page_number > 6)
                {
                    if(($page_count - $page_number) >= 4)
                        $next_page_count = 4;
                    else
                        $next_page_count = $page_count - $page_number;
                    
                    $previous_page_count = 9 - $next_page_count;
                }
                else
                {
                    $previous_page_count = $page_number - 1;
                    $next_page_count = 9 - $previous_page_count;
                }
            }
            else
            {
                $previous_page_count = $page_number - 1;
                $next_page_count = $page_count - $page_number;
            }

            $data['previous_page_count'] = $previous_page_count;
            $data['next_page_count'] = $next_page_count;
            
            return $data;
        }
    }