<?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    class Authorization
    {
        protected $CI;

        // We'll use a constructor, as you can't directly call a function
        // from a property definition.
        public function __construct()
        {
            // Assign the CodeIgniter super-object
            $this->CI =& get_instance();

            $this->CI->load->library('session');
            $this->CI->load->helper('url');
        }

        public function is_logged_out()
        {
            if($this->CI->session->has_userdata('account_id'))
                redirect();
        }

        public function is_logged_in($parameters = '')
        {
            if(!$this->CI->session->has_userdata('user_id'))
            {	
                $this->CI->session->set_userdata('previous_url', current_url().$parameters);

                redirect(base_url('otentikasi/masuk'));
            }
        }
    }