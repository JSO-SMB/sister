function setPagination(parameters)
{
    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            document.getElementById("pagination-div").innerHTML = xmlhttp.responseText;
            // document.getElementById("record-id-select-unselect-all-input").checked = false;

            // checkUncheckAllCurrentPageRecords();
        }
    };
    
    xmlhttp.open("GET", document.getElementById("controller-link").value + "/pagination/" + parameters, true);
    xmlhttp.send();
}

function preventSubmit(event)
{
    if (event.keyCode == 13)
    {
        event.preventDefault();
        return false;
    }
}

function checkUncheckAllCurrentPageRecords()
{
    var recordIdInput = document.getElementsByClassName("record-id-input");
    var elementCounter;
    
    for(elementCounter = 0; elementCounter < recordIdInput.length; elementCounter++)
    {
        if(document.getElementById("record-id-select-unselect-all-input").checked === true)
        {
            recordIdInput[elementCounter].checked = true;
            
            document.getElementById("pagination-div").style.display = 'none';
            document.getElementById("bulk-action-div").style.display = 'block';
        }
        else
        {
            recordIdInput[elementCounter].checked = false;
            
            document.getElementById("bulk-action-div").style.display = 'none';
            document.getElementById("pagination-div").style.display = 'block';
        }
    }
}

function showHideBulkAction()
{
    var recordIdInput = document.getElementsByClassName("record-id-input");
    var elementCounter;
    var checkedRecordIdInput = 0;

    for(elementCounter = 0; elementCounter < recordIdInput.length; elementCounter++)
    {
        if(recordIdInput[elementCounter].checked === true)
        {
            checkedRecordIdInput++;
            
            break;
        }
    }

    if(checkedRecordIdInput > 0)
    {
        document.getElementById("pagination-div").style.display = 'none';
        document.getElementById("bulk-action-div").style.display = 'block';
    }
    else
    {
        document.getElementById("bulk-action-div").style.display = 'none';
        document.getElementById("pagination-div").style.display = 'block';
    }
}

function confirmDeletion()
{
    if(document.getElementById("formaction").value.includes("create_update_category"))
        var confirmation = 'Selected service category and all services within it will be deleted. Are You sure?';
    else
        var confirmation = 'Data yang dipilih akan dihapus. Apa Anda yakin?';

    if(confirm(confirmation) == false)
        return false;
}

function setformAction(visibility)
{
    document.getElementById("bulk-action-submit").formAction = document.getElementById("formaction").value + visibility;
}

function confirmBulkAction()
{
    if(document.getElementById("bulk-action-select").value == 'Dihapus' || document.getElementById("bulk-action-select").value == '?status=Dihapus')
    {
        if(document.getElementById("formaction").value.includes("create_update_category"))
            var confirmation = 'Selected service categories and all services within them will be deleted. Are You sure?';
        else
            var confirmation = 'Data yang dipilih akan dihapus. Apa Anda yakin?';

        if(confirm(confirmation) == false)
            return false;
    }
}