function setHostingDueDate()
{
    var jsHostingDueDate = new Date(document.getElementById("hosting-purchase-date-input").value);

    jsHostingDueDate.setFullYear(jsHostingDueDate.getFullYear() + 1);

    htmlHostingDueDate = jsHostingDueDate.getFullYear() + '-';

    if((jsHostingDueDate.getMonth() + 1) < 10)
        htmlHostingDueDate = htmlHostingDueDate + '0';
    
    htmlHostingDueDate = htmlHostingDueDate + (jsHostingDueDate.getMonth() + 1) + '-';

    if(jsHostingDueDate.getDate() < 10)
        htmlHostingDueDate = htmlHostingDueDate + '0';
    
    htmlHostingDueDate = htmlHostingDueDate + jsHostingDueDate.getDate();
    
    document.getElementById("hosting-due-date-input").value = htmlHostingDueDate;
}

function calculateSpaceRemaining()
{
    document.getElementById("space-remaining-input").value = parseInt(document.getElementById("space-total-input").value) - parseInt(document.getElementById("space-used-input").value);
}

function setDomainNameDueDate()
{
    var jsDomainNameDueDate = new Date(document.getElementById("domain-name-purchase-date-input").value);

    jsDomainNameDueDate.setFullYear(jsDomainNameDueDate.getFullYear() + 1);

    htmlDomainNameDueDate = jsDomainNameDueDate.getFullYear() + '-';

    if((jsDomainNameDueDate.getMonth() + 1) < 10)
        htmlDomainNameDueDate = htmlDomainNameDueDate + '0';
    
    htmlDomainNameDueDate = htmlDomainNameDueDate + (jsDomainNameDueDate.getMonth() + 1) + '-';

    if(jsDomainNameDueDate.getDate() < 10)
        htmlDomainNameDueDate = htmlDomainNameDueDate + '0';
    
    htmlDomainNameDueDate = htmlDomainNameDueDate + jsDomainNameDueDate.getDate();
    
    document.getElementById("domain-name-due-date-input").value = htmlDomainNameDueDate;
}

function calculateTotalPrice()
{
    var totalPrice = parseInt(document.getElementById("domain-name-annual-renewal-price-input").value.replace(/\./g,"")) + parseInt(document.getElementById("whois-privacy-price-input").value.replace(/\./g,"")) + parseInt(document.getElementById("ssl-certificate-price-input").value.replace(/\./g,""));
    
    document.getElementById("total-price-input").value = totalPrice.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
}

function calculatePostTotal()
{
    document.getElementById("post-total-input").value = parseInt(document.getElementById("post-draft-input").value) + parseInt(document.getElementById("post-published-input").value) + parseInt(document.getElementById("post-scheduled-input").value);
}

function initialCalculation()
{
    setHostingDueDate();
    calculateSpaceRemaining();
    setDomainNameDueDate();
    calculateTotalPrice();
    calculatePostTotal();
}

setTimeout(initialCalculation(), 1);

function hideShowTypicalDiv(type)
{
    var hostingDiv = document.getElementsByClassName("hosting");
    var elementCounter;
    
    for(elementCounter = 0; elementCounter < hostingDiv.length; elementCounter++)
    {
        if(type == 'Hosting')
            hostingDiv[elementCounter].style.display = 'block';
        else
            hostingDiv[elementCounter].style.display = 'none';
    }
    
    var domainNameDiv = document.getElementsByClassName("domain");
    
    for(elementCounter = 0; elementCounter < domainNameDiv.length; elementCounter++)
    {
        if(type == 'Domain')
            domainNameDiv[elementCounter].style.display = 'block';
        else
            domainNameDiv[elementCounter].style.display = 'none';
    }

    if(type == 'email')
        document.getElementById("email-div").style.display = 'block';
    else
        document.getElementById("email-div").style.display = 'none';
    
    if(type == 'Nomor HP/Telepon')
        document.getElementById("mobile-number-div").style.display = 'block';
    else
        document.getElementById("mobile-number-div").style.display = 'none';
    
    if(type == 'Akun Medsos dll.')
        document.getElementById("social-media-div").style.display = 'block';
    else
        document.getElementById("social-media-div").style.display = 'none';
}

function setUnitRelatedOptions(unitRelatedOptionRetrieveLink, unitId, query = 'Domain')
{   
    if(window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function()
    {
        if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            if(query == 'Domain')
            {
                $('option', $('#multiselect2')).remove();
                $('#multiselect2').append(xmlhttp.responseText);
                $('#multiselect2').multiselect('rebuild');

                nextQuery = 'Hosting';
            }
            else
            {
                if(query == 'Hosting')
                {
                    className = 'hosting-select';
                    nextQuery = 'email';
                }
                else if(query == 'email')
                {
                    className = 'email-address-select';
                    nextQuery = 'Staff';
                }
                else if(query == 'Staff')
                {
                    className = 'marketing-select';
                    nextQuery = 'Nomor HP/Telepon';
                }
                else if(query == 'Nomor HP/Telepon')
                {
                    className = 'mobile-number-select';
                    nextQuery = 'Manajer';
                }
                else if(query == 'Manajer')
                {
                    className = 'manager-select';
                    nextQuery = '';
                }
                else if(query == '')
                    className = 'pic-select';
                
                selectElement = document.getElementsByClassName(className);
                
                for(selectCounter = 0; selectCounter < selectElement.length; selectCounter++)
                {
                    selectElement[selectCounter].innerHTML = xmlhttp.responseText;
                }
            }

            if(query != '')
                setUnitRelatedOptions(unitRelatedOptionRetrieveLink, unitId, nextQuery);
        }
    };

    xmlhttp.open("GET", unitRelatedOptionRetrieveLink + unitId + '?kueri=' + encodeURIComponent(query), true);
    xmlhttp.send();
}

function checkAccount(accountCheckLink, initialAccount, account)
{
    var type = document.getElementById("type-select").value;
    var spanId;

    if(type == 'Hosting')
    {
        spanId = 'hosting-span';
        inputId = 'hosting-data-name-input';
    }
    else if(type == 'Domain')
    {
        spanId = 'domain-span';
        inputId = 'domain-name-data-name-input';
    }
    else if(type == 'email')
    {
        spanId = 'email-span';
        inputId = 'email-username-input';
    }
    else if(type == 'Nomor HP/Telepon')
    {
        spanId = 'mobile-number-span';
        inputId = 'mobile-number-input';
    }
    else
    {
        spanId = 'social-media-span';
        inputId = 'social-media-link-input';
    }
    
    if(account != '' && initialAccount != account)
    {
        if(window.XMLHttpRequest)
        {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        }
        else
        {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        xmlhttp.onreadystatechange = function()
        {
            if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
            {
                if(xmlhttp.responseText < 1)
                    document.getElementById(spanId).style.display = "none";
                else
                {
                    document.getElementById(spanId).style.display = "inline";
                    
                    document.getElementById(inputId).focus();
                }
            }
        };
        
        xmlhttp.open("GET", accountCheckLink + '?jenis=' + encodeURIComponent(type) + '&akun=' + encodeURIComponent(account), true);
        xmlhttp.send();
    }
    else
        document.getElementById(spanId).style.display = "none";
}

function setDataName()
{
    var elementCounter;
    var dataNameInput = document.getElementsByClassName("data-name");
    var type = document.getElementById("type-select").value;
    
    for(elementCounter = 0; elementCounter < dataNameInput.length; elementCounter++)
    {
        if(type == 'Hosting' || type == 'Domain')
        {
            dataNameInput[elementCounter].type = 'url';

            if(type == 'Hosting')
                dataNameInput[elementCounter].value = document.getElementById("hosting-data-name-input").value;
            else
                dataNameInput[elementCounter].value = document.getElementById("domain-name-data-name-input").value;
        }
        else
        {
            dataNameInput[elementCounter].type = 'text';

            if(type == 'email')
                dataNameInput[elementCounter].value = document.getElementById("email-data-name-input").value;
            else
                dataNameInput[elementCounter].value = document.getElementById("social-media-data-name-input").value;
        }
    }
}

function setVendor(vendorId)
{
    if(document.getElementById("type-select").value == 'Hosting')
        document.getElementById("domain-name-vendor-id-select").value = vendorId;
    else
        document.getElementById("hosting-vendor-id-select").value = vendorId;
}

// function setPurchaseDueDate(purchaseDate)
// {
//     if(document.getElementById("type-select").value == 'Hosting')
//     {
//         document.getElementById("domain-name-purchase-date-input").value = purchaseDate;
        
//         setDomainNameDueDate();
//     }
//     else
//     {
//         document.getElementById("hosting-purchase-date-input").value = purchaseDate;
        
//         setHostingDueDate();
//     }
// }

function setPurchaseDueDate(purchaseDate)
{
    if(document.getElementById("type-select").value == 'Hosting')
        document.getElementById("domain-name-purchase-date-input").value = purchaseDate;
    else
        document.getElementById("hosting-purchase-date-input").value = purchaseDate;
        
    setHostingDueDate();
    setDomainNameDueDate();
}

function setAnnualRenewalPrice(annualRenewalPrice)
{
    if(document.getElementById("type-select").value == 'Hosting')
    {
        document.getElementById("domain-name-annual-renewal-price-input").value = annualRenewalPrice;
        
        calculateTotalPrice();
    }
    else
        document.getElementById("hosting-annual-renewal-price-input").value = annualRenewalPrice;
}

function setCreationDate(creationDate)
{
    if(document.getElementById("type-select").value == 'email')
        document.getElementById("social-media-creation-date-input").value = creationDate;
    else
        document.getElementById("email-creation-date-input").value = creationDate;
}

function setPIC()
{
    var elementCounter;
    var picSelect = document.getElementsByClassName("pic-select");
    var type = document.getElementById("type-select").value;
    
    for(elementCounter = 0; elementCounter < picSelect.length; elementCounter++)
    {
        if(type == 'email')
            picSelect[elementCounter].value = document.getElementById("email-pic-user-id-select").value;
        else if(type == 'Nomor HP/Telepon')
            picSelect[elementCounter].value = document.getElementById("mobile-number-pic-user-id-select").value;
        else
            picSelect[elementCounter].value = document.getElementById("social-media-pic-user-id-select").value;
    }
}

function validateSubmission()
{
    var proposalDate = new Date(document.getElementById("proposal-date-input").value);
    var startDate = new Date(document.getElementById("start-date-input").value);
    var endDate = new Date(document.getElementById("end-date-input").value);

    if(proposalDate >= startDate)
    {
        alert('Tanggal proposal harus lebih awal dari tanggal mulai pelatihan!');

        return false;
    }
    else if(startDate > endDate)
    {
        alert('Tanggal mulai harus lebih awal dari tanggal berakhir pelatihan!');

        return false;
    }
    else if(document.getElementById("status-select").value == 'Almost' || document.getElementById("status-select").value == 'Fixed')
    {
        if(confirm('Data Operasional & Data RAB akan dikirimkan ke divisi Logistik & Finance, jadi pastikan seluruh data yang diisikan sudah betul.\n\nJika Anda yakin seluruh data sudah betul, silakan tekan tombol "OK" untuk melanjutkan. Tetapi jika Anda ingin memastikan kembali data yang telah Anda masukkan, silakan tekan tombol "Cancel".') == false)
            return false;
    }
}

$(document).ready(function(){
    // Format mata uang.
    $( '.currency' ).mask('000.000.000.000.000.000', {reverse: true});
})