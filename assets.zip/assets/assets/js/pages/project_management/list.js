function getDynamicContent(pageNumber)
{
    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
            document.getElementById("card").innerHTML = xmlhttp.responseText;
    };
    
    url = document.getElementById("controller-link").value + "projects/" + pageNumber;
    //url = url + "?division=" + encodeURIComponent(document.getElementById("division").value);
    url = url + "?unit_id=";
    
    if(typeof(document.getElementById("unit-id-select")) != 'undefined' && document.getElementById("unit-id-select") != null && document.getElementById("unit-id-select").value != '')
        url = url + document.getElementById("unit-id-select").value;
    
    url = url + "&project_status=";
    
    if(typeof(document.getElementById("project-status-select")) != 'undefined' && document.getElementById("project-status-select") != null && document.getElementById("project-status-select").value != '')
        url = url + document.getElementById("project-status-select").value;
    
    url = url + "&start_date=";
    
    if(typeof(document.getElementById("start-date-input")) != 'undefined' && document.getElementById("start-date-input") != null && document.getElementById("start-date-input").value != '')
        url = url + encodeURIComponent(document.getElementById("start-date-input").value);
    
    /*url = url + "&ordering_column=";
    
    if(typeof(document.getElementById("ordering-column-select")) != 'undefined' && document.getElementById("ordering-column-select") != null)
        url = url + encodeURIComponent(document.getElementById("ordering-column-select").value);
    else
        url = url + encodeURIComponent("transaction_date");*/
    
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

setTimeout(getDynamicContent(1), 1);

function setFilterValue(filterColumn)
{
    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            var filterValueSelect = document.getElementById('filter-value-select');
            var filterValueInput = document.getElementById('filter-value-input');
            
            if(filterColumn == 'payment_date,like')
            {
                document.getElementById("filter-value-label").innerHTML = 'Bulan & Tahun';
                filterValueInput.type = 'month';
                
                var attribute = filterValueInput.getAttributeNode("disabled");

                if(attribute != null)
                    filterValueInput.removeAttributeNode(attribute);
                
                filterValueInput.style.display = 'inline';


                attribute = document.createAttribute("disabled");
                
                attribute.value = "disabled";
                
                filterValueSelect.setAttributeNode(attribute);
                
                filterValueSelect.style.display = 'none';
            }
            else
            {
                if(filterColumn == 'events.unit_id,where')
                    document.getElementById("filter-value-label").innerHTML = 'Nama Unit';
                else
                    document.getElementById("filter-value-label").innerHTML = 'Status Pembayaran';
                
                var attribute = filterValueSelect.getAttributeNode("disabled");

                document.getElementById("filter-value-select").innerHTML = xmlhttp.responseText;

                if(attribute != null)
                    filterValueSelect.removeAttributeNode(attribute);
                
                filterValueSelect.style.display = 'inline';


                attribute = document.createAttribute("disabled");
                
                attribute.value = "disabled";
                
                filterValueInput.setAttributeNode(attribute);
                
                filterValueInput.style.display = 'none';
            }
        }
    };
    
    xmlhttp.open("GET", document.getElementById("controller-link").value + 'opsi_nilai_filter_pembayaran?filter_column=' + encodeURIComponent(filterColumn), true);
    xmlhttp.send();
}