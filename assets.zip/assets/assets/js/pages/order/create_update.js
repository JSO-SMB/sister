function calculateTotal()
{
    var total = document.getElementById("price-input").value.replace(/\./g,"") * document.getElementById("quantity-input").value;
    
    document.getElementById("total-input").value = total.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
}

setTimeout(calculateTotal(), 1);

function validateSubmission()
{
    var orderDate = new Date(document.getElementById("order-date-input").value);
    var estimatedCompletionDate = new Date(document.getElementById("estimated-completion-date-input").value);

    if(estimatedCompletionDate < orderDate)
    {
        alert('Tanggal estimasi jadi tidak boleh lebih awal dari hari ini!');

        return false;
    }
}

$(document).ready(function(){
    // Format mata uang.
    $( '.currency' ).mask('000.000.000.000.000.000', {reverse: true});
})