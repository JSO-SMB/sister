function getDynamicContent(pageNumber)
{
    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
            document.getElementById("card").innerHTML = xmlhttp.responseText;
    };
    
    url = document.getElementById("controller-link").value + "data/" + document.getElementById("role-id").value + "/" + pageNumber;
    
    if(document.getElementById("role-id").value < 2)
    {
        url = url + "/" + document.getElementById("view").value;

        /*if(typeof(document.getElementById("vendor-id-select")) != 'undefined' && document.getElementById("vendor-id-select") != null && document.getElementById("vendor-id-select").value > 0)
            url = url + "/" + encodeURI(document.getElementById("vendor-id-select").value);
        else */if(typeof(document.getElementById("unit-id-select")) != 'undefined' && document.getElementById("unit-id-select") != null && document.getElementById("unit-id-select").value > 0)
            url = url + "/" + encodeURI(document.getElementById("unit-id-select").value);
        else
            url = url + "/0";
        
        url = url + "/" + encodeURI(document.getElementById("division").value);
        
        if(typeof(document.getElementById("office-location-select")) != 'undefined' && document.getElementById("office-location-select") != null && document.getElementById("office-location-select").value != '')
            url = url + "/" + encodeURIComponent(document.getElementById("office-location-select").value);
        else
            url = url + "/" + encodeURIComponent(document.getElementById("office-location").value);
    }
    else
    {
        if(typeof(document.getElementById("order-date-input")) != 'undefined' && document.getElementById("order-date-input") != null && document.getElementById("order-date-input").value != '')
            url = url + "/pesanan/" + encodeURI(document.getElementById("order-date-input").value);
    }
    
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

setTimeout(getDynamicContent(1), 1);