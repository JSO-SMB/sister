function getResponse()
{
    if(document.getElementById("beginning-start-date-input").value == '' || document.getElementById("ending-start-date-input").value == '')
    {
        if(document.getElementById("beginning-start-date-input").value == '')
            alert('"Bulan & Tahun Awal" harus terisi dengan lengkap!');
        else
            alert('"Bulan & Tahun Akhir" harus terisi dengan lengkap!');
    }
    else
    {
        if (window.XMLHttpRequest)
        {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        }
        else
        {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        xmlhttp.onreadystatechange = function()
        {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
                document.getElementById("revenue-table").innerHTML = xmlhttp.responseText;
        };
        
        url = document.getElementById("controller-link").value + "data_pendapatan";
        //url = url + "?division=" + encodeURIComponent(document.getElementById("division").value);
        url = url + "?unit_id=" + document.getElementById("unit-id-select").value;
        url = url + "&project_status=" + encodeURIComponent(document.getElementById("project-status-select").value);
        url = url + "&beginning_start_date=" + encodeURIComponent(document.getElementById("beginning-start-date-input").value);
        url = url + "&ending_start_date=" + encodeURIComponent(document.getElementById("ending-start-date-input").value);
        
        /*url = url + "&ordering_column=";
        
        if(typeof(document.getElementById("ordering-column-select")) != 'undefined' && document.getElementById("ordering-column-select") != null)
            url = url + encodeURIComponent(document.getElementById("ordering-column-select").value);
        else
            url = url + encodeURIComponent("transaction_date");*/
        
        xmlhttp.open("GET", url, true);
        xmlhttp.send();
    }
}