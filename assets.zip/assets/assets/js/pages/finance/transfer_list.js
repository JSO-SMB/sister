function getDynamicContent(pageNumber)
{
    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
            document.getElementById("card").innerHTML = xmlhttp.responseText;
    };
    
    url = document.getElementById("controller-link").value + "data_pengajuan/" + pageNumber;
    url = url + "?division=" + encodeURIComponent(document.getElementById("division").value);
    url = url + "&filter_column=";
    
    if(typeof(document.getElementById("filter-column-select")) != 'undefined' && document.getElementById("filter-column-select") != null)
        url = url + encodeURIComponent(document.getElementById("filter-column-select").value);
    else
        url = url + encodeURIComponent("funding_submissions.status");
    
    url = url + "&filter_value=";
    
    if(typeof(document.getElementById("filter-value-select")) != 'undefined' && document.getElementById("filter-value-select") != null && document.getElementById("filter-value-select").value != '')
        url = url + encodeURIComponent(document.getElementById("filter-value-select").value);
    
    url = url + "&ordering_column=";
    
    if(typeof(document.getElementById("ordering-column-select")) != 'undefined' && document.getElementById("ordering-column-select") != null)
        url = url + encodeURIComponent(document.getElementById("ordering-column-select").value);
    else
        url = url + encodeURIComponent("payment_deadline");
    
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

setTimeout(getDynamicContent(1), 1);

function setFilterValue(filterColumn)
{
    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            if(filterColumn == 'funding_submissions.status')
                document.getElementById("filter-value-label").innerHTML = 'Status Pengajuan';
            else if(filterColumn == 'funding_submissions.utilizing_unit_id')
                document.getElementById("filter-value-label").innerHTML = 'Penggunaan untuk unit apa?';
            else
                document.getElementById("filter-value-label").innerHTML = 'Kode Pembiayaan';

            document.getElementById("filter-value-select").innerHTML = xmlhttp.responseText;
        }
    };
    
    xmlhttp.open("GET", document.getElementById("controller-link").value + 'opsi_nilai_filter_pengajuan/' + encodeURIComponent(filterColumn), true);
    xmlhttp.send();
}