function setBankAccount()
{
    var financeCode = document.getElementById("financing-code-select").value;

    if(financeCode == 'Bebkantor (Telp; Speedy; Listrik; Uang Sampah)')
    {
        document.getElementById("accountee-input").value = '';
        document.getElementById("bank-input").value = '';
        document.getElementById("account-number-input").value = '';
    }
    else
    {
        if (window.XMLHttpRequest)
        {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        }
        else
        {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        xmlhttp.onreadystatechange = function()
        {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
            {
                if(financeCode == 'Fee Agent' || financeCode == 'Lunch / Dinner' || financeCode == 'Operasional')
                {
                    document.getElementById("accountee-input").value = '';
                    document.getElementById("bank-input").value = '';
                    document.getElementById("account-number-input").value = '';
                }
                else
                {
                    account = xmlhttp.responseText.split(";");
                    
                    document.getElementById("accountee-input").value = account[0];
                    document.getElementById("bank-input").value = account[1];
                    document.getElementById("account-number-input").value = account[2];

                    if(financeCode == 'Honor Instruktur 1' || financeCode == 'Honor Instruktur 2' || financeCode == 'Sertifikasi / Kunjungan' || financeCode == 'Meeting Room' || financeCode == 'Akomodasi Peserta' || financeCode == 'Akomodasi Instruktur' || financeCode == 'Akomodasi Tim' || financeCode == 'Transportasi Peserta' || financeCode == 'Transportasi Instruktur' || financeCode == 'City Tour' || financeCode == 'Transportasi Tim' || financeCode == 'Modul' || financeCode == 'Dokumentasi' || financeCode == 'Spanduk' || financeCode == 'Sewa' || financeCode == 'Pengiriman' || financeCode == 'Fee Agent' || financeCode == 'Fee Driver' || financeCode == 'Fee CS' || financeCode == 'Lunch / Dinner' || financeCode == 'Operasional')
                        document.getElementById("nominal-input").setAttribute("data-max-value", account[3]);
                }
            }
        };

        var financeCode = document.getElementById("financing-code-select").value;

        if(financeCode == 'Honor Instruktur 1' || financeCode == 'Honor Instruktur 2' || financeCode == 'Sertifikasi / Kunjungan' || financeCode == 'Meeting Room' || financeCode == 'Akomodasi Peserta' || financeCode == 'Akomodasi Instruktur' || financeCode == 'Akomodasi Tim' || financeCode == 'Transportasi Peserta' || financeCode == 'Transportasi Instruktur' || financeCode == 'City Tour' || financeCode == 'Transportasi Tim' || financeCode == 'Modul' || financeCode == 'Dokumentasi' || financeCode == 'Spanduk' || financeCode == 'Sewa' || financeCode == 'Pengiriman' || financeCode == 'Fee Agent' || financeCode == 'Fee Driver' || financeCode == 'Fee CS' || financeCode == 'Lunch / Dinner' || financeCode == 'Operasional')
        {
            reference = 'event/' + document.getElementById("event-id-select").value;
            
            if(financeCode == 'Honor Instruktur 1')
                reference = reference + '?columns=' + encodeURIComponent('instructor_user_id as user_id, per_unit_instructor_a_honorarium as per_unit_budget, instructor_a_quantity as quantity');
            else if(financeCode == 'Honor Instruktur 2')
                reference = reference + '?columns=' + encodeURIComponent('per_unit_instructor_b_honorarium as per_unit_budget, instructor_b_quantity as quantity') + '&receiver_user_id=' + document.getElementById("receiver-user-id-select").value;
            else if(financeCode == 'Sertifikasi / Kunjungan')
                reference = reference + '?columns=' + encodeURIComponent('per_unit_certification_trip_budget as per_unit_budget, certification_trip_quantity as quantity') + '&receiver_user_id=' + document.getElementById("receiver-user-id-select").value;
            else if(financeCode == 'Meeting Room')
                reference = reference + '?columns=' + encodeURIComponent('hotel_vendor_id as vendor_id, per_unit_meeting_room_budget as per_unit_budget, meeting_room_quantity as quantity');
            else if(financeCode == 'Akomodasi Peserta')
                reference = reference + '?columns=' + encodeURIComponent('per_unit_participant_accommodation_budget as per_unit_budget, participant_accommodation_quantity as quantity') + '&vendor_id=' + document.getElementById("vendor-id-select").value;
            else if(financeCode == 'Akomodasi Instruktur')
                reference = reference + '?columns=' + encodeURIComponent('per_unit_instructor_accommodation_budget as per_unit_budget, instructor_accommodation_quantity as quantity') + '&vendor_id=' + document.getElementById("vendor-id-select").value;
            else if(financeCode == 'Akomodasi Tim')
                reference = reference + '?columns=' + encodeURIComponent('per_unit_team_accommodation_budget as per_unit_budget, team_accommodation_quantity as quantity') + '&vendor_id=' + document.getElementById("vendor-id-select").value;
            else if(financeCode == 'Transportasi Peserta')
                reference = reference + '?columns=' + encodeURIComponent('transportation_vendor_id as vendor_id, per_unit_participant_transportation_budget as per_unit_budget, participant_transportation_quantity as quantity');
            else if(financeCode == 'Transportasi Instruktur')
                reference = reference + '?columns=' + encodeURIComponent('per_unit_instructor_transportation_budget as per_unit_budget, instructor_transportation_quantity as quantity') + '&vendor_id=' + document.getElementById("vendor-id-select").value;
            else if(financeCode == 'Transportasi Tim')
                reference = reference + '?columns=' + encodeURIComponent('per_unit_team_transportation_budget as per_unit_budget, team_transportation_quantity as quantity') + '&vendor_id=' + document.getElementById("vendor-id-select").value;
            else if(financeCode == 'Modul')
                reference = reference + '?columns=' + encodeURIComponent('per_unit_module_budget as per_unit_budget, module_quantity as quantity') + '&vendor_id=' + document.getElementById("vendor-id-select").value;
            else if(financeCode == 'Dokumentasi')
                reference = reference + '?columns=' + encodeURIComponent('per_unit_documentation_budget as per_unit_budget, documentation_quantity as quantity') + '&vendor_id=' + document.getElementById("vendor-id-select").value;
            else if(financeCode == 'Spanduk')
                reference = reference + '?columns=' + encodeURIComponent('per_unit_banner_budget as per_unit_budget, banner_quantity as quantity') + '&vendor_id=' + document.getElementById("vendor-id-select").value;
            else if(financeCode == 'Sewa')
                reference = reference + '?columns=' + encodeURIComponent('per_unit_rental_cost as per_unit_budget, rental_quantity as quantity') + '&vendor_id=' + document.getElementById("vendor-id-select").value;
            else if(financeCode == 'Pengiriman')
                reference = reference + '?columns=' + encodeURIComponent('per_unit_delivery_budget as per_unit_budget, delivery_quantity as quantity') + '&vendor_id=' + document.getElementById("vendor-id-select").value;
            else if(financeCode == 'City Tour')
                reference = reference + '?columns=' + encodeURIComponent('per_unit_city_tour_budget as per_unit_budget, city_tour_quantity as quantity') + '&vendor_id=' + document.getElementById("vendor-id-select").value;
            else if(financeCode == 'Fee Agent')
                reference = reference + '?columns=' + encodeURIComponent('per_unit_agent_fee as per_unit_budget, agent_quantity as quantity');
            else if(financeCode == 'Fee Driver')
                reference = reference + '?columns=' + encodeURIComponent('driver_user_id as user_id, per_unit_driver_fee as per_unit_budget, driver_quantity as quantity');
            else if(financeCode == 'Fee CS')
                reference = reference + '?columns=' + encodeURIComponent('cs_user_id as user_id, per_unit_cs_fee as per_unit_budget, cs_quantity as quantity');
            else if(financeCode == 'Lunch / Dinner')
                reference = reference + '?columns=' + encodeURIComponent('per_unit_meal_budget as per_unit_budget, meal_quantity as quantity');
            else if(financeCode == 'Operasional')
                reference = reference + '?columns=' + encodeURIComponent('per_unit_operational_budget as per_unit_budget, operational_quantity as quantity');
        }
        else if(financeCode == 'Kit (DP; Pelunasan; Training kit)')
            reference = 'order/' + document.getElementById("order-id-select").value;
        //else if(financeCode == 'Logistik (Bensin Kendaraan Kantor; ATK)' || financeCode == 'Inventaris (Pengadaan Barang Inventaris Perusahaan)' || financeCode == 'Bebkantor (Telp; Speedy; Listrik; Uang Sampah)')
        //    reference = 'unit';
        else if(financeCode == 'IT (Hostdomain; Software)')
            reference = 'it/' + document.getElementById("it-data-id-select").value;
        else// if(financeCode == 'Outing (Gathering; Sayembara) & CSR (Sumbangan)')
            reference = 'user/' + document.getElementById("applicant-user-id").value;
        
        //alert(document.getElementById("controller-link").value + "rekening_bank/" + reference);
        
        xmlhttp.open("GET", document.getElementById("controller-link").value + "rekening_bank/" + reference, true);
        xmlhttp.send();
    }
}

function setUnitOptions()
{
    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            document.getElementById("utilizing-unit-id-select").innerHTML = xmlhttp.responseText;

            setBankAccount();
        }
    };

    var financeCode = document.getElementById("financing-code-select").value;

    if(financeCode == 'Kit (DP; Pelunasan; Training kit)')
        reference = 'order/' + document.getElementById("order-id-select").value;
    else if(financeCode == 'Logistik (Bensin Kendaraan Kantor; ATK)' || financeCode == 'Inventaris (Pengadaan Barang Inventaris Perusahaan)' || financeCode == 'Bebkantor (Telp; Speedy; Listrik; Uang Sampah)')
        reference = 'unit';
    else if((financeCode == 'IT (Hostdomain; Software)') || (financeCode == 'Pulsa (Go-Jek; Pulsa HP Kantor)'))
        reference = 'it/' + document.getElementById("it-data-id-select").value;
    else if(financeCode == 'Honor Instruktur 1' || financeCode == 'Honor Instruktur 2' || financeCode == 'Sertifikasi / Kunjungan' || financeCode == 'Meeting Room' || financeCode == 'Akomodasi Peserta' || financeCode == 'Akomodasi Instruktur' || financeCode == 'Akomodasi Tim' || financeCode == 'Transportasi Peserta' || financeCode == 'Transportasi Instruktur' || financeCode == 'City Tour' || financeCode == 'Transportasi Tim' || financeCode == 'Modul' || financeCode == 'Dokumentasi' || financeCode == 'Spanduk' || financeCode == 'Sewa' || financeCode == 'Pengiriman' || financeCode == 'Fee Agent' || financeCode == 'Fee Driver' || financeCode == 'Fee CS' || financeCode == 'Lunch / Dinner' || financeCode == 'Operasional' || financeCode == 'Outing (Gathering; Sayembara) & CSR (Sumbangan)')
        reference = 'user/' + document.getElementById("applicant-user-id").value;
    
    xmlhttp.open("GET", document.getElementById("controller-link").value + 'opsi_unit/' + reference, true);
    xmlhttp.send();
}

function setUtilizationData(financeCode)
{
    var elmnt = document.getElementById("other-details-textarea");
    
    if(financeCode == 'Logistik (Bensin Kendaraan Kantor; ATK)' || financeCode == 'Outing (Gathering; Sayembara) & CSR (Sumbangan)' || financeCode == 'Bebkantor (Telp; Speedy; Listrik; Uang Sampah)')
    {
        document.getElementById("utilization-data-div").style.display = 'none';
        document.getElementById("utilization-details-div").innerHTML = '';
        document.getElementById("bank-account-line").style.display = 'none';
        
        if(financeCode == 'Bebkantor (Telp; Speedy; Listrik; Uang Sampah)')
        {
            var attr = document.createAttribute("required");

            attr.value = "required";
            
            elmnt.setAttributeNode(attr);
        }
        else
        {
            var attr = elmnt.getAttributeNode("required");

            if(attr != null)
                elmnt.removeAttributeNode(attr);
        }

        setUnitOptions();
    }
    else
    {
        if (window.XMLHttpRequest)
        {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        }
        else
        {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        xmlhttp.onreadystatechange = function()
        {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
            {
                document.getElementById("utilization-details-div").innerHTML = xmlhttp.responseText;
                document.getElementById("bank-account-line").style.display = 'block';
                document.getElementById("utilization-data-div").style.display = 'block';

                var attr = elmnt.getAttributeNode("required");
                    
                if(attr != null)
                    elmnt.removeAttributeNode(attr);

                setUnitOptions();
            }
        };
        
        xmlhttp.open("GET", document.getElementById("controller-link").value + 'detail_penggunaan?kode=' + encodeURIComponent(financeCode), true);
        xmlhttp.send();
    }
}

$(document).ready(function(){
    // Format mata uang.
    $( '.currency' ).mask('000.000.000.000.000.000.000.000.000.000', {reverse: true});
})

function validateSubmission()
{
    var financeCode = document.getElementById("financing-code-select").value;

    if(financeCode == 'Honor Instruktur 1' || financeCode == 'Honor Instruktur 2' || financeCode == 'Sertifikasi / Kunjungan' || financeCode == 'Meeting Room' || financeCode == 'Akomodasi Peserta' || financeCode == 'Akomodasi Instruktur' || financeCode == 'Akomodasi Tim' || financeCode == 'Transportasi Peserta' || financeCode == 'Transportasi Instruktur' || financeCode == 'City Tour' || financeCode == 'Transportasi Tim' || financeCode == 'Modul' || financeCode == 'Dokumentasi' || financeCode == 'Spanduk' || financeCode == 'Sewa' || financeCode == 'Pengiriman' || financeCode == 'Fee Agent' || financeCode == 'Fee Driver' || financeCode == 'Fee CS' || financeCode == 'Lunch / Dinner' || financeCode == 'Operasional')
    {
        if(document.getElementById("nominal-input").value.replace(/\./g,"") > document.getElementById("nominal-input").getAttribute("data-max-value"))
        {
            alert('Jumlah pada field "Nominal" tidak boleh melebihi pada data event yakni ' + document.getElementById("nominal-input").getAttribute("data-max-value"));

            return false;
        }
    }
}

/*$('#finance-form').submit(function()
{
    //check whether browser fully supports all File API
    if(window.File && window.FileReader && window.FileList && window.Blob)
    {
        /*get the file size and file type from file input field
        var fsize = $('#user-picture')[0].files[0].size;
        
        if(fsize>2097152) //do something if file size more than 2 mb (2097152)
        {
            alert("File You selected is larger than 2 MB");
            
            return false;
        }
        
        //get the file size and file type from file input field
        var ftype = $('#proof-of-payments-input')[0].files[0].type;
        
        if(ftype != 'image/jpeg')
        {
            alert('File SPKWT harus dalam format pdf!');
            
            return false;
        }

        ftype = $('#transfer-letter-input')[0].files[0].type;
        
        if(ftype != 'application/pdf')
        {
            alert('File Surat Keterangan Mutasi harus dalam format pdf!');
            
            return false;
        }

        ftype = $('#resignation-letter-input')[0].files[0].type;
        
        if(ftype != 'application/pdf')
        {
            alert('File Surat Resign harus dalam format pdf!');
            
            return false;
        }

        ftype = $('#warning-letter-input')[0].files[0].type;
        
        if(ftype != 'application/pdf')
        {
            alert('File SP harus dalam format pdf!');
            
            return false;
        }
    }
    else
    {
        alert("Please upgrade your browser, because your current browser lacks some new features we need!");
    }
});*/