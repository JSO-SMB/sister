function getDynamicContent(pageNumber)
{
    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
            document.getElementById("card").innerHTML = xmlhttp.responseText;
    };
    
    url = document.getElementById("controller-link").value + "data/" + pageNumber + "/" + document.getElementById("status").value + "/" + document.getElementById("view").value + "/" + encodeURI(document.getElementById("division").value);
    
    if(document.getElementById("status").value == 'all')
    {
        if(typeof(document.getElementById("name-input")) != 'undefined' && document.getElementById("name-input") != null && document.getElementById("name-input").value != '')
            url = url + "/" + encodeURI(document.getElementById("name-input").value);
    }
    else
    {
        if(typeof(document.getElementById("unit-id-select")) != 'undefined' && document.getElementById("unit-id-select") != null)
            url = url + "/" + encodeURI(document.getElementById("unit-id-select").value);
        else
            url = url + "/0";
        
        if(typeof(document.getElementById("office-location-select")) != 'undefined' && document.getElementById("office-location-select") != null && document.getElementById("office-location-select").value != '')
            url = url + "/" + encodeURIComponent(document.getElementById("office-location-select").value);
        else
            url = url + "/" + encodeURIComponent(document.getElementById("office-location").value);
    }

    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

setTimeout(getDynamicContent(1), 1);