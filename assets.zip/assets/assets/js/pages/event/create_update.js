function setBudgetPlan()
{
    var turnover = document.getElementById("budget-plan-clients-number-input").value * document.getElementById("budget-plan-price-input").value.replace(/\./g,"");
    
    document.getElementById("operational-turnover-input").value = turnover.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById("budget-plan-turnover-input").value = document.getElementById("operational-turnover-input").value;
    
    var totalInstructorAHonorarium = document.getElementById('per-unit-instructor-a-honorarium-input').value.replace(/\./g,"") * document.getElementById('instructor-a-quantity-input').value;
    var totalInstructorBHonorarium = document.getElementById('per-unit-instructor-b-honorarium-input').value.replace(/\./g,"") * document.getElementById('instructor-b-quantity-input').value;
    var totalMeetingRoomBudget = document.getElementById('per-unit-meeting-room-budget-input').value.replace(/\./g,"") * document.getElementById('meeting-room-quantity-input').value;
    var totalParticipantAccommodationBudget = document.getElementById('per-unit-participant-accommodation-budget-input').value.replace(/\./g,"") * document.getElementById('participant-accommodation-quantity-input').value;
    var totalCertificationTripBudget = document.getElementById('per-unit-certification-trip-budget-input').value.replace(/\./g,"") * document.getElementById('certification-trip-quantity-input').value;
    var totalParticipantTransportationBudget = document.getElementById('per-unit-participant-transportation-budget-input').value.replace(/\./g,"") * document.getElementById('participant-transportation-quantity-input').value;
    var totalInstructorAccommodationBudget = document.getElementById('per-unit-instructor-accommodation-budget-input').value.replace(/\./g,"") * document.getElementById('instructor-accommodation-quantity-input').value;
    var totalInstructorTransportationBudget = document.getElementById('per-unit-instructor-transportation-budget-input').value.replace(/\./g,"") * document.getElementById('instructor-transportation-quantity-input').value;
    var totalModuleBudget = document.getElementById('per-unit-module-budget-input').value.replace(/\./g,"") * document.getElementById('module-quantity-input').value;
    var totalCertificateBudget = document.getElementById('per-unit-certificate-budget-input').value.replace(/\./g,"") * document.getElementById('certificate-quantity-input').value;
    var totalFolderBudget = document.getElementById('per-unit-folder-budget-input').value.replace(/\./g,"") * document.getElementById('folder-quantity-input').value;
    var totalEnvelopeBudget = document.getElementById('per-unit-envelope-budget-input').value.replace(/\./g,"") * document.getElementById('envelope-quantity-input').value;
    var totalExclusiveBagBudget = document.getElementById('per-unit-exclusive-bag-budget-input').value.replace(/\./g,"") * document.getElementById('exclusive-bag-quantity-input').value;
    var totalEconomicBagBudget = document.getElementById('per-unit-economic-bag-budget-input').value.replace(/\./g,"") * document.getElementById('economic-bag-quantity-input').value;
    var totalGiftBudget = document.getElementById('per-unit-gift-budget-input').value.replace(/\./g,"") * document.getElementById('gift-quantity-input').value;
    var totalBatikBudget = document.getElementById('per-unit-batik-budget-input').value.replace(/\./g,"") * document.getElementById('batik-quantity-input').value;
    var totalShirtBudget = document.getElementById('per-unit-shirt-budget-input').value.replace(/\./g,"") * document.getElementById('shirt-quantity-input').value;
    var totalPowerbankBudget = document.getElementById('per-unit-powerbank-budget-input').value.replace(/\./g,"") * document.getElementById('powerbank-quantity-input').value;
    var totalJacketBudget = document.getElementById('per-unit-jacket-budget-input').value.replace(/\./g,"") * document.getElementById('jacket-quantity-input').value;
    var totalPlacardBudget = document.getElementById('per-unit-placard-budget-input').value.replace(/\./g,"") * document.getElementById('placard-quantity-input').value;
    var totalSouvenirBudget = document.getElementById('per-unit-souvenir-budget-input').value.replace(/\./g,"") * document.getElementById('souvenir-quantity-input').value;
    var totalNameTagBudget = document.getElementById('per-unit-name-tag-budget-input').value.replace(/\./g,"") * document.getElementById('name-tag-quantity-input').value;
    var totalGoodyBagBudget = document.getElementById('per-unit-goody-bag-budget-input').value.replace(/\./g,"") * document.getElementById('goody-bag-quantity-input').value;
    var totalBallpointBudget = document.getElementById('per-unit-ballpoint-budget-input').value.replace(/\./g,"") * document.getElementById('ballpoint-quantity-input').value;
    var totalBlocknoteBudget = document.getElementById('per-unit-blocknote-budget-input').value.replace(/\./g,"") * document.getElementById('blocknote-quantity-input').value;
    var totalFlashdiskBudget = document.getElementById('per-unit-flashdisk-budget-input').value.replace(/\./g,"") * document.getElementById('flashdisk-quantity-input').value;
    var totalCdBudget = document.getElementById('per-unit-cd-budget-input').value.replace(/\./g,"") * document.getElementById('cd-quantity-input').value;
    var totalDocumentationBudget = document.getElementById('per-unit-documentation-budget-input').value.replace(/\./g,"") * document.getElementById('documentation-quantity-input').value;
    var totalBannerBudget = document.getElementById('per-unit-banner-budget-input').value.replace(/\./g,"") * document.getElementById('banner-quantity-input').value;
    var totalValueAddedTax = document.getElementById('per-unit-value-added-tax-input').value.replace(/\./g,"") * document.getElementById('value-added-tax-quantity-input').value;
    var totalAgentFee = document.getElementById('per-unit-agent-fee-input').value.replace(/\./g,"") * document.getElementById('agent-quantity-input').value;
    var totalDriverFee = document.getElementById('per-unit-driver-fee-input').value.replace(/\./g,"") * document.getElementById('driver-quantity-input').value;
    var totalCsFee = document.getElementById('per-unit-cs-fee-input').value.replace(/\./g,"") * document.getElementById('cs-quantity-input').value;
    var totalRentalCost = document.getElementById('per-unit-rental-cost-input').value.replace(/\./g,"") * document.getElementById('rental-quantity-input').value;
    var totalMealBudget = document.getElementById('per-unit-meal-budget-input').value.replace(/\./g,"") * document.getElementById('meal-quantity-input').value;
    var totalCityTourBudget = document.getElementById('per-unit-city-tour-budget-input').value.replace(/\./g,"") * document.getElementById('city-tour-quantity-input').value;
    var totalOperationalBudget = document.getElementById('per-unit-operational-budget-input').value.replace(/\./g,"") * document.getElementById('operational-quantity-input').value;
    var totalTeamAccommodationBudget = document.getElementById('per-unit-team-accommodation-budget-input').value.replace(/\./g,"") * document.getElementById('team-accommodation-quantity-input').value;
    var totalTeamTransportationBudget = document.getElementById('per-unit-team-transportation-budget-input').value.replace(/\./g,"") * document.getElementById('team-transportation-quantity-input').value;
    var totalIncomeTax = document.getElementById('per-unit-income-tax-input').value.replace(/\./g,"") * document.getElementById('income-tax-quantity-input').value;
    var totalDeliveryBudget = document.getElementById('per-unit-delivery-budget-input').value.replace(/\./g,"") * document.getElementById('delivery-quantity-input').value;

    document.getElementById('total-instructor-a-honorarium-input').value = totalInstructorAHonorarium.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-instructor-b-honorarium-input').value = totalInstructorBHonorarium.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-meeting-room-budget-input').value = totalMeetingRoomBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-participant-accommodation-budget-input').value = totalParticipantAccommodationBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-certification-trip-budget-input').value = totalCertificationTripBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-participant-transportation-budget-input').value = totalParticipantTransportationBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-instructor-accommodation-budget-input').value = totalInstructorAccommodationBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-instructor-transportation-budget-input').value = totalInstructorTransportationBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-module-budget-input').value = totalModuleBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-certificate-budget-input').value = totalCertificateBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-folder-budget-input').value = totalFolderBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-envelope-budget-input').value = totalEnvelopeBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-exclusive-bag-budget-input').value = totalExclusiveBagBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-economic-bag-budget-input').value = totalEconomicBagBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-gift-budget-input').value = totalGiftBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-batik-budget-input').value = totalBatikBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-shirt-budget-input').value = totalShirtBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-powerbank-budget-input').value = totalPowerbankBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-jacket-budget-input').value = totalJacketBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-placard-budget-input').value = totalPlacardBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-souvenir-budget-input').value = totalSouvenirBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-name-tag-budget-input').value = totalNameTagBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-goody-bag-budget-input').value = totalGoodyBagBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-ballpoint-budget-input').value = totalBallpointBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-blocknote-budget-input').value = totalBlocknoteBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-flashdisk-budget-input').value = totalFlashdiskBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-cd-budget-input').value = totalCdBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-documentation-budget-input').value = totalDocumentationBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-banner-budget-input').value = totalBannerBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-value-added-tax-input').value = totalValueAddedTax.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-agent-fee-input').value = totalAgentFee.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-driver-fee-input').value = totalDriverFee.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-cs-fee-input').value = totalCsFee.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-rental-cost-input').value = totalRentalCost.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-meal-budget-input').value = totalMealBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-city-tour-budget-input').value = totalCityTourBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-operational-budget-input').value = totalOperationalBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-team-accommodation-budget-input').value = totalTeamAccommodationBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-team-transportation-budget-input').value = totalTeamTransportationBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-income-tax-input').value = totalIncomeTax.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('total-delivery-budget-input').value = totalDeliveryBudget.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');

    var totalExpense = totalInstructorAHonorarium + totalInstructorBHonorarium + totalMeetingRoomBudget + totalParticipantAccommodationBudget + totalCertificationTripBudget + totalParticipantTransportationBudget + totalInstructorAccommodationBudget + totalInstructorTransportationBudget + totalModuleBudget + totalCertificateBudget + totalFolderBudget + totalEnvelopeBudget + totalExclusiveBagBudget + totalEconomicBagBudget + totalGiftBudget + totalBatikBudget + totalShirtBudget + totalPowerbankBudget + totalJacketBudget + totalPlacardBudget + totalSouvenirBudget + totalNameTagBudget + totalGoodyBagBudget + totalBallpointBudget + totalBlocknoteBudget + totalFlashdiskBudget + totalCdBudget + totalDocumentationBudget + totalBannerBudget + totalValueAddedTax + totalAgentFee + totalDriverFee + totalCsFee + totalRentalCost + totalMealBudget + totalCityTourBudget + totalOperationalBudget + totalTeamAccommodationBudget + totalTeamTransportationBudget + totalIncomeTax + totalDeliveryBudget;

    document.getElementById("total-expense-input").value = totalExpense.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');

    var profitNominal = turnover - totalExpense;

    document.getElementById("profit-nominal-input").value = profitNominal.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');

    var profitPercentage = profitNominal / turnover * 100;

    document.getElementById("profit-percentage-input").value = profitPercentage;
}

setTimeout(setBudgetPlan(), 1);

function setBudgetPlanPrice(price)
{
    document.getElementById("budget-plan-price-input").value = price;
    
    setBudgetPlan();
}

function setOperationalPrice(price)
{
    document.getElementById("operational-price-input").value = price;
    
    setBudgetPlan();
}

function setBudgetPlanClientsNumber(clientsNumber)
{
    document.getElementById("budget-plan-clients-number-input").value = clientsNumber;
    
    setBudgetPlan();
}

function setOperationalClientsNumber(clientsNumber)
{
    document.getElementById("operational-clients-number-input").value = clientsNumber;
    
    setBudgetPlan();
}

function hideShowInvoiceReceiptBudgetPlan(status)
{
    var element = [
        document.getElementById("document-recipient-input"),
        document.getElementById("company-phone-number-input"),
        document.getElementById("payment-plan-input"),
        document.getElementById("company-address-textarea"),
        document.getElementById('per-unit-instructor-a-honorarium-input'), document.getElementById('instructor-a-quantity-input'), 
        document.getElementById('per-unit-instructor-b-honorarium-input'), document.getElementById('instructor-b-quantity-input'), 
        document.getElementById('per-unit-meeting-room-budget-input'), document.getElementById('meeting-room-quantity-input'), 
        document.getElementById('per-unit-participant-accommodation-budget-input'), document.getElementById('participant-accommodation-quantity-input'), 
        document.getElementById('per-unit-certification-trip-budget-input'), document.getElementById('certification-trip-quantity-input'), 
        document.getElementById('per-unit-participant-transportation-budget-input'), document.getElementById('participant-transportation-quantity-input'), 
        document.getElementById('per-unit-instructor-accommodation-budget-input'), document.getElementById('instructor-accommodation-quantity-input'), 
        document.getElementById('per-unit-instructor-transportation-budget-input'), document.getElementById('instructor-transportation-quantity-input'), 
        document.getElementById('per-unit-module-budget-input'), document.getElementById('module-quantity-input'), 
        document.getElementById('per-unit-certificate-budget-input'), document.getElementById('certificate-quantity-input'), 
        document.getElementById('per-unit-folder-budget-input'), document.getElementById('folder-quantity-input'), 
        document.getElementById('per-unit-envelope-budget-input'), document.getElementById('envelope-quantity-input'), 
        document.getElementById('per-unit-exclusive-bag-budget-input'), document.getElementById('exclusive-bag-quantity-input'), 
        document.getElementById('per-unit-economic-bag-budget-input'), document.getElementById('economic-bag-quantity-input'), 
        document.getElementById('per-unit-gift-budget-input'), document.getElementById('gift-quantity-input'), 
        document.getElementById('per-unit-batik-budget-input'), document.getElementById('batik-quantity-input'), 
        document.getElementById('per-unit-shirt-budget-input'), document.getElementById('shirt-quantity-input'), 
        document.getElementById('per-unit-powerbank-budget-input'), document.getElementById('powerbank-quantity-input'), 
        document.getElementById('per-unit-jacket-budget-input'), document.getElementById('jacket-quantity-input'), 
        document.getElementById('per-unit-placard-budget-input'), document.getElementById('placard-quantity-input'), 
        document.getElementById('per-unit-souvenir-budget-input'), document.getElementById('souvenir-quantity-input'), 
        document.getElementById('per-unit-name-tag-budget-input'), document.getElementById('name-tag-quantity-input'), 
        document.getElementById('per-unit-goody-bag-budget-input'), document.getElementById('goody-bag-quantity-input'), 
        document.getElementById('per-unit-ballpoint-budget-input'), document.getElementById('ballpoint-quantity-input'), 
        document.getElementById('per-unit-blocknote-budget-input'), document.getElementById('blocknote-quantity-input'), 
        document.getElementById('per-unit-flashdisk-budget-input'), document.getElementById('flashdisk-quantity-input'), 
        document.getElementById('per-unit-cd-budget-input'), document.getElementById('cd-quantity-input'), 
        document.getElementById('per-unit-documentation-budget-input'), document.getElementById('documentation-quantity-input'), 
        document.getElementById('per-unit-banner-budget-input'), document.getElementById('banner-quantity-input'), 
        document.getElementById('per-unit-value-added-tax-input'), document.getElementById('value-added-tax-quantity-input'), 
        document.getElementById('per-unit-agent-fee-input'), document.getElementById('agent-quantity-input'), 
        document.getElementById('per-unit-driver-fee-input'), document.getElementById('driver-quantity-input'), 
        document.getElementById('per-unit-cs-fee-input'), document.getElementById('cs-quantity-input'), 
        document.getElementById('per-unit-rental-cost-input'), document.getElementById('rental-quantity-input'), 
        document.getElementById('per-unit-meal-budget-input'), document.getElementById('meal-quantity-input'), 
        document.getElementById('per-unit-city-tour-budget-input'), document.getElementById('city-tour-quantity-input'), 
        document.getElementById('per-unit-operational-budget-input'), document.getElementById('operational-quantity-input'), 
        document.getElementById('per-unit-team-accommodation-budget-input'), document.getElementById('team-accommodation-quantity-input'), 
        document.getElementById('per-unit-team-transportation-budget-input'), document.getElementById('team-transportation-quantity-input'), 
        document.getElementById('per-unit-income-tax-input'), document.getElementById('income-tax-quantity-input'), 
        document.getElementById('per-unit-delivery-budget-input'), document.getElementById('delivery-quantity-input')
    ];
    
    if(status == 'Fixed')
    {
        for(elementCounter = 0; elementCounter < 86; elementCounter++)
        {
            elmnt = element[elementCounter];
            attr = document.createAttribute("required");
            
            attr.value = "required";
            
            elmnt.setAttributeNode(attr);
        }

        document.getElementById("marketing-website-line").style.display = 'block';
        document.getElementById("invoice-receipt-div").style.display = 'block';
        document.getElementById("invoice-receipt-line").style.display = 'block';
        document.getElementById("budget-plan-div").style.display = 'block';
        document.getElementById("budget-plan-line").style.display = 'block';
        document.getElementById("division-approval-div").style.display = 'block';
    }   
    else
    {
        for(elementCounter = 0; elementCounter < 86; elementCounter++)
        {
            elmnt = element[elementCounter];
            attr = elmnt.getAttributeNode("required");
            
            elmnt.removeAttributeNode(attr);
        }
        
        document.getElementById("marketing-website-line").style.display = 'none';
        document.getElementById("invoice-receipt-div").style.display = 'none';
        document.getElementById("invoice-receipt-line").style.display = 'none';
        document.getElementById("budget-plan-div").style.display = 'none';
        document.getElementById("budget-plan-line").style.display = 'none';
        document.getElementById("division-approval-div").style.display = 'none';
    }
}

function hideShowSourceDetail(setSourceDetailLink, source)
{
    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            document.getElementById("source-detail-div").innerHTML = xmlhttp.responseText;
            
            if(source == 'Website' || source == 'Referensi')
            {
                document.getElementById("source-detail-div").style.display = 'block';
                document.getElementById("source-detail-input").focus();
            }   
            else
                document.getElementById("source-detail-div").style.display = 'none';
        }
    };
    
    xmlhttp.open("GET", setSourceDetailLink + encodeURI(source), true);
    xmlhttp.send();
}

function validateSubmission()
{
    var proposalDate = new Date(document.getElementById("proposal-date-input").value);
    var startDate = new Date(document.getElementById("start-date-input").value);
    var endDate = new Date(document.getElementById("end-date-input").value);

    if(proposalDate >= startDate)
    {
        alert('Tanggal proposal harus lebih awal dari tanggal mulai pelatihan!');

        return false;
    }
    else if(startDate > endDate)
    {
        alert('Tanggal mulai harus lebih awal dari tanggal berakhir pelatihan!');

        return false;
    }
    else if(document.getElementById("status-select").value == 'Almost' || document.getElementById("status-select").value == 'Fixed')
    {
        if(confirm('Data Operasional & Data RAB akan dikirimkan ke divisi Logistik & Finance, jadi pastikan seluruh data yang diisikan sudah betul.\n\nJika Anda yakin seluruh data sudah betul, silakan tekan tombol "OK" untuk melanjutkan. Tetapi jika Anda ingin memastikan kembali data yang telah Anda masukkan, silakan tekan tombol "Cancel".') == false)
            return false;
    }
}

$(document).ready(function(){
    // Format mata uang.
    $( '.currency' ).mask('000.000.000.000.000.000', {reverse: true});
})