function getDynamicContent(pageNumber)
{
    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
            document.getElementById("card").innerHTML = xmlhttp.responseText;
    };
    
    url = document.getElementById("controller-link").value + "data_keuangan_kegiatan/" + pageNumber;
    //url = url + "?division=" + encodeURIComponent(document.getElementById("division").value);
    url = url + "?unit_id=";
    
    if(typeof(document.getElementById("unit-id-select")) != 'undefined' && document.getElementById("unit-id-select") != null && document.getElementById("unit-id-select").value != '')
        url = url + document.getElementById("unit-id-select").value;
    
    url = url + "&marketing_user_id=";
    
    if(typeof(document.getElementById("marketing-user-id-select")) != 'undefined' && document.getElementById("marketing-user-id-select") != null && document.getElementById("marketing-user-id-select").value != '')
        url = url + document.getElementById("marketing-user-id-select").value;
    else if(typeof(document.getElementById("marketing-user-id-input")) != 'undefined' && document.getElementById("marketing-user-id-input") != null && document.getElementById("marketing-user-id-input").value != '')
        url = url + document.getElementById("marketing-user-id-input").value;
    
    url = url + "&manager_user_id=";
    
    if(typeof(document.getElementById("manager-user-id-select")) != 'undefined' && document.getElementById("manager-user-id-select") != null && document.getElementById("manager-user-id-select").value != '')
        url = url + document.getElementById("manager-user-id-select").value;
    else if(typeof(document.getElementById("manager-user-id-input")) != 'undefined' && document.getElementById("manager-user-id-input") != null && document.getElementById("manager-user-id-input").value != '')
        url = url + document.getElementById("manager-user-id-input").value;
    
    /*url = url + "&project_status=";
    
    if(typeof(document.getElementById("project-status-select")) != 'undefined' && document.getElementById("project-status-select") != null && document.getElementById("project-status-select").value != '')
        url = url + document.getElementById("project-status-select").value;*/
    
    url = url + "&start_date=";
    
    if(typeof(document.getElementById("start-date-input")) != 'undefined' && document.getElementById("start-date-input") != null && document.getElementById("start-date-input").value != '')
        url = url + encodeURIComponent(document.getElementById("start-date-input").value);
    
    url = url + "&ordering=";
    
    if(typeof(document.getElementById("ordering-select")) != 'undefined' && document.getElementById("ordering-select") != null)
        url = url + encodeURIComponent(document.getElementById("ordering-select").value);
    else
        url = url + 'DESC';
    
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

setTimeout(getDynamicContent(1), 1);

function setStaffField(unitId)
{
    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            document.getElementById("marketing-user-id-select").innerHTML = xmlhttp.responseText;

            setManagerField(unitId);
        }
    };
    
    xmlhttp.open("GET", document.getElementById("controller-link").value + 'staf_marketing?unit_id=' + unitId, true);
    xmlhttp.send();
}

function setManagerField(unitId)
{
    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            document.getElementById("manager-user-id-select").innerHTML = xmlhttp.responseText;
        }
    };
    
    xmlhttp.open("GET", document.getElementById("controller-link").value + 'manajer_marketing?unit_id=' + unitId, true);
    xmlhttp.send();
}