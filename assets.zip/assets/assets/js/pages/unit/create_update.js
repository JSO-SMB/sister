function resetShareholders(url)
{
    var elementCounter;
    var attr;
    var directorDocumentsInput = document.getElementsByClassName("director-documents-input");

    if(document.getElementById("deed-of-amendment-a-input").files.length > 0 || document.getElementById("deed-of-amendment-b-input").files.length > 0 || document.getElementById("deed-of-amendment-c-input").files.length > 0 || document.getElementById("deed-of-amendment-d-input").files.length > 0)
    {
        var shareholdersNameInput = document.getElementsByClassName("shareholders-name-input");
        
        for(elementCounter = 0; elementCounter < shareholdersNameInput.length; elementCounter++)
        {
            shareholdersNameInput[elementCounter].value = '';
        }

        if(window.XMLHttpRequest)
        {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        }
        else
        {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        xmlhttp.onreadystatechange = function()
        {
            if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
            {}
        };
        
        xmlhttp.open("GET", url + '/' + document.getElementById("unit-id").value, true);
        xmlhttp.send();
        
        var shareholdersDocumentsInput = document.getElementsByClassName("shareholders-documents-input");
        
        for(elementCounter = 0; elementCounter < shareholdersDocumentsInput.length; elementCounter++)
        {
            shareholdersDocumentsInput[elementCounter].style.display = "none";
        }
        
        for(elementCounter = 0; elementCounter < directorDocumentsInput.length; elementCounter++)
        {
            elmnt = directorDocumentsInput[elementCounter];
            
            attr = document.createAttribute("required");
            
            attr.value = "required";
            
            elmnt.setAttributeNode(attr);
        }
    }
    else
    {
        for(elementCounter = 0; elementCounter < directorDocumentsInput.length; elementCounter++)
        {
            elmnt = directorDocumentsInput[elementCounter];
            
            attr = elmnt.getAttributeNode("required");
            
            elmnt.removeAttributeNode(attr);
        }
    }
}

$('#unit-form').submit(function()
{
    //check whether browser fully supports all File API
    if(window.File && window.FileReader && window.FileList && window.Blob)
    {
        /*get the file size and file type from file input field
        var fsize = $('#user-picture')[0].files[0].size;
        
        if(fsize>2097152) //do something if file size more than 2 mb (2097152)
        {
            alert("File You selected is larger than 2 MB");
            
            return false;
        }*/

        var input = [
            '#director-id-card-input',
            '#director-tax-id-number-card-input',
            '#commissioner-1-id-card-input',
            '#commissioner-1-tax-id-number-card-input',
            '#commissioner-2-id-card-input',
            '#commissioner-2-tax-id-number-card-input',
            '#commissioner-3-id-card-input',
            '#commissioner-3-tax-id-number-card-input',
            '#commissioner-4-id-card-input',
            '#commissioner-4-tax-id-number-card-input',
            '#commissioner-5-id-card-input',
            '#commissioner-5-tax-id-number-card-input',
            '#deed-of-incorporation-input',
            '#deed-of-amendment-a-input',
            '#deed-of-amendment-b-input',
            '#deed-of-amendment-c-input',
            '#deed-of-amendment-d-input',
            '#certificate-of-company-registration-input',
            '#business-license-input',
            '#domicile-of-business-input',
            '#hinder-ordonantie-input',
            '#brand-certificate-input',
            '#certificate-of-competence-input',
            '#health-social-security-administrator-input',
            '#institution-of-social-security-employment-input',
            '#willingness-obedient-letter-input',
            '#virtual-office-statement-input',
            '#statement-of-environmental-management-input',
            '#building-permit-input',
            '#tax-id-number-card-input',
            '#certification-of-registration-input',
            '#taxable-employer-confirmation-letter-input',
            '#saving-book-a-input',
            '#saving-book-b-input',
            '#saving-book-c-input',
            '#saving-book-d-input',
            '#saving-book-e-input',
            '#proposal-format-input',
            '#registration-form-format-input',
            '#confirmation-letter-example-input',
            '#company-profile-input',
            '#invoice-format-input',
            '#receipt-format-input',
            '#certificate-of-non-taxable-company-format-input',
            '#logo-input',
            '#masthead-format-input',
            '#attendance-list-design-input',
            '#training-evaluation-form-design-input',
            '#instructor-evaluation-form-design-input'
        ];
        var label = [
            'KTP Persero Aktif/Direktur',
            'NPWP Persero Aktif/Direktur',
            'KTP Persero Pasif/Komisaris 1',
            'NPWP Persero Pasif/Komisaris 1',
            'KTP Persero Pasif/Komisaris 2',
            'NPWP Persero Pasif/Komisaris 2',
            'KTP Persero Pasif/Komisaris 3',
            'NPWP Persero Pasif/Komisaris 3',
            'KTP Persero Pasif/Komisaris 4',
            'NPWP Persero Pasif/Komisaris 4',
            'KTP Persero Pasif/Komisaris 5',
            'NPWP Persero Pasif/Komisaris 5',
            'Dokumen Akta Pendirian',
            'Dokumen Akta Perubahan',
            'Dokumen Akta Perubahan',
            'Dokumen Akta Perubahan',
            'Dokumen Akta Perubahan',
            'Dokumen TDP/NIB',
            'Dokumen SIUP',
            'Dokumen Surat Domisili Usaha',
            'Dokumen HO',
            'Sertifikat Dagang',
            'Sertifikat Kompetensi',
            'BPJS Kesehatan',
            'BPJS Ketenagakerjaan',
            'Surat Kesediaan Patuh',
            'Surat Virtual Office',
            'SPPL',
            'IMB',
            'Dokumen NPWP',
            'Dokumen SKT Pajak',
            'Dokumen Surat Pengukuhan PKP',
            'Scan Buku Tabungan 1',
            'Scan Buku Tabungan 2',
            'Scan Buku Tabungan 3',
            'Scan Buku Tabungan 4',
            'Scan Buku Tabungan 5',
            'Contoh Format Proposal',
            'Contoh Format Form Registrasi',
            'Contoh Confirmation Letter',
            'Company Profile',
            'Contoh Format Invoice',
            'Contoh Format Kuitansi',
            'Contoh Format Surat Keterangan Non PKP',
            'Logo Perusahaan',
            'Format Header Kop Surat',
            'Desain Daftar Hadir / Absensi',
            'Desain Form Evaluasi Training',
            'Desain Form Evaluasi Instruktur'
        ];
    
        for(labelCounter = 0; labelCounter < 49; labelCounter++)
        {
            if((labelCounter > 11 && labelCounter < 17) || labelCounter == 28 || labelCounter == 40)
                var type = [
                    'application/pdf',
                    'application/pdf',
                    'application/pdf',
                    'pdf'
                ];
            else if((labelCounter > 36 && labelCounter < 40) || (labelCounter > 40 && labelCounter < 44) || labelCounter > 45)
                var type = [
                    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                    'application/msword',
                    'application/msword',
                    'docx/doc'
                ];
            else
                var type = [
                    'image/jpeg',
                    'image/png',
                    'application/pdf',
                    'jpeg/png/pdf'
                ];
            
            if($(input[labelCounter])[0].files.length > 0)
            {
                if($(input[labelCounter])[0].files[0].type != type[0] && $(input[labelCounter])[0].files[0].type != type[1] && $(input[labelCounter])[0].files[0].type != type[2])
                {
                    alert(label[labelCounter] + ' harus dalam format ' + type[3]);
                    
                    event.preventDefault();
                }
            }
        }
    }
    else
    {
        alert("Please upgrade your browser, because your current browser lacks some new features we need!");
    }
});