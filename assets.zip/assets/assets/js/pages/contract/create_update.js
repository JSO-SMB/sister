function checkReferenceNumber(referenceNumberCheckLink, initialReferenceNumber, referenceNumber)
{
    if(referenceNumber != '' && initialReferenceNumber != referenceNumber)
    {
        if (window.XMLHttpRequest)
        {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        }
        else
        {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        xmlhttp.onreadystatechange = function()
        {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
            {
                if(xmlhttp.responseText == 0)
                    document.getElementById("reference-number-help").style.display = "none";
                else
                {
                    document.getElementById("reference-number-help").style.color = "red";
                    document.getElementById("reference-number-help").style.display = "inline";
                    
                    document.getElementById("reference-number-input").focus();
                }
            }
        };
        
        xmlhttp.open("GET", referenceNumberCheckLink + encodeURIComponent(referenceNumber), true);
        xmlhttp.send();
    }
    else
        document.getElementById("reference-number-help").style.display = "none";
}

function getValidityPeriod()
{
    var effectiveDate = new Date(document.getElementById("effective-date-input").value);
    var expiryDate = new Date(document.getElementById("expiry-date-input").value);
    var validityPeriod = 12 * (expiryDate.getFullYear() - effectiveDate.getFullYear());
    validityPeriod = validityPeriod + (expiryDate.getMonth() - effectiveDate.getMonth());
    
    document.getElementById("validity-period-input").value = validityPeriod;
}

function enableDisableTransferField()
{
    if(document.getElementById("transfer-letter-input").files.length == 0)
    {
        var elmnt = document.getElementById("division-select");
        var attr = document.createAttribute("disabled");
        
        attr.value = "disabled";
        
        elmnt.setAttributeNode(attr);

        elmnt = document.getElementById("information-textarea");
        attr = elmnt.getAttributeNode("required");
        
        elmnt.removeAttributeNode(attr);

        attr = document.createAttribute("readonly");
        
        attr.value = "readonly";
        
        elmnt.setAttributeNode(attr);
    }
    else
    {
        var elmnt = document.getElementById("division-select");
        var attr = elmnt.getAttributeNode("disabled");
        
        elmnt.removeAttributeNode(attr);

        elmnt = document.getElementById("information-textarea");
        attr = elmnt.getAttributeNode("readonly");
        
        elmnt.removeAttributeNode(attr);
        
        attr = document.createAttribute("required");

        attr.value = "required";
        
        elmnt.setAttributeNode(attr);
    }
}

function enableDisableResignationField()
{
    if(document.getElementById("resignation-letter-input").files.length == 0)
    {
        var elmnt = document.getElementById("receipt-date-input");
        var attr = document.createAttribute("disabled");
        
        attr.value = "disabled";
        
        elmnt.setAttributeNode(attr);

        elmnt = document.getElementById("dismissal-date-input");
        attr = document.createAttribute("disabled");
        
        attr.value = "disabled";
        
        elmnt.setAttributeNode(attr);

        elmnt = document.getElementById("reason-textarea");
        attr = elmnt.getAttributeNode("required");
        
        elmnt.removeAttributeNode(attr);

        attr = document.createAttribute("readonly");
        
        attr.value = "readonly";
        
        elmnt.setAttributeNode(attr);
    }
    else
    {
        var elmnt = document.getElementById("receipt-date-input");
        var attr = elmnt.getAttributeNode("disabled");
        
        elmnt.removeAttributeNode(attr);
        
        elmnt = document.getElementById("dismissal-date-input");
        attr = elmnt.getAttributeNode("disabled");
        
        elmnt.removeAttributeNode(attr);

        elmnt = document.getElementById("reason-textarea");
        attr = elmnt.getAttributeNode("readonly");
        
        elmnt.removeAttributeNode(attr);
        
        attr = document.createAttribute("required");

        attr.value = "required";
        
        elmnt.setAttributeNode(attr);
    }
}

function enableDisableWarningLetterField()
{
    if(document.getElementById("warning-letter-input").files.length == 0)
    {
        var elmnt = document.getElementById("letter-type-select");
        attr = document.createAttribute("disabled");
        
        attr.value = "disabled";
        
        elmnt.setAttributeNode(attr);

        var elmnt = document.getElementById("date-of-issue-input");
        attr = document.createAttribute("disabled");
        
        attr.value = "disabled";
        
        elmnt.setAttributeNode(attr);

        elmnt = document.getElementById("cause-textarea");
        attr = elmnt.getAttributeNode("required");
        
        elmnt.removeAttributeNode(attr);

        attr = document.createAttribute("readonly");
        
        attr.value = "readonly";
        
        elmnt.setAttributeNode(attr);
    }
    else
    {
        var elmnt = document.getElementById("letter-type-select");
        attr = elmnt.getAttributeNode("disabled");
        
        elmnt.removeAttributeNode(attr);

        var elmnt = document.getElementById("date-of-issue-input");
        attr = elmnt.getAttributeNode("disabled");
        
        elmnt.removeAttributeNode(attr);

        elmnt = document.getElementById("cause-textarea");
        attr = elmnt.getAttributeNode("readonly");
        
        elmnt.removeAttributeNode(attr);
        
        attr = document.createAttribute("required");

        attr.value = "required";
        
        elmnt.setAttributeNode(attr);
    }
}

$('#contract-form').submit(function()
{
    //check whether browser fully supports all File API
    if(window.File && window.FileReader && window.FileList && window.Blob)
    {
        /*get the file size and file type from file input field
        var fsize = $('#user-picture')[0].files[0].size;
        
        if(fsize>2097152) //do something if file size more than 2 mb (2097152)
        {
            alert("File You selected is larger than 2 MB");
            
            return false;
        }*/
        
        //get the file size and file type from file input field
        var ftype = $('#specific-period-work-agreement-input')[0].files[0].type;
        
        if(ftype != 'application/pdf')
        {
            alert('File SPKWT harus dalam format pdf!');
            
            return false;
        }

        ftype = $('#transfer-letter-input')[0].files[0].type;
        
        if(ftype != 'application/pdf')
        {
            alert('File Surat Keterangan Mutasi harus dalam format pdf!');
            
            return false;
        }

        ftype = $('#resignation-letter-input')[0].files[0].type;
        
        if(ftype != 'application/pdf')
        {
            alert('File Surat Resign harus dalam format pdf!');
            
            return false;
        }

        ftype = $('#warning-letter-input')[0].files[0].type;
        
        if(ftype != 'application/pdf')
        {
            alert('File SP harus dalam format pdf!');
            
            return false;
        }
    }
    else
    {
        alert("Please upgrade your browser, because your current browser lacks some new features we need!");
    }
});