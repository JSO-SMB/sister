function getDynamicContent(pageNumber)
{
    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
            document.getElementById("card").innerHTML = xmlhttp.responseText;
        
        $('.js-basic-single').select2({
            width: 'resolve'
        });

        $('.currency').mask('000.000.000.000.000.000.000.000.000.000', {reverse: true});
    };
    
    url = document.getElementById("controller-link").value + "data_transaksi/" + pageNumber;
    //url = url + "?division=" + encodeURIComponent(document.getElementById("division").value);
    url = url + "?unit_id=";
    
    if(typeof(document.getElementById("unit-id-select")) != 'undefined' && document.getElementById("unit-id-select") != null && document.getElementById("unit-id-select").value != '')
        url = url + document.getElementById("unit-id-select").value;
    
    url = url + "&debt_reference_code=";
    
    if(typeof(document.getElementById("debt-reference-code-select")) != 'undefined' && document.getElementById("debt-reference-code-select") != null && document.getElementById("debt-reference-code-select").value != '')
        url = url + encodeURIComponent(document.getElementById("debt-reference-code-select").value);
    
    url = url + "&credit_reference_code=";
    
    if(typeof(document.getElementById("credit-reference-code-select")) != 'undefined' && document.getElementById("credit-reference-code-select") != null && document.getElementById("credit-reference-code-select").value != '')
        url = url + encodeURIComponent(document.getElementById("credit-reference-code-select").value);
    
    url = url + "&submission_period_parameter=";
    
    if(typeof(document.getElementById("submission-period-parameter-select")) != 'undefined' && document.getElementById("submission-period-parameter-select") != null)
        submission_period_parameter = document.getElementById("submission-period-parameter-select").value;
    else
        submission_period_parameter = 'submission_date,where';
    
    url = url + encodeURIComponent(submission_period_parameter);
    
    url = url + "&submission_period=";
    
    if(submission_period_parameter == 'YEAR(submission_date),where')
    {
        if(typeof(document.getElementById("submission-period-select")) != 'undefined' && document.getElementById("submission-period-select") != null && document.getElementById("submission-period-select").value != '')
            url = url + document.getElementById("submission-period-select").value;
    }
    else
    {
        if(typeof(document.getElementById("submission-period-input")) != 'undefined' && document.getElementById("submission-period-input") != null && document.getElementById("submission-period-input").value != '')
            url = url + encodeURIComponent(document.getElementById("submission-period-input").value);
    }
    
    url = url + "&transaction_period_parameter=";
    
    if(typeof(document.getElementById("transaction-period-parameter-select")) != 'undefined' && document.getElementById("transaction-period-parameter-select") != null)
        transaction_period_parameter = document.getElementById("transaction-period-parameter-select").value;
    else
        transaction_period_parameter = 'transaction_date,where';
    
    url = url + encodeURIComponent(transaction_period_parameter);
    
    url = url + "&transaction_period=";
    
    if(transaction_period_parameter == 'YEAR(transaction_date),where')
    {
        if(typeof(document.getElementById("transaction-period-select")) != 'undefined' && document.getElementById("transaction-period-select") != null && document.getElementById("transaction-period-select").value != '')
            url = url + document.getElementById("transaction-period-select").value;
    }
    else
    {
        if(typeof(document.getElementById("transaction-period-input")) != 'undefined' && document.getElementById("transaction-period-input") != null && document.getElementById("transaction-period-input").value != '')
            url = url + encodeURIComponent(document.getElementById("transaction-period-input").value);
    }
    
    url = url + "&ordering_column=";
    
    if(typeof(document.getElementById("ordering-column-select")) != 'undefined' && document.getElementById("ordering-column-select") != null)
        url = url + encodeURIComponent(document.getElementById("ordering-column-select").value);
    else
        url = url + encodeURIComponent("transaction_date");
    
    //document.getElementById('card').innerHTML = url;
    
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

setTimeout(getDynamicContent(1), 1);

function setSubmissionPeriodField(submissionPeriodParameter)
{
    var submissionPeriodLabel = document.getElementById("submission-period-label");
    var submissionPeriodSelect = document.getElementById('submission-period-select');
    var submissionPeriodInput = document.getElementById('submission-period-input');
    
    if(submissionPeriodParameter == 'YEAR(submission_date),where')
    {
        submissionPeriodLabel.innerHTML = 'Tahun';

        var options = '<option value="">Semua Tahun</option>';

        var option_counter;
        
        for(option_counter = new Date().getFullYear(); option_counter >= 2020; option_counter--)
        {
            options = options + '<option value="' + option_counter + '">' + option_counter + '</option>';
        }

        submissionPeriodSelect.innerHTML = options;
        
        var attribute = submissionPeriodSelect.getAttributeNode("disabled");

        if(attribute != null)
            submissionPeriodSelect.removeAttributeNode(attribute);
        
        submissionPeriodSelect.style.display = 'inline';


        attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        submissionPeriodInput.setAttributeNode(attribute);
        
        submissionPeriodInput.style.display = 'none';
    }
    else
    {
        if(submissionPeriodParameter == 'submission_date,where')
        {
            submissionPeriodLabel.innerHTML = 'Tanggal';
            submissionPeriodInput.type = 'date';
        }
        else
        {
            submissionPeriodLabel.innerHTML = 'Bulan & Tahun';
            submissionPeriodInput.type = 'month';
        }
        
        var attribute = submissionPeriodInput.getAttributeNode("disabled");

        if(attribute != null)
            submissionPeriodInput.removeAttributeNode(attribute);
        
        submissionPeriodInput.style.display = 'inline';


        attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        submissionPeriodSelect.setAttributeNode(attribute);
        
        submissionPeriodSelect.style.display = 'none';
    }
}

function setTransactionPeriodField(transactionPeriodParameter)
{
    var transactionPeriodLabel = document.getElementById("transaction-period-label");
    var transactionPeriodSelect = document.getElementById('transaction-period-select');
    var transactionPeriodInput = document.getElementById('transaction-period-input');
    
    if(transactionPeriodParameter == 'YEAR(transaction_date),where')
    {
        transactionPeriodLabel.innerHTML = 'Tahun';

        var options = '<option value="">Semua Tahun</option>';

        var option_counter;
        
        for(option_counter = new Date().getFullYear(); option_counter >= 2020; option_counter--)
        {
            options = options + '<option value="' + option_counter + '">' + option_counter + '</option>';
        }

        transactionPeriodSelect.innerHTML = options;
        
        var attribute = transactionPeriodSelect.getAttributeNode("disabled");

        if(attribute != null)
            transactionPeriodSelect.removeAttributeNode(attribute);
        
        transactionPeriodSelect.style.display = 'inline';


        attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        transactionPeriodInput.setAttributeNode(attribute);
        
        transactionPeriodInput.style.display = 'none';
    }
    else
    {
        if(transactionPeriodParameter == 'transaction_date,where')
        {
            transactionPeriodLabel.innerHTML = 'Tanggal';
            transactionPeriodInput.type = 'date';
        }
        else
        {
            transactionPeriodLabel.innerHTML = 'Bulan & Tahun';
            transactionPeriodInput.type = 'month';
        }
        
        var attribute = transactionPeriodInput.getAttributeNode("disabled");

        if(attribute != null)
            transactionPeriodInput.removeAttributeNode(attribute);
        
        transactionPeriodInput.style.display = 'inline';


        attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        transactionPeriodSelect.setAttributeNode(attribute);
        
        transactionPeriodSelect.style.display = 'none';
    }
}

function setTransactionCodeField(transactionType)
{
    var eventIdSelect = document.getElementById('event_id[' + transactionType.getAttribute("data-transaction-id") + ']');
    var fundingSubmissionIdSelect = document.getElementById('funding_submission_id[' + transactionType.getAttribute("data-transaction-id") + ']');
    var transactionCodeInput = document.getElementById('transaction_code[' + transactionType.getAttribute("data-transaction-id") + ']');

    if(transactionType.value == 'IN: Event')
    {
        var attribute = eventIdSelect.getAttributeNode("disabled");

        if(attribute != null)
            eventIdSelect.removeAttributeNode(attribute);
        
        eventIdSelect.style.display = 'inline';

        document.getElementById('event-funding-submission-detail[' + transactionType.getAttribute("data-transaction-id") + ']').innerHTML = '<a href="' + document.getElementById('base-url').value + 'kegiatan/tambah_ubah/' + eventIdSelect.value + '" target="_blank">Detail</a>';


        attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        fundingSubmissionIdSelect.setAttributeNode(attribute);
        
        fundingSubmissionIdSelect.style.display = 'none';


        attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        transactionCodeInput.setAttributeNode(attribute);

        transactionCodeInput.style.display = 'none';
    }
    else if(transactionType.value == 'OUT: Pengajuan')
    {
        var attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        eventIdSelect.setAttributeNode(attribute);
        
        eventIdSelect.style.display = 'none';


        attribute = fundingSubmissionIdSelect.getAttributeNode("disabled");

        if(attribute != null)
            fundingSubmissionIdSelect.removeAttributeNode(attribute);
        
        fundingSubmissionIdSelect.style.display = 'inline';

        document.getElementById('event-funding-submission-detail[' + transactionType.getAttribute("data-transaction-id") + ']').innerHTML = '<a href="' + document.getElementById('base-url').value + 'keuangan/pengajuan/' + fundingSubmissionIdSelect.value + '" target="_blank">Detail</a>';


        attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        transactionCodeInput.setAttributeNode(attribute);

        transactionCodeInput.style.display = 'none';
    }
    else
    {
        var attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        eventIdSelect.setAttributeNode(attribute);
        
        eventIdSelect.style.display = 'none';


        attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        fundingSubmissionIdSelect.setAttributeNode(attribute);
        
        fundingSubmissionIdSelect.style.display = 'none';

        document.getElementById('event-funding-submission-detail[' + transactionType.getAttribute("data-transaction-id") + ']').innerHTML = '';


        attribute = transactionCodeInput.getAttributeNode("disabled");

        if(attribute != null)
            transactionCodeInput.removeAttributeNode(attribute);
        
        transactionCodeInput.style.display = 'inline';
        
        document.getElementById('event-funding-submission-detail[' + transactionType.getAttribute("data-transaction-id") + ']').innerHTML = '<select class="form-control" id="unit_id[' + transactionType.getAttribute("data-transaction-id") + ']"></select>';

        if (window.XMLHttpRequest)
        {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        }
        else
        {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        xmlhttp.onreadystatechange = function()
        {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
                document.getElementById('unit_id[' + transactionType.getAttribute("data-transaction-id") + ']').innerHTML = xmlhttp.responseText;
        };
        
        url = document.getElementById("controller-link").value + "opsi_unit";
        
        xmlhttp.open("GET", url, true);
        xmlhttp.send();
    }
}

function setEventFundingSubmissionDetail(eventFundingSubmission, controllerFunction)
{
    document.getElementById('event-funding-submission-detail[' + eventFundingSubmission.getAttribute("data-transaction-id") + ']').innerHTML = '<a href="' + document.getElementById('base-url').value + controllerFunction + eventFundingSubmission.value + '" target="_blank">Detail</a>';
}


function setCreditNominal(nominal)
{
    document.getElementById('credit-nominal-data[' + nominal.getAttribute("data-transaction-id") + ']').innerHTML = nominal.value;
}

function setApprovalRequirement(approvalStatus)
{
    var plannedTransferDateInput = document.getElementById('planned_transfer_date[' + approvalStatus.getAttribute("data-transaction-id") + ']');
    var transferProofLink = document.getElementsByClassName('transfer_proof_link[' + approvalStatus.getAttribute("data-transaction-id") + ']');
    var transferProofInput = document.getElementById('transfer_proof[' + approvalStatus.getAttribute("data-transaction-id") + ']');
    var rejectionReasonInput = document.getElementById('rejection_reason[' + approvalStatus.getAttribute("data-transaction-id") + ']');

    if(approvalStatus.value == 'Unchecked')
    {
        var attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        plannedTransferDateInput.setAttributeNode(attribute);
        
        plannedTransferDateInput.style.display = 'none';


        attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        transferProofInput.setAttributeNode(attribute);

        if(typeof(transferProofLink) != 'undefined' && transferProofLink != null)
        {
            var elementCounter;
            
            for(elementCounter = 0; elementCounter < transferProofLink.length; elementCounter++)
            {
                transferProofLink[elementCounter].style.display = 'none';
            }
        }
        
        transferProofInput.style.display = 'none';


        attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        rejectionReasonInput.setAttributeNode(attribute);

        rejectionReasonInput.style.display = 'none';
    }
    else if(approvalStatus.value == 'Pending')
    {
        var attribute = plannedTransferDateInput.getAttributeNode("disabled");

        if(attribute != null)
            plannedTransferDateInput.removeAttributeNode(attribute);
        
        plannedTransferDateInput.style.display = 'inline';


        attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        transferProofInput.setAttributeNode(attribute);

        if(typeof(transferProofLink) != 'undefined' && transferProofLink != null)
        {
            var elementCounter;
            
            for(elementCounter = 0; elementCounter < transferProofLink.length; elementCounter++)
            {
                transferProofLink[elementCounter].style.display = 'none';
            }
        }
        
        transferProofInput.style.display = 'none';


        attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        rejectionReasonInput.setAttributeNode(attribute);

        rejectionReasonInput.style.display = 'none';
    }
    else if(approvalStatus.value == 'Approved')
    {
        var attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        plannedTransferDateInput.setAttributeNode(attribute);
        
        plannedTransferDateInput.style.display = 'none';


        attribute = transferProofInput.getAttributeNode("disabled");

        if(attribute != null)
            transferProofInput.removeAttributeNode(attribute);

        if(typeof(transferProofLink) != 'undefined' && transferProofLink != null)
        {
            var elementCounter;
            
            for(elementCounter = 0; elementCounter < transferProofLink.length; elementCounter++)
            {
                transferProofLink[elementCounter].style.display = 'block';
            }
        }
        
        transferProofInput.style.display = 'inline';


        attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        rejectionReasonInput.setAttributeNode(attribute);

        rejectionReasonInput.style.display = 'none';
    }
    else
    {
        var attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        plannedTransferDateInput.setAttributeNode(attribute);
        
        plannedTransferDateInput.style.display = 'none';


        attribute = document.createAttribute("disabled");
        
        attribute.value = "disabled";
        
        transferProofInput.setAttributeNode(attribute);

        if(typeof(transferProofLink) != 'undefined' && transferProofLink != null)
        {
            var elementCounter;
            
            for(elementCounter = 0; elementCounter < transferProofLink.length; elementCounter++)
            {
                transferProofLink[elementCounter].style.display = 'none';
            }
        }
        
        transferProofInput.style.display = 'none';


        attribute = rejectionReasonInput.getAttributeNode("disabled");

        if(attribute != null)
            rejectionReasonInput.removeAttributeNode(attribute);
        
        rejectionReasonInput.style.display = 'inline';
    }
}

function saveTransaction(transactionId)
{
    var transactionDate = encodeURIComponent(document.getElementById("transaction_date[" + transactionId + "]").value);
    var transactionType = document.getElementById("transaction_type[" + transactionId + "]").value;
    var nominal = document.getElementById("nominal[" + transactionId + "]").value;
    var approvalStatus = '';

    var parameters = "?transaction_id=" + transactionId;
    parameters = parameters + "&transaction_date=" + transactionDate;
    parameters = parameters + "&transaction_type=" + encodeURIComponent(transactionType);

    if(transactionType == 'IN: Event')
        parameters = parameters + "&event_id=" + document.getElementById("event_id[" + transactionId + "]").value;
    else if(transactionType == 'OUT: Pengajuan')
        parameters = parameters + "&funding_submission_id=" + document.getElementById("funding_submission_id[" + transactionId + "]").value;
    else
    {
        var transactionCode = encodeURIComponent(document.getElementById("transaction_code[" + transactionId + "]").value);
        
        parameters = parameters + "&transaction_code=" + transactionCode;
        parameters = parameters + "&unit_id=" + document.getElementById("unit_id[" + transactionId + "]").value;
    }
    
    parameters = parameters + "&bank=" + encodeURIComponent(document.getElementById("bank[" + transactionId + "]").value);
    parameters = parameters + "&account_number=" + encodeURIComponent(document.getElementById("account_number[" + transactionId + "]").value);
    parameters = parameters + "&accountee=" + encodeURIComponent(document.getElementById("accountee[" + transactionId + "]").value);
    parameters = parameters + "&notes=" + encodeURIComponent(document.getElementById("notes[" + transactionId + "]").value);
    parameters = parameters + "&debt_reference_code=" + encodeURIComponent(document.getElementById("debt_reference_code[" + transactionId + "]").value);
    parameters = parameters + "&credit_reference_code=" + encodeURIComponent(document.getElementById("credit_reference_code[" + transactionId + "]").value);
    parameters = parameters + "&nominal=" + nominal;

    if(transactionId == 0)
        approvalStatus = 'Unchecked';
    else
    {
        approvalStatus = document.getElementById("approval_status[" + transactionId + "]").value;

        if(approvalStatus == 'Pending')
        {
            var approvalRequirement = encodeURIComponent(document.getElementById("planned_transfer_date[" + transactionId + "]").value);
            
            parameters = parameters + "&planned_transfer_date=" + approvalRequirement;
        }
        else if(approvalStatus == 'Rejected')
        {
            var approvalRequirement = encodeURIComponent(document.getElementById("rejection_reason[" + transactionId + "]").value);
            
            parameters = parameters + "&rejection_reason=" + approvalRequirement;
        }
        else
        {
            var i;
            var transferProof = document.getElementById("transfer_proof[" + transactionId + "]");
            var formData = new FormData();
            
            for(i = 0;i < transferProof.files.length;i++)
            {
                formData.append('transfer_proof[]', transferProof.files[i]);
            }

            var approvalRequirement = transferProof.value;
        }
    }
        
    parameters = parameters + "&approval_status=" + approvalStatus;
    
    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            alert('Data transaksi berhasil disimpan!' + xmlhttp.responseText);

            getDynamicContent(1);
        }
    };

    if(transactionDate == '')
        alert('Tanggal transaksi tidak boleh kosong!');
    else if((transactionType == 'IN: Manual' || transactionType == 'OUT: Manual') && transactionCode == '')
        alert('Kode transaksi tidak boleh kosong!');
    else if(nominal == '')
        alert('Nominal kolom debit tidak boleh kosong!');
    else if((approvalStatus == 'Pending' || approvalStatus == 'Rejected') && approvalRequirement == '')
    {
        if(approvalStatus == 'Pending')
            alert('Rencana tanggal transfer tidak boleh kosong!');
        else// if(approvalStatus == 'Rejected')
            alert('Alasan reject tidak boleh kosong!');
        /*else
            alert('Bukti transfer tidak boleh kosong!');*/
    }
    else
    {
        if(approvalStatus == 'Approved' && approvalRequirement != '')
        {
            xmlhttp.open('POST', document.getElementById("controller-link").value + "/simpan_data_transaksi" + parameters, true);
            xmlhttp.send(formData);
        }
        else
        {
            xmlhttp.open("GET", document.getElementById("controller-link").value + "/simpan_data_transaksi" + parameters, true);
            xmlhttp.send();
        }
    }
}

$(document).ready(function(){
    // Format mata uang.
    $( '.currency' ).mask('000.000.000.000.000.000.000.000.000.000', {reverse: true});
})