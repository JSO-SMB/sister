$(document).ready(function() {
    $('.select2-single').select2();
    $('.select2-multiple').select2();
});

function getTableData(pageNumber)
{
    var parameters = pageNumber + "/" + document.getElementById("limit-select").value;
    parameters = parameters + "?name=" + encodeURIComponent(document.getElementById("name-input").value);
    parameters = parameters + "&email_address=" + encodeURIComponent(document.getElementById("email-address-input").value);
    parameters = parameters + "&age=" + document.getElementById("age-input").value;
    parameters = parameters + "&division=" + encodeURIComponent($("#division-select").val());
    parameters = parameters + "&address=" + encodeURIComponent(document.getElementById("address-input").value);
    parameters = parameters + "&last_education=" + encodeURIComponent($("#last-education-select").val());
    parameters = parameters + "&major=" + encodeURIComponent(document.getElementById("major-input").value);
    parameters = parameters + "&expertise=" + encodeURIComponent(document.getElementById("expertise-input").value);
    parameters = parameters + "&user_status=" + encodeURIComponent($("#user-status-select").val());

    if(document.getElementById("order-select") != '')
        parameters = parameters + "&order_by=" + encodeURIComponent(document.getElementById("order-select").value);
    
    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            document.getElementById("table-content").innerHTML = xmlhttp.responseText;

            setPagination(parameters);
        }
    };
    
    xmlhttp.open("GET", document.getElementById("controller-link").value + "/table_data/" + parameters, true);
    xmlhttp.send();
}

setTimeout(getTableData(1), 1);