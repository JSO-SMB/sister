$(document).ready(function() {
    // $('.select2-single').select2();
    $('.select2-multiple').select2();
});