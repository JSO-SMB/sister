function updateSchedule()
{
    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            if(typeof(document.getElementById("division-select")) != 'undefined' && document.getElementById("division-select") != null)
            {
                var slctd = document.getElementById("division-select").selectedIndex;
                var opti = document.getElementById("division-select").options;
                var attr = document.createAttribute("selected");
                attr.value = "selected";
                opti[slctd].setAttributeNode(attr);

                if(document.getElementById("division-div").innerHTML == xmlhttp.responseText)
                {
                    var elmnt = opti[slctd];
                    var attr = elmnt.getAttributeNode("selected");
                    
                    elmnt.removeAttributeNode(attr);
                }
                else
                {
                    document.getElementById("division-div").innerHTML = xmlhttp.responseText;
                    
                    var scrpt = document.createElement("script");
                    var node = document.createTextNode(alert('Terdapat penyesuaian jadwal wawancara untuk satu atau lebih posisi.\nSilakan pastikan posisi & jadwal wawancara yang Anda pilih sudah sesuai.'));
                    scrpt.appendChild(node);
                    var elmnt = document.getElementById("body");
                    elmnt.appendChild(scrpt);
                }   
            }
            else
            {
                document.getElementById("division-div").innerHTML = xmlhttp.responseText;
            }
        }
    };
    
    if(typeof(document.getElementById("division-select")) != 'undefined' && document.getElementById("division-select") != null)
        url = encodeURI(document.getElementById("controller-link").value + "wawancara?division_schedule=" + document.getElementById("division-select").value);
    else
        url = document.getElementById("controller-link").value + "wawancara";

    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

if(document.getElementById("title").value == ':: Sister JSO :: Registrasi Seleksi Calon Karyawan')
{
    setTimeout(updateSchedule, 1);
    setInterval(updateSchedule, 60000);
}

function checkEmailAddress(emailAddressCheckLink, initialEmailAddress, emailAddress)
{
    if(emailAddress != '' && initialEmailAddress != emailAddress)
    {
        if (window.XMLHttpRequest)
        {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        }
        else
        {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        xmlhttp.onreadystatechange = function()
        {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
            {
                if(xmlhttp.responseText == '')
                    document.getElementById("email-help").style.display = "none";
                else if(xmlhttp.responseText == 'Aktif')
                {
                    document.getElementById("email-help").style.color = "red";
                    document.getElementById("email-help").style.display = "inline";
                    
                    document.getElementById("email-input").focus();
                }
                else if(xmlhttp.responseText == 'Calon karyawan')
                {
                    document.getElementById("email-help").style.display = "none";
                    
                    if(confirm('Alamat email Anda tercatat sudah pernah digunakan untuk melakukan registrasi seleksi calon karyawan di perusahaan kami.\n\nApakah Anda ingin sistem memuat data yang pernah Anda isikan? (Tekan "OK" untuk memuat data yang pernah Anda isikan atau tekan "Cancel" jika Anda ingin menggunakan alamat email lain untuk pendaftaran ini)'))
                        location.replace(document.getElementById("controller-link").value + "tambah_ubah/" + encodeURIComponent(emailAddress));
                    else
                    {
                        document.getElementById("email-input").value = '';
                        document.getElementById("email-input").focus();
                    }
                }
            }
        };
        
        xmlhttp.open("GET", emailAddressCheckLink + encodeURIComponent(emailAddress), true);
        xmlhttp.send();
    }
    else
        document.getElementById("email-help").style.display = "none";
}

function validatePassword()
{
    if(document.getElementById("password-input").value != '' || document.getElementById("password-confirmation-input").value != '')
    {
        if(document.getElementById("password-input").value == document.getElementById("password-confirmation-input").value)
            document.getElementById("password-confirmation-help").style.display = "none";
        else
            document.getElementById("password-confirmation-help").style.display = "inline";
    }
    else
        document.getElementById("password-confirmation-help").style.display = "none";
}

function getAge(DOB)
{
    var today = new Date();
    var birthDate = new Date(DOB);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate()))
    {
        age = age - 1;
    }

    document.getElementById("age").value = age;
}

function hideShowMajor(education)
{
    if(education == 'SMP / SEDERAJAT')
    {
        document.getElementById("major-div").style.display = "none";
        
        var elmnt = document.getElementById("major-input");
        var attr = elmnt.getAttributeNode("required");
        
        elmnt.removeAttributeNode(attr);
        elmnt.value = "";
    }
    else
    {
        var elmnt = document.getElementById("major-input");
        var attr = document.createAttribute("required");
        
        attr.value = "required";
        
        elmnt.setAttributeNode(attr);
        
        document.getElementById("major-div").style.display = "inline";
    }
}

function hideShowAddress(singleAddress)
{
    if(singleAddress)
    {
        var elmnt = document.getElementById("city-input");
        var attr = elmnt.getAttributeNode("required");
        
        elmnt.removeAttributeNode(attr);
        elmnt.style.display = "none";

        var elmnt = document.getElementById("address-textarea");
        var attr = elmnt.getAttributeNode("required");
        
        elmnt.removeAttributeNode(attr);

        document.getElementById("address-div").style.display = "none";
    }
    else
    {
        var elmnt = document.getElementById("city-input");
        var attr = document.createAttribute("required");
        
        attr.value = "required";
        
        elmnt.setAttributeNode(attr);
        elmnt.style.display = "inline";

        var elmnt = document.getElementById("address-textarea");
        var attr = document.createAttribute("required");

        attr.value = "required";
        
        elmnt.setAttributeNode(attr);
        
        document.getElementById("address-div").style.display = "inline";
    }
}

function hideShowMate(maritalStatus)
{
    if(maritalStatus == 'Menikah')
    {
        var elmnt = document.getElementById("mate-phone-number-input");
        var attr = document.createAttribute("required");
        
        attr.value = "required";
        
        elmnt.setAttributeNode(attr);

        var elmnt = document.getElementById("mate-name-input");
        var attr = document.createAttribute("required");
        
        attr.value = "required";
        
        elmnt.setAttributeNode(attr);

        var elmnt = document.getElementById("mate-occupation-input");
        var attr = document.createAttribute("required");
        
        attr.value = "required";
        
        elmnt.setAttributeNode(attr);
        
        document.getElementById("mate-phone-number-div").style.display = "block";
        document.getElementById("mate-name-div").style.display = "block";
        document.getElementById("mate-occupation-div").style.display = "block";
    }
    else
    {
        document.getElementById("mate-phone-number-div").style.display = "none";
        document.getElementById("mate-name-div").style.display = "none";
        document.getElementById("mate-occupation-div").style.display = "none";
        
        var elmnt = document.getElementById("mate-phone-number-input");
        var attr = elmnt.getAttributeNode("required");
        
        elmnt.removeAttributeNode(attr);
        elmnt.value = "";
        
        var elmnt = document.getElementById("mate-name-input");
        var attr = elmnt.getAttributeNode("required");
        
        elmnt.removeAttributeNode(attr);
        elmnt.value = "";
        
        var elmnt = document.getElementById("mate-occupation-input");
        var attr = elmnt.getAttributeNode("required");
        
        elmnt.removeAttributeNode(attr);
        elmnt.value = "";
    }
}

$('#user-form').submit(function()
{
    //check whether browser fully supports all File API
    if(window.File && window.FileReader && window.FileList && window.Blob)
    {
        /*get the file size and file type from file input field
        var fsize = $('#user-picture')[0].files[0].size;
        
        if(fsize>2097152) //do something if file size more than 2 mb (2097152)
        {
            alert("File You selected is larger than 2 MB");
            
            return false;
        }*/
        
        //get the file size and file type from file input field
        var ftype = $('#id-card-input')[0].files[0].type;
        
        if(ftype != 'image/jpeg')
        {
            alert('File KTP harus dalam format jpg/jpeg!');
            
            return false;
        }

        var ftype = $('#photo-input')[0].files[0].type;
        
        if(ftype != 'image/jpeg')
        {
            alert('File Foto harus dalam format jpg/jpeg!');
            
            return false;
        }
        
        if(document.getElementById("password-confirmation-help").style.display == "inline")
        {
            alert('Password yang Anda input-kan tidak cocok!');
            
            return false;
        }
    }
    else
    {
        alert("Please upgrade your browser, because your current browser lacks some new features we need!");
    }
});