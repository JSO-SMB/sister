function validateSubmission()
{
    if((document.getElementById("email-address-input").value == '' && document.getElementById("mobile-number-input").value == '') || (document.getElementById("email-marketing-input").checked == false && document.getElementById("whatsapp-marketing-input").checked == false))
    {
        if(document.getElementById("email-address-input").value == '' && document.getElementById("mobile-number-input").value == '')
            alert('Minimal salah satu dari isian "Alamat email" atau "Nomor HP" harus diisi!');
        else
            alert('Channel pemasaran harus dipilih minimal salah satu!');
        
        return false;
    }
}